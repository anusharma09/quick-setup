namespace CCEJobs.PresentationLayer
{
    partial class frmChangeOrder
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmChangeOrder));
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling140 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling141 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling142 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraBars.Ribbon.GalleryItemGroup galleryItemGroup1 = new DevExpress.XtraBars.Ribbon.GalleryItemGroup();
            DevExpress.XtraBars.Ribbon.GalleryItemGroup galleryItemGroup2 = new DevExpress.XtraBars.Ribbon.GalleryItemGroup();
            DevExpress.XtraBars.Ribbon.GalleryItemGroup galleryItemGroup3 = new DevExpress.XtraBars.Ribbon.GalleryItemGroup();
            DevExpress.XtraBars.Ribbon.GalleryItemGroup galleryItemGroup4 = new DevExpress.XtraBars.Ribbon.GalleryItemGroup();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling143 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling144 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling145 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling146 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling147 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling148 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling149 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling150 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling151 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling152 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling153 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling154 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling155 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling156 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling157 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling158 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling159 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling160 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling161 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling162 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling163 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling164 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling165 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling166 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling167 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling168 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling1 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling2 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling3 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling4 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling5 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling6 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling7 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling8 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling9 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling10 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling11 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling12 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling13 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling14 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling15 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling16 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling17 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling18 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling19 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling20 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling21 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling22 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling23 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling24 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling25 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling26 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling27 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling28 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling29 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling30 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling31 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling32 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling33 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling34 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling35 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling36 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling37 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling38 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling39 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling40 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling41 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling42 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling43 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling44 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling45 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling46 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling47 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling48 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling49 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling50 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling51 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling52 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling53 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling54 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling55 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling56 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling57 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling58 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling59 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling60 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling61 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling62 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling63 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling64 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling65 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling66 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling67 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling68 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling69 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling70 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling71 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling72 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling73 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling74 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling75 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling76 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling77 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling78 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling79 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling85 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling86 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling87 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling88 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling89 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling90 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling91 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling92 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling93 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling94 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling95 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling96 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling97 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling98 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling99 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling100 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling101 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling102 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling103 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling104 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling105 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling106 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling107 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling108 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling109 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling110 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling111 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling112 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling113 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling114 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling115 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling116 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling117 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling118 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling119 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling120 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling121 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling122 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling123 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling124 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling125 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling126 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling127 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling128 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling129 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling130 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling131 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling132 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling133 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling134 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling135 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling136 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling137 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling138 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling139 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling84 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling83 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling82 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling81 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling80 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            this.imgCollection = new DevExpress.Utils.ImageCollection();
            this.btnToolInspectionsReport = new DevExpress.XtraBars.BarButtonItem();
            this.btnToolRepairPartsReport = new DevExpress.XtraBars.BarButtonItem();
            this.btnToolComponentsReport = new DevExpress.XtraBars.BarButtonItem();
            this.btnToolAccessoriesReport = new DevExpress.XtraBars.BarButtonItem();
            this.btnProjectInfoSheetReport = new DevExpress.XtraBars.BarButtonItem();
            this.btnToolEventScheduledReport = new DevExpress.XtraBars.BarButtonItem();
            this.btnAccessories = new DevExpress.XtraBars.BarButtonItem();
            this.btnComponents = new DevExpress.XtraBars.BarButtonItem();
            this.btnRepairParts = new DevExpress.XtraBars.BarButtonItem();
            this.btnInspections = new DevExpress.XtraBars.BarButtonItem();
            this.btnGeneral = new DevExpress.XtraBars.BarButtonItem();
            this.ribbonGroup2 = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.btnNew = new DevExpress.XtraBars.BarButtonItem();
            this.btnCopy = new DevExpress.XtraBars.BarButtonItem();
            this.btnSave = new DevExpress.XtraBars.BarButtonItem();
            this.btnUndo = new DevExpress.XtraBars.BarButtonItem();
            this.btnRev = new DevExpress.XtraBars.BarButtonItem();
            this.btnDelete = new DevExpress.XtraBars.BarButtonItem();
            this.ribbonPage1 = new DevExpress.XtraBars.Ribbon.RibbonPage();
            this.ribbonReport = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.barSubItem2 = new DevExpress.XtraBars.BarSubItem();
            this.btnChangeOrderSheet = new DevExpress.XtraBars.BarButtonItem();
            this.btnChangeOrderLetter = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItem3 = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItem4 = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonInspectionTicket = new DevExpress.XtraBars.BarButtonItem();
            this.barSubItemReports = new DevExpress.XtraBars.BarSubItem();
            this.imageCollection1 = new DevExpress.Utils.ImageCollection();
            this.barButtonGroup5 = new DevExpress.XtraBars.BarButtonGroup();
            this.btnTimeCard = new DevExpress.XtraBars.BarButtonItem();
            this.btnCostToComplete = new DevExpress.XtraBars.BarButtonItem();
            this.btnJobProgress = new DevExpress.XtraBars.BarButtonItem();
            this.btnLaborProd = new DevExpress.XtraBars.BarButtonItem();
            this.btnExcelQuantity = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItem2 = new DevExpress.XtraBars.BarButtonItem();
            this.btnDown = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonGroup4 = new DevExpress.XtraBars.BarButtonGroup();
            this.dxErrorProvider = new DevExpress.XtraEditors.DXErrorProvider.DXErrorProvider();
            this.textEdit30 = new DevExpress.XtraEditors.TextEdit();
            this.labelControl66 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl65 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl63 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl61 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl49 = new DevExpress.XtraEditors.LabelControl();
            this.textEdit32 = new DevExpress.XtraEditors.TextEdit();
            this.textEdit31 = new DevExpress.XtraEditors.TextEdit();
            this.labelControl48 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl60 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl59 = new DevExpress.XtraEditors.LabelControl();
            this.btnExcelHours = new DevExpress.XtraBars.BarButtonItem();
            this.btnLaborFeedbackReport = new DevExpress.XtraBars.BarButtonItem();
            this.btnLaborFeedback = new DevExpress.XtraBars.BarButtonItem();
            this.iWeb = new DevExpress.XtraBars.BarButtonItem();
            this.iProtected = new DevExpress.XtraBars.BarButtonItem();
            this.iBullets = new DevExpress.XtraBars.BarButtonItem();
            this.iFont = new DevExpress.XtraBars.BarButtonItem();
            this.btnGeneralOld = new DevExpress.XtraBars.BarButtonItem();
            this.iAbout = new DevExpress.XtraBars.BarButtonItem();
            this.iBold = new DevExpress.XtraBars.BarButtonItem();
            this.iAlignRight = new DevExpress.XtraBars.BarButtonItem();
            this.iCenter = new DevExpress.XtraBars.BarButtonItem();
            this.iAlignLeft = new DevExpress.XtraBars.BarButtonItem();
            this.iUnderline = new DevExpress.XtraBars.BarButtonItem();
            this.iSelectAll = new DevExpress.XtraBars.BarButtonItem();
            this.btnTimeSheet = new DevExpress.XtraBars.BarButtonItem();
            this.btnUp = new DevExpress.XtraBars.BarButtonItem();
            this.imageCollection2 = new DevExpress.Utils.ImageCollection();
            this.ribProjectOpportunity = new DevExpress.XtraBars.Ribbon.RibbonControl();
            this.iSaveAs = new DevExpress.XtraBars.BarButtonItem();
            this.btnCostCodesWeekly = new DevExpress.XtraBars.BarButtonItem();
            this.btnCostCodes = new DevExpress.XtraBars.BarButtonItem();
            this.btnstrategic = new DevExpress.XtraBars.BarButtonItem();
            this.iFontColor = new DevExpress.XtraBars.BarButtonItem();
            this.siPosition = new DevExpress.XtraBars.BarButtonItem();
            this.siModified = new DevExpress.XtraBars.BarButtonItem();
            this.siDocName = new DevExpress.XtraBars.BarStaticItem();
            this.bgFontStyle = new DevExpress.XtraBars.BarButtonGroup();
            this.bgAlign = new DevExpress.XtraBars.BarButtonGroup();
            this.bgFont = new DevExpress.XtraBars.BarButtonGroup();
            this.bgBullets = new DevExpress.XtraBars.BarButtonGroup();
            this.sbiPaste = new DevExpress.XtraBars.BarSubItem();
            this.iPasteSpecial = new DevExpress.XtraBars.BarButtonItem();
            this.iLargeUndo = new DevExpress.XtraBars.BarLargeButtonItem();
            this.iTemplate = new DevExpress.XtraBars.BarButtonItem();
            this.rgbiSkins = new DevExpress.XtraBars.RibbonGalleryBarItem();
            this.beiFontSize = new DevExpress.XtraBars.BarEditItem();
            this.rgbiFont = new DevExpress.XtraBars.RibbonGalleryBarItem();
            this.bbiFontColorPopup = new DevExpress.XtraBars.BarButtonItem();
            this.rgbiFontColor = new DevExpress.XtraBars.RibbonGalleryBarItem();
            this.btnPersonnel = new DevExpress.XtraBars.BarButtonItem();
            this.iGeneral = new DevExpress.XtraBars.BarSubItem();
            this.btnNote = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItem5 = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItem6 = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonGroup1 = new DevExpress.XtraBars.BarButtonGroup();
            this.barButtonGroup2 = new DevExpress.XtraBars.BarButtonGroup();
            this.barButtonGroup3 = new DevExpress.XtraBars.BarButtonGroup();
            this.barLinkContainerItem1 = new DevExpress.XtraBars.BarLinkContainerItem();
            this.barMdiChildrenListItem1 = new DevExpress.XtraBars.BarMdiChildrenListItem();
            this.barButtonItem1 = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonGroup6 = new DevExpress.XtraBars.BarButtonGroup();
            this.barButtonGroup7 = new DevExpress.XtraBars.BarButtonGroup();
            this.barButtonGroup8 = new DevExpress.XtraBars.BarButtonGroup();
            this.barSubItem1 = new DevExpress.XtraBars.BarSubItem();
            this.labelControl68 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl99 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl98 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl100 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl97 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl101 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl102 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl104 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl96 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl103 = new DevExpress.XtraEditors.LabelControl();
            this.textEdit78 = new DevExpress.XtraEditors.TextEdit();
            this.textEdit77 = new DevExpress.XtraEditors.TextEdit();
            this.textEdit76 = new DevExpress.XtraEditors.TextEdit();
            this.labelControl78 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl77 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl75 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl79 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl74 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl70 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl69 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl72 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl95 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl94 = new DevExpress.XtraEditors.LabelControl();
            this.textEdit68 = new DevExpress.XtraEditors.TextEdit();
            this.labelControl93 = new DevExpress.XtraEditors.LabelControl();
            this.textEdit67 = new DevExpress.XtraEditors.TextEdit();
            this.textEdit69 = new DevExpress.XtraEditors.TextEdit();
            this.textEdit70 = new DevExpress.XtraEditors.TextEdit();
            this.textEdit75 = new DevExpress.XtraEditors.TextEdit();
            this.textEdit74 = new DevExpress.XtraEditors.TextEdit();
            this.textEdit73 = new DevExpress.XtraEditors.TextEdit();
            this.textEdit72 = new DevExpress.XtraEditors.TextEdit();
            this.textEdit71 = new DevExpress.XtraEditors.TextEdit();
            this.labelControl92 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl91 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl84 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl83 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl81 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl86 = new DevExpress.XtraEditors.LabelControl();
            this.lookUpEdit3 = new DevExpress.XtraEditors.LookUpEdit();
            this.labelControl90 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl89 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl88 = new DevExpress.XtraEditors.LabelControl();
            this.textEdit66 = new DevExpress.XtraEditors.TextEdit();
            this.labelControl30 = new DevExpress.XtraEditors.LabelControl();
            this.radioGroup1 = new DevExpress.XtraEditors.RadioGroup();
            this.labelControl31 = new DevExpress.XtraEditors.LabelControl();
            this.panelControl4 = new DevExpress.XtraEditors.PanelControl();
            this.textEdit4 = new DevExpress.XtraEditors.TextEdit();
            this.labelControl32 = new DevExpress.XtraEditors.LabelControl();
            this.textEdit5 = new DevExpress.XtraEditors.TextEdit();
            this.textEdit6 = new DevExpress.XtraEditors.TextEdit();
            this.labelControl33 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl34 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl35 = new DevExpress.XtraEditors.LabelControl();
            this.textEdit7 = new DevExpress.XtraEditors.TextEdit();
            this.memoEdit1 = new DevExpress.XtraEditors.MemoEdit();
            this.labelControl36 = new DevExpress.XtraEditors.LabelControl();
            this.panelControl6 = new DevExpress.XtraEditors.PanelControl();
            this.dateEdit1 = new DevExpress.XtraEditors.DateEdit();
            this.lookUpEdit1 = new DevExpress.XtraEditors.LookUpEdit();
            this.labelControl38 = new DevExpress.XtraEditors.LabelControl();
            this.lookUpEdit2 = new DevExpress.XtraEditors.LookUpEdit();
            this.lookUpEdit4 = new DevExpress.XtraEditors.LookUpEdit();
            this.lookUpEdit5 = new DevExpress.XtraEditors.LookUpEdit();
            this.textEdit8 = new DevExpress.XtraEditors.TextEdit();
            this.textEdit9 = new DevExpress.XtraEditors.TextEdit();
            this.dateEdit2 = new DevExpress.XtraEditors.DateEdit();
            this.comboBoxEdit1 = new DevExpress.XtraEditors.ComboBoxEdit();
            this.labelControl39 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl40 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl41 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl42 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl43 = new DevExpress.XtraEditors.LabelControl();
            this.lookUpEdit6 = new DevExpress.XtraEditors.LookUpEdit();
            this.dateEdit3 = new DevExpress.XtraEditors.DateEdit();
            this.labelControl44 = new DevExpress.XtraEditors.LabelControl();
            this.dateEdit4 = new DevExpress.XtraEditors.DateEdit();
            this.textEdit10 = new DevExpress.XtraEditors.TextEdit();
            this.textEdit11 = new DevExpress.XtraEditors.TextEdit();
            this.labelControl45 = new DevExpress.XtraEditors.LabelControl();
            this.textEdit12 = new DevExpress.XtraEditors.TextEdit();
            this.textEdit13 = new DevExpress.XtraEditors.TextEdit();
            this.labelControl46 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl47 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl52 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl55 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl57 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl58 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl105 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl106 = new DevExpress.XtraEditors.LabelControl();
            this.panelControl7 = new DevExpress.XtraEditors.PanelControl();
            this.dateEdit5 = new DevExpress.XtraEditors.DateEdit();
            this.dateEdit6 = new DevExpress.XtraEditors.DateEdit();
            this.textEdit14 = new DevExpress.XtraEditors.TextEdit();
            this.textEdit15 = new DevExpress.XtraEditors.TextEdit();
            this.labelControl107 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl108 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl109 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl110 = new DevExpress.XtraEditors.LabelControl();
            this.splitContainerControl1 = new DevExpress.XtraEditors.SplitContainerControl();
            this.xtraTabControl1 = new DevExpress.XtraTab.XtraTabControl();
            this.xtraTabPage4 = new DevExpress.XtraTab.XtraTabPage();
            this.panelControl14 = new DevExpress.XtraEditors.PanelControl();
            this.txtRecordID = new DevExpress.XtraEditors.TextEdit();
            this.txtJobChangeOrderApprovedAmount = new DevExpress.XtraEditors.TextEdit();
            this.txtJobChangeOrderApprovedDate = new DevExpress.XtraEditors.DateEdit();
            this.txtJobChangeOrderRequestedAmount = new DevExpress.XtraEditors.TextEdit();
            this.txtJobChangeOrderRequestDate = new DevExpress.XtraEditors.DateEdit();
            this.txtPriceAdjustment = new DevExpress.XtraEditors.TextEdit();
            this.txtChangeOrderAmount = new DevExpress.XtraEditors.TextEdit();
            this.cboJobChangeOrderStatus = new DevExpress.XtraEditors.ComboBoxEdit();
            this.txtJobChangeOrderOwnerNumber = new DevExpress.XtraEditors.TextEdit();
            this.txtJobChangeOrderCCENumber = new DevExpress.XtraEditors.TextEdit();
            this.txtJobChangeOrderUserDescription = new DevExpress.XtraEditors.TextEdit();
            this.cboJobChangeOrderDescription = new DevExpress.XtraEditors.ComboBoxEdit();
            this.txtJobChangeOrderNumber = new DevExpress.XtraEditors.TextEdit();
            this.labelControl144 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl143 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl142 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl141 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl140 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl139 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl138 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl137 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl82 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl80 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl76 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl73 = new DevExpress.XtraEditors.LabelControl();
            this.panelControl8 = new DevExpress.XtraEditors.PanelControl();
            this.labelControl64 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl62 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl56 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl1 = new DevExpress.XtraEditors.LabelControl();
            this.txtProfitPercentBudgetTotals = new DevExpress.XtraEditors.TextEdit();
            this.txtProfitDollarBudgetTotals = new DevExpress.XtraEditors.TextEdit();
            this.labelControl53 = new DevExpress.XtraEditors.LabelControl();
            this.txtProfitPercentEstimateDefaults = new DevExpress.XtraEditors.TextEdit();
            this.txtProfitDollarEstimateDefaults = new DevExpress.XtraEditors.TextEdit();
            this.labelControl54 = new DevExpress.XtraEditors.LabelControl();
            this.txtSubcontractsBudgetTotals = new DevExpress.XtraEditors.TextEdit();
            this.txtContractDollarBudgetTotals = new DevExpress.XtraEditors.TextEdit();
            this.txtTotalCostBudgetTotals = new DevExpress.XtraEditors.TextEdit();
            this.txtOtherBudgetTotals = new DevExpress.XtraEditors.TextEdit();
            this.txtMaterialsBudgetTotals = new DevExpress.XtraEditors.TextEdit();
            this.txtLaborRateBudgetTotals = new DevExpress.XtraEditors.TextEdit();
            this.txtLaborDollarBudgetTotals = new DevExpress.XtraEditors.TextEdit();
            this.txtLaborHoursBudgetTotals = new DevExpress.XtraEditors.TextEdit();
            this.labelControl2 = new DevExpress.XtraEditors.LabelControl();
            this.txtSubcontractsEstimateDefaults = new DevExpress.XtraEditors.TextEdit();
            this.labelControl26 = new DevExpress.XtraEditors.LabelControl();
            this.txtContractDollarEstimateDefaults = new DevExpress.XtraEditors.TextEdit();
            this.txtTotalCostEstimateDefaults = new DevExpress.XtraEditors.TextEdit();
            this.labelControl27 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl28 = new DevExpress.XtraEditors.LabelControl();
            this.txtOtherEstimateDefaults = new DevExpress.XtraEditors.TextEdit();
            this.labelControl29 = new DevExpress.XtraEditors.LabelControl();
            this.txtMaterialsEstimateDefaults = new DevExpress.XtraEditors.TextEdit();
            this.txtLaborRateEstimateDefaults = new DevExpress.XtraEditors.TextEdit();
            this.labelControl37 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl50 = new DevExpress.XtraEditors.LabelControl();
            this.txtLaborDollarEstimateDefaults = new DevExpress.XtraEditors.TextEdit();
            this.txtLaborHoursEstimateDefaults = new DevExpress.XtraEditors.TextEdit();
            this.labelControl51 = new DevExpress.XtraEditors.LabelControl();
            this.xtraTabPage1 = new DevExpress.XtraTab.XtraTabPage();
            this.labelControl67 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl71 = new DevExpress.XtraEditors.LabelControl();
            this.panelControl9 = new DevExpress.XtraEditors.PanelControl();
            this.txtSubcontractsAmount = new DevExpress.XtraEditors.TextEdit();
            this.labelControl85 = new DevExpress.XtraEditors.LabelControl();
            this.panelControl10 = new DevExpress.XtraEditors.PanelControl();
            this.txtEstimatedBIMHoursDT = new DevExpress.XtraEditors.TextEdit();
            this.txtEstimatedBIMHoursOT = new DevExpress.XtraEditors.TextEdit();
            this.labelControl168 = new DevExpress.XtraEditors.LabelControl();
            this.txtEstimatedBIMHours = new DevExpress.XtraEditors.TextEdit();
            this.labelControl161 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl162 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl163 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl131 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl134 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl160 = new DevExpress.XtraEditors.LabelControl();
            this.txtPremiumHoursActualHoursDT = new DevExpress.XtraEditors.TextEdit();
            this.txtProjectEngineerActualHoursDT = new DevExpress.XtraEditors.TextEdit();
            this.txtProjectManagerActualHoursDT = new DevExpress.XtraEditors.TextEdit();
            this.txtSuperintendentActualHoursDT = new DevExpress.XtraEditors.TextEdit();
            this.txtGeneralForemanActualHoursDT = new DevExpress.XtraEditors.TextEdit();
            this.txtForemanActualHoursDT = new DevExpress.XtraEditors.TextEdit();
            this.txtPremiumHoursActualHoursOT = new DevExpress.XtraEditors.TextEdit();
            this.txtProjectEngineerActualHoursOT = new DevExpress.XtraEditors.TextEdit();
            this.txtProjectManagerActualHoursOT = new DevExpress.XtraEditors.TextEdit();
            this.txtSuperintendentActualHoursOT = new DevExpress.XtraEditors.TextEdit();
            this.txtGeneralForemanActualHoursOT = new DevExpress.XtraEditors.TextEdit();
            this.txtForemanActualHoursOT = new DevExpress.XtraEditors.TextEdit();
            this.txtProjectEngineerDefaultHoursDT = new DevExpress.XtraEditors.TextEdit();
            this.txtProjectManagerDefaultHoursDT = new DevExpress.XtraEditors.TextEdit();
            this.txtSuperintendentDefaultHoursDT = new DevExpress.XtraEditors.TextEdit();
            this.txtGeneralForemanDefaultHoursDT = new DevExpress.XtraEditors.TextEdit();
            this.txtForemanDefaultHoursDT = new DevExpress.XtraEditors.TextEdit();
            this.txtProjectEngineerDefaultHoursOT = new DevExpress.XtraEditors.TextEdit();
            this.txtProjectManagerDefaultHoursOT = new DevExpress.XtraEditors.TextEdit();
            this.txtSuperintendentDefaultHoursOT = new DevExpress.XtraEditors.TextEdit();
            this.txtGeneralForemanDefaultHoursOT = new DevExpress.XtraEditors.TextEdit();
            this.txtForemanDefaultHoursOT = new DevExpress.XtraEditors.TextEdit();
            this.labelControl157 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl158 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl159 = new DevExpress.XtraEditors.LabelControl();
            this.txtEstimatedApprenticeHoursDT = new DevExpress.XtraEditors.TextEdit();
            this.txtEstimatedElectricianHoursDT = new DevExpress.XtraEditors.TextEdit();
            this.txtEstimatedApprenticeHoursOT = new DevExpress.XtraEditors.TextEdit();
            this.txtEstimatedElectricianHoursOT = new DevExpress.XtraEditors.TextEdit();
            this.labelControl153 = new DevExpress.XtraEditors.LabelControl();
            this.txtEstimatedApprenticeHours = new DevExpress.XtraEditors.TextEdit();
            this.labelControl145 = new DevExpress.XtraEditors.LabelControl();
            this.txtPremiumHoursActualHours = new DevExpress.XtraEditors.TextEdit();
            this.labelControl135 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl111 = new DevExpress.XtraEditors.LabelControl();
            this.txtProjectEngineerDefaultHours = new DevExpress.XtraEditors.TextEdit();
            this.txtProjectManagerDefaultHours = new DevExpress.XtraEditors.TextEdit();
            this.txtSuperintendentDefaultHours = new DevExpress.XtraEditors.TextEdit();
            this.txtGeneralForemanDefaultHours = new DevExpress.XtraEditors.TextEdit();
            this.txtForemanDefaultHours = new DevExpress.XtraEditors.TextEdit();
            this.txtEstimatedElectricianHours = new DevExpress.XtraEditors.TextEdit();
            this.labelControl87 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl121 = new DevExpress.XtraEditors.LabelControl();
            this.txtProjectEngineerActualHours = new DevExpress.XtraEditors.TextEdit();
            this.labelControl122 = new DevExpress.XtraEditors.LabelControl();
            this.txtProjectManagerActualHours = new DevExpress.XtraEditors.TextEdit();
            this.txtSuperintendentActualHours = new DevExpress.XtraEditors.TextEdit();
            this.labelControl123 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl124 = new DevExpress.XtraEditors.LabelControl();
            this.txtGeneralForemanActualHours = new DevExpress.XtraEditors.TextEdit();
            this.txtForemanActualHours = new DevExpress.XtraEditors.TextEdit();
            this.labelControl125 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl126 = new DevExpress.XtraEditors.LabelControl();
            this.panelControl11 = new DevExpress.XtraEditors.PanelControl();
            this.labelControl136 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl127 = new DevExpress.XtraEditors.LabelControl();
            this.txtOtherExpenses3Description = new DevExpress.XtraEditors.TextEdit();
            this.txtOtherExpenses2Description = new DevExpress.XtraEditors.TextEdit();
            this.txtOtherExpenses1Description = new DevExpress.XtraEditors.TextEdit();
            this.txtOtherExpenses3 = new DevExpress.XtraEditors.TextEdit();
            this.labelControl128 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl129 = new DevExpress.XtraEditors.LabelControl();
            this.txtOtherExpenses2 = new DevExpress.XtraEditors.TextEdit();
            this.txtOtherExpenses1 = new DevExpress.XtraEditors.TextEdit();
            this.labelControl130 = new DevExpress.XtraEditors.LabelControl();
            this.panelControl13 = new DevExpress.XtraEditors.PanelControl();
            this.txtDirectMaterials = new DevExpress.XtraEditors.TextEdit();
            this.labelControl132 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl133 = new DevExpress.XtraEditors.LabelControl();
            this.xtraTabPage2 = new DevExpress.XtraTab.XtraTabPage();
            this.labelControl23 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl22 = new DevExpress.XtraEditors.LabelControl();
            this.panelControl5 = new DevExpress.XtraEditors.PanelControl();
            this.txtBondPercent = new DevExpress.XtraEditors.TextEdit();
            this.txtWarrantyPercent = new DevExpress.XtraEditors.TextEdit();
            this.txtSubcontractAdministrationPercent = new DevExpress.XtraEditors.TextEdit();
            this.txtProfitPercent = new DevExpress.XtraEditors.TextEdit();
            this.txtOverheadPercent = new DevExpress.XtraEditors.TextEdit();
            this.panelControl3 = new DevExpress.XtraEditors.PanelControl();
            this.labelControl15 = new DevExpress.XtraEditors.LabelControl();
            this.txtFringeBenefitsPercent = new DevExpress.XtraEditors.TextEdit();
            this.txtSafetyMeetingPercent = new DevExpress.XtraEditors.TextEdit();
            this.labelControl16 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl17 = new DevExpress.XtraEditors.LabelControl();
            this.txtProjectEngineerPercentOfLabor = new DevExpress.XtraEditors.TextEdit();
            this.labelControl11 = new DevExpress.XtraEditors.LabelControl();
            this.txtProjectManagerPercentOfLabor = new DevExpress.XtraEditors.TextEdit();
            this.txtSuperintendentPercentOfLabor = new DevExpress.XtraEditors.TextEdit();
            this.labelControl12 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl13 = new DevExpress.XtraEditors.LabelControl();
            this.txtGeneralForemanPercentOfLabor = new DevExpress.XtraEditors.TextEdit();
            this.txtForemanPercentOfLabor = new DevExpress.XtraEditors.TextEdit();
            this.labelControl14 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl10 = new DevExpress.XtraEditors.LabelControl();
            this.panelControl2 = new DevExpress.XtraEditors.PanelControl();
            this.txtCartigeHandlingPercentText = new DevExpress.XtraEditors.TextEdit();
            this.txtAsBuiltsEngineeringPercentText = new DevExpress.XtraEditors.TextEdit();
            this.txtCartigeHandlingPercent = new DevExpress.XtraEditors.TextEdit();
            this.txtSmallToolsPercentText = new DevExpress.XtraEditors.TextEdit();
            this.txtSmallToolsPercent = new DevExpress.XtraEditors.TextEdit();
            this.txtStoragePercentText = new DevExpress.XtraEditors.TextEdit();
            this.txtStoragePercent = new DevExpress.XtraEditors.TextEdit();
            this.txtAsBuiltsEngineeringPercent = new DevExpress.XtraEditors.TextEdit();
            this.panelControl1 = new DevExpress.XtraEditors.PanelControl();
            this.labelControl5 = new DevExpress.XtraEditors.LabelControl();
            this.txtSalesTaxPercent = new DevExpress.XtraEditors.TextEdit();
            this.txtSundriesPercentOfMaterial = new DevExpress.XtraEditors.TextEdit();
            this.labelControl4 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl25 = new DevExpress.XtraEditors.LabelControl();
            this.xtraTabPage3 = new DevExpress.XtraTab.XtraTabPage();
            this.labelControl112 = new DevExpress.XtraEditors.LabelControl();
            this.panelControl12 = new DevExpress.XtraEditors.PanelControl();
            this.txtBIMRateDT = new DevExpress.XtraEditors.TextEdit();
            this.txtBIMRateOT = new DevExpress.XtraEditors.TextEdit();
            this.labelControl167 = new DevExpress.XtraEditors.LabelControl();
            this.txtBIMRate = new DevExpress.XtraEditors.TextEdit();
            this.labelControl154 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl155 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl156 = new DevExpress.XtraEditors.LabelControl();
            this.txtApprenticeLaborRateDT = new DevExpress.XtraEditors.TextEdit();
            this.txtProjectEngineerLaborRateDT = new DevExpress.XtraEditors.TextEdit();
            this.txtPremiumTimeLaborRateDT = new DevExpress.XtraEditors.TextEdit();
            this.txtSafetyMeetingsLaborRateDT = new DevExpress.XtraEditors.TextEdit();
            this.txtProjectManagerLaborRateDT = new DevExpress.XtraEditors.TextEdit();
            this.txtSuperintendentLaborRateDT = new DevExpress.XtraEditors.TextEdit();
            this.txtGeneralForemanLaborRateDT = new DevExpress.XtraEditors.TextEdit();
            this.txtForemanLaborRateDT = new DevExpress.XtraEditors.TextEdit();
            this.txtElectricianLaborRateDT = new DevExpress.XtraEditors.TextEdit();
            this.txtApprenticeLaborRateOT = new DevExpress.XtraEditors.TextEdit();
            this.txtProjectEngineerLaborRateOT = new DevExpress.XtraEditors.TextEdit();
            this.txtPremiumTimeLaborRateOT = new DevExpress.XtraEditors.TextEdit();
            this.txtSafetyMeetingsLaborRateOT = new DevExpress.XtraEditors.TextEdit();
            this.txtProjectManagerLaborRateOT = new DevExpress.XtraEditors.TextEdit();
            this.txtSuperintendentLaborRateOT = new DevExpress.XtraEditors.TextEdit();
            this.txtGeneralForemanLaborRateOT = new DevExpress.XtraEditors.TextEdit();
            this.txtForemanLaborRateOT = new DevExpress.XtraEditors.TextEdit();
            this.txtElectricianLaborRateOT = new DevExpress.XtraEditors.TextEdit();
            this.labelControl152 = new DevExpress.XtraEditors.LabelControl();
            this.txtApprenticeLaborRate = new DevExpress.XtraEditors.TextEdit();
            this.labelControl120 = new DevExpress.XtraEditors.LabelControl();
            this.txtProjectEngineerLaborRate = new DevExpress.XtraEditors.TextEdit();
            this.labelControl113 = new DevExpress.XtraEditors.LabelControl();
            this.txtPremiumTimeLaborRate = new DevExpress.XtraEditors.TextEdit();
            this.txtSafetyMeetingsLaborRate = new DevExpress.XtraEditors.TextEdit();
            this.labelControl114 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl115 = new DevExpress.XtraEditors.LabelControl();
            this.txtProjectManagerLaborRate = new DevExpress.XtraEditors.TextEdit();
            this.labelControl116 = new DevExpress.XtraEditors.LabelControl();
            this.txtSuperintendentLaborRate = new DevExpress.XtraEditors.TextEdit();
            this.txtGeneralForemanLaborRate = new DevExpress.XtraEditors.TextEdit();
            this.labelControl117 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl118 = new DevExpress.XtraEditors.LabelControl();
            this.txtForemanLaborRate = new DevExpress.XtraEditors.TextEdit();
            this.txtElectricianLaborRate = new DevExpress.XtraEditors.TextEdit();
            this.labelControl119 = new DevExpress.XtraEditors.LabelControl();
            this.xtraTabPage5 = new DevExpress.XtraTab.XtraTabPage();
            this.txtLetterExclusion = new ControlsLibrary.RichBoxEditor();
            this.txtLetterWorkDescription = new ControlsLibrary.RichBoxEditor();
            this.txtCompany = new DevExpress.XtraEditors.TextEdit();
            this.labelControl151 = new DevExpress.XtraEditors.LabelControl();
            this.txtFrom = new DevExpress.XtraEditors.TextEdit();
            this.labelControl149 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl150 = new DevExpress.XtraEditors.LabelControl();
            this.cboContact = new DevExpress.XtraEditors.LookUpEdit();
            this.txtLetterTimeExtension = new DevExpress.XtraEditors.TextEdit();
            this.labelControl148 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl147 = new DevExpress.XtraEditors.HyperlinkLabelControl();
            this.labelControl146 = new DevExpress.XtraEditors.HyperlinkLabelControl();
            this.grdCostCode = new DevExpress.XtraGrid.GridControl();
            this.gridView1 = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.chkSelectedItem = new DevExpress.XtraEditors.Repository.RepositoryItemCheckEdit();
            this.txtUserDescription = new DevExpress.XtraEditors.Repository.RepositoryItemMemoExEdit();
            this.txtMaterialCost = new DevExpress.XtraEditors.Repository.RepositoryItemTextEdit();
            this.txtLaborCost = new DevExpress.XtraEditors.Repository.RepositoryItemTextEdit();
            this.txtOtherCost = new DevExpress.XtraEditors.Repository.RepositoryItemTextEdit();
            this.txtQuantity = new DevExpress.XtraEditors.Repository.RepositoryItemTextEdit();
            this.txtHours = new DevExpress.XtraEditors.Repository.RepositoryItemTextEdit();
            this.cboUnit = new DevExpress.XtraEditors.Repository.RepositoryItemComboBox();
            this.txtUserDescription1 = new DevExpress.XtraEditors.Repository.RepositoryItemTextEdit();
            this.panCostCodes = new DevExpress.XtraEditors.PanelControl();
            this.btnSaveCostCodes = new DevExpress.XtraEditors.SimpleButton();
            this.btnProcess = new DevExpress.XtraEditors.SimpleButton();
            this.labelControl18 = new DevExpress.XtraEditors.LabelControl();
            this.cboPhase = new DevExpress.XtraEditors.LookUpEdit();
            this.chkSelected = new DevExpress.XtraEditors.CheckEdit();
            this.spellChecker1 = new DevExpress.XtraSpellChecker.SpellChecker();
            this.comboBoxEdit2 = new DevExpress.XtraEditors.ComboBoxEdit();
            this.labelControl164 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl165 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl166 = new DevExpress.XtraEditors.LabelControl();
            this.cboRevision = new DevExpress.XtraEditors.ComboBoxEdit();
            this.txtOverheadPercentText = new DevExpress.XtraEditors.TextEdit();
            this.txtProfitPercentText = new DevExpress.XtraEditors.TextEdit();
            this.txtSubcontractAdministrationPercentText = new DevExpress.XtraEditors.TextEdit();
            this.txtWarrantyPercentText = new DevExpress.XtraEditors.TextEdit();
            this.txtBondPercentText = new DevExpress.XtraEditors.TextEdit();
            ((System.ComponentModel.ISupportInitialize)(this.imgCollection)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.imageCollection1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dxErrorProvider)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.textEdit30.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.textEdit32.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.textEdit31.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.imageCollection2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ribProjectOpportunity)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.textEdit78.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.textEdit77.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.textEdit76.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.textEdit68.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.textEdit67.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.textEdit69.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.textEdit70.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.textEdit75.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.textEdit74.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.textEdit73.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.textEdit72.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.textEdit71.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lookUpEdit3.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.textEdit66.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radioGroup1.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.panelControl4)).BeginInit();
            this.panelControl4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.textEdit4.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.textEdit5.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.textEdit6.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.textEdit7.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.memoEdit1.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.panelControl6)).BeginInit();
            this.panelControl6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dateEdit1.Properties.CalendarTimeProperties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dateEdit1.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lookUpEdit1.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lookUpEdit2.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lookUpEdit4.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lookUpEdit5.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.textEdit8.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.textEdit9.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dateEdit2.Properties.CalendarTimeProperties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dateEdit2.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.comboBoxEdit1.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lookUpEdit6.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dateEdit3.Properties.CalendarTimeProperties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dateEdit3.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dateEdit4.Properties.CalendarTimeProperties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dateEdit4.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.textEdit10.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.textEdit11.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.textEdit12.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.textEdit13.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.panelControl7)).BeginInit();
            this.panelControl7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dateEdit5.Properties.CalendarTimeProperties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dateEdit5.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dateEdit6.Properties.CalendarTimeProperties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dateEdit6.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.textEdit14.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.textEdit15.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainerControl1)).BeginInit();
            this.splitContainerControl1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.xtraTabControl1)).BeginInit();
            this.xtraTabControl1.SuspendLayout();
            this.xtraTabPage4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.panelControl14)).BeginInit();
            this.panelControl14.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtRecordID.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtJobChangeOrderApprovedAmount.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtJobChangeOrderApprovedDate.Properties.CalendarTimeProperties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtJobChangeOrderApprovedDate.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtJobChangeOrderRequestedAmount.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtJobChangeOrderRequestDate.Properties.CalendarTimeProperties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtJobChangeOrderRequestDate.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtPriceAdjustment.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtChangeOrderAmount.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cboJobChangeOrderStatus.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtJobChangeOrderOwnerNumber.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtJobChangeOrderCCENumber.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtJobChangeOrderUserDescription.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cboJobChangeOrderDescription.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtJobChangeOrderNumber.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.panelControl8)).BeginInit();
            this.panelControl8.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtProfitPercentBudgetTotals.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtProfitDollarBudgetTotals.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtProfitPercentEstimateDefaults.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtProfitDollarEstimateDefaults.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtSubcontractsBudgetTotals.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtContractDollarBudgetTotals.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtTotalCostBudgetTotals.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtOtherBudgetTotals.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtMaterialsBudgetTotals.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtLaborRateBudgetTotals.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtLaborDollarBudgetTotals.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtLaborHoursBudgetTotals.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtSubcontractsEstimateDefaults.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtContractDollarEstimateDefaults.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtTotalCostEstimateDefaults.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtOtherEstimateDefaults.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtMaterialsEstimateDefaults.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtLaborRateEstimateDefaults.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtLaborDollarEstimateDefaults.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtLaborHoursEstimateDefaults.Properties)).BeginInit();
            this.xtraTabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.panelControl9)).BeginInit();
            this.panelControl9.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtSubcontractsAmount.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.panelControl10)).BeginInit();
            this.panelControl10.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtEstimatedBIMHoursDT.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtEstimatedBIMHoursOT.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtEstimatedBIMHours.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtPremiumHoursActualHoursDT.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtProjectEngineerActualHoursDT.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtProjectManagerActualHoursDT.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtSuperintendentActualHoursDT.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtGeneralForemanActualHoursDT.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtForemanActualHoursDT.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtPremiumHoursActualHoursOT.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtProjectEngineerActualHoursOT.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtProjectManagerActualHoursOT.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtSuperintendentActualHoursOT.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtGeneralForemanActualHoursOT.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtForemanActualHoursOT.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtProjectEngineerDefaultHoursDT.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtProjectManagerDefaultHoursDT.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtSuperintendentDefaultHoursDT.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtGeneralForemanDefaultHoursDT.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtForemanDefaultHoursDT.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtProjectEngineerDefaultHoursOT.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtProjectManagerDefaultHoursOT.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtSuperintendentDefaultHoursOT.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtGeneralForemanDefaultHoursOT.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtForemanDefaultHoursOT.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtEstimatedApprenticeHoursDT.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtEstimatedElectricianHoursDT.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtEstimatedApprenticeHoursOT.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtEstimatedElectricianHoursOT.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtEstimatedApprenticeHours.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtPremiumHoursActualHours.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtProjectEngineerDefaultHours.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtProjectManagerDefaultHours.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtSuperintendentDefaultHours.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtGeneralForemanDefaultHours.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtForemanDefaultHours.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtEstimatedElectricianHours.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtProjectEngineerActualHours.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtProjectManagerActualHours.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtSuperintendentActualHours.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtGeneralForemanActualHours.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtForemanActualHours.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.panelControl11)).BeginInit();
            this.panelControl11.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtOtherExpenses3Description.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtOtherExpenses2Description.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtOtherExpenses1Description.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtOtherExpenses3.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtOtherExpenses2.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtOtherExpenses1.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.panelControl13)).BeginInit();
            this.panelControl13.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtDirectMaterials.Properties)).BeginInit();
            this.xtraTabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.panelControl5)).BeginInit();
            this.panelControl5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtBondPercent.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtWarrantyPercent.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtSubcontractAdministrationPercent.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtProfitPercent.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtOverheadPercent.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.panelControl3)).BeginInit();
            this.panelControl3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtFringeBenefitsPercent.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtSafetyMeetingPercent.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtProjectEngineerPercentOfLabor.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtProjectManagerPercentOfLabor.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtSuperintendentPercentOfLabor.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtGeneralForemanPercentOfLabor.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtForemanPercentOfLabor.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.panelControl2)).BeginInit();
            this.panelControl2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtCartigeHandlingPercentText.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtAsBuiltsEngineeringPercentText.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtCartigeHandlingPercent.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtSmallToolsPercentText.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtSmallToolsPercent.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtStoragePercentText.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtStoragePercent.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtAsBuiltsEngineeringPercent.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.panelControl1)).BeginInit();
            this.panelControl1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtSalesTaxPercent.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtSundriesPercentOfMaterial.Properties)).BeginInit();
            this.xtraTabPage3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.panelControl12)).BeginInit();
            this.panelControl12.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtBIMRateDT.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtBIMRateOT.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtBIMRate.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtApprenticeLaborRateDT.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtProjectEngineerLaborRateDT.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtPremiumTimeLaborRateDT.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtSafetyMeetingsLaborRateDT.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtProjectManagerLaborRateDT.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtSuperintendentLaborRateDT.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtGeneralForemanLaborRateDT.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtForemanLaborRateDT.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtElectricianLaborRateDT.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtApprenticeLaborRateOT.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtProjectEngineerLaborRateOT.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtPremiumTimeLaborRateOT.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtSafetyMeetingsLaborRateOT.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtProjectManagerLaborRateOT.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtSuperintendentLaborRateOT.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtGeneralForemanLaborRateOT.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtForemanLaborRateOT.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtElectricianLaborRateOT.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtApprenticeLaborRate.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtProjectEngineerLaborRate.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtPremiumTimeLaborRate.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtSafetyMeetingsLaborRate.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtProjectManagerLaborRate.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtSuperintendentLaborRate.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtGeneralForemanLaborRate.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtForemanLaborRate.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtElectricianLaborRate.Properties)).BeginInit();
            this.xtraTabPage5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtCompany.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtFrom.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cboContact.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtLetterTimeExtension.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.grdCostCode)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkSelectedItem)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtUserDescription)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtMaterialCost)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtLaborCost)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtOtherCost)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtQuantity)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtHours)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cboUnit)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtUserDescription1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.panCostCodes)).BeginInit();
            this.panCostCodes.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.cboPhase.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkSelected.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.comboBoxEdit2.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cboRevision.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtOverheadPercentText.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtProfitPercentText.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtSubcontractAdministrationPercentText.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtWarrantyPercentText.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtBondPercentText.Properties)).BeginInit();
            this.SuspendLayout();
            // 
            // imgCollection
            // 
            this.imgCollection.ImageStream = ((DevExpress.Utils.ImageCollectionStreamer)(resources.GetObject("imgCollection.ImageStream")));
            // 
            // btnToolInspectionsReport
            // 
            this.btnToolInspectionsReport.Id = 155;
            this.btnToolInspectionsReport.Name = "btnToolInspectionsReport";
            // 
            // btnToolRepairPartsReport
            // 
            this.btnToolRepairPartsReport.Id = 154;
            this.btnToolRepairPartsReport.Name = "btnToolRepairPartsReport";
            // 
            // btnToolComponentsReport
            // 
            this.btnToolComponentsReport.Id = 153;
            this.btnToolComponentsReport.Name = "btnToolComponentsReport";
            // 
            // btnToolAccessoriesReport
            // 
            this.btnToolAccessoriesReport.Id = 158;
            this.btnToolAccessoriesReport.Name = "btnToolAccessoriesReport";
            // 
            // btnProjectInfoSheetReport
            // 
            this.btnProjectInfoSheetReport.Id = 152;
            this.btnProjectInfoSheetReport.Name = "btnProjectInfoSheetReport";
            // 
            // btnToolEventScheduledReport
            // 
            this.btnToolEventScheduledReport.Id = 156;
            this.btnToolEventScheduledReport.Name = "btnToolEventScheduledReport";
            // 
            // btnAccessories
            // 
            this.btnAccessories.Id = 157;
            this.btnAccessories.Name = "btnAccessories";
            // 
            // btnComponents
            // 
            this.btnComponents.Id = 149;
            this.btnComponents.Name = "btnComponents";
            // 
            // btnRepairParts
            // 
            this.btnRepairParts.Id = 151;
            this.btnRepairParts.Name = "btnRepairParts";
            // 
            // btnInspections
            // 
            this.btnInspections.Id = 150;
            this.btnInspections.Name = "btnInspections";
            // 
            // btnGeneral
            // 
            this.btnGeneral.Id = 148;
            this.btnGeneral.Name = "btnGeneral";
            // 
            // ribbonGroup2
            // 
            this.ribbonGroup2.ImageIndex = 1;
            this.ribbonGroup2.ItemLinks.Add(this.btnNew);
            this.ribbonGroup2.ItemLinks.Add(this.btnCopy);
            this.ribbonGroup2.ItemLinks.Add(this.btnSave);
            this.ribbonGroup2.ItemLinks.Add(this.btnUndo);
            this.ribbonGroup2.ItemLinks.Add(this.btnRev);
            this.ribbonGroup2.ItemLinks.Add(this.btnDelete);
            this.ribbonGroup2.Name = "ribbonGroup2";
            this.ribbonGroup2.ShowCaptionButton = false;
            this.ribbonGroup2.Text = "Action";
            // 
            // btnNew
            // 
            this.btnNew.Caption = "&New";
            this.btnNew.Description = "Create a New Change Order";
            this.btnNew.Hint = "Create a New Change Order";
            this.btnNew.Id = 0;
            this.btnNew.ImageIndex = 6;
            this.btnNew.LargeImageIndex = 0;
            this.btnNew.Name = "btnNew";
            this.btnNew.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large;
            this.btnNew.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.allButtons_ItemClick);
            // 
            // btnCopy
            // 
            this.btnCopy.Caption = "&Copy";
            this.btnCopy.Description = "Copy the Active Change Order to New Change Order";
            this.btnCopy.Hint = "Copy the Active Change Order to New Change Order";
            this.btnCopy.Id = 0;
            this.btnCopy.ImageIndex = 23;
            this.btnCopy.Name = "btnCopy";
            this.btnCopy.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithText;
            this.btnCopy.Visibility = DevExpress.XtraBars.BarItemVisibility.Never;
            this.btnCopy.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.allButtons_ItemClick);
            // 
            // btnSave
            // 
            this.btnSave.Caption = "&Save";
            this.btnSave.Description = "Save the Change Order";
            this.btnSave.Enabled = false;
            this.btnSave.Hint = "Save the Change Order";
            this.btnSave.Id = 3;
            this.btnSave.ImageIndex = 10;
            this.btnSave.LargeImageIndex = 7;
            this.btnSave.Name = "btnSave";
            this.btnSave.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithText;
            this.btnSave.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.allButtons_ItemClick);
            // 
            // btnUndo
            // 
            this.btnUndo.Caption = "&Undo";
            this.btnUndo.Description = "Undo Change Order Changes";
            this.btnUndo.Hint = "Undo Change Oreder Changes";
            this.btnUndo.Id = 8;
            this.btnUndo.ImageIndex = 11;
            this.btnUndo.Name = "btnUndo";
            this.btnUndo.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithText;
            this.btnUndo.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.allButtons_ItemClick);
            // 
            // btnRev
            // 
            this.btnRev.Caption = "&Rev";
            this.btnRev.Description = "Copy the Active Change Order for Archive";
            this.btnRev.Hint = "Copy the Active Change Order for Archive";
            this.btnRev.Id = 2;
            this.btnRev.ImageIndex = 23;
            this.btnRev.Name = "btnRev";
            this.btnRev.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithText;
            this.btnRev.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.allButtons_ItemClick);
            // 
            // btnDelete
            // 
            this.btnDelete.Caption = "&Delete";
            this.btnDelete.Description = "Delete Change Order";
            this.btnDelete.Hint = "Delete Change Order";
            this.btnDelete.Id = 25;
            this.btnDelete.ImageIndex = 13;
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithText;
            this.btnDelete.Visibility = DevExpress.XtraBars.BarItemVisibility.Never;
            // 
            // ribbonPage1
            // 
            this.ribbonPage1.Groups.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPageGroup[] {
            this.ribbonGroup2,
            this.ribbonReport});
            this.ribbonPage1.Name = "ribbonPage1";
            this.ribbonPage1.Text = "Change Order";
            // 
            // ribbonReport
            // 
            this.ribbonReport.ItemLinks.Add(this.barSubItem2);
            this.ribbonReport.Name = "ribbonReport";
            this.ribbonReport.ShowCaptionButton = false;
            this.ribbonReport.Text = "Print";
            // 
            // barSubItem2
            // 
            this.barSubItem2.Caption = "Reports";
            this.barSubItem2.Id = 169;
            this.barSubItem2.LargeImageIndex = 11;
            this.barSubItem2.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.btnChangeOrderSheet),
            new DevExpress.XtraBars.LinkPersistInfo(this.btnChangeOrderLetter),
            new DevExpress.XtraBars.LinkPersistInfo(this.barButtonItem3),
            new DevExpress.XtraBars.LinkPersistInfo(this.barButtonItem4)});
            this.barSubItem2.Name = "barSubItem2";
            // 
            // btnChangeOrderSheet
            // 
            this.btnChangeOrderSheet.Caption = "&Change Order Contract";
            this.btnChangeOrderSheet.Id = 170;
            this.btnChangeOrderSheet.ImageIndex = 32;
            this.btnChangeOrderSheet.Name = "btnChangeOrderSheet";
            this.btnChangeOrderSheet.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.allButtons_ItemClick);
            // 
            // btnChangeOrderLetter
            // 
            this.btnChangeOrderLetter.Caption = "&Change Order Letter";
            this.btnChangeOrderLetter.Id = 172;
            this.btnChangeOrderLetter.ImageIndex = 32;
            this.btnChangeOrderLetter.Name = "btnChangeOrderLetter";
            this.btnChangeOrderLetter.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.allButtons_ItemClick);
            // 
            // barButtonItem3
            // 
            this.barButtonItem3.Caption = "Budget Sheet";
            this.barButtonItem3.Id = 173;
            this.barButtonItem3.ImageIndex = 32;
            this.barButtonItem3.Name = "barButtonItem3";
            this.barButtonItem3.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.allButtons_ItemClick);
            // 
            // barButtonItem4
            // 
            this.barButtonItem4.Caption = "Change Order Contract && Letter";
            this.barButtonItem4.Id = 174;
            this.barButtonItem4.ImageIndex = 32;
            this.barButtonItem4.Name = "barButtonItem4";
            this.barButtonItem4.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.allButtons_ItemClick);
            // 
            // barButtonInspectionTicket
            // 
            this.barButtonInspectionTicket.Caption = "&Inspection Ticket";
            this.barButtonInspectionTicket.Id = 171;
            this.barButtonInspectionTicket.ImageIndex = 9;
            this.barButtonInspectionTicket.Name = "barButtonInspectionTicket";
            // 
            // barSubItemReports
            // 
            this.barSubItemReports.Caption = "Reports";
            this.barSubItemReports.Id = 140;
            this.barSubItemReports.LargeImageIndex = 6;
            this.barSubItemReports.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.btnProjectInfoSheetReport),
            new DevExpress.XtraBars.LinkPersistInfo(this.btnToolAccessoriesReport),
            new DevExpress.XtraBars.LinkPersistInfo(this.btnToolComponentsReport),
            new DevExpress.XtraBars.LinkPersistInfo(this.btnToolRepairPartsReport),
            new DevExpress.XtraBars.LinkPersistInfo(this.btnToolInspectionsReport),
            new DevExpress.XtraBars.LinkPersistInfo(this.btnToolEventScheduledReport)});
            this.barSubItemReports.Name = "barSubItemReports";
            // 
            // imageCollection1
            // 
            this.imageCollection1.ImageSize = new System.Drawing.Size(32, 32);
            this.imageCollection1.ImageStream = ((DevExpress.Utils.ImageCollectionStreamer)(resources.GetObject("imageCollection1.ImageStream")));
            // 
            // barButtonGroup5
            // 
            this.barButtonGroup5.Caption = "barButtonGroup5";
            this.barButtonGroup5.Id = 137;
            this.barButtonGroup5.Name = "barButtonGroup5";
            // 
            // btnTimeCard
            // 
            this.btnTimeCard.Id = 124;
            this.btnTimeCard.Name = "btnTimeCard";
            // 
            // btnCostToComplete
            // 
            this.btnCostToComplete.Id = 123;
            this.btnCostToComplete.Name = "btnCostToComplete";
            // 
            // btnJobProgress
            // 
            this.btnJobProgress.Id = 122;
            this.btnJobProgress.Name = "btnJobProgress";
            // 
            // btnLaborProd
            // 
            this.btnLaborProd.Id = 121;
            this.btnLaborProd.Name = "btnLaborProd";
            // 
            // btnExcelQuantity
            // 
            this.btnExcelQuantity.Id = 120;
            this.btnExcelQuantity.Name = "btnExcelQuantity";
            // 
            // barButtonItem2
            // 
            this.barButtonItem2.Caption = "barButtonItem2";
            this.barButtonItem2.Id = 125;
            this.barButtonItem2.Name = "barButtonItem2";
            // 
            // btnDown
            // 
            this.btnDown.Caption = "Next Change Order";
            this.btnDown.Description = "Go to Next Change Order";
            this.btnDown.Hint = "Go to Next Change Order";
            this.btnDown.Id = 126;
            this.btnDown.ImageIndex = 29;
            this.btnDown.Name = "btnDown";
            this.btnDown.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.allButtons_ItemClick);
            // 
            // barButtonGroup4
            // 
            this.barButtonGroup4.Caption = "barButtonGroup4";
            this.barButtonGroup4.Id = 127;
            this.barButtonGroup4.Name = "barButtonGroup4";
            // 
            // dxErrorProvider
            // 
            this.dxErrorProvider.ContainerControl = this;
            // 
            // textEdit30
            // 
            this.textEdit30.Location = new System.Drawing.Point(-192, 494);
            this.textEdit30.Name = "textEdit30";
            this.spellChecker1.SetShowSpellCheckMenu(this.textEdit30, true);
            this.textEdit30.Size = new System.Drawing.Size(64, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.textEdit30, optionsSpelling140);
            this.textEdit30.TabIndex = 236;
            // 
            // labelControl66
            // 
            this.labelControl66.Location = new System.Drawing.Point(-247, 332);
            this.labelControl66.Name = "labelControl66";
            this.labelControl66.Size = new System.Drawing.Size(49, 13);
            this.labelControl66.TabIndex = 216;
            this.labelControl66.Text = "Address1:";
            // 
            // labelControl65
            // 
            this.labelControl65.Location = new System.Drawing.Point(-221, 378);
            this.labelControl65.Name = "labelControl65";
            this.labelControl65.Size = new System.Drawing.Size(23, 13);
            this.labelControl65.TabIndex = 217;
            this.labelControl65.Text = "City:";
            // 
            // labelControl63
            // 
            this.labelControl63.Location = new System.Drawing.Point(-221, 404);
            this.labelControl63.Name = "labelControl63";
            this.labelControl63.Size = new System.Drawing.Size(23, 13);
            this.labelControl63.TabIndex = 219;
            this.labelControl63.Text = "Rep:";
            // 
            // labelControl61
            // 
            this.labelControl61.Location = new System.Drawing.Point(-250, 358);
            this.labelControl61.Name = "labelControl61";
            this.labelControl61.Size = new System.Drawing.Size(52, 13);
            this.labelControl61.TabIndex = 228;
            this.labelControl61.Text = "Address 2:";
            // 
            // labelControl49
            // 
            this.labelControl49.Location = new System.Drawing.Point(-262, 471);
            this.labelControl49.Name = "labelControl49";
            this.labelControl49.Size = new System.Drawing.Size(64, 13);
            this.labelControl49.TabIndex = 232;
            this.labelControl49.Text = "Alpha Codes:";
            // 
            // textEdit32
            // 
            this.textEdit32.Location = new System.Drawing.Point(-192, 446);
            this.textEdit32.Name = "textEdit32";
            this.spellChecker1.SetShowSpellCheckMenu(this.textEdit32, true);
            this.textEdit32.Size = new System.Drawing.Size(64, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.textEdit32, optionsSpelling141);
            this.textEdit32.TabIndex = 233;
            // 
            // textEdit31
            // 
            this.textEdit31.Location = new System.Drawing.Point(-192, 468);
            this.textEdit31.Name = "textEdit31";
            this.spellChecker1.SetShowSpellCheckMenu(this.textEdit31, true);
            this.textEdit31.Size = new System.Drawing.Size(64, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.textEdit31, optionsSpelling142);
            this.textEdit31.TabIndex = 234;
            // 
            // labelControl48
            // 
            this.labelControl48.Location = new System.Drawing.Point(-250, 501);
            this.labelControl48.Name = "labelControl48";
            this.labelControl48.Size = new System.Drawing.Size(32, 13);
            this.labelControl48.TabIndex = 235;
            this.labelControl48.Text = "Other:";
            // 
            // labelControl60
            // 
            this.labelControl60.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl60.Location = new System.Drawing.Point(-255, 427);
            this.labelControl60.Name = "labelControl60";
            this.labelControl60.Size = new System.Drawing.Size(68, 13);
            this.labelControl60.TabIndex = 230;
            this.labelControl60.Text = "Pricing Data";
            // 
            // labelControl59
            // 
            this.labelControl59.Location = new System.Drawing.Point(-250, 449);
            this.labelControl59.Name = "labelControl59";
            this.labelControl59.Size = new System.Drawing.Size(57, 13);
            this.labelControl59.TabIndex = 231;
            this.labelControl59.Text = "Labor Rate:";
            // 
            // btnExcelHours
            // 
            this.btnExcelHours.Id = 119;
            this.btnExcelHours.Name = "btnExcelHours";
            // 
            // btnLaborFeedbackReport
            // 
            this.btnLaborFeedbackReport.Caption = "&Labor Feedback";
            this.btnLaborFeedbackReport.Description = "Print Labor Feedback";
            this.btnLaborFeedbackReport.Hint = "Print Labor Feedback for Selected Report";
            this.btnLaborFeedbackReport.Id = 112;
            this.btnLaborFeedbackReport.ImageIndex = 9;
            this.btnLaborFeedbackReport.LargeImageIndex = 6;
            this.btnLaborFeedbackReport.Name = "btnLaborFeedbackReport";
            // 
            // btnLaborFeedback
            // 
            this.btnLaborFeedback.Caption = "Labor Feedback";
            this.btnLaborFeedback.Description = "Labor Feedback";
            this.btnLaborFeedback.Hint = "Labor Feedback Related Information";
            this.btnLaborFeedback.Id = 111;
            this.btnLaborFeedback.ImageIndex = 6;
            this.btnLaborFeedback.LargeImageIndex = 0;
            this.btnLaborFeedback.Name = "btnLaborFeedback";
            // 
            // iWeb
            // 
            this.iWeb.Caption = "&Developer Express on the Web";
            this.iWeb.Description = "Opens the web page.";
            this.iWeb.Hint = "Developer Express on the Web";
            this.iWeb.Id = 21;
            this.iWeb.ImageIndex = 24;
            this.iWeb.Name = "iWeb";
            // 
            // iProtected
            // 
            this.iProtected.ButtonStyle = DevExpress.XtraBars.BarButtonStyle.Check;
            this.iProtected.Caption = "P&rotected";
            this.iProtected.Description = "Protects the selected text.";
            this.iProtected.Hint = "Protects the selected text";
            this.iProtected.Id = 19;
            this.iProtected.Name = "iProtected";
            // 
            // iBullets
            // 
            this.iBullets.ButtonStyle = DevExpress.XtraBars.BarButtonStyle.Check;
            this.iBullets.Caption = "&Bullets";
            this.iBullets.Description = "Adds bullets to or removes bullets from selected paragraphs.";
            this.iBullets.Hint = "Bullets";
            this.iBullets.Id = 18;
            this.iBullets.ImageIndex = 0;
            this.iBullets.Name = "iBullets";
            // 
            // iFont
            // 
            this.iFont.ButtonStyle = DevExpress.XtraBars.BarButtonStyle.DropDown;
            this.iFont.Caption = "&Font...";
            this.iFont.Description = "Changes the font and character spacing formats of the selected text.";
            this.iFont.Hint = "Font Dialog";
            this.iFont.Id = 17;
            this.iFont.ImageIndex = 4;
            this.iFont.Name = "iFont";
            this.iFont.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithText;
            // 
            // btnGeneralOld
            // 
            this.btnGeneralOld.Caption = "General";
            this.btnGeneralOld.Description = "Account General Information";
            this.btnGeneralOld.Hint = "Account General Information";
            this.btnGeneralOld.Id = 14;
            this.btnGeneralOld.ImageIndex = 3;
            this.btnGeneralOld.LargeImageIndex = 4;
            this.btnGeneralOld.Name = "btnGeneralOld";
            // 
            // iAbout
            // 
            this.iAbout.Alignment = DevExpress.XtraBars.BarItemLinkAlignment.Right;
            this.iAbout.Caption = "&About";
            this.iAbout.Description = "Displays the description of this program.";
            this.iAbout.Hint = "Displays the About dialog";
            this.iAbout.Id = 22;
            this.iAbout.Name = "iAbout";
            // 
            // iBold
            // 
            this.iBold.ButtonStyle = DevExpress.XtraBars.BarButtonStyle.Check;
            this.iBold.Caption = "&Bold";
            this.iBold.Description = "Makes selected text and numbers bold. If the selection is already bold, clicking " +
    "button removes bold formatting.";
            this.iBold.Hint = "Bold";
            this.iBold.Id = 24;
            this.iBold.ImageIndex = 15;
            this.iBold.Name = "iBold";
            // 
            // iAlignRight
            // 
            this.iAlignRight.ButtonStyle = DevExpress.XtraBars.BarButtonStyle.Check;
            this.iAlignRight.Caption = "Align &Right";
            this.iAlignRight.Description = "Aligns the selected text to the right.";
            this.iAlignRight.GroupIndex = 1;
            this.iAlignRight.Hint = "Align Right";
            this.iAlignRight.Id = 29;
            this.iAlignRight.ImageIndex = 20;
            this.iAlignRight.Name = "iAlignRight";
            // 
            // iCenter
            // 
            this.iCenter.ButtonStyle = DevExpress.XtraBars.BarButtonStyle.Check;
            this.iCenter.Caption = "&Center";
            this.iCenter.Description = "Centers the selected text.";
            this.iCenter.GroupIndex = 1;
            this.iCenter.Hint = "Center";
            this.iCenter.Id = 28;
            this.iCenter.ImageIndex = 19;
            this.iCenter.Name = "iCenter";
            // 
            // iAlignLeft
            // 
            this.iAlignLeft.ButtonStyle = DevExpress.XtraBars.BarButtonStyle.Check;
            this.iAlignLeft.Caption = "Align &Left";
            this.iAlignLeft.Description = "Aligns the selected text to the left.";
            this.iAlignLeft.GroupIndex = 1;
            this.iAlignLeft.Hint = "Align Left";
            this.iAlignLeft.Id = 27;
            this.iAlignLeft.ImageIndex = 18;
            this.iAlignLeft.Name = "iAlignLeft";
            // 
            // iUnderline
            // 
            this.iUnderline.ButtonStyle = DevExpress.XtraBars.BarButtonStyle.Check;
            this.iUnderline.Caption = "&Underline";
            this.iUnderline.Description = "Underlines selected text and numbers. If the selection is already underlined, cli" +
    "cking button removes underlining.";
            this.iUnderline.Hint = "Underline";
            this.iUnderline.Id = 26;
            this.iUnderline.ImageIndex = 17;
            this.iUnderline.Name = "iUnderline";
            // 
            // iSelectAll
            // 
            this.iSelectAll.Caption = "Select A&ll";
            this.iSelectAll.Description = "Selects all text in the active document.";
            this.iSelectAll.Hint = "Selects all text in the active document.";
            this.iSelectAll.Id = 13;
            this.iSelectAll.Name = "iSelectAll";
            // 
            // btnTimeSheet
            // 
            this.btnTimeSheet.Caption = "&Time Sheet";
            this.btnTimeSheet.Description = "Print Time Sheet";
            this.btnTimeSheet.Hint = "Print Time Sheet";
            this.btnTimeSheet.Id = 12;
            this.btnTimeSheet.ImageIndex = 9;
            this.btnTimeSheet.LargeImageIndex = 6;
            this.btnTimeSheet.Name = "btnTimeSheet";
            this.btnTimeSheet.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large;
            // 
            // btnUp
            // 
            this.btnUp.Caption = "Previous Change Order";
            this.btnUp.Description = "Go to Previous Change Order";
            this.btnUp.Hint = "Go to Previous Change Order";
            this.btnUp.Id = 15;
            this.btnUp.ImageIndex = 28;
            this.btnUp.Name = "btnUp";
            this.btnUp.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.allButtons_ItemClick);
            // 
            // imageCollection2
            // 
            this.imageCollection2.ImageStream = ((DevExpress.Utils.ImageCollectionStreamer)(resources.GetObject("imageCollection2.ImageStream")));
            // 
            // ribProjectOpportunity
            // 
            this.ribProjectOpportunity.ApplicationIcon = ((System.Drawing.Bitmap)(resources.GetObject("ribProjectOpportunity.ApplicationIcon")));
            this.ribProjectOpportunity.Categories.AddRange(new DevExpress.XtraBars.BarManagerCategory[] {
            new DevExpress.XtraBars.BarManagerCategory("File", new System.Guid("4b511317-d784-42ba-b4ed-0d2a746d6c1f")),
            new DevExpress.XtraBars.BarManagerCategory("Edit", new System.Guid("7c2486e1-92ea-4293-ad55-b819f61ff7f1")),
            new DevExpress.XtraBars.BarManagerCategory("Format", new System.Guid("d3052f28-4b3e-4bae-b581-b3bb1c432258")),
            new DevExpress.XtraBars.BarManagerCategory("Help", new System.Guid("e07a4c24-66ac-4de6-bbcb-c0b6cfa7798b")),
            new DevExpress.XtraBars.BarManagerCategory("Status", new System.Guid("77795bb7-9bc5-4dd2-a297-cc758682e23d"))});
            this.ribProjectOpportunity.ExpandCollapseItem.Id = 0;
            this.ribProjectOpportunity.Images = this.imageCollection2;
            this.ribProjectOpportunity.Items.AddRange(new DevExpress.XtraBars.BarItem[] {
            this.ribProjectOpportunity.ExpandCollapseItem,
            this.btnSave,
            this.btnUndo,
            this.btnUp,
            this.btnNew,
            this.btnRev,
            this.iSaveAs,
            this.btnCostCodesWeekly,
            this.btnCostCodes,
            this.btnstrategic,
            this.btnGeneral,
            this.btnTimeSheet,
            this.iSelectAll,
            this.btnGeneralOld,
            this.iFont,
            this.iBullets,
            this.iProtected,
            this.iWeb,
            this.iAbout,
            this.iBold,
            this.btnDelete,
            this.iUnderline,
            this.iAlignLeft,
            this.iCenter,
            this.iAlignRight,
            this.iFontColor,
            this.siPosition,
            this.siModified,
            this.siDocName,
            this.bgFontStyle,
            this.bgAlign,
            this.bgFont,
            this.bgBullets,
            this.sbiPaste,
            this.iPasteSpecial,
            this.btnCopy,
            this.iLargeUndo,
            this.iTemplate,
            this.rgbiSkins,
            this.beiFontSize,
            this.rgbiFont,
            this.bbiFontColorPopup,
            this.rgbiFontColor,
            this.btnPersonnel,
            this.iGeneral,
            this.btnNote,
            this.barButtonItem5,
            this.barButtonItem6,
            this.barButtonGroup1,
            this.barButtonGroup2,
            this.barButtonGroup3,
            this.barLinkContainerItem1,
            this.barMdiChildrenListItem1,
            this.barButtonItem1,
            this.btnLaborFeedback,
            this.btnLaborFeedbackReport,
            this.btnExcelHours,
            this.btnExcelQuantity,
            this.btnLaborProd,
            this.btnJobProgress,
            this.btnCostToComplete,
            this.btnTimeCard,
            this.barButtonItem2,
            this.btnDown,
            this.barButtonGroup4,
            this.btnComponents,
            this.btnInspections,
            this.btnRepairParts,
            this.barButtonGroup5,
            this.barSubItemReports,
            this.btnProjectInfoSheetReport,
            this.btnToolComponentsReport,
            this.btnToolRepairPartsReport,
            this.btnToolInspectionsReport,
            this.btnToolEventScheduledReport,
            this.btnAccessories,
            this.btnToolAccessoriesReport,
            this.barButtonGroup6,
            this.barButtonGroup7,
            this.barButtonGroup8,
            this.barSubItem1,
            this.barSubItem2,
            this.btnChangeOrderSheet,
            this.barButtonInspectionTicket,
            this.btnChangeOrderLetter,
            this.barButtonItem3,
            this.barButtonItem4});
            this.ribProjectOpportunity.LargeImages = this.imageCollection1;
            this.ribProjectOpportunity.Location = new System.Drawing.Point(0, 0);
            this.ribProjectOpportunity.MaxItemId = 175;
            this.ribProjectOpportunity.Name = "ribProjectOpportunity";
            this.ribProjectOpportunity.PageCategoryAlignment = DevExpress.XtraBars.Ribbon.RibbonPageCategoryAlignment.Right;
            this.ribProjectOpportunity.Pages.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPage[] {
            this.ribbonPage1});
            this.ribProjectOpportunity.ShowPageHeadersMode = DevExpress.XtraBars.Ribbon.ShowPageHeadersMode.Hide;
            this.ribProjectOpportunity.ShowToolbarCustomizeItem = false;
            this.ribProjectOpportunity.Size = new System.Drawing.Size(927, 143);
            this.ribProjectOpportunity.Toolbar.ItemLinks.Add(this.btnUp);
            this.ribProjectOpportunity.Toolbar.ItemLinks.Add(this.btnDown);
            this.ribProjectOpportunity.Toolbar.ShowCustomizeItem = false;
            this.ribProjectOpportunity.ToolbarLocation = DevExpress.XtraBars.Ribbon.RibbonQuickAccessToolbarLocation.Above;
            // 
            // iSaveAs
            // 
            this.iSaveAs.Caption = "Save &As...";
            this.iSaveAs.Description = "Saves the active document with a different file name.";
            this.iSaveAs.Hint = "Saves the active document with a different file name";
            this.iSaveAs.Id = 4;
            this.iSaveAs.ImageIndex = 21;
            this.iSaveAs.LargeImageIndex = 2;
            this.iSaveAs.Name = "iSaveAs";
            // 
            // btnCostCodesWeekly
            // 
            this.btnCostCodesWeekly.Caption = "Cost Codes Weekly";
            this.btnCostCodesWeekly.Description = "Cost Codes Weekly";
            this.btnCostCodesWeekly.Hint = "Cost Codes Weekly Related Information";
            this.btnCostCodesWeekly.Id = 6;
            this.btnCostCodesWeekly.ImageIndex = 26;
            this.btnCostCodesWeekly.LargeImageIndex = 0;
            this.btnCostCodesWeekly.Name = "btnCostCodesWeekly";
            // 
            // btnCostCodes
            // 
            this.btnCostCodes.Caption = "Cost Codes";
            this.btnCostCodes.Description = "Cost Codes";
            this.btnCostCodes.Hint = "Cost Codes Related Information";
            this.btnCostCodes.Id = 9;
            this.btnCostCodes.ImageIndex = 0;
            this.btnCostCodes.LargeImageIndex = 0;
            this.btnCostCodes.Name = "btnCostCodes";
            // 
            // btnstrategic
            // 
            this.btnstrategic.Caption = "Strategic";
            this.btnstrategic.Description = "Account Strategic";
            this.btnstrategic.Hint = "Account Strategic";
            this.btnstrategic.Id = 10;
            this.btnstrategic.ImageIndex = 1;
            this.btnstrategic.LargeImageIndex = 0;
            this.btnstrategic.Name = "btnstrategic";
            // 
            // iFontColor
            // 
            this.iFontColor.ButtonStyle = DevExpress.XtraBars.BarButtonStyle.DropDown;
            this.iFontColor.Caption = "Font C&olor";
            this.iFontColor.Description = "Formats the selected text with the color you click.";
            this.iFontColor.Hint = "Font Color";
            this.iFontColor.Id = 30;
            this.iFontColor.ImageIndex = 5;
            this.iFontColor.Name = "iFontColor";
            // 
            // siPosition
            // 
            this.siPosition.Id = 0;
            this.siPosition.Name = "siPosition";
            // 
            // siModified
            // 
            this.siModified.Id = 1;
            this.siModified.ImageIndex = 27;
            this.siModified.Name = "siModified";
            // 
            // siDocName
            // 
            this.siDocName.Id = 2;
            this.siDocName.Name = "siDocName";
            this.siDocName.TextAlignment = System.Drawing.StringAlignment.Near;
            // 
            // bgFontStyle
            // 
            this.bgFontStyle.Caption = "FontStyle";
            this.bgFontStyle.Id = 0;
            this.bgFontStyle.Name = "bgFontStyle";
            // 
            // bgAlign
            // 
            this.bgAlign.Caption = "Align";
            this.bgAlign.Id = 0;
            this.bgAlign.Name = "bgAlign";
            // 
            // bgFont
            // 
            this.bgFont.Caption = "Font";
            this.bgFont.Id = 0;
            this.bgFont.Name = "bgFont";
            // 
            // bgBullets
            // 
            this.bgBullets.Caption = "Bullets";
            this.bgBullets.Id = 1;
            this.bgBullets.Name = "bgBullets";
            // 
            // sbiPaste
            // 
            this.sbiPaste.Caption = "Contact";
            this.sbiPaste.Description = "Inserts the contents of the Clipboard at the insertion point";
            this.sbiPaste.Hint = "Inserts the contents of the Clipboard at the insertion point";
            this.sbiPaste.Id = 1;
            this.sbiPaste.ImageIndex = 8;
            this.sbiPaste.LargeImageIndex = 3;
            this.sbiPaste.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.btnGeneral),
            new DevExpress.XtraBars.LinkPersistInfo(this.iPasteSpecial)});
            this.sbiPaste.Name = "sbiPaste";
            // 
            // iPasteSpecial
            // 
            this.iPasteSpecial.Caption = "Paste &Special...";
            this.iPasteSpecial.Description = "Opens the Paste Special dialog";
            this.iPasteSpecial.Enabled = false;
            this.iPasteSpecial.Hint = "Opens the Paste Special dialog";
            this.iPasteSpecial.Id = 3;
            this.iPasteSpecial.ImageIndex = 8;
            this.iPasteSpecial.Name = "iPasteSpecial";
            // 
            // iLargeUndo
            // 
            this.iLargeUndo.Caption = "&Undo";
            this.iLargeUndo.Hint = "Undo";
            this.iLargeUndo.Id = 0;
            this.iLargeUndo.ImageIndex = 11;
            this.iLargeUndo.LargeImageIndex = 5;
            this.iLargeUndo.Name = "iLargeUndo";
            // 
            // iTemplate
            // 
            this.iTemplate.Caption = "Template...";
            this.iTemplate.Description = "Creates a new template";
            this.iTemplate.Enabled = false;
            this.iTemplate.Hint = "Creates a new template";
            this.iTemplate.Id = 1;
            this.iTemplate.ImageIndex = 6;
            this.iTemplate.Name = "iTemplate";
            // 
            // rgbiSkins
            // 
            this.rgbiSkins.Caption = "Skins";
            // 
            // 
            // 
            this.rgbiSkins.Gallery.AllowHoverImages = true;
            this.rgbiSkins.Gallery.Appearance.ItemCaptionAppearance.Normal.Options.UseFont = true;
            this.rgbiSkins.Gallery.Appearance.ItemCaptionAppearance.Normal.Options.UseTextOptions = true;
            this.rgbiSkins.Gallery.Appearance.ItemCaptionAppearance.Normal.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.rgbiSkins.Gallery.ColumnCount = 4;
            this.rgbiSkins.Gallery.FixedHoverImageSize = false;
            galleryItemGroup1.Caption = "Main Skins";
            galleryItemGroup2.Caption = "Office Skins";
            this.rgbiSkins.Gallery.Groups.AddRange(new DevExpress.XtraBars.Ribbon.GalleryItemGroup[] {
            galleryItemGroup1,
            galleryItemGroup2});
            this.rgbiSkins.Gallery.ImageSize = new System.Drawing.Size(32, 17);
            this.rgbiSkins.Gallery.ItemImageLocation = DevExpress.Utils.Locations.Top;
            this.rgbiSkins.Gallery.RowCount = 4;
            this.rgbiSkins.Id = 13;
            this.rgbiSkins.Name = "rgbiSkins";
            // 
            // beiFontSize
            // 
            this.beiFontSize.Caption = "Font Size";
            this.beiFontSize.Edit = null;
            this.beiFontSize.Hint = "Font Size";
            this.beiFontSize.Id = 27;
            this.beiFontSize.Name = "beiFontSize";
            // 
            // rgbiFont
            // 
            this.rgbiFont.Caption = "Font";
            // 
            // 
            // 
            this.rgbiFont.Gallery.AllowHoverImages = true;
            galleryItemGroup3.Caption = "Main";
            this.rgbiFont.Gallery.Groups.AddRange(new DevExpress.XtraBars.Ribbon.GalleryItemGroup[] {
            galleryItemGroup3});
            this.rgbiFont.Id = 29;
            this.rgbiFont.Name = "rgbiFont";
            // 
            // bbiFontColorPopup
            // 
            this.bbiFontColorPopup.ActAsDropDown = true;
            this.bbiFontColorPopup.ButtonStyle = DevExpress.XtraBars.BarButtonStyle.DropDown;
            this.bbiFontColorPopup.Caption = "Font Color";
            this.bbiFontColorPopup.Description = "Formats the selected text with the color you click";
            this.bbiFontColorPopup.Hint = "Formats the selected text with the color you click";
            this.bbiFontColorPopup.Id = 36;
            this.bbiFontColorPopup.Name = "bbiFontColorPopup";
            // 
            // rgbiFontColor
            // 
            this.rgbiFontColor.Caption = "Color";
            // 
            // 
            // 
            this.rgbiFontColor.Gallery.ColumnCount = 10;
            galleryItemGroup4.Caption = "Main";
            this.rgbiFontColor.Gallery.Groups.AddRange(new DevExpress.XtraBars.Ribbon.GalleryItemGroup[] {
            galleryItemGroup4});
            this.rgbiFontColor.Gallery.ImageSize = new System.Drawing.Size(10, 7);
            this.rgbiFontColor.Id = 37;
            this.rgbiFontColor.Name = "rgbiFontColor";
            // 
            // btnPersonnel
            // 
            this.btnPersonnel.Caption = "&Time Sheet";
            this.btnPersonnel.Description = "Print Time Sheet ";
            this.btnPersonnel.Hint = "Print Time Sheet for Selected Week";
            this.btnPersonnel.Id = 92;
            this.btnPersonnel.ImageIndex = 9;
            this.btnPersonnel.LargeImageIndex = 6;
            this.btnPersonnel.Name = "btnPersonnel";
            // 
            // iGeneral
            // 
            this.iGeneral.Caption = "General";
            this.iGeneral.Description = "Account General Information";
            this.iGeneral.Hint = "Account General Information";
            this.iGeneral.Id = 96;
            this.iGeneral.ImageIndex = 6;
            this.iGeneral.LargeImageIndex = 0;
            this.iGeneral.Name = "iGeneral";
            // 
            // btnNote
            // 
            this.btnNote.Caption = "Note";
            this.btnNote.Description = "Account Notes";
            this.btnNote.Hint = "Account Notes";
            this.btnNote.Id = 98;
            this.btnNote.LargeImageIndex = 0;
            this.btnNote.Name = "btnNote";
            // 
            // barButtonItem5
            // 
            this.barButtonItem5.Caption = "barButtonItem1";
            this.barButtonItem5.Id = 100;
            this.barButtonItem5.Name = "barButtonItem5";
            // 
            // barButtonItem6
            // 
            this.barButtonItem6.Caption = "barButtonItem3";
            this.barButtonItem6.Id = 101;
            this.barButtonItem6.Name = "barButtonItem6";
            // 
            // barButtonGroup1
            // 
            this.barButtonGroup1.Caption = "barButtonGroup1";
            this.barButtonGroup1.Id = 102;
            this.barButtonGroup1.Name = "barButtonGroup1";
            // 
            // barButtonGroup2
            // 
            this.barButtonGroup2.Caption = "barButtonGroup2";
            this.barButtonGroup2.Id = 105;
            this.barButtonGroup2.Name = "barButtonGroup2";
            // 
            // barButtonGroup3
            // 
            this.barButtonGroup3.Caption = "barButtonGroup3";
            this.barButtonGroup3.Id = 106;
            this.barButtonGroup3.Name = "barButtonGroup3";
            // 
            // barLinkContainerItem1
            // 
            this.barLinkContainerItem1.Caption = "barLinkContainerItem1";
            this.barLinkContainerItem1.Id = 108;
            this.barLinkContainerItem1.Name = "barLinkContainerItem1";
            // 
            // barMdiChildrenListItem1
            // 
            this.barMdiChildrenListItem1.Caption = "barMdiChildrenListItem1";
            this.barMdiChildrenListItem1.Id = 109;
            this.barMdiChildrenListItem1.Name = "barMdiChildrenListItem1";
            // 
            // barButtonItem1
            // 
            this.barButtonItem1.Caption = "barButtonItem1";
            this.barButtonItem1.Id = 110;
            this.barButtonItem1.Name = "barButtonItem1";
            // 
            // barButtonGroup6
            // 
            this.barButtonGroup6.Caption = "barButtonGroup6";
            this.barButtonGroup6.Id = 162;
            this.barButtonGroup6.Name = "barButtonGroup6";
            // 
            // barButtonGroup7
            // 
            this.barButtonGroup7.Caption = "barButtonGroup7";
            this.barButtonGroup7.Id = 164;
            this.barButtonGroup7.Name = "barButtonGroup7";
            // 
            // barButtonGroup8
            // 
            this.barButtonGroup8.Caption = "barButtonGroup8";
            this.barButtonGroup8.Id = 165;
            this.barButtonGroup8.Name = "barButtonGroup8";
            // 
            // barSubItem1
            // 
            this.barSubItem1.Caption = "barSubItem1";
            this.barSubItem1.Id = 167;
            this.barSubItem1.Name = "barSubItem1";
            // 
            // labelControl68
            // 
            this.labelControl68.Location = new System.Drawing.Point(-229, 306);
            this.labelControl68.Name = "labelControl68";
            this.labelControl68.Size = new System.Drawing.Size(31, 13);
            this.labelControl68.TabIndex = 214;
            this.labelControl68.Text = "Name:";
            // 
            // labelControl99
            // 
            this.labelControl99.Location = new System.Drawing.Point(-221, -103);
            this.labelControl99.Name = "labelControl99";
            this.labelControl99.Size = new System.Drawing.Size(23, 13);
            this.labelControl99.TabIndex = 152;
            this.labelControl99.Text = "City:";
            // 
            // labelControl98
            // 
            this.labelControl98.Location = new System.Drawing.Point(189, -103);
            this.labelControl98.Name = "labelControl98";
            this.labelControl98.Size = new System.Drawing.Size(18, 13);
            this.labelControl98.TabIndex = 153;
            this.labelControl98.Text = "Zip:";
            // 
            // labelControl100
            // 
            this.labelControl100.Location = new System.Drawing.Point(-247, -149);
            this.labelControl100.Name = "labelControl100";
            this.labelControl100.Size = new System.Drawing.Size(49, 13);
            this.labelControl100.TabIndex = 151;
            this.labelControl100.Text = "Address1:";
            // 
            // labelControl97
            // 
            this.labelControl97.Location = new System.Drawing.Point(-255, -77);
            this.labelControl97.Name = "labelControl97";
            this.labelControl97.Size = new System.Drawing.Size(57, 13);
            this.labelControl97.TabIndex = 154;
            this.labelControl97.Text = "Description:";
            // 
            // labelControl101
            // 
            this.labelControl101.Location = new System.Drawing.Point(89, -103);
            this.labelControl101.Name = "labelControl101";
            this.labelControl101.Size = new System.Drawing.Size(30, 13);
            this.labelControl101.TabIndex = 150;
            this.labelControl101.Text = "State:";
            // 
            // labelControl102
            // 
            this.labelControl102.Location = new System.Drawing.Point(-229, -175);
            this.labelControl102.Name = "labelControl102";
            this.labelControl102.Size = new System.Drawing.Size(31, 13);
            this.labelControl102.TabIndex = 149;
            this.labelControl102.Text = "Name:";
            // 
            // labelControl104
            // 
            this.labelControl104.Location = new System.Drawing.Point(61, -179);
            this.labelControl104.Name = "labelControl104";
            this.labelControl104.Size = new System.Drawing.Size(56, 13);
            this.labelControl104.TabIndex = 147;
            this.labelControl104.Text = "Estimate #:";
            // 
            // labelControl96
            // 
            this.labelControl96.Location = new System.Drawing.Point(85, -153);
            this.labelControl96.Name = "labelControl96";
            this.labelControl96.Size = new System.Drawing.Size(34, 13);
            this.labelControl96.TabIndex = 155;
            this.labelControl96.Text = "Phone:";
            // 
            // labelControl103
            // 
            this.labelControl103.Location = new System.Drawing.Point(189, -231);
            this.labelControl103.Name = "labelControl103";
            this.labelControl103.Size = new System.Drawing.Size(32, 13);
            this.labelControl103.TabIndex = 148;
            this.labelControl103.Text = "Job #:";
            // 
            // textEdit78
            // 
            this.textEdit78.Location = new System.Drawing.Point(123, -182);
            this.textEdit78.Name = "textEdit78";
            this.spellChecker1.SetShowSpellCheckMenu(this.textEdit78, true);
            this.textEdit78.Size = new System.Drawing.Size(84, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.textEdit78, optionsSpelling143);
            this.textEdit78.TabIndex = 156;
            // 
            // textEdit77
            // 
            this.textEdit77.Location = new System.Drawing.Point(227, -234);
            this.textEdit77.Name = "textEdit77";
            this.spellChecker1.SetShowSpellCheckMenu(this.textEdit77, true);
            this.textEdit77.Size = new System.Drawing.Size(84, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.textEdit77, optionsSpelling144);
            this.textEdit77.TabIndex = 157;
            // 
            // textEdit76
            // 
            this.textEdit76.Location = new System.Drawing.Point(-192, -178);
            this.textEdit76.Name = "textEdit76";
            this.spellChecker1.SetShowSpellCheckMenu(this.textEdit76, true);
            this.textEdit76.Size = new System.Drawing.Size(221, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.textEdit76, optionsSpelling145);
            this.textEdit76.TabIndex = 158;
            // 
            // labelControl78
            // 
            this.labelControl78.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl78.Location = new System.Drawing.Point(-255, 137);
            this.labelControl78.Name = "labelControl78";
            this.labelControl78.Size = new System.Drawing.Size(108, 13);
            this.labelControl78.TabIndex = 196;
            this.labelControl78.Text = "General Contractor";
            // 
            // labelControl77
            // 
            this.labelControl77.Location = new System.Drawing.Point(-229, 159);
            this.labelControl77.Name = "labelControl77";
            this.labelControl77.Size = new System.Drawing.Size(31, 13);
            this.labelControl77.TabIndex = 197;
            this.labelControl77.Text = "Name:";
            // 
            // labelControl75
            // 
            this.labelControl75.Location = new System.Drawing.Point(-247, 185);
            this.labelControl75.Name = "labelControl75";
            this.labelControl75.Size = new System.Drawing.Size(49, 13);
            this.labelControl75.TabIndex = 199;
            this.labelControl75.Text = "Address1:";
            // 
            // labelControl79
            // 
            this.labelControl79.Location = new System.Drawing.Point(-250, 68);
            this.labelControl79.Name = "labelControl79";
            this.labelControl79.Size = new System.Drawing.Size(52, 13);
            this.labelControl79.TabIndex = 194;
            this.labelControl79.Text = "Address 2:";
            // 
            // labelControl74
            // 
            this.labelControl74.Location = new System.Drawing.Point(-221, 231);
            this.labelControl74.Name = "labelControl74";
            this.labelControl74.Size = new System.Drawing.Size(23, 13);
            this.labelControl74.TabIndex = 200;
            this.labelControl74.Text = "City:";
            // 
            // labelControl70
            // 
            this.labelControl70.Location = new System.Drawing.Point(-250, 211);
            this.labelControl70.Name = "labelControl70";
            this.labelControl70.Size = new System.Drawing.Size(52, 13);
            this.labelControl70.TabIndex = 211;
            this.labelControl70.Text = "Address 2:";
            // 
            // labelControl69
            // 
            this.labelControl69.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl69.Location = new System.Drawing.Point(-255, 284);
            this.labelControl69.Name = "labelControl69";
            this.labelControl69.Size = new System.Drawing.Size(66, 13);
            this.labelControl69.TabIndex = 213;
            this.labelControl69.Text = "Owner Data";
            // 
            // labelControl72
            // 
            this.labelControl72.Location = new System.Drawing.Point(-221, 257);
            this.labelControl72.Name = "labelControl72";
            this.labelControl72.Size = new System.Drawing.Size(23, 13);
            this.labelControl72.TabIndex = 202;
            this.labelControl72.Text = "Rep:";
            // 
            // labelControl95
            // 
            this.labelControl95.Location = new System.Drawing.Point(402, -231);
            this.labelControl95.Name = "labelControl95";
            this.labelControl95.Size = new System.Drawing.Size(49, 13);
            this.labelControl95.TabIndex = 166;
            this.labelControl95.Text = "Record #:";
            // 
            // labelControl94
            // 
            this.labelControl94.Location = new System.Drawing.Point(-268, -231);
            this.labelControl94.Name = "labelControl94";
            this.labelControl94.Size = new System.Drawing.Size(70, 13);
            this.labelControl94.TabIndex = 167;
            this.labelControl94.Text = "Completed by:";
            // 
            // textEdit68
            // 
            this.textEdit68.Location = new System.Drawing.Point(-192, -234);
            this.textEdit68.Name = "textEdit68";
            this.spellChecker1.SetShowSpellCheckMenu(this.textEdit68, true);
            this.textEdit68.Size = new System.Drawing.Size(173, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.textEdit68, optionsSpelling146);
            this.textEdit68.TabIndex = 168;
            // 
            // labelControl93
            // 
            this.labelControl93.Location = new System.Drawing.Point(56, -231);
            this.labelControl93.Name = "labelControl93";
            this.labelControl93.Size = new System.Drawing.Size(27, 13);
            this.labelControl93.TabIndex = 169;
            this.labelControl93.Text = "Date:";
            // 
            // textEdit67
            // 
            this.textEdit67.Location = new System.Drawing.Point(89, -234);
            this.textEdit67.Name = "textEdit67";
            this.spellChecker1.SetShowSpellCheckMenu(this.textEdit67, true);
            this.textEdit67.Size = new System.Drawing.Size(72, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.textEdit67, optionsSpelling147);
            this.textEdit67.TabIndex = 170;
            // 
            // textEdit69
            // 
            this.textEdit69.Location = new System.Drawing.Point(485, -234);
            this.textEdit69.Name = "textEdit69";
            this.spellChecker1.SetShowSpellCheckMenu(this.textEdit69, true);
            this.textEdit69.Size = new System.Drawing.Size(84, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.textEdit69, optionsSpelling148);
            this.textEdit69.TabIndex = 165;
            // 
            // textEdit70
            // 
            this.textEdit70.Location = new System.Drawing.Point(213, -106);
            this.textEdit70.Name = "textEdit70";
            this.spellChecker1.SetShowSpellCheckMenu(this.textEdit70, true);
            this.textEdit70.Size = new System.Drawing.Size(89, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.textEdit70, optionsSpelling149);
            this.textEdit70.TabIndex = 164;
            // 
            // textEdit75
            // 
            this.textEdit75.Location = new System.Drawing.Point(-192, -80);
            this.textEdit75.Name = "textEdit75";
            this.spellChecker1.SetShowSpellCheckMenu(this.textEdit75, true);
            this.textEdit75.Size = new System.Drawing.Size(494, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.textEdit75, optionsSpelling150);
            this.textEdit75.TabIndex = 159;
            // 
            // textEdit74
            // 
            this.textEdit74.Location = new System.Drawing.Point(-192, -156);
            this.textEdit74.Name = "textEdit74";
            this.spellChecker1.SetShowSpellCheckMenu(this.textEdit74, true);
            this.textEdit74.Size = new System.Drawing.Size(221, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.textEdit74, optionsSpelling151);
            this.textEdit74.TabIndex = 160;
            // 
            // textEdit73
            // 
            this.textEdit73.Location = new System.Drawing.Point(-192, -106);
            this.textEdit73.Name = "textEdit73";
            this.spellChecker1.SetShowSpellCheckMenu(this.textEdit73, true);
            this.textEdit73.Size = new System.Drawing.Size(221, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.textEdit73, optionsSpelling152);
            this.textEdit73.TabIndex = 161;
            // 
            // textEdit72
            // 
            this.textEdit72.Location = new System.Drawing.Point(123, -156);
            this.textEdit72.Name = "textEdit72";
            this.spellChecker1.SetShowSpellCheckMenu(this.textEdit72, true);
            this.textEdit72.Size = new System.Drawing.Size(84, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.textEdit72, optionsSpelling153);
            this.textEdit72.TabIndex = 162;
            // 
            // textEdit71
            // 
            this.textEdit71.Location = new System.Drawing.Point(123, -106);
            this.textEdit71.Name = "textEdit71";
            this.spellChecker1.SetShowSpellCheckMenu(this.textEdit71, true);
            this.textEdit71.Size = new System.Drawing.Size(51, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.textEdit71, optionsSpelling154);
            this.textEdit71.TabIndex = 163;
            // 
            // labelControl92
            // 
            this.labelControl92.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl92.Location = new System.Drawing.Point(-254, -199);
            this.labelControl92.Name = "labelControl92";
            this.labelControl92.Size = new System.Drawing.Size(113, 13);
            this.labelControl92.TabIndex = 171;
            this.labelControl92.Text = "Job Date && Location";
            // 
            // labelControl91
            // 
            this.labelControl91.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl91.Location = new System.Drawing.Point(-254, -54);
            this.labelControl91.Name = "labelControl91";
            this.labelControl91.Size = new System.Drawing.Size(68, 13);
            this.labelControl91.TabIndex = 172;
            this.labelControl91.Text = "Owner Class";
            // 
            // labelControl84
            // 
            this.labelControl84.Location = new System.Drawing.Point(-247, 42);
            this.labelControl84.Name = "labelControl84";
            this.labelControl84.Size = new System.Drawing.Size(49, 13);
            this.labelControl84.TabIndex = 181;
            this.labelControl84.Text = "Address1:";
            // 
            // labelControl83
            // 
            this.labelControl83.Location = new System.Drawing.Point(-221, 88);
            this.labelControl83.Name = "labelControl83";
            this.labelControl83.Size = new System.Drawing.Size(23, 13);
            this.labelControl83.TabIndex = 182;
            this.labelControl83.Text = "City:";
            // 
            // labelControl81
            // 
            this.labelControl81.Location = new System.Drawing.Point(-221, 114);
            this.labelControl81.Name = "labelControl81";
            this.labelControl81.Size = new System.Drawing.Size(23, 13);
            this.labelControl81.TabIndex = 184;
            this.labelControl81.Text = "Rep:";
            // 
            // labelControl86
            // 
            this.labelControl86.Location = new System.Drawing.Point(-229, 16);
            this.labelControl86.Name = "labelControl86";
            this.labelControl86.Size = new System.Drawing.Size(31, 13);
            this.labelControl86.TabIndex = 179;
            this.labelControl86.Text = "Name:";
            // 
            // lookUpEdit3
            // 
            this.lookUpEdit3.Location = new System.Drawing.Point(-192, -32);
            this.lookUpEdit3.Name = "lookUpEdit3";
            this.lookUpEdit3.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.lookUpEdit3.Size = new System.Drawing.Size(144, 20);
            this.lookUpEdit3.TabIndex = 173;
            // 
            // labelControl90
            // 
            this.labelControl90.Location = new System.Drawing.Point(-262, -29);
            this.labelControl90.Name = "labelControl90";
            this.labelControl90.Size = new System.Drawing.Size(64, 13);
            this.labelControl90.TabIndex = 174;
            this.labelControl90.Text = "Class Owner:";
            // 
            // labelControl89
            // 
            this.labelControl89.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl89.Location = new System.Drawing.Point(-255, -6);
            this.labelControl89.Name = "labelControl89";
            this.labelControl89.Size = new System.Drawing.Size(170, 13);
            this.labelControl89.TabIndex = 175;
            this.labelControl89.Text = "Customer Data Billing Address";
            // 
            // labelControl88
            // 
            this.labelControl88.Location = new System.Drawing.Point(-250, -123);
            this.labelControl88.Name = "labelControl88";
            this.labelControl88.Size = new System.Drawing.Size(52, 13);
            this.labelControl88.TabIndex = 176;
            this.labelControl88.Text = "Address 2:";
            // 
            // textEdit66
            // 
            this.textEdit66.Location = new System.Drawing.Point(-192, -130);
            this.textEdit66.Name = "textEdit66";
            this.spellChecker1.SetShowSpellCheckMenu(this.textEdit66, true);
            this.textEdit66.Size = new System.Drawing.Size(221, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.textEdit66, optionsSpelling155);
            this.textEdit66.TabIndex = 177;
            // 
            // labelControl30
            // 
            this.labelControl30.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))));
            this.labelControl30.Location = new System.Drawing.Point(6, 274);
            this.labelControl30.Name = "labelControl30";
            this.labelControl30.Size = new System.Drawing.Size(52, 13);
            this.labelControl30.TabIndex = 556;
            this.labelControl30.Text = "Purchase";
            // 
            // radioGroup1
            // 
            this.radioGroup1.Location = new System.Drawing.Point(9, 86);
            this.radioGroup1.Name = "radioGroup1";
            this.radioGroup1.Properties.Appearance.BackColor = System.Drawing.Color.Transparent;
            this.radioGroup1.Properties.Appearance.Options.UseBackColor = true;
            this.radioGroup1.Properties.Items.AddRange(new DevExpress.XtraEditors.Controls.RadioGroupItem[] {
            new DevExpress.XtraEditors.Controls.RadioGroupItem(0, "By Day"),
            new DevExpress.XtraEditors.Controls.RadioGroupItem(1, "By Meter"),
            new DevExpress.XtraEditors.Controls.RadioGroupItem(2, "Whichever Occurs First")});
            this.radioGroup1.Size = new System.Drawing.Size(173, 65);
            this.radioGroup1.TabIndex = 0;
            // 
            // labelControl31
            // 
            this.labelControl31.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))));
            this.labelControl31.Location = new System.Drawing.Point(9, 63);
            this.labelControl31.Name = "labelControl31";
            this.labelControl31.Size = new System.Drawing.Size(82, 13);
            this.labelControl31.TabIndex = 577;
            this.labelControl31.Text = "Schedule Type";
            // 
            // panelControl4
            // 
            this.panelControl4.Controls.Add(this.textEdit4);
            this.panelControl4.Controls.Add(this.labelControl32);
            this.panelControl4.Controls.Add(this.textEdit5);
            this.panelControl4.Controls.Add(this.textEdit6);
            this.panelControl4.Controls.Add(this.labelControl33);
            this.panelControl4.Controls.Add(this.labelControl34);
            this.panelControl4.Location = new System.Drawing.Point(9, 20);
            this.panelControl4.Name = "panelControl4";
            this.panelControl4.Size = new System.Drawing.Size(564, 37);
            this.panelControl4.TabIndex = 576;
            // 
            // textEdit4
            // 
            this.textEdit4.Location = new System.Drawing.Point(491, 8);
            this.textEdit4.Name = "textEdit4";
            this.textEdit4.Properties.DisplayFormat.FormatString = "n2";
            this.textEdit4.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.textEdit4.Properties.EditFormat.FormatString = "n2";
            this.textEdit4.Properties.EditFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.textEdit4.Properties.Mask.EditMask = "n2";
            this.textEdit4.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.textEdit4.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.textEdit4.Properties.MaxLength = 20;
            this.textEdit4.Properties.ReadOnly = true;
            this.spellChecker1.SetShowSpellCheckMenu(this.textEdit4, true);
            this.textEdit4.Size = new System.Drawing.Size(59, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.textEdit4, optionsSpelling156);
            this.textEdit4.TabIndex = 576;
            // 
            // labelControl32
            // 
            this.labelControl32.Location = new System.Drawing.Point(423, 12);
            this.labelControl32.Name = "labelControl32";
            this.labelControl32.Size = new System.Drawing.Size(62, 13);
            this.labelControl32.TabIndex = 575;
            this.labelControl32.Text = "Crrent Meter";
            // 
            // textEdit5
            // 
            this.textEdit5.Location = new System.Drawing.Point(209, 9);
            this.textEdit5.Name = "textEdit5";
            this.textEdit5.Properties.DisplayFormat.FormatString = "c2";
            this.textEdit5.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.textEdit5.Properties.EditFormat.FormatString = "c2";
            this.textEdit5.Properties.EditFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.textEdit5.Properties.Mask.EditMask = "c2";
            this.textEdit5.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.textEdit5.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.textEdit5.Properties.MaxLength = 20;
            this.textEdit5.Properties.ReadOnly = true;
            this.spellChecker1.SetShowSpellCheckMenu(this.textEdit5, true);
            this.textEdit5.Size = new System.Drawing.Size(208, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.textEdit5, optionsSpelling157);
            this.textEdit5.TabIndex = 574;
            // 
            // textEdit6
            // 
            this.textEdit6.Location = new System.Drawing.Point(55, 8);
            this.textEdit6.Name = "textEdit6";
            this.textEdit6.Properties.MaxLength = 15;
            this.textEdit6.Properties.ReadOnly = true;
            this.spellChecker1.SetShowSpellCheckMenu(this.textEdit6, true);
            this.textEdit6.Size = new System.Drawing.Size(82, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.textEdit6, optionsSpelling158);
            this.textEdit6.TabIndex = 573;
            // 
            // labelControl33
            // 
            this.labelControl33.Location = new System.Drawing.Point(143, 12);
            this.labelControl33.Name = "labelControl33";
            this.labelControl33.Size = new System.Drawing.Size(57, 13);
            this.labelControl33.TabIndex = 568;
            this.labelControl33.Text = "Description:";
            // 
            // labelControl34
            // 
            this.labelControl34.Location = new System.Drawing.Point(5, 11);
            this.labelControl34.Name = "labelControl34";
            this.labelControl34.Size = new System.Drawing.Size(44, 13);
            this.labelControl34.TabIndex = 24;
            this.labelControl34.Text = "Tool No.:";
            // 
            // labelControl35
            // 
            this.labelControl35.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))));
            this.labelControl35.Location = new System.Drawing.Point(9, 3);
            this.labelControl35.Name = "labelControl35";
            this.labelControl35.Size = new System.Drawing.Size(53, 13);
            this.labelControl35.TabIndex = 575;
            this.labelControl35.Text = "Tool Info.";
            // 
            // textEdit7
            // 
            this.textEdit7.Location = new System.Drawing.Point(349, 296);
            this.textEdit7.Name = "textEdit7";
            this.textEdit7.Properties.MaxLength = 50;
            this.spellChecker1.SetShowSpellCheckMenu(this.textEdit7, true);
            this.textEdit7.Size = new System.Drawing.Size(0, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.textEdit7, optionsSpelling159);
            this.textEdit7.TabIndex = 564;
            // 
            // memoEdit1
            // 
            this.memoEdit1.Location = new System.Drawing.Point(8, 428);
            this.memoEdit1.Name = "memoEdit1";
            this.spellChecker1.SetShowSpellCheckMenu(this.memoEdit1, true);
            this.memoEdit1.Size = new System.Drawing.Size(682, 59);
            this.spellChecker1.SetSpellCheckerOptions(this.memoEdit1, optionsSpelling160);
            this.memoEdit1.TabIndex = 563;
            // 
            // labelControl36
            // 
            this.labelControl36.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))));
            this.labelControl36.Location = new System.Drawing.Point(6, 409);
            this.labelControl36.Name = "labelControl36";
            this.labelControl36.Size = new System.Drawing.Size(35, 13);
            this.labelControl36.TabIndex = 562;
            this.labelControl36.Text = "Notes:";
            // 
            // panelControl6
            // 
            this.panelControl6.Controls.Add(this.dateEdit1);
            this.panelControl6.Controls.Add(this.lookUpEdit1);
            this.panelControl6.Controls.Add(this.labelControl38);
            this.panelControl6.Controls.Add(this.lookUpEdit2);
            this.panelControl6.Controls.Add(this.lookUpEdit4);
            this.panelControl6.Controls.Add(this.lookUpEdit5);
            this.panelControl6.Controls.Add(this.textEdit8);
            this.panelControl6.Controls.Add(this.textEdit9);
            this.panelControl6.Controls.Add(this.dateEdit2);
            this.panelControl6.Controls.Add(this.comboBoxEdit1);
            this.panelControl6.Controls.Add(this.labelControl39);
            this.panelControl6.Controls.Add(this.labelControl40);
            this.panelControl6.Controls.Add(this.labelControl41);
            this.panelControl6.Controls.Add(this.labelControl42);
            this.panelControl6.Controls.Add(this.labelControl43);
            this.panelControl6.Controls.Add(this.lookUpEdit6);
            this.panelControl6.Controls.Add(this.dateEdit3);
            this.panelControl6.Controls.Add(this.labelControl44);
            this.panelControl6.Controls.Add(this.dateEdit4);
            this.panelControl6.Controls.Add(this.textEdit10);
            this.panelControl6.Controls.Add(this.textEdit11);
            this.panelControl6.Controls.Add(this.labelControl45);
            this.panelControl6.Controls.Add(this.textEdit12);
            this.panelControl6.Controls.Add(this.textEdit13);
            this.panelControl6.Controls.Add(this.labelControl46);
            this.panelControl6.Controls.Add(this.labelControl47);
            this.panelControl6.Controls.Add(this.labelControl52);
            this.panelControl6.Controls.Add(this.labelControl55);
            this.panelControl6.Controls.Add(this.labelControl57);
            this.panelControl6.Controls.Add(this.labelControl58);
            this.panelControl6.Controls.Add(this.labelControl105);
            this.panelControl6.Location = new System.Drawing.Point(258, 294);
            this.panelControl6.Name = "panelControl6";
            this.panelControl6.Size = new System.Drawing.Size(432, 113);
            this.panelControl6.TabIndex = 561;
            // 
            // dateEdit1
            // 
            this.dateEdit1.EditValue = null;
            this.dateEdit1.Location = new System.Drawing.Point(285, 25);
            this.dateEdit1.Name = "dateEdit1";
            this.dateEdit1.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.dateEdit1.Properties.CalendarTimeProperties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton()});
            this.dateEdit1.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.dateEdit1.Size = new System.Drawing.Size(142, 20);
            this.dateEdit1.TabIndex = 595;
            // 
            // lookUpEdit1
            // 
            this.lookUpEdit1.Location = new System.Drawing.Point(89, 45);
            this.lookUpEdit1.Name = "lookUpEdit1";
            this.lookUpEdit1.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.lookUpEdit1.Properties.NullText = "";
            this.lookUpEdit1.Properties.TextEditStyle = DevExpress.XtraEditors.Controls.TextEditStyles.Standard;
            this.lookUpEdit1.Size = new System.Drawing.Size(123, 20);
            this.lookUpEdit1.TabIndex = 594;
            // 
            // labelControl38
            // 
            this.labelControl38.Location = new System.Drawing.Point(109, 10);
            this.labelControl38.Name = "labelControl38";
            this.labelControl38.Size = new System.Drawing.Size(33, 13);
            this.labelControl38.TabIndex = 574;
            this.labelControl38.Text = "Office:";
            // 
            // lookUpEdit2
            // 
            this.lookUpEdit2.Location = new System.Drawing.Point(285, 6);
            this.lookUpEdit2.Name = "lookUpEdit2";
            this.lookUpEdit2.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.lookUpEdit2.Properties.NullText = "";
            this.lookUpEdit2.Properties.TextEditStyle = DevExpress.XtraEditors.Controls.TextEditStyles.Standard;
            this.lookUpEdit2.Size = new System.Drawing.Size(142, 20);
            this.lookUpEdit2.TabIndex = 593;
            // 
            // lookUpEdit4
            // 
            this.lookUpEdit4.Location = new System.Drawing.Point(189, 7);
            this.lookUpEdit4.Name = "lookUpEdit4";
            this.lookUpEdit4.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.lookUpEdit4.Properties.NullText = "";
            this.lookUpEdit4.Properties.TextEditStyle = DevExpress.XtraEditors.Controls.TextEditStyles.Standard;
            this.lookUpEdit4.Size = new System.Drawing.Size(160, 20);
            this.lookUpEdit4.TabIndex = 573;
            // 
            // lookUpEdit5
            // 
            this.lookUpEdit5.Location = new System.Drawing.Point(188, 67);
            this.lookUpEdit5.Name = "lookUpEdit5";
            this.lookUpEdit5.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.lookUpEdit5.Properties.NullText = "";
            this.lookUpEdit5.Properties.TextEditStyle = DevExpress.XtraEditors.Controls.TextEditStyles.Standard;
            this.lookUpEdit5.Size = new System.Drawing.Size(162, 20);
            this.lookUpEdit5.TabIndex = 565;
            // 
            // textEdit8
            // 
            this.textEdit8.Location = new System.Drawing.Point(285, 67);
            this.textEdit8.Name = "textEdit8";
            this.textEdit8.Properties.MaxLength = 12;
            this.spellChecker1.SetShowSpellCheckMenu(this.textEdit8, true);
            this.textEdit8.Size = new System.Drawing.Size(142, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.textEdit8, optionsSpelling161);
            this.textEdit8.TabIndex = 592;
            // 
            // textEdit9
            // 
            this.textEdit9.Location = new System.Drawing.Point(285, 47);
            this.textEdit9.Name = "textEdit9";
            this.textEdit9.Properties.DisplayFormat.FormatString = "n2";
            this.textEdit9.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.textEdit9.Properties.EditFormat.FormatString = "n2";
            this.textEdit9.Properties.EditFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.textEdit9.Properties.Mask.EditMask = "n2";
            this.textEdit9.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.textEdit9.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.textEdit9.Properties.MaxLength = 20;
            this.spellChecker1.SetShowSpellCheckMenu(this.textEdit9, true);
            this.textEdit9.Size = new System.Drawing.Size(75, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.textEdit9, optionsSpelling162);
            this.textEdit9.TabIndex = 574;
            // 
            // dateEdit2
            // 
            this.dateEdit2.EditValue = null;
            this.dateEdit2.Location = new System.Drawing.Point(285, 87);
            this.dateEdit2.Name = "dateEdit2";
            this.dateEdit2.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.dateEdit2.Properties.CalendarTimeProperties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton()});
            this.dateEdit2.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.dateEdit2.Size = new System.Drawing.Size(142, 20);
            this.dateEdit2.TabIndex = 590;
            // 
            // comboBoxEdit1
            // 
            this.comboBoxEdit1.EditValue = "";
            this.comboBoxEdit1.Location = new System.Drawing.Point(363, 47);
            this.comboBoxEdit1.Name = "comboBoxEdit1";
            this.comboBoxEdit1.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.comboBoxEdit1.Properties.Items.AddRange(new object[] {
            "BX",
            "C",
            "CN",
            "D",
            "DZ",
            "EA",
            "FT",
            "GAL",
            "IN",
            "K",
            "M",
            "PK",
            "PR",
            "W"});
            this.comboBoxEdit1.Properties.MaxLength = 10;
            this.comboBoxEdit1.Size = new System.Drawing.Size(64, 20);
            this.comboBoxEdit1.TabIndex = 588;
            // 
            // labelControl39
            // 
            this.labelControl39.Location = new System.Drawing.Point(218, 94);
            this.labelControl39.Name = "labelControl39";
            this.labelControl39.Size = new System.Drawing.Size(59, 13);
            this.labelControl39.TabIndex = 585;
            this.labelControl39.Text = "Next Count:";
            // 
            // labelControl40
            // 
            this.labelControl40.Location = new System.Drawing.Point(218, 74);
            this.labelControl40.Name = "labelControl40";
            this.labelControl40.Size = new System.Drawing.Size(18, 13);
            this.labelControl40.TabIndex = 584;
            this.labelControl40.Text = "Bin:";
            // 
            // labelControl41
            // 
            this.labelControl41.Location = new System.Drawing.Point(218, 54);
            this.labelControl41.Name = "labelControl41";
            this.labelControl41.Size = new System.Drawing.Size(32, 13);
            this.labelControl41.TabIndex = 583;
            this.labelControl41.Text = "Meter:";
            // 
            // labelControl42
            // 
            this.labelControl42.Location = new System.Drawing.Point(218, 14);
            this.labelControl42.Name = "labelControl42";
            this.labelControl42.Size = new System.Drawing.Size(35, 13);
            this.labelControl42.TabIndex = 582;
            this.labelControl42.Text = "Status:";
            this.labelControl42.Visible = false;
            // 
            // labelControl43
            // 
            this.labelControl43.Location = new System.Drawing.Point(218, 33);
            this.labelControl43.Name = "labelControl43";
            this.labelControl43.Size = new System.Drawing.Size(52, 13);
            this.labelControl43.TabIndex = 581;
            this.labelControl43.Text = "Expiration:";
            // 
            // lookUpEdit6
            // 
            this.lookUpEdit6.Location = new System.Drawing.Point(188, 87);
            this.lookUpEdit6.Name = "lookUpEdit6";
            this.lookUpEdit6.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.lookUpEdit6.Properties.NullText = "";
            this.lookUpEdit6.Properties.TextEditStyle = DevExpress.XtraEditors.Controls.TextEditStyles.Standard;
            this.lookUpEdit6.Size = new System.Drawing.Size(162, 20);
            this.lookUpEdit6.TabIndex = 34;
            // 
            // dateEdit3
            // 
            this.dateEdit3.EditValue = null;
            this.dateEdit3.Location = new System.Drawing.Point(89, 85);
            this.dateEdit3.Name = "dateEdit3";
            this.dateEdit3.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.dateEdit3.Properties.CalendarTimeProperties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton()});
            this.dateEdit3.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.dateEdit3.Size = new System.Drawing.Size(123, 20);
            this.dateEdit3.TabIndex = 580;
            // 
            // labelControl44
            // 
            this.labelControl44.Location = new System.Drawing.Point(111, 30);
            this.labelControl44.Name = "labelControl44";
            this.labelControl44.Size = new System.Drawing.Size(44, 13);
            this.labelControl44.TabIndex = 23;
            this.labelControl44.Text = "Tool No.:";
            // 
            // dateEdit4
            // 
            this.dateEdit4.EditValue = null;
            this.dateEdit4.Location = new System.Drawing.Point(89, 65);
            this.dateEdit4.Name = "dateEdit4";
            this.dateEdit4.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.dateEdit4.Properties.CalendarTimeProperties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton()});
            this.dateEdit4.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.dateEdit4.Properties.ReadOnly = true;
            this.dateEdit4.Size = new System.Drawing.Size(123, 20);
            this.dateEdit4.TabIndex = 579;
            // 
            // textEdit10
            // 
            this.textEdit10.Location = new System.Drawing.Point(188, 27);
            this.textEdit10.Name = "textEdit10";
            this.textEdit10.Properties.MaxLength = 15;
            this.spellChecker1.SetShowSpellCheckMenu(this.textEdit10, true);
            this.textEdit10.Size = new System.Drawing.Size(161, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.textEdit10, optionsSpelling163);
            this.textEdit10.TabIndex = 24;
            // 
            // textEdit11
            // 
            this.textEdit11.Location = new System.Drawing.Point(89, 5);
            this.textEdit11.Name = "textEdit11";
            this.textEdit11.Properties.MaxLength = 20;
            this.spellChecker1.SetShowSpellCheckMenu(this.textEdit11, true);
            this.textEdit11.Size = new System.Drawing.Size(123, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.textEdit11, optionsSpelling164);
            this.textEdit11.TabIndex = 577;
            // 
            // labelControl45
            // 
            this.labelControl45.Location = new System.Drawing.Point(111, 49);
            this.labelControl45.Name = "labelControl45";
            this.labelControl45.Size = new System.Drawing.Size(48, 13);
            this.labelControl45.TabIndex = 535;
            this.labelControl45.Text = "Bar Code:";
            // 
            // textEdit12
            // 
            this.textEdit12.Location = new System.Drawing.Point(89, 25);
            this.textEdit12.Name = "textEdit12";
            this.textEdit12.Properties.MaxLength = 15;
            this.spellChecker1.SetShowSpellCheckMenu(this.textEdit12, true);
            this.textEdit12.Size = new System.Drawing.Size(123, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.textEdit12, optionsSpelling165);
            this.textEdit12.TabIndex = 573;
            // 
            // textEdit13
            // 
            this.textEdit13.Location = new System.Drawing.Point(188, 47);
            this.textEdit13.Name = "textEdit13";
            this.textEdit13.Properties.MaxLength = 15;
            this.spellChecker1.SetShowSpellCheckMenu(this.textEdit13, true);
            this.textEdit13.Size = new System.Drawing.Size(161, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.textEdit13, optionsSpelling166);
            this.textEdit13.TabIndex = 25;
            // 
            // labelControl46
            // 
            this.labelControl46.Location = new System.Drawing.Point(11, 91);
            this.labelControl46.Name = "labelControl46";
            this.labelControl46.Size = new System.Drawing.Size(71, 13);
            this.labelControl46.TabIndex = 570;
            this.labelControl46.Text = "Date Counted:";
            // 
            // labelControl47
            // 
            this.labelControl47.Location = new System.Drawing.Point(111, 76);
            this.labelControl47.Name = "labelControl47";
            this.labelControl47.Size = new System.Drawing.Size(61, 13);
            this.labelControl47.TabIndex = 536;
            this.labelControl47.Text = "Department:";
            // 
            // labelControl52
            // 
            this.labelControl52.Location = new System.Drawing.Point(11, 71);
            this.labelControl52.Name = "labelControl52";
            this.labelControl52.Size = new System.Drawing.Size(63, 13);
            this.labelControl52.TabIndex = 569;
            this.labelControl52.Text = "Return Date:";
            // 
            // labelControl55
            // 
            this.labelControl55.Location = new System.Drawing.Point(111, 96);
            this.labelControl55.Name = "labelControl55";
            this.labelControl55.Size = new System.Drawing.Size(29, 13);
            this.labelControl55.TabIndex = 554;
            this.labelControl55.Text = "Class:";
            // 
            // labelControl57
            // 
            this.labelControl57.Location = new System.Drawing.Point(11, 51);
            this.labelControl57.Name = "labelControl57";
            this.labelControl57.Size = new System.Drawing.Size(62, 13);
            this.labelControl57.TabIndex = 568;
            this.labelControl57.Text = "Assigned To:";
            // 
            // labelControl58
            // 
            this.labelControl58.Location = new System.Drawing.Point(11, 11);
            this.labelControl58.Name = "labelControl58";
            this.labelControl58.Size = new System.Drawing.Size(50, 13);
            this.labelControl58.TabIndex = 567;
            this.labelControl58.Text = "Serial No.:";
            this.labelControl58.Visible = false;
            // 
            // labelControl105
            // 
            this.labelControl105.Location = new System.Drawing.Point(11, 30);
            this.labelControl105.Name = "labelControl105";
            this.labelControl105.Size = new System.Drawing.Size(66, 13);
            this.labelControl105.TabIndex = 24;
            this.labelControl105.Text = "License Plate:";
            // 
            // labelControl106
            // 
            this.labelControl106.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))));
            this.labelControl106.Location = new System.Drawing.Point(265, 277);
            this.labelControl106.Name = "labelControl106";
            this.labelControl106.Size = new System.Drawing.Size(50, 13);
            this.labelControl106.TabIndex = 560;
            this.labelControl106.Text = "Tool Info";
            // 
            // panelControl7
            // 
            this.panelControl7.Controls.Add(this.dateEdit5);
            this.panelControl7.Controls.Add(this.dateEdit6);
            this.panelControl7.Controls.Add(this.textEdit14);
            this.panelControl7.Controls.Add(this.textEdit15);
            this.panelControl7.Controls.Add(this.labelControl107);
            this.panelControl7.Controls.Add(this.labelControl108);
            this.panelControl7.Controls.Add(this.labelControl109);
            this.panelControl7.Controls.Add(this.labelControl110);
            this.panelControl7.Location = new System.Drawing.Point(8, 294);
            this.panelControl7.Name = "panelControl7";
            this.panelControl7.Size = new System.Drawing.Size(239, 113);
            this.panelControl7.TabIndex = 557;
            // 
            // dateEdit5
            // 
            this.dateEdit5.EditValue = null;
            this.dateEdit5.Location = new System.Drawing.Point(78, 69);
            this.dateEdit5.Name = "dateEdit5";
            this.dateEdit5.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.dateEdit5.Properties.CalendarTimeProperties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton()});
            this.dateEdit5.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.dateEdit5.Size = new System.Drawing.Size(116, 20);
            this.dateEdit5.TabIndex = 578;
            // 
            // dateEdit6
            // 
            this.dateEdit6.EditValue = null;
            this.dateEdit6.Location = new System.Drawing.Point(78, 49);
            this.dateEdit6.Name = "dateEdit6";
            this.dateEdit6.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.dateEdit6.Properties.CalendarTimeProperties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton()});
            this.dateEdit6.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.dateEdit6.Size = new System.Drawing.Size(116, 20);
            this.dateEdit6.TabIndex = 577;
            // 
            // textEdit14
            // 
            this.textEdit14.Location = new System.Drawing.Point(78, 29);
            this.textEdit14.Name = "textEdit14";
            this.textEdit14.Properties.DisplayFormat.FormatString = "c2";
            this.textEdit14.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.textEdit14.Properties.EditFormat.FormatString = "c2";
            this.textEdit14.Properties.EditFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.textEdit14.Properties.Mask.EditMask = "c2";
            this.textEdit14.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.textEdit14.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.textEdit14.Properties.MaxLength = 20;
            this.spellChecker1.SetShowSpellCheckMenu(this.textEdit14, true);
            this.textEdit14.Size = new System.Drawing.Size(116, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.textEdit14, optionsSpelling167);
            this.textEdit14.TabIndex = 574;
            // 
            // textEdit15
            // 
            this.textEdit15.Location = new System.Drawing.Point(78, 9);
            this.textEdit15.Name = "textEdit15";
            this.textEdit15.Properties.MaxLength = 15;
            this.spellChecker1.SetShowSpellCheckMenu(this.textEdit15, true);
            this.textEdit15.Size = new System.Drawing.Size(116, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.textEdit15, optionsSpelling168);
            this.textEdit15.TabIndex = 573;
            // 
            // labelControl107
            // 
            this.labelControl107.Location = new System.Drawing.Point(11, 72);
            this.labelControl107.Name = "labelControl107";
            this.labelControl107.Size = new System.Drawing.Size(46, 13);
            this.labelControl107.TabIndex = 570;
            this.labelControl107.Text = "Warranty";
            // 
            // labelControl108
            // 
            this.labelControl108.Location = new System.Drawing.Point(11, 52);
            this.labelControl108.Name = "labelControl108";
            this.labelControl108.Size = new System.Drawing.Size(27, 13);
            this.labelControl108.TabIndex = 569;
            this.labelControl108.Text = "Date:";
            // 
            // labelControl109
            // 
            this.labelControl109.Location = new System.Drawing.Point(11, 32);
            this.labelControl109.Name = "labelControl109";
            this.labelControl109.Size = new System.Drawing.Size(26, 13);
            this.labelControl109.TabIndex = 568;
            this.labelControl109.Text = "Cost:";
            // 
            // labelControl110
            // 
            this.labelControl110.Location = new System.Drawing.Point(11, 11);
            this.labelControl110.Name = "labelControl110";
            this.labelControl110.Size = new System.Drawing.Size(38, 13);
            this.labelControl110.TabIndex = 24;
            this.labelControl110.Text = "PO No.:";
            // 
            // splitContainerControl1
            // 
            this.splitContainerControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainerControl1.Horizontal = false;
            this.splitContainerControl1.Location = new System.Drawing.Point(0, 143);
            this.splitContainerControl1.Name = "splitContainerControl1";
            this.splitContainerControl1.Panel1.Controls.Add(this.xtraTabControl1);
            this.splitContainerControl1.Panel1.Text = "Panel1";
            this.splitContainerControl1.Panel2.Controls.Add(this.grdCostCode);
            this.splitContainerControl1.Panel2.Controls.Add(this.panCostCodes);
            this.splitContainerControl1.Panel2.Text = "Panel2";
            this.splitContainerControl1.Size = new System.Drawing.Size(927, 632);
            this.splitContainerControl1.SplitterPosition = 426;
            this.splitContainerControl1.TabIndex = 649;
            this.splitContainerControl1.Text = "splitContainerControl1";
            // 
            // xtraTabControl1
            // 
            this.xtraTabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.xtraTabControl1.Location = new System.Drawing.Point(0, 0);
            this.xtraTabControl1.Name = "xtraTabControl1";
            this.xtraTabControl1.SelectedTabPage = this.xtraTabPage4;
            this.xtraTabControl1.Size = new System.Drawing.Size(927, 426);
            this.xtraTabControl1.TabIndex = 598;
            this.xtraTabControl1.TabPages.AddRange(new DevExpress.XtraTab.XtraTabPage[] {
            this.xtraTabPage4,
            this.xtraTabPage1,
            this.xtraTabPage2,
            this.xtraTabPage3,
            this.xtraTabPage5});
            // 
            // xtraTabPage4
            // 
            this.xtraTabPage4.AutoScroll = true;
            this.xtraTabPage4.Controls.Add(this.panelControl14);
            this.xtraTabPage4.Controls.Add(this.panelControl8);
            this.xtraTabPage4.Name = "xtraTabPage4";
            this.xtraTabPage4.Size = new System.Drawing.Size(921, 398);
            this.xtraTabPage4.Text = "Change Order";
            // 
            // panelControl14
            // 
            this.panelControl14.Controls.Add(this.txtRecordID);
            this.panelControl14.Controls.Add(this.txtJobChangeOrderApprovedAmount);
            this.panelControl14.Controls.Add(this.txtJobChangeOrderApprovedDate);
            this.panelControl14.Controls.Add(this.txtJobChangeOrderRequestedAmount);
            this.panelControl14.Controls.Add(this.txtJobChangeOrderRequestDate);
            this.panelControl14.Controls.Add(this.txtPriceAdjustment);
            this.panelControl14.Controls.Add(this.txtChangeOrderAmount);
            this.panelControl14.Controls.Add(this.cboJobChangeOrderStatus);
            this.panelControl14.Controls.Add(this.txtJobChangeOrderOwnerNumber);
            this.panelControl14.Controls.Add(this.txtJobChangeOrderCCENumber);
            this.panelControl14.Controls.Add(this.txtJobChangeOrderUserDescription);
            this.panelControl14.Controls.Add(this.cboJobChangeOrderDescription);
            this.panelControl14.Controls.Add(this.txtJobChangeOrderNumber);
            this.panelControl14.Controls.Add(this.labelControl144);
            this.panelControl14.Controls.Add(this.labelControl143);
            this.panelControl14.Controls.Add(this.labelControl142);
            this.panelControl14.Controls.Add(this.labelControl141);
            this.panelControl14.Controls.Add(this.labelControl140);
            this.panelControl14.Controls.Add(this.labelControl139);
            this.panelControl14.Controls.Add(this.labelControl138);
            this.panelControl14.Controls.Add(this.labelControl137);
            this.panelControl14.Controls.Add(this.labelControl82);
            this.panelControl14.Controls.Add(this.labelControl80);
            this.panelControl14.Controls.Add(this.labelControl76);
            this.panelControl14.Controls.Add(this.labelControl73);
            this.panelControl14.Location = new System.Drawing.Point(4, 17);
            this.panelControl14.Name = "panelControl14";
            this.panelControl14.Size = new System.Drawing.Size(520, 300);
            this.panelControl14.TabIndex = 605;
            // 
            // txtRecordID
            // 
            this.txtRecordID.Location = new System.Drawing.Point(153, 145);
            this.txtRecordID.Name = "txtRecordID";
            this.spellChecker1.SetShowSpellCheckMenu(this.txtRecordID, true);
            this.txtRecordID.Size = new System.Drawing.Size(0, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.txtRecordID, optionsSpelling1);
            this.txtRecordID.TabIndex = 595;
            // 
            // txtJobChangeOrderApprovedAmount
            // 
            this.txtJobChangeOrderApprovedAmount.Location = new System.Drawing.Point(395, 119);
            this.txtJobChangeOrderApprovedAmount.Name = "txtJobChangeOrderApprovedAmount";
            this.txtJobChangeOrderApprovedAmount.Properties.DisplayFormat.FormatString = "c2";
            this.txtJobChangeOrderApprovedAmount.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtJobChangeOrderApprovedAmount.Properties.EditFormat.FormatString = "c2";
            this.txtJobChangeOrderApprovedAmount.Properties.EditFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtJobChangeOrderApprovedAmount.Properties.Mask.EditMask = "c2";
            this.txtJobChangeOrderApprovedAmount.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.txtJobChangeOrderApprovedAmount.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.txtJobChangeOrderApprovedAmount.Properties.MaxLength = 20;
            this.spellChecker1.SetShowSpellCheckMenu(this.txtJobChangeOrderApprovedAmount, true);
            this.txtJobChangeOrderApprovedAmount.Size = new System.Drawing.Size(101, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.txtJobChangeOrderApprovedAmount, optionsSpelling2);
            this.txtJobChangeOrderApprovedAmount.TabIndex = 10;
            this.txtJobChangeOrderApprovedAmount.EditValueChanged += new System.EventHandler(this.AllControls_EditValue);
            // 
            // txtJobChangeOrderApprovedDate
            // 
            this.txtJobChangeOrderApprovedDate.EditValue = null;
            this.txtJobChangeOrderApprovedDate.Location = new System.Drawing.Point(395, 89);
            this.txtJobChangeOrderApprovedDate.Name = "txtJobChangeOrderApprovedDate";
            this.txtJobChangeOrderApprovedDate.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.txtJobChangeOrderApprovedDate.Properties.CalendarTimeProperties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton()});
            this.txtJobChangeOrderApprovedDate.Size = new System.Drawing.Size(100, 20);
            this.txtJobChangeOrderApprovedDate.TabIndex = 9;
            this.txtJobChangeOrderApprovedDate.EditValueChanged += new System.EventHandler(this.AllControls_EditValue);
            // 
            // txtJobChangeOrderRequestedAmount
            // 
            this.txtJobChangeOrderRequestedAmount.Location = new System.Drawing.Point(395, 63);
            this.txtJobChangeOrderRequestedAmount.Name = "txtJobChangeOrderRequestedAmount";
            this.txtJobChangeOrderRequestedAmount.Properties.DisplayFormat.FormatString = "c2";
            this.txtJobChangeOrderRequestedAmount.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtJobChangeOrderRequestedAmount.Properties.EditFormat.FormatString = "c2";
            this.txtJobChangeOrderRequestedAmount.Properties.EditFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtJobChangeOrderRequestedAmount.Properties.Mask.EditMask = "c2";
            this.txtJobChangeOrderRequestedAmount.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.txtJobChangeOrderRequestedAmount.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.txtJobChangeOrderRequestedAmount.Properties.MaxLength = 20;
            this.txtJobChangeOrderRequestedAmount.Properties.ReadOnly = true;
            this.spellChecker1.SetShowSpellCheckMenu(this.txtJobChangeOrderRequestedAmount, true);
            this.txtJobChangeOrderRequestedAmount.Size = new System.Drawing.Size(101, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.txtJobChangeOrderRequestedAmount, optionsSpelling3);
            this.txtJobChangeOrderRequestedAmount.TabIndex = 8;
            this.txtJobChangeOrderRequestedAmount.EditValueChanged += new System.EventHandler(this.AllControls_EditValue);
            // 
            // txtJobChangeOrderRequestDate
            // 
            this.txtJobChangeOrderRequestDate.EditValue = null;
            this.txtJobChangeOrderRequestDate.Location = new System.Drawing.Point(395, 37);
            this.txtJobChangeOrderRequestDate.Name = "txtJobChangeOrderRequestDate";
            this.txtJobChangeOrderRequestDate.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.txtJobChangeOrderRequestDate.Properties.CalendarTimeProperties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton()});
            this.txtJobChangeOrderRequestDate.Size = new System.Drawing.Size(100, 20);
            this.txtJobChangeOrderRequestDate.TabIndex = 7;
            this.txtJobChangeOrderRequestDate.EditValueChanged += new System.EventHandler(this.AllControls_EditValue);
            // 
            // txtPriceAdjustment
            // 
            this.txtPriceAdjustment.Location = new System.Drawing.Point(317, 250);
            this.txtPriceAdjustment.Name = "txtPriceAdjustment";
            this.txtPriceAdjustment.Properties.DisplayFormat.FormatString = "c2";
            this.txtPriceAdjustment.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtPriceAdjustment.Properties.EditFormat.FormatString = "c2";
            this.txtPriceAdjustment.Properties.EditFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtPriceAdjustment.Properties.Mask.EditMask = "c2";
            this.txtPriceAdjustment.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.txtPriceAdjustment.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.txtPriceAdjustment.Properties.MaxLength = 20;
            this.spellChecker1.SetShowSpellCheckMenu(this.txtPriceAdjustment, true);
            this.txtPriceAdjustment.Size = new System.Drawing.Size(101, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.txtPriceAdjustment, optionsSpelling4);
            this.txtPriceAdjustment.TabIndex = 6;
            this.txtPriceAdjustment.Visible = false;
            this.txtPriceAdjustment.EditValueChanged += new System.EventHandler(this.AllControls_EditValue);
            // 
            // txtChangeOrderAmount
            // 
            this.txtChangeOrderAmount.Location = new System.Drawing.Point(200, 250);
            this.txtChangeOrderAmount.Name = "txtChangeOrderAmount";
            this.txtChangeOrderAmount.Properties.DisplayFormat.FormatString = "c2";
            this.txtChangeOrderAmount.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtChangeOrderAmount.Properties.EditFormat.FormatString = "c2";
            this.txtChangeOrderAmount.Properties.EditFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtChangeOrderAmount.Properties.Mask.EditMask = "c2";
            this.txtChangeOrderAmount.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.txtChangeOrderAmount.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.txtChangeOrderAmount.Properties.MaxLength = 20;
            this.txtChangeOrderAmount.Properties.ReadOnly = true;
            this.spellChecker1.SetShowSpellCheckMenu(this.txtChangeOrderAmount, true);
            this.txtChangeOrderAmount.Size = new System.Drawing.Size(101, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.txtChangeOrderAmount, optionsSpelling5);
            this.txtChangeOrderAmount.TabIndex = 5;
            this.txtChangeOrderAmount.Visible = false;
            this.txtChangeOrderAmount.EditValueChanged += new System.EventHandler(this.AllControls_EditValue);
            // 
            // cboJobChangeOrderStatus
            // 
            this.cboJobChangeOrderStatus.Location = new System.Drawing.Point(395, 11);
            this.cboJobChangeOrderStatus.Name = "cboJobChangeOrderStatus";
            this.cboJobChangeOrderStatus.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.cboJobChangeOrderStatus.Properties.Items.AddRange(new object[] {
            "APPROVED",
            "PENDING"});
            this.cboJobChangeOrderStatus.Size = new System.Drawing.Size(103, 20);
            this.cboJobChangeOrderStatus.TabIndex = 4;
            this.cboJobChangeOrderStatus.EditValueChanged += new System.EventHandler(this.AllControls_EditValue);
            // 
            // txtJobChangeOrderOwnerNumber
            // 
            this.txtJobChangeOrderOwnerNumber.Location = new System.Drawing.Point(90, 93);
            this.txtJobChangeOrderOwnerNumber.Name = "txtJobChangeOrderOwnerNumber";
            this.txtJobChangeOrderOwnerNumber.Properties.MaxLength = 5;
            this.spellChecker1.SetShowSpellCheckMenu(this.txtJobChangeOrderOwnerNumber, true);
            this.txtJobChangeOrderOwnerNumber.Size = new System.Drawing.Size(138, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.txtJobChangeOrderOwnerNumber, optionsSpelling6);
            this.txtJobChangeOrderOwnerNumber.TabIndex = 3;
            this.txtJobChangeOrderOwnerNumber.EditValueChanged += new System.EventHandler(this.AllControls_EditValue);
            // 
            // txtJobChangeOrderCCENumber
            // 
            this.txtJobChangeOrderCCENumber.Location = new System.Drawing.Point(90, 67);
            this.txtJobChangeOrderCCENumber.Name = "txtJobChangeOrderCCENumber";
            this.txtJobChangeOrderCCENumber.Properties.MaxLength = 20;
            this.spellChecker1.SetShowSpellCheckMenu(this.txtJobChangeOrderCCENumber, true);
            this.txtJobChangeOrderCCENumber.Size = new System.Drawing.Size(138, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.txtJobChangeOrderCCENumber, optionsSpelling7);
            this.txtJobChangeOrderCCENumber.TabIndex = 2;
            this.txtJobChangeOrderCCENumber.EditValueChanged += new System.EventHandler(this.AllControls_EditValue);
            // 
            // txtJobChangeOrderUserDescription
            // 
            this.txtJobChangeOrderUserDescription.Location = new System.Drawing.Point(90, 142);
            this.txtJobChangeOrderUserDescription.Name = "txtJobChangeOrderUserDescription";
            this.txtJobChangeOrderUserDescription.Properties.MaxLength = 50;
            this.spellChecker1.SetShowSpellCheckMenu(this.txtJobChangeOrderUserDescription, true);
            this.txtJobChangeOrderUserDescription.Size = new System.Drawing.Size(312, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.txtJobChangeOrderUserDescription, optionsSpelling8);
            this.txtJobChangeOrderUserDescription.TabIndex = 11;
            this.txtJobChangeOrderUserDescription.EditValueChanged += new System.EventHandler(this.AllControls_EditValue);
            // 
            // cboJobChangeOrderDescription
            // 
            this.cboJobChangeOrderDescription.Location = new System.Drawing.Point(90, 37);
            this.cboJobChangeOrderDescription.Name = "cboJobChangeOrderDescription";
            this.cboJobChangeOrderDescription.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.cboJobChangeOrderDescription.Size = new System.Drawing.Size(191, 20);
            this.cboJobChangeOrderDescription.TabIndex = 1;
            this.cboJobChangeOrderDescription.EditValueChanged += new System.EventHandler(this.AllControls_EditValue);
            // 
            // txtJobChangeOrderNumber
            // 
            this.txtJobChangeOrderNumber.Location = new System.Drawing.Point(90, 11);
            this.txtJobChangeOrderNumber.Name = "txtJobChangeOrderNumber";
            this.txtJobChangeOrderNumber.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.txtJobChangeOrderNumber.Properties.MaxLength = 20;
            this.txtJobChangeOrderNumber.Properties.ReadOnly = true;
            this.spellChecker1.SetShowSpellCheckMenu(this.txtJobChangeOrderNumber, true);
            this.txtJobChangeOrderNumber.Size = new System.Drawing.Size(73, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.txtJobChangeOrderNumber, optionsSpelling9);
            this.txtJobChangeOrderNumber.TabIndex = 0;
            this.txtJobChangeOrderNumber.TabStop = false;
            // 
            // labelControl144
            // 
            this.labelControl144.Location = new System.Drawing.Point(105, 275);
            this.labelControl144.Name = "labelControl144";
            this.labelControl144.Size = new System.Drawing.Size(85, 13);
            this.labelControl144.TabIndex = 582;
            this.labelControl144.Text = "Price Adjustment:";
            this.labelControl144.Visible = false;
            // 
            // labelControl143
            // 
            this.labelControl143.Location = new System.Drawing.Point(90, 253);
            this.labelControl143.Name = "labelControl143";
            this.labelControl143.Size = new System.Drawing.Size(79, 13);
            this.labelControl143.TabIndex = 581;
            this.labelControl143.Text = "Charge Amount:";
            this.labelControl143.Visible = false;
            // 
            // labelControl142
            // 
            this.labelControl142.Location = new System.Drawing.Point(296, 14);
            this.labelControl142.Name = "labelControl142";
            this.labelControl142.Size = new System.Drawing.Size(93, 13);
            this.labelControl142.TabIndex = 580;
            this.labelControl142.Text = "Pending/Approved:";
            // 
            // labelControl141
            // 
            this.labelControl141.Location = new System.Drawing.Point(6, 71);
            this.labelControl141.Name = "labelControl141";
            this.labelControl141.Size = new System.Drawing.Size(47, 13);
            this.labelControl141.TabIndex = 579;
            this.labelControl141.Text = "Owner #:";
            // 
            // labelControl140
            // 
            this.labelControl140.Location = new System.Drawing.Point(6, 96);
            this.labelControl140.Name = "labelControl140";
            this.labelControl140.Size = new System.Drawing.Size(29, 13);
            this.labelControl140.TabIndex = 578;
            this.labelControl140.Text = "GC #:";
            // 
            // labelControl139
            // 
            this.labelControl139.Location = new System.Drawing.Point(6, 145);
            this.labelControl139.Name = "labelControl139";
            this.labelControl139.Size = new System.Drawing.Size(57, 13);
            this.labelControl139.TabIndex = 577;
            this.labelControl139.Text = "Description:";
            // 
            // labelControl138
            // 
            this.labelControl138.Location = new System.Drawing.Point(5, 40);
            this.labelControl138.Name = "labelControl138";
            this.labelControl138.Size = new System.Drawing.Size(35, 13);
            this.labelControl138.TabIndex = 576;
            this.labelControl138.Text = "Status:";
            // 
            // labelControl137
            // 
            this.labelControl137.Location = new System.Drawing.Point(296, 122);
            this.labelControl137.Name = "labelControl137";
            this.labelControl137.Size = new System.Drawing.Size(91, 13);
            this.labelControl137.TabIndex = 575;
            this.labelControl137.Text = "Approved Amount:";
            // 
            // labelControl82
            // 
            this.labelControl82.Location = new System.Drawing.Point(296, 96);
            this.labelControl82.Name = "labelControl82";
            this.labelControl82.Size = new System.Drawing.Size(77, 13);
            this.labelControl82.TabIndex = 574;
            this.labelControl82.Text = "Approved Date:";
            // 
            // labelControl80
            // 
            this.labelControl80.Location = new System.Drawing.Point(296, 67);
            this.labelControl80.Name = "labelControl80";
            this.labelControl80.Size = new System.Drawing.Size(96, 13);
            this.labelControl80.TabIndex = 573;
            this.labelControl80.Text = "Requested Amount:";
            // 
            // labelControl76
            // 
            this.labelControl76.Location = new System.Drawing.Point(296, 40);
            this.labelControl76.Name = "labelControl76";
            this.labelControl76.Size = new System.Drawing.Size(82, 13);
            this.labelControl76.TabIndex = 572;
            this.labelControl76.Text = "Requested Date:";
            // 
            // labelControl73
            // 
            this.labelControl73.Location = new System.Drawing.Point(5, 14);
            this.labelControl73.Name = "labelControl73";
            this.labelControl73.Size = new System.Drawing.Size(52, 13);
            this.labelControl73.TabIndex = 571;
            this.labelControl73.Text = "Order No.:";
            // 
            // panelControl8
            // 
            this.panelControl8.Controls.Add(this.labelControl64);
            this.panelControl8.Controls.Add(this.labelControl62);
            this.panelControl8.Controls.Add(this.labelControl56);
            this.panelControl8.Controls.Add(this.labelControl1);
            this.panelControl8.Controls.Add(this.txtProfitPercentBudgetTotals);
            this.panelControl8.Controls.Add(this.txtProfitDollarBudgetTotals);
            this.panelControl8.Controls.Add(this.labelControl53);
            this.panelControl8.Controls.Add(this.txtProfitPercentEstimateDefaults);
            this.panelControl8.Controls.Add(this.txtProfitDollarEstimateDefaults);
            this.panelControl8.Controls.Add(this.labelControl54);
            this.panelControl8.Controls.Add(this.txtSubcontractsBudgetTotals);
            this.panelControl8.Controls.Add(this.txtContractDollarBudgetTotals);
            this.panelControl8.Controls.Add(this.txtTotalCostBudgetTotals);
            this.panelControl8.Controls.Add(this.txtOtherBudgetTotals);
            this.panelControl8.Controls.Add(this.txtMaterialsBudgetTotals);
            this.panelControl8.Controls.Add(this.txtLaborRateBudgetTotals);
            this.panelControl8.Controls.Add(this.txtLaborDollarBudgetTotals);
            this.panelControl8.Controls.Add(this.txtLaborHoursBudgetTotals);
            this.panelControl8.Controls.Add(this.labelControl2);
            this.panelControl8.Controls.Add(this.txtSubcontractsEstimateDefaults);
            this.panelControl8.Controls.Add(this.labelControl26);
            this.panelControl8.Controls.Add(this.txtContractDollarEstimateDefaults);
            this.panelControl8.Controls.Add(this.txtTotalCostEstimateDefaults);
            this.panelControl8.Controls.Add(this.labelControl27);
            this.panelControl8.Controls.Add(this.labelControl28);
            this.panelControl8.Controls.Add(this.txtOtherEstimateDefaults);
            this.panelControl8.Controls.Add(this.labelControl29);
            this.panelControl8.Controls.Add(this.txtMaterialsEstimateDefaults);
            this.panelControl8.Controls.Add(this.txtLaborRateEstimateDefaults);
            this.panelControl8.Controls.Add(this.labelControl37);
            this.panelControl8.Controls.Add(this.labelControl50);
            this.panelControl8.Controls.Add(this.txtLaborDollarEstimateDefaults);
            this.panelControl8.Controls.Add(this.txtLaborHoursEstimateDefaults);
            this.panelControl8.Controls.Add(this.labelControl51);
            this.panelControl8.Location = new System.Drawing.Point(530, 17);
            this.panelControl8.Name = "panelControl8";
            this.panelControl8.Size = new System.Drawing.Size(359, 300);
            this.panelControl8.TabIndex = 604;
            // 
            // labelControl64
            // 
            this.labelControl64.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.labelControl64.Location = new System.Drawing.Point(254, 4);
            this.labelControl64.Name = "labelControl64";
            this.labelControl64.Size = new System.Drawing.Size(60, 13);
            this.labelControl64.TabIndex = 602;
            this.labelControl64.Text = "(B) Budget";
            // 
            // labelControl62
            // 
            this.labelControl62.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.labelControl62.Location = new System.Drawing.Point(155, 4);
            this.labelControl62.Name = "labelControl62";
            this.labelControl62.Size = new System.Drawing.Size(74, 13);
            this.labelControl62.TabIndex = 601;
            this.labelControl62.Text = "(A) Estimate ";
            // 
            // labelControl56
            // 
            this.labelControl56.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.labelControl56.Location = new System.Drawing.Point(265, 18);
            this.labelControl56.Name = "labelControl56";
            this.labelControl56.Size = new System.Drawing.Size(35, 13);
            this.labelControl56.TabIndex = 600;
            this.labelControl56.Text = "Totals";
            // 
            // labelControl1
            // 
            this.labelControl1.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.labelControl1.Location = new System.Drawing.Point(169, 18);
            this.labelControl1.Name = "labelControl1";
            this.labelControl1.Size = new System.Drawing.Size(47, 13);
            this.labelControl1.TabIndex = 599;
            this.labelControl1.Text = "Defaults";
            // 
            // txtProfitPercentBudgetTotals
            // 
            this.txtProfitPercentBudgetTotals.Location = new System.Drawing.Point(245, 272);
            this.txtProfitPercentBudgetTotals.Name = "txtProfitPercentBudgetTotals";
            this.txtProfitPercentBudgetTotals.Properties.DisplayFormat.FormatString = "p2";
            this.txtProfitPercentBudgetTotals.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtProfitPercentBudgetTotals.Properties.EditFormat.FormatString = "p2";
            this.txtProfitPercentBudgetTotals.Properties.EditFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtProfitPercentBudgetTotals.Properties.Mask.EditMask = "p2";
            this.txtProfitPercentBudgetTotals.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.txtProfitPercentBudgetTotals.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.txtProfitPercentBudgetTotals.Properties.MaxLength = 20;
            this.txtProfitPercentBudgetTotals.Properties.ReadOnly = true;
            this.spellChecker1.SetShowSpellCheckMenu(this.txtProfitPercentBudgetTotals, true);
            this.txtProfitPercentBudgetTotals.Size = new System.Drawing.Size(73, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.txtProfitPercentBudgetTotals, optionsSpelling10);
            this.txtProfitPercentBudgetTotals.TabIndex = 31;
            this.txtProfitPercentBudgetTotals.TabStop = false;
            // 
            // txtProfitDollarBudgetTotals
            // 
            this.txtProfitDollarBudgetTotals.Location = new System.Drawing.Point(245, 246);
            this.txtProfitDollarBudgetTotals.Name = "txtProfitDollarBudgetTotals";
            this.txtProfitDollarBudgetTotals.Properties.DisplayFormat.FormatString = "c2";
            this.txtProfitDollarBudgetTotals.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtProfitDollarBudgetTotals.Properties.EditFormat.FormatString = "c2";
            this.txtProfitDollarBudgetTotals.Properties.EditFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtProfitDollarBudgetTotals.Properties.Mask.EditMask = "c2";
            this.txtProfitDollarBudgetTotals.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.txtProfitDollarBudgetTotals.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.txtProfitDollarBudgetTotals.Properties.MaxLength = 20;
            this.txtProfitDollarBudgetTotals.Properties.ReadOnly = true;
            this.spellChecker1.SetShowSpellCheckMenu(this.txtProfitDollarBudgetTotals, true);
            this.txtProfitDollarBudgetTotals.Size = new System.Drawing.Size(73, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.txtProfitDollarBudgetTotals, optionsSpelling11);
            this.txtProfitDollarBudgetTotals.TabIndex = 30;
            this.txtProfitDollarBudgetTotals.TabStop = false;
            // 
            // labelControl53
            // 
            this.labelControl53.Location = new System.Drawing.Point(5, 272);
            this.labelControl53.Name = "labelControl53";
            this.labelControl53.Size = new System.Drawing.Size(44, 13);
            this.labelControl53.TabIndex = 596;
            this.labelControl53.Text = "Profit %:";
            // 
            // txtProfitPercentEstimateDefaults
            // 
            this.txtProfitPercentEstimateDefaults.Location = new System.Drawing.Point(155, 271);
            this.txtProfitPercentEstimateDefaults.Name = "txtProfitPercentEstimateDefaults";
            this.txtProfitPercentEstimateDefaults.Properties.DisplayFormat.FormatString = "p2";
            this.txtProfitPercentEstimateDefaults.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtProfitPercentEstimateDefaults.Properties.EditFormat.FormatString = "p2";
            this.txtProfitPercentEstimateDefaults.Properties.EditFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtProfitPercentEstimateDefaults.Properties.Mask.EditMask = "p2";
            this.txtProfitPercentEstimateDefaults.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.txtProfitPercentEstimateDefaults.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.txtProfitPercentEstimateDefaults.Properties.MaxLength = 20;
            this.txtProfitPercentEstimateDefaults.Properties.ReadOnly = true;
            this.spellChecker1.SetShowSpellCheckMenu(this.txtProfitPercentEstimateDefaults, true);
            this.txtProfitPercentEstimateDefaults.Size = new System.Drawing.Size(73, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.txtProfitPercentEstimateDefaults, optionsSpelling12);
            this.txtProfitPercentEstimateDefaults.TabIndex = 21;
            this.txtProfitPercentEstimateDefaults.TabStop = false;
            // 
            // txtProfitDollarEstimateDefaults
            // 
            this.txtProfitDollarEstimateDefaults.Location = new System.Drawing.Point(155, 245);
            this.txtProfitDollarEstimateDefaults.Name = "txtProfitDollarEstimateDefaults";
            this.txtProfitDollarEstimateDefaults.Properties.DisplayFormat.FormatString = "c2";
            this.txtProfitDollarEstimateDefaults.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtProfitDollarEstimateDefaults.Properties.EditFormat.FormatString = "c2";
            this.txtProfitDollarEstimateDefaults.Properties.EditFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtProfitDollarEstimateDefaults.Properties.Mask.EditMask = "c2";
            this.txtProfitDollarEstimateDefaults.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.txtProfitDollarEstimateDefaults.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.txtProfitDollarEstimateDefaults.Properties.MaxLength = 20;
            this.txtProfitDollarEstimateDefaults.Properties.ReadOnly = true;
            this.spellChecker1.SetShowSpellCheckMenu(this.txtProfitDollarEstimateDefaults, true);
            this.txtProfitDollarEstimateDefaults.Size = new System.Drawing.Size(73, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.txtProfitDollarEstimateDefaults, optionsSpelling13);
            this.txtProfitDollarEstimateDefaults.TabIndex = 20;
            this.txtProfitDollarEstimateDefaults.TabStop = false;
            // 
            // labelControl54
            // 
            this.labelControl54.Location = new System.Drawing.Point(5, 248);
            this.labelControl54.Name = "labelControl54";
            this.labelControl54.Size = new System.Drawing.Size(39, 13);
            this.labelControl54.TabIndex = 595;
            this.labelControl54.Text = "Profit $:";
            // 
            // txtSubcontractsBudgetTotals
            // 
            this.txtSubcontractsBudgetTotals.Location = new System.Drawing.Point(245, 168);
            this.txtSubcontractsBudgetTotals.Name = "txtSubcontractsBudgetTotals";
            this.txtSubcontractsBudgetTotals.Properties.DisplayFormat.FormatString = "c2";
            this.txtSubcontractsBudgetTotals.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtSubcontractsBudgetTotals.Properties.EditFormat.FormatString = "c2";
            this.txtSubcontractsBudgetTotals.Properties.EditFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtSubcontractsBudgetTotals.Properties.Mask.EditMask = "c2";
            this.txtSubcontractsBudgetTotals.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.txtSubcontractsBudgetTotals.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.txtSubcontractsBudgetTotals.Properties.MaxLength = 20;
            this.txtSubcontractsBudgetTotals.Properties.ReadOnly = true;
            this.spellChecker1.SetShowSpellCheckMenu(this.txtSubcontractsBudgetTotals, true);
            this.txtSubcontractsBudgetTotals.Size = new System.Drawing.Size(73, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.txtSubcontractsBudgetTotals, optionsSpelling14);
            this.txtSubcontractsBudgetTotals.TabIndex = 27;
            this.txtSubcontractsBudgetTotals.TabStop = false;
            // 
            // txtContractDollarBudgetTotals
            // 
            this.txtContractDollarBudgetTotals.Location = new System.Drawing.Point(245, 220);
            this.txtContractDollarBudgetTotals.Name = "txtContractDollarBudgetTotals";
            this.txtContractDollarBudgetTotals.Properties.DisplayFormat.FormatString = "c2";
            this.txtContractDollarBudgetTotals.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtContractDollarBudgetTotals.Properties.EditFormat.FormatString = "c2";
            this.txtContractDollarBudgetTotals.Properties.EditFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtContractDollarBudgetTotals.Properties.Mask.EditMask = "c2";
            this.txtContractDollarBudgetTotals.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.txtContractDollarBudgetTotals.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.txtContractDollarBudgetTotals.Properties.MaxLength = 20;
            this.txtContractDollarBudgetTotals.Properties.ReadOnly = true;
            this.spellChecker1.SetShowSpellCheckMenu(this.txtContractDollarBudgetTotals, true);
            this.txtContractDollarBudgetTotals.Size = new System.Drawing.Size(73, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.txtContractDollarBudgetTotals, optionsSpelling15);
            this.txtContractDollarBudgetTotals.TabIndex = 29;
            this.txtContractDollarBudgetTotals.TabStop = false;
            // 
            // txtTotalCostBudgetTotals
            // 
            this.txtTotalCostBudgetTotals.Location = new System.Drawing.Point(245, 194);
            this.txtTotalCostBudgetTotals.Name = "txtTotalCostBudgetTotals";
            this.txtTotalCostBudgetTotals.Properties.DisplayFormat.FormatString = "c2";
            this.txtTotalCostBudgetTotals.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtTotalCostBudgetTotals.Properties.EditFormat.FormatString = "c2";
            this.txtTotalCostBudgetTotals.Properties.EditFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtTotalCostBudgetTotals.Properties.Mask.EditMask = "c2";
            this.txtTotalCostBudgetTotals.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.txtTotalCostBudgetTotals.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.txtTotalCostBudgetTotals.Properties.MaxLength = 20;
            this.txtTotalCostBudgetTotals.Properties.ReadOnly = true;
            this.spellChecker1.SetShowSpellCheckMenu(this.txtTotalCostBudgetTotals, true);
            this.txtTotalCostBudgetTotals.Size = new System.Drawing.Size(73, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.txtTotalCostBudgetTotals, optionsSpelling16);
            this.txtTotalCostBudgetTotals.TabIndex = 28;
            this.txtTotalCostBudgetTotals.TabStop = false;
            this.txtTotalCostBudgetTotals.EditValueChanged += new System.EventHandler(this.AllControls_EditValue);
            // 
            // txtOtherBudgetTotals
            // 
            this.txtOtherBudgetTotals.Location = new System.Drawing.Point(245, 142);
            this.txtOtherBudgetTotals.Name = "txtOtherBudgetTotals";
            this.txtOtherBudgetTotals.Properties.DisplayFormat.FormatString = "c2";
            this.txtOtherBudgetTotals.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtOtherBudgetTotals.Properties.EditFormat.FormatString = "c2";
            this.txtOtherBudgetTotals.Properties.EditFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtOtherBudgetTotals.Properties.Mask.EditMask = "c2";
            this.txtOtherBudgetTotals.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.txtOtherBudgetTotals.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.txtOtherBudgetTotals.Properties.MaxLength = 20;
            this.txtOtherBudgetTotals.Properties.ReadOnly = true;
            this.spellChecker1.SetShowSpellCheckMenu(this.txtOtherBudgetTotals, true);
            this.txtOtherBudgetTotals.Size = new System.Drawing.Size(73, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.txtOtherBudgetTotals, optionsSpelling17);
            this.txtOtherBudgetTotals.TabIndex = 26;
            this.txtOtherBudgetTotals.TabStop = false;
            // 
            // txtMaterialsBudgetTotals
            // 
            this.txtMaterialsBudgetTotals.Location = new System.Drawing.Point(245, 116);
            this.txtMaterialsBudgetTotals.Name = "txtMaterialsBudgetTotals";
            this.txtMaterialsBudgetTotals.Properties.DisplayFormat.FormatString = "c2";
            this.txtMaterialsBudgetTotals.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtMaterialsBudgetTotals.Properties.EditFormat.FormatString = "c2";
            this.txtMaterialsBudgetTotals.Properties.EditFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtMaterialsBudgetTotals.Properties.Mask.EditMask = "c2";
            this.txtMaterialsBudgetTotals.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.txtMaterialsBudgetTotals.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.txtMaterialsBudgetTotals.Properties.MaxLength = 20;
            this.txtMaterialsBudgetTotals.Properties.ReadOnly = true;
            this.spellChecker1.SetShowSpellCheckMenu(this.txtMaterialsBudgetTotals, true);
            this.txtMaterialsBudgetTotals.Size = new System.Drawing.Size(73, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.txtMaterialsBudgetTotals, optionsSpelling18);
            this.txtMaterialsBudgetTotals.TabIndex = 25;
            this.txtMaterialsBudgetTotals.TabStop = false;
            // 
            // txtLaborRateBudgetTotals
            // 
            this.txtLaborRateBudgetTotals.Location = new System.Drawing.Point(245, 90);
            this.txtLaborRateBudgetTotals.Name = "txtLaborRateBudgetTotals";
            this.txtLaborRateBudgetTotals.Properties.DisplayFormat.FormatString = "c2";
            this.txtLaborRateBudgetTotals.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtLaborRateBudgetTotals.Properties.EditFormat.FormatString = "c2";
            this.txtLaborRateBudgetTotals.Properties.EditFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtLaborRateBudgetTotals.Properties.Mask.EditMask = "c2";
            this.txtLaborRateBudgetTotals.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.txtLaborRateBudgetTotals.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.txtLaborRateBudgetTotals.Properties.MaxLength = 20;
            this.txtLaborRateBudgetTotals.Properties.ReadOnly = true;
            this.spellChecker1.SetShowSpellCheckMenu(this.txtLaborRateBudgetTotals, true);
            this.txtLaborRateBudgetTotals.Size = new System.Drawing.Size(73, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.txtLaborRateBudgetTotals, optionsSpelling19);
            this.txtLaborRateBudgetTotals.TabIndex = 24;
            this.txtLaborRateBudgetTotals.TabStop = false;
            // 
            // txtLaborDollarBudgetTotals
            // 
            this.txtLaborDollarBudgetTotals.Location = new System.Drawing.Point(245, 64);
            this.txtLaborDollarBudgetTotals.Name = "txtLaborDollarBudgetTotals";
            this.txtLaborDollarBudgetTotals.Properties.DisplayFormat.FormatString = "c2";
            this.txtLaborDollarBudgetTotals.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtLaborDollarBudgetTotals.Properties.EditFormat.FormatString = "c2";
            this.txtLaborDollarBudgetTotals.Properties.EditFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtLaborDollarBudgetTotals.Properties.Mask.EditMask = "c2";
            this.txtLaborDollarBudgetTotals.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.txtLaborDollarBudgetTotals.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.txtLaborDollarBudgetTotals.Properties.MaxLength = 20;
            this.txtLaborDollarBudgetTotals.Properties.ReadOnly = true;
            this.spellChecker1.SetShowSpellCheckMenu(this.txtLaborDollarBudgetTotals, true);
            this.txtLaborDollarBudgetTotals.Size = new System.Drawing.Size(73, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.txtLaborDollarBudgetTotals, optionsSpelling20);
            this.txtLaborDollarBudgetTotals.TabIndex = 23;
            this.txtLaborDollarBudgetTotals.TabStop = false;
            // 
            // txtLaborHoursBudgetTotals
            // 
            this.txtLaborHoursBudgetTotals.Location = new System.Drawing.Point(245, 38);
            this.txtLaborHoursBudgetTotals.Name = "txtLaborHoursBudgetTotals";
            this.txtLaborHoursBudgetTotals.Properties.DisplayFormat.FormatString = "n2";
            this.txtLaborHoursBudgetTotals.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtLaborHoursBudgetTotals.Properties.EditFormat.FormatString = "n2";
            this.txtLaborHoursBudgetTotals.Properties.EditFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtLaborHoursBudgetTotals.Properties.Mask.EditMask = "n2";
            this.txtLaborHoursBudgetTotals.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.txtLaborHoursBudgetTotals.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.txtLaborHoursBudgetTotals.Properties.MaxLength = 20;
            this.txtLaborHoursBudgetTotals.Properties.ReadOnly = true;
            this.spellChecker1.SetShowSpellCheckMenu(this.txtLaborHoursBudgetTotals, true);
            this.txtLaborHoursBudgetTotals.Size = new System.Drawing.Size(73, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.txtLaborHoursBudgetTotals, optionsSpelling21);
            this.txtLaborHoursBudgetTotals.TabIndex = 22;
            this.txtLaborHoursBudgetTotals.TabStop = false;
            // 
            // labelControl2
            // 
            this.labelControl2.Location = new System.Drawing.Point(5, 170);
            this.labelControl2.Name = "labelControl2";
            this.labelControl2.Size = new System.Drawing.Size(63, 13);
            this.labelControl2.TabIndex = 584;
            this.labelControl2.Text = "Subcontacts:";
            // 
            // txtSubcontractsEstimateDefaults
            // 
            this.txtSubcontractsEstimateDefaults.Location = new System.Drawing.Point(155, 167);
            this.txtSubcontractsEstimateDefaults.Name = "txtSubcontractsEstimateDefaults";
            this.txtSubcontractsEstimateDefaults.Properties.DisplayFormat.FormatString = "c2";
            this.txtSubcontractsEstimateDefaults.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtSubcontractsEstimateDefaults.Properties.EditFormat.FormatString = "c2";
            this.txtSubcontractsEstimateDefaults.Properties.EditFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtSubcontractsEstimateDefaults.Properties.Mask.EditMask = "c2";
            this.txtSubcontractsEstimateDefaults.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.txtSubcontractsEstimateDefaults.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.txtSubcontractsEstimateDefaults.Properties.MaxLength = 20;
            this.txtSubcontractsEstimateDefaults.Properties.ReadOnly = true;
            this.spellChecker1.SetShowSpellCheckMenu(this.txtSubcontractsEstimateDefaults, true);
            this.txtSubcontractsEstimateDefaults.Size = new System.Drawing.Size(73, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.txtSubcontractsEstimateDefaults, optionsSpelling22);
            this.txtSubcontractsEstimateDefaults.TabIndex = 17;
            this.txtSubcontractsEstimateDefaults.TabStop = false;
            // 
            // labelControl26
            // 
            this.labelControl26.Location = new System.Drawing.Point(5, 220);
            this.labelControl26.Name = "labelControl26";
            this.labelControl26.Size = new System.Drawing.Size(55, 13);
            this.labelControl26.TabIndex = 582;
            this.labelControl26.Text = "Contract $:";
            // 
            // txtContractDollarEstimateDefaults
            // 
            this.txtContractDollarEstimateDefaults.Location = new System.Drawing.Point(155, 219);
            this.txtContractDollarEstimateDefaults.Name = "txtContractDollarEstimateDefaults";
            this.txtContractDollarEstimateDefaults.Properties.DisplayFormat.FormatString = "c2";
            this.txtContractDollarEstimateDefaults.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtContractDollarEstimateDefaults.Properties.EditFormat.FormatString = "c2";
            this.txtContractDollarEstimateDefaults.Properties.EditFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtContractDollarEstimateDefaults.Properties.Mask.EditMask = "c2";
            this.txtContractDollarEstimateDefaults.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.txtContractDollarEstimateDefaults.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.txtContractDollarEstimateDefaults.Properties.MaxLength = 20;
            this.txtContractDollarEstimateDefaults.Properties.ReadOnly = true;
            this.spellChecker1.SetShowSpellCheckMenu(this.txtContractDollarEstimateDefaults, true);
            this.txtContractDollarEstimateDefaults.Size = new System.Drawing.Size(73, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.txtContractDollarEstimateDefaults, optionsSpelling23);
            this.txtContractDollarEstimateDefaults.TabIndex = 19;
            this.txtContractDollarEstimateDefaults.TabStop = false;
            // 
            // txtTotalCostEstimateDefaults
            // 
            this.txtTotalCostEstimateDefaults.Location = new System.Drawing.Point(155, 193);
            this.txtTotalCostEstimateDefaults.Name = "txtTotalCostEstimateDefaults";
            this.txtTotalCostEstimateDefaults.Properties.DisplayFormat.FormatString = "c2";
            this.txtTotalCostEstimateDefaults.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtTotalCostEstimateDefaults.Properties.EditFormat.FormatString = "c2";
            this.txtTotalCostEstimateDefaults.Properties.EditFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtTotalCostEstimateDefaults.Properties.Mask.EditMask = "c2";
            this.txtTotalCostEstimateDefaults.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.txtTotalCostEstimateDefaults.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.txtTotalCostEstimateDefaults.Properties.MaxLength = 20;
            this.txtTotalCostEstimateDefaults.Properties.ReadOnly = true;
            this.spellChecker1.SetShowSpellCheckMenu(this.txtTotalCostEstimateDefaults, true);
            this.txtTotalCostEstimateDefaults.Size = new System.Drawing.Size(73, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.txtTotalCostEstimateDefaults, optionsSpelling24);
            this.txtTotalCostEstimateDefaults.TabIndex = 18;
            this.txtTotalCostEstimateDefaults.TabStop = false;
            // 
            // labelControl27
            // 
            this.labelControl27.Location = new System.Drawing.Point(5, 196);
            this.labelControl27.Name = "labelControl27";
            this.labelControl27.Size = new System.Drawing.Size(53, 13);
            this.labelControl27.TabIndex = 580;
            this.labelControl27.Text = "Total Cost:";
            // 
            // labelControl28
            // 
            this.labelControl28.Location = new System.Drawing.Point(5, 142);
            this.labelControl28.Name = "labelControl28";
            this.labelControl28.Size = new System.Drawing.Size(54, 13);
            this.labelControl28.TabIndex = 578;
            this.labelControl28.Text = "Other/DJE:";
            // 
            // txtOtherEstimateDefaults
            // 
            this.txtOtherEstimateDefaults.Location = new System.Drawing.Point(155, 141);
            this.txtOtherEstimateDefaults.Name = "txtOtherEstimateDefaults";
            this.txtOtherEstimateDefaults.Properties.DisplayFormat.FormatString = "c2";
            this.txtOtherEstimateDefaults.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtOtherEstimateDefaults.Properties.EditFormat.FormatString = "c2";
            this.txtOtherEstimateDefaults.Properties.EditFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtOtherEstimateDefaults.Properties.Mask.EditMask = "c2";
            this.txtOtherEstimateDefaults.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.txtOtherEstimateDefaults.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.txtOtherEstimateDefaults.Properties.MaxLength = 20;
            this.txtOtherEstimateDefaults.Properties.ReadOnly = true;
            this.spellChecker1.SetShowSpellCheckMenu(this.txtOtherEstimateDefaults, true);
            this.txtOtherEstimateDefaults.Size = new System.Drawing.Size(73, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.txtOtherEstimateDefaults, optionsSpelling25);
            this.txtOtherEstimateDefaults.TabIndex = 16;
            this.txtOtherEstimateDefaults.TabStop = false;
            // 
            // labelControl29
            // 
            this.labelControl29.Location = new System.Drawing.Point(5, 116);
            this.labelControl29.Name = "labelControl29";
            this.labelControl29.Size = new System.Drawing.Size(47, 13);
            this.labelControl29.TabIndex = 576;
            this.labelControl29.Text = "Materials:";
            // 
            // txtMaterialsEstimateDefaults
            // 
            this.txtMaterialsEstimateDefaults.Location = new System.Drawing.Point(155, 115);
            this.txtMaterialsEstimateDefaults.Name = "txtMaterialsEstimateDefaults";
            this.txtMaterialsEstimateDefaults.Properties.DisplayFormat.FormatString = "c2";
            this.txtMaterialsEstimateDefaults.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtMaterialsEstimateDefaults.Properties.EditFormat.FormatString = "c2";
            this.txtMaterialsEstimateDefaults.Properties.EditFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtMaterialsEstimateDefaults.Properties.Mask.EditMask = "c2";
            this.txtMaterialsEstimateDefaults.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.txtMaterialsEstimateDefaults.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.txtMaterialsEstimateDefaults.Properties.MaxLength = 20;
            this.txtMaterialsEstimateDefaults.Properties.ReadOnly = true;
            this.spellChecker1.SetShowSpellCheckMenu(this.txtMaterialsEstimateDefaults, true);
            this.txtMaterialsEstimateDefaults.Size = new System.Drawing.Size(73, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.txtMaterialsEstimateDefaults, optionsSpelling26);
            this.txtMaterialsEstimateDefaults.TabIndex = 15;
            this.txtMaterialsEstimateDefaults.TabStop = false;
            // 
            // txtLaborRateEstimateDefaults
            // 
            this.txtLaborRateEstimateDefaults.Location = new System.Drawing.Point(155, 89);
            this.txtLaborRateEstimateDefaults.Name = "txtLaborRateEstimateDefaults";
            this.txtLaborRateEstimateDefaults.Properties.DisplayFormat.FormatString = "c2";
            this.txtLaborRateEstimateDefaults.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtLaborRateEstimateDefaults.Properties.EditFormat.FormatString = "c2";
            this.txtLaborRateEstimateDefaults.Properties.EditFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtLaborRateEstimateDefaults.Properties.Mask.EditMask = "c2";
            this.txtLaborRateEstimateDefaults.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.txtLaborRateEstimateDefaults.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.txtLaborRateEstimateDefaults.Properties.MaxLength = 20;
            this.txtLaborRateEstimateDefaults.Properties.ReadOnly = true;
            this.spellChecker1.SetShowSpellCheckMenu(this.txtLaborRateEstimateDefaults, true);
            this.txtLaborRateEstimateDefaults.Size = new System.Drawing.Size(73, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.txtLaborRateEstimateDefaults, optionsSpelling27);
            this.txtLaborRateEstimateDefaults.TabIndex = 14;
            this.txtLaborRateEstimateDefaults.TabStop = false;
            // 
            // labelControl37
            // 
            this.labelControl37.Location = new System.Drawing.Point(5, 92);
            this.labelControl37.Name = "labelControl37";
            this.labelControl37.Size = new System.Drawing.Size(60, 13);
            this.labelControl37.TabIndex = 574;
            this.labelControl37.Text = " Labor Rate:";
            // 
            // labelControl50
            // 
            this.labelControl50.Location = new System.Drawing.Point(5, 64);
            this.labelControl50.Name = "labelControl50";
            this.labelControl50.Size = new System.Drawing.Size(40, 13);
            this.labelControl50.TabIndex = 572;
            this.labelControl50.Text = "Labor $:";
            // 
            // txtLaborDollarEstimateDefaults
            // 
            this.txtLaborDollarEstimateDefaults.Location = new System.Drawing.Point(155, 63);
            this.txtLaborDollarEstimateDefaults.Name = "txtLaborDollarEstimateDefaults";
            this.txtLaborDollarEstimateDefaults.Properties.DisplayFormat.FormatString = "c2";
            this.txtLaborDollarEstimateDefaults.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtLaborDollarEstimateDefaults.Properties.EditFormat.FormatString = "c2";
            this.txtLaborDollarEstimateDefaults.Properties.EditFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtLaborDollarEstimateDefaults.Properties.Mask.EditMask = "c2";
            this.txtLaborDollarEstimateDefaults.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.txtLaborDollarEstimateDefaults.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.txtLaborDollarEstimateDefaults.Properties.MaxLength = 20;
            this.txtLaborDollarEstimateDefaults.Properties.ReadOnly = true;
            this.spellChecker1.SetShowSpellCheckMenu(this.txtLaborDollarEstimateDefaults, true);
            this.txtLaborDollarEstimateDefaults.Size = new System.Drawing.Size(73, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.txtLaborDollarEstimateDefaults, optionsSpelling28);
            this.txtLaborDollarEstimateDefaults.TabIndex = 13;
            this.txtLaborDollarEstimateDefaults.TabStop = false;
            // 
            // txtLaborHoursEstimateDefaults
            // 
            this.txtLaborHoursEstimateDefaults.Location = new System.Drawing.Point(155, 37);
            this.txtLaborHoursEstimateDefaults.Name = "txtLaborHoursEstimateDefaults";
            this.txtLaborHoursEstimateDefaults.Properties.DisplayFormat.FormatString = "n2";
            this.txtLaborHoursEstimateDefaults.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtLaborHoursEstimateDefaults.Properties.EditFormat.FormatString = "n2";
            this.txtLaborHoursEstimateDefaults.Properties.EditFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtLaborHoursEstimateDefaults.Properties.Mask.EditMask = "n2";
            this.txtLaborHoursEstimateDefaults.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.txtLaborHoursEstimateDefaults.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.txtLaborHoursEstimateDefaults.Properties.MaxLength = 20;
            this.txtLaborHoursEstimateDefaults.Properties.ReadOnly = true;
            this.spellChecker1.SetShowSpellCheckMenu(this.txtLaborHoursEstimateDefaults, true);
            this.txtLaborHoursEstimateDefaults.Size = new System.Drawing.Size(73, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.txtLaborHoursEstimateDefaults, optionsSpelling29);
            this.txtLaborHoursEstimateDefaults.TabIndex = 12;
            this.txtLaborHoursEstimateDefaults.TabStop = false;
            // 
            // labelControl51
            // 
            this.labelControl51.Location = new System.Drawing.Point(5, 40);
            this.labelControl51.Name = "labelControl51";
            this.labelControl51.Size = new System.Drawing.Size(62, 13);
            this.labelControl51.TabIndex = 570;
            this.labelControl51.Text = "Labor Hours:";
            // 
            // xtraTabPage1
            // 
            this.xtraTabPage1.AutoScroll = true;
            this.xtraTabPage1.Controls.Add(this.labelControl67);
            this.xtraTabPage1.Controls.Add(this.labelControl71);
            this.xtraTabPage1.Controls.Add(this.panelControl9);
            this.xtraTabPage1.Controls.Add(this.panelControl10);
            this.xtraTabPage1.Controls.Add(this.labelControl126);
            this.xtraTabPage1.Controls.Add(this.panelControl11);
            this.xtraTabPage1.Controls.Add(this.panelControl13);
            this.xtraTabPage1.Controls.Add(this.labelControl133);
            this.xtraTabPage1.Name = "xtraTabPage1";
            this.xtraTabPage1.Size = new System.Drawing.Size(921, 398);
            this.xtraTabPage1.Text = "Change Order Entries";
            // 
            // labelControl67
            // 
            this.labelControl67.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))));
            this.labelControl67.Location = new System.Drawing.Point(550, 157);
            this.labelControl67.Name = "labelControl67";
            this.labelControl67.Size = new System.Drawing.Size(105, 13);
            this.labelControl67.TabIndex = 610;
            this.labelControl67.Text = "Subcontract Detail";
            // 
            // labelControl71
            // 
            this.labelControl71.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))));
            this.labelControl71.Location = new System.Drawing.Point(17, 80);
            this.labelControl71.Name = "labelControl71";
            this.labelControl71.Size = new System.Drawing.Size(68, 13);
            this.labelControl71.TabIndex = 609;
            this.labelControl71.Text = "Labor Detail";
            // 
            // panelControl9
            // 
            this.panelControl9.Controls.Add(this.txtSubcontractsAmount);
            this.panelControl9.Controls.Add(this.labelControl85);
            this.panelControl9.Location = new System.Drawing.Point(550, 176);
            this.panelControl9.Name = "panelControl9";
            this.panelControl9.Size = new System.Drawing.Size(258, 43);
            this.panelControl9.TabIndex = 608;
            // 
            // txtSubcontractsAmount
            // 
            this.txtSubcontractsAmount.Location = new System.Drawing.Point(155, 8);
            this.txtSubcontractsAmount.Name = "txtSubcontractsAmount";
            this.txtSubcontractsAmount.Properties.DisplayFormat.FormatString = "c2";
            this.txtSubcontractsAmount.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtSubcontractsAmount.Properties.EditFormat.FormatString = "c2";
            this.txtSubcontractsAmount.Properties.EditFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtSubcontractsAmount.Properties.Mask.EditMask = "c2";
            this.txtSubcontractsAmount.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.txtSubcontractsAmount.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.txtSubcontractsAmount.Properties.MaxLength = 20;
            this.spellChecker1.SetShowSpellCheckMenu(this.txtSubcontractsAmount, true);
            this.txtSubcontractsAmount.Size = new System.Drawing.Size(73, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.txtSubcontractsAmount, optionsSpelling30);
            this.txtSubcontractsAmount.TabIndex = 51;
            this.txtSubcontractsAmount.TabStop = false;
            this.txtSubcontractsAmount.EditValueChanged += new System.EventHandler(this.AllControls_EditValue);
            // 
            // labelControl85
            // 
            this.labelControl85.Location = new System.Drawing.Point(5, 11);
            this.labelControl85.Name = "labelControl85";
            this.labelControl85.Size = new System.Drawing.Size(102, 13);
            this.labelControl85.TabIndex = 570;
            this.labelControl85.Text = "Subcontract Amount:";
            // 
            // panelControl10
            // 
            this.panelControl10.Controls.Add(this.txtEstimatedBIMHoursDT);
            this.panelControl10.Controls.Add(this.txtEstimatedBIMHoursOT);
            this.panelControl10.Controls.Add(this.labelControl168);
            this.panelControl10.Controls.Add(this.txtEstimatedBIMHours);
            this.panelControl10.Controls.Add(this.labelControl161);
            this.panelControl10.Controls.Add(this.labelControl162);
            this.panelControl10.Controls.Add(this.labelControl163);
            this.panelControl10.Controls.Add(this.labelControl131);
            this.panelControl10.Controls.Add(this.labelControl134);
            this.panelControl10.Controls.Add(this.labelControl160);
            this.panelControl10.Controls.Add(this.txtPremiumHoursActualHoursDT);
            this.panelControl10.Controls.Add(this.txtProjectEngineerActualHoursDT);
            this.panelControl10.Controls.Add(this.txtProjectManagerActualHoursDT);
            this.panelControl10.Controls.Add(this.txtSuperintendentActualHoursDT);
            this.panelControl10.Controls.Add(this.txtGeneralForemanActualHoursDT);
            this.panelControl10.Controls.Add(this.txtForemanActualHoursDT);
            this.panelControl10.Controls.Add(this.txtPremiumHoursActualHoursOT);
            this.panelControl10.Controls.Add(this.txtProjectEngineerActualHoursOT);
            this.panelControl10.Controls.Add(this.txtProjectManagerActualHoursOT);
            this.panelControl10.Controls.Add(this.txtSuperintendentActualHoursOT);
            this.panelControl10.Controls.Add(this.txtGeneralForemanActualHoursOT);
            this.panelControl10.Controls.Add(this.txtForemanActualHoursOT);
            this.panelControl10.Controls.Add(this.txtProjectEngineerDefaultHoursDT);
            this.panelControl10.Controls.Add(this.txtProjectManagerDefaultHoursDT);
            this.panelControl10.Controls.Add(this.txtSuperintendentDefaultHoursDT);
            this.panelControl10.Controls.Add(this.txtGeneralForemanDefaultHoursDT);
            this.panelControl10.Controls.Add(this.txtForemanDefaultHoursDT);
            this.panelControl10.Controls.Add(this.txtProjectEngineerDefaultHoursOT);
            this.panelControl10.Controls.Add(this.txtProjectManagerDefaultHoursOT);
            this.panelControl10.Controls.Add(this.txtSuperintendentDefaultHoursOT);
            this.panelControl10.Controls.Add(this.txtGeneralForemanDefaultHoursOT);
            this.panelControl10.Controls.Add(this.txtForemanDefaultHoursOT);
            this.panelControl10.Controls.Add(this.labelControl157);
            this.panelControl10.Controls.Add(this.labelControl158);
            this.panelControl10.Controls.Add(this.labelControl159);
            this.panelControl10.Controls.Add(this.txtEstimatedApprenticeHoursDT);
            this.panelControl10.Controls.Add(this.txtEstimatedElectricianHoursDT);
            this.panelControl10.Controls.Add(this.txtEstimatedApprenticeHoursOT);
            this.panelControl10.Controls.Add(this.txtEstimatedElectricianHoursOT);
            this.panelControl10.Controls.Add(this.labelControl153);
            this.panelControl10.Controls.Add(this.txtEstimatedApprenticeHours);
            this.panelControl10.Controls.Add(this.labelControl145);
            this.panelControl10.Controls.Add(this.txtPremiumHoursActualHours);
            this.panelControl10.Controls.Add(this.labelControl135);
            this.panelControl10.Controls.Add(this.labelControl111);
            this.panelControl10.Controls.Add(this.txtProjectEngineerDefaultHours);
            this.panelControl10.Controls.Add(this.txtProjectManagerDefaultHours);
            this.panelControl10.Controls.Add(this.txtSuperintendentDefaultHours);
            this.panelControl10.Controls.Add(this.txtGeneralForemanDefaultHours);
            this.panelControl10.Controls.Add(this.txtForemanDefaultHours);
            this.panelControl10.Controls.Add(this.txtEstimatedElectricianHours);
            this.panelControl10.Controls.Add(this.labelControl87);
            this.panelControl10.Controls.Add(this.labelControl121);
            this.panelControl10.Controls.Add(this.txtProjectEngineerActualHours);
            this.panelControl10.Controls.Add(this.labelControl122);
            this.panelControl10.Controls.Add(this.txtProjectManagerActualHours);
            this.panelControl10.Controls.Add(this.txtSuperintendentActualHours);
            this.panelControl10.Controls.Add(this.labelControl123);
            this.panelControl10.Controls.Add(this.labelControl124);
            this.panelControl10.Controls.Add(this.txtGeneralForemanActualHours);
            this.panelControl10.Controls.Add(this.txtForemanActualHours);
            this.panelControl10.Controls.Add(this.labelControl125);
            this.panelControl10.Location = new System.Drawing.Point(16, 99);
            this.panelControl10.Name = "panelControl10";
            this.panelControl10.Size = new System.Drawing.Size(528, 289);
            this.panelControl10.TabIndex = 607;
            // 
            // txtEstimatedBIMHoursDT
            // 
            this.txtEstimatedBIMHoursDT.Location = new System.Drawing.Point(353, 23);
            this.txtEstimatedBIMHoursDT.Name = "txtEstimatedBIMHoursDT";
            this.txtEstimatedBIMHoursDT.Properties.DisplayFormat.FormatString = "n2";
            this.txtEstimatedBIMHoursDT.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtEstimatedBIMHoursDT.Properties.EditFormat.FormatString = "n2";
            this.txtEstimatedBIMHoursDT.Properties.EditFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtEstimatedBIMHoursDT.Properties.Mask.EditMask = "n2";
            this.txtEstimatedBIMHoursDT.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.txtEstimatedBIMHoursDT.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.txtEstimatedBIMHoursDT.Properties.MaxLength = 20;
            this.spellChecker1.SetShowSpellCheckMenu(this.txtEstimatedBIMHoursDT, true);
            this.txtEstimatedBIMHoursDT.Size = new System.Drawing.Size(65, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.txtEstimatedBIMHoursDT, optionsSpelling31);
            this.txtEstimatedBIMHoursDT.TabIndex = 644;
            this.txtEstimatedBIMHoursDT.EditValueChanged += new System.EventHandler(this.AllControls_EditValue);
            // 
            // txtEstimatedBIMHoursOT
            // 
            this.txtEstimatedBIMHoursOT.Location = new System.Drawing.Point(263, 23);
            this.txtEstimatedBIMHoursOT.Name = "txtEstimatedBIMHoursOT";
            this.txtEstimatedBIMHoursOT.Properties.DisplayFormat.FormatString = "n2";
            this.txtEstimatedBIMHoursOT.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtEstimatedBIMHoursOT.Properties.EditFormat.FormatString = "n2";
            this.txtEstimatedBIMHoursOT.Properties.EditFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtEstimatedBIMHoursOT.Properties.Mask.EditMask = "n2";
            this.txtEstimatedBIMHoursOT.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.txtEstimatedBIMHoursOT.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.txtEstimatedBIMHoursOT.Properties.MaxLength = 20;
            this.spellChecker1.SetShowSpellCheckMenu(this.txtEstimatedBIMHoursOT, true);
            this.txtEstimatedBIMHoursOT.Size = new System.Drawing.Size(65, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.txtEstimatedBIMHoursOT, optionsSpelling32);
            this.txtEstimatedBIMHoursOT.TabIndex = 643;
            this.txtEstimatedBIMHoursOT.EditValueChanged += new System.EventHandler(this.AllControls_EditValue);
            // 
            // labelControl168
            // 
            this.labelControl168.Location = new System.Drawing.Point(2, 26);
            this.labelControl168.Name = "labelControl168";
            this.labelControl168.Size = new System.Drawing.Size(103, 13);
            this.labelControl168.TabIndex = 642;
            this.labelControl168.Text = "Estimated BIM Hours:";
            // 
            // txtEstimatedBIMHours
            // 
            this.txtEstimatedBIMHours.Location = new System.Drawing.Point(173, 23);
            this.txtEstimatedBIMHours.Name = "txtEstimatedBIMHours";
            this.txtEstimatedBIMHours.Properties.DisplayFormat.FormatString = "n2";
            this.txtEstimatedBIMHours.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtEstimatedBIMHours.Properties.EditFormat.FormatString = "n2";
            this.txtEstimatedBIMHours.Properties.EditFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtEstimatedBIMHours.Properties.Mask.EditMask = "n2";
            this.txtEstimatedBIMHours.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.txtEstimatedBIMHours.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.txtEstimatedBIMHours.Properties.MaxLength = 20;
            this.spellChecker1.SetShowSpellCheckMenu(this.txtEstimatedBIMHours, true);
            this.txtEstimatedBIMHours.Size = new System.Drawing.Size(65, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.txtEstimatedBIMHours, optionsSpelling33);
            this.txtEstimatedBIMHours.TabIndex = 31;
            this.txtEstimatedBIMHours.EditValueChanged += new System.EventHandler(this.AllControls_EditValue);
            // 
            // labelControl161
            // 
            this.labelControl161.Location = new System.Drawing.Point(471, 115);
            this.labelControl161.Name = "labelControl161";
            this.labelControl161.Size = new System.Drawing.Size(13, 13);
            this.labelControl161.TabIndex = 640;
            this.labelControl161.Text = "DT";
            // 
            // labelControl162
            // 
            this.labelControl162.Location = new System.Drawing.Point(404, 115);
            this.labelControl162.Name = "labelControl162";
            this.labelControl162.Size = new System.Drawing.Size(14, 13);
            this.labelControl162.TabIndex = 639;
            this.labelControl162.Text = "OT";
            // 
            // labelControl163
            // 
            this.labelControl163.Location = new System.Drawing.Point(327, 115);
            this.labelControl163.Name = "labelControl163";
            this.labelControl163.Size = new System.Drawing.Size(12, 13);
            this.labelControl163.TabIndex = 638;
            this.labelControl163.Text = "ST";
            // 
            // labelControl131
            // 
            this.labelControl131.Location = new System.Drawing.Point(263, 115);
            this.labelControl131.Name = "labelControl131";
            this.labelControl131.Size = new System.Drawing.Size(13, 13);
            this.labelControl131.TabIndex = 637;
            this.labelControl131.Text = "DT";
            // 
            // labelControl134
            // 
            this.labelControl134.Location = new System.Drawing.Point(196, 115);
            this.labelControl134.Name = "labelControl134";
            this.labelControl134.Size = new System.Drawing.Size(14, 13);
            this.labelControl134.TabIndex = 636;
            this.labelControl134.Text = "OT";
            // 
            // labelControl160
            // 
            this.labelControl160.Location = new System.Drawing.Point(119, 115);
            this.labelControl160.Name = "labelControl160";
            this.labelControl160.Size = new System.Drawing.Size(12, 13);
            this.labelControl160.TabIndex = 635;
            this.labelControl160.Text = "ST";
            // 
            // txtPremiumHoursActualHoursDT
            // 
            this.txtPremiumHoursActualHoursDT.Location = new System.Drawing.Point(452, 263);
            this.txtPremiumHoursActualHoursDT.Name = "txtPremiumHoursActualHoursDT";
            this.txtPremiumHoursActualHoursDT.Properties.DisplayFormat.FormatString = "n2";
            this.txtPremiumHoursActualHoursDT.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtPremiumHoursActualHoursDT.Properties.EditFormat.FormatString = "n2";
            this.txtPremiumHoursActualHoursDT.Properties.EditFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtPremiumHoursActualHoursDT.Properties.Mask.EditMask = "n2";
            this.txtPremiumHoursActualHoursDT.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.txtPremiumHoursActualHoursDT.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.txtPremiumHoursActualHoursDT.Properties.MaxLength = 20;
            this.spellChecker1.SetShowSpellCheckMenu(this.txtPremiumHoursActualHoursDT, true);
            this.txtPremiumHoursActualHoursDT.Size = new System.Drawing.Size(65, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.txtPremiumHoursActualHoursDT, optionsSpelling34);
            this.txtPremiumHoursActualHoursDT.TabIndex = 634;
            this.txtPremiumHoursActualHoursDT.EditValueChanged += new System.EventHandler(this.AllControls_EditValue);
            // 
            // txtProjectEngineerActualHoursDT
            // 
            this.txtProjectEngineerActualHoursDT.Location = new System.Drawing.Point(452, 237);
            this.txtProjectEngineerActualHoursDT.Name = "txtProjectEngineerActualHoursDT";
            this.txtProjectEngineerActualHoursDT.Properties.DisplayFormat.FormatString = "n2";
            this.txtProjectEngineerActualHoursDT.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtProjectEngineerActualHoursDT.Properties.EditFormat.FormatString = "n2";
            this.txtProjectEngineerActualHoursDT.Properties.EditFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtProjectEngineerActualHoursDT.Properties.Mask.EditMask = "n2";
            this.txtProjectEngineerActualHoursDT.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.txtProjectEngineerActualHoursDT.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.txtProjectEngineerActualHoursDT.Properties.MaxLength = 20;
            this.spellChecker1.SetShowSpellCheckMenu(this.txtProjectEngineerActualHoursDT, true);
            this.txtProjectEngineerActualHoursDT.Size = new System.Drawing.Size(65, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.txtProjectEngineerActualHoursDT, optionsSpelling35);
            this.txtProjectEngineerActualHoursDT.TabIndex = 633;
            this.txtProjectEngineerActualHoursDT.EditValueChanged += new System.EventHandler(this.AllControls_EditValue);
            // 
            // txtProjectManagerActualHoursDT
            // 
            this.txtProjectManagerActualHoursDT.Location = new System.Drawing.Point(452, 211);
            this.txtProjectManagerActualHoursDT.Name = "txtProjectManagerActualHoursDT";
            this.txtProjectManagerActualHoursDT.Properties.DisplayFormat.FormatString = "n2";
            this.txtProjectManagerActualHoursDT.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtProjectManagerActualHoursDT.Properties.EditFormat.FormatString = "n2";
            this.txtProjectManagerActualHoursDT.Properties.EditFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtProjectManagerActualHoursDT.Properties.Mask.EditMask = "n2";
            this.txtProjectManagerActualHoursDT.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.txtProjectManagerActualHoursDT.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.txtProjectManagerActualHoursDT.Properties.MaxLength = 20;
            this.spellChecker1.SetShowSpellCheckMenu(this.txtProjectManagerActualHoursDT, true);
            this.txtProjectManagerActualHoursDT.Size = new System.Drawing.Size(65, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.txtProjectManagerActualHoursDT, optionsSpelling36);
            this.txtProjectManagerActualHoursDT.TabIndex = 632;
            this.txtProjectManagerActualHoursDT.EditValueChanged += new System.EventHandler(this.AllControls_EditValue);
            // 
            // txtSuperintendentActualHoursDT
            // 
            this.txtSuperintendentActualHoursDT.Location = new System.Drawing.Point(452, 185);
            this.txtSuperintendentActualHoursDT.Name = "txtSuperintendentActualHoursDT";
            this.txtSuperintendentActualHoursDT.Properties.DisplayFormat.FormatString = "n2";
            this.txtSuperintendentActualHoursDT.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtSuperintendentActualHoursDT.Properties.EditFormat.FormatString = "n2";
            this.txtSuperintendentActualHoursDT.Properties.EditFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtSuperintendentActualHoursDT.Properties.Mask.EditMask = "n2";
            this.txtSuperintendentActualHoursDT.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.txtSuperintendentActualHoursDT.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.txtSuperintendentActualHoursDT.Properties.MaxLength = 20;
            this.spellChecker1.SetShowSpellCheckMenu(this.txtSuperintendentActualHoursDT, true);
            this.txtSuperintendentActualHoursDT.Size = new System.Drawing.Size(65, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.txtSuperintendentActualHoursDT, optionsSpelling37);
            this.txtSuperintendentActualHoursDT.TabIndex = 631;
            this.txtSuperintendentActualHoursDT.EditValueChanged += new System.EventHandler(this.AllControls_EditValue);
            // 
            // txtGeneralForemanActualHoursDT
            // 
            this.txtGeneralForemanActualHoursDT.Location = new System.Drawing.Point(452, 159);
            this.txtGeneralForemanActualHoursDT.Name = "txtGeneralForemanActualHoursDT";
            this.txtGeneralForemanActualHoursDT.Properties.DisplayFormat.FormatString = "n2";
            this.txtGeneralForemanActualHoursDT.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtGeneralForemanActualHoursDT.Properties.EditFormat.FormatString = "n2";
            this.txtGeneralForemanActualHoursDT.Properties.EditFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtGeneralForemanActualHoursDT.Properties.Mask.EditMask = "n2";
            this.txtGeneralForemanActualHoursDT.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.txtGeneralForemanActualHoursDT.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.txtGeneralForemanActualHoursDT.Properties.MaxLength = 20;
            this.spellChecker1.SetShowSpellCheckMenu(this.txtGeneralForemanActualHoursDT, true);
            this.txtGeneralForemanActualHoursDT.Size = new System.Drawing.Size(65, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.txtGeneralForemanActualHoursDT, optionsSpelling38);
            this.txtGeneralForemanActualHoursDT.TabIndex = 630;
            this.txtGeneralForemanActualHoursDT.EditValueChanged += new System.EventHandler(this.AllControls_EditValue);
            // 
            // txtForemanActualHoursDT
            // 
            this.txtForemanActualHoursDT.Location = new System.Drawing.Point(452, 133);
            this.txtForemanActualHoursDT.Name = "txtForemanActualHoursDT";
            this.txtForemanActualHoursDT.Properties.DisplayFormat.FormatString = "n2";
            this.txtForemanActualHoursDT.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtForemanActualHoursDT.Properties.EditFormat.FormatString = "n2";
            this.txtForemanActualHoursDT.Properties.EditFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtForemanActualHoursDT.Properties.Mask.EditMask = "n2";
            this.txtForemanActualHoursDT.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.txtForemanActualHoursDT.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.txtForemanActualHoursDT.Properties.MaxLength = 20;
            this.spellChecker1.SetShowSpellCheckMenu(this.txtForemanActualHoursDT, true);
            this.txtForemanActualHoursDT.Size = new System.Drawing.Size(65, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.txtForemanActualHoursDT, optionsSpelling39);
            this.txtForemanActualHoursDT.TabIndex = 629;
            this.txtForemanActualHoursDT.EditValueChanged += new System.EventHandler(this.AllControls_EditValue);
            // 
            // txtPremiumHoursActualHoursOT
            // 
            this.txtPremiumHoursActualHoursOT.Location = new System.Drawing.Point(381, 263);
            this.txtPremiumHoursActualHoursOT.Name = "txtPremiumHoursActualHoursOT";
            this.txtPremiumHoursActualHoursOT.Properties.DisplayFormat.FormatString = "n2";
            this.txtPremiumHoursActualHoursOT.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtPremiumHoursActualHoursOT.Properties.EditFormat.FormatString = "n2";
            this.txtPremiumHoursActualHoursOT.Properties.EditFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtPremiumHoursActualHoursOT.Properties.Mask.EditMask = "n2";
            this.txtPremiumHoursActualHoursOT.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.txtPremiumHoursActualHoursOT.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.txtPremiumHoursActualHoursOT.Properties.MaxLength = 20;
            this.spellChecker1.SetShowSpellCheckMenu(this.txtPremiumHoursActualHoursOT, true);
            this.txtPremiumHoursActualHoursOT.Size = new System.Drawing.Size(65, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.txtPremiumHoursActualHoursOT, optionsSpelling40);
            this.txtPremiumHoursActualHoursOT.TabIndex = 628;
            this.txtPremiumHoursActualHoursOT.EditValueChanged += new System.EventHandler(this.AllControls_EditValue);
            // 
            // txtProjectEngineerActualHoursOT
            // 
            this.txtProjectEngineerActualHoursOT.Location = new System.Drawing.Point(381, 237);
            this.txtProjectEngineerActualHoursOT.Name = "txtProjectEngineerActualHoursOT";
            this.txtProjectEngineerActualHoursOT.Properties.DisplayFormat.FormatString = "n2";
            this.txtProjectEngineerActualHoursOT.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtProjectEngineerActualHoursOT.Properties.EditFormat.FormatString = "n2";
            this.txtProjectEngineerActualHoursOT.Properties.EditFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtProjectEngineerActualHoursOT.Properties.Mask.EditMask = "n2";
            this.txtProjectEngineerActualHoursOT.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.txtProjectEngineerActualHoursOT.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.txtProjectEngineerActualHoursOT.Properties.MaxLength = 20;
            this.spellChecker1.SetShowSpellCheckMenu(this.txtProjectEngineerActualHoursOT, true);
            this.txtProjectEngineerActualHoursOT.Size = new System.Drawing.Size(65, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.txtProjectEngineerActualHoursOT, optionsSpelling41);
            this.txtProjectEngineerActualHoursOT.TabIndex = 627;
            this.txtProjectEngineerActualHoursOT.EditValueChanged += new System.EventHandler(this.AllControls_EditValue);
            // 
            // txtProjectManagerActualHoursOT
            // 
            this.txtProjectManagerActualHoursOT.Location = new System.Drawing.Point(381, 211);
            this.txtProjectManagerActualHoursOT.Name = "txtProjectManagerActualHoursOT";
            this.txtProjectManagerActualHoursOT.Properties.DisplayFormat.FormatString = "n2";
            this.txtProjectManagerActualHoursOT.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtProjectManagerActualHoursOT.Properties.EditFormat.FormatString = "n2";
            this.txtProjectManagerActualHoursOT.Properties.EditFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtProjectManagerActualHoursOT.Properties.Mask.EditMask = "n2";
            this.txtProjectManagerActualHoursOT.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.txtProjectManagerActualHoursOT.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.txtProjectManagerActualHoursOT.Properties.MaxLength = 20;
            this.spellChecker1.SetShowSpellCheckMenu(this.txtProjectManagerActualHoursOT, true);
            this.txtProjectManagerActualHoursOT.Size = new System.Drawing.Size(65, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.txtProjectManagerActualHoursOT, optionsSpelling42);
            this.txtProjectManagerActualHoursOT.TabIndex = 626;
            this.txtProjectManagerActualHoursOT.EditValueChanged += new System.EventHandler(this.AllControls_EditValue);
            // 
            // txtSuperintendentActualHoursOT
            // 
            this.txtSuperintendentActualHoursOT.Location = new System.Drawing.Point(381, 185);
            this.txtSuperintendentActualHoursOT.Name = "txtSuperintendentActualHoursOT";
            this.txtSuperintendentActualHoursOT.Properties.DisplayFormat.FormatString = "n2";
            this.txtSuperintendentActualHoursOT.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtSuperintendentActualHoursOT.Properties.EditFormat.FormatString = "n2";
            this.txtSuperintendentActualHoursOT.Properties.EditFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtSuperintendentActualHoursOT.Properties.Mask.EditMask = "n2";
            this.txtSuperintendentActualHoursOT.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.txtSuperintendentActualHoursOT.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.txtSuperintendentActualHoursOT.Properties.MaxLength = 20;
            this.spellChecker1.SetShowSpellCheckMenu(this.txtSuperintendentActualHoursOT, true);
            this.txtSuperintendentActualHoursOT.Size = new System.Drawing.Size(65, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.txtSuperintendentActualHoursOT, optionsSpelling43);
            this.txtSuperintendentActualHoursOT.TabIndex = 625;
            this.txtSuperintendentActualHoursOT.EditValueChanged += new System.EventHandler(this.AllControls_EditValue);
            // 
            // txtGeneralForemanActualHoursOT
            // 
            this.txtGeneralForemanActualHoursOT.Location = new System.Drawing.Point(381, 159);
            this.txtGeneralForemanActualHoursOT.Name = "txtGeneralForemanActualHoursOT";
            this.txtGeneralForemanActualHoursOT.Properties.DisplayFormat.FormatString = "n2";
            this.txtGeneralForemanActualHoursOT.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtGeneralForemanActualHoursOT.Properties.EditFormat.FormatString = "n2";
            this.txtGeneralForemanActualHoursOT.Properties.EditFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtGeneralForemanActualHoursOT.Properties.Mask.EditMask = "n2";
            this.txtGeneralForemanActualHoursOT.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.txtGeneralForemanActualHoursOT.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.txtGeneralForemanActualHoursOT.Properties.MaxLength = 20;
            this.spellChecker1.SetShowSpellCheckMenu(this.txtGeneralForemanActualHoursOT, true);
            this.txtGeneralForemanActualHoursOT.Size = new System.Drawing.Size(65, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.txtGeneralForemanActualHoursOT, optionsSpelling44);
            this.txtGeneralForemanActualHoursOT.TabIndex = 624;
            this.txtGeneralForemanActualHoursOT.EditValueChanged += new System.EventHandler(this.AllControls_EditValue);
            // 
            // txtForemanActualHoursOT
            // 
            this.txtForemanActualHoursOT.Location = new System.Drawing.Point(381, 133);
            this.txtForemanActualHoursOT.Name = "txtForemanActualHoursOT";
            this.txtForemanActualHoursOT.Properties.DisplayFormat.FormatString = "n2";
            this.txtForemanActualHoursOT.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtForemanActualHoursOT.Properties.EditFormat.FormatString = "n2";
            this.txtForemanActualHoursOT.Properties.EditFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtForemanActualHoursOT.Properties.Mask.EditMask = "n2";
            this.txtForemanActualHoursOT.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.txtForemanActualHoursOT.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.txtForemanActualHoursOT.Properties.MaxLength = 20;
            this.spellChecker1.SetShowSpellCheckMenu(this.txtForemanActualHoursOT, true);
            this.txtForemanActualHoursOT.Size = new System.Drawing.Size(65, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.txtForemanActualHoursOT, optionsSpelling45);
            this.txtForemanActualHoursOT.TabIndex = 623;
            this.txtForemanActualHoursOT.EditValueChanged += new System.EventHandler(this.AllControls_EditValue);
            // 
            // txtProjectEngineerDefaultHoursDT
            // 
            this.txtProjectEngineerDefaultHoursDT.Location = new System.Drawing.Point(237, 238);
            this.txtProjectEngineerDefaultHoursDT.Name = "txtProjectEngineerDefaultHoursDT";
            this.txtProjectEngineerDefaultHoursDT.Properties.DisplayFormat.FormatString = "n2";
            this.txtProjectEngineerDefaultHoursDT.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtProjectEngineerDefaultHoursDT.Properties.EditFormat.FormatString = "n2";
            this.txtProjectEngineerDefaultHoursDT.Properties.EditFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtProjectEngineerDefaultHoursDT.Properties.Mask.EditMask = "n2";
            this.txtProjectEngineerDefaultHoursDT.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.txtProjectEngineerDefaultHoursDT.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.txtProjectEngineerDefaultHoursDT.Properties.MaxLength = 20;
            this.txtProjectEngineerDefaultHoursDT.Properties.ReadOnly = true;
            this.spellChecker1.SetShowSpellCheckMenu(this.txtProjectEngineerDefaultHoursDT, true);
            this.txtProjectEngineerDefaultHoursDT.Size = new System.Drawing.Size(65, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.txtProjectEngineerDefaultHoursDT, optionsSpelling46);
            this.txtProjectEngineerDefaultHoursDT.TabIndex = 622;
            this.txtProjectEngineerDefaultHoursDT.TabStop = false;
            this.txtProjectEngineerDefaultHoursDT.EditValueChanged += new System.EventHandler(this.AllControls_EditValue);
            // 
            // txtProjectManagerDefaultHoursDT
            // 
            this.txtProjectManagerDefaultHoursDT.Location = new System.Drawing.Point(237, 212);
            this.txtProjectManagerDefaultHoursDT.Name = "txtProjectManagerDefaultHoursDT";
            this.txtProjectManagerDefaultHoursDT.Properties.DisplayFormat.FormatString = "n2";
            this.txtProjectManagerDefaultHoursDT.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtProjectManagerDefaultHoursDT.Properties.EditFormat.FormatString = "n2";
            this.txtProjectManagerDefaultHoursDT.Properties.EditFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtProjectManagerDefaultHoursDT.Properties.Mask.EditMask = "n2";
            this.txtProjectManagerDefaultHoursDT.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.txtProjectManagerDefaultHoursDT.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.txtProjectManagerDefaultHoursDT.Properties.MaxLength = 20;
            this.txtProjectManagerDefaultHoursDT.Properties.ReadOnly = true;
            this.spellChecker1.SetShowSpellCheckMenu(this.txtProjectManagerDefaultHoursDT, true);
            this.txtProjectManagerDefaultHoursDT.Size = new System.Drawing.Size(65, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.txtProjectManagerDefaultHoursDT, optionsSpelling47);
            this.txtProjectManagerDefaultHoursDT.TabIndex = 621;
            this.txtProjectManagerDefaultHoursDT.TabStop = false;
            this.txtProjectManagerDefaultHoursDT.EditValueChanged += new System.EventHandler(this.AllControls_EditValue);
            // 
            // txtSuperintendentDefaultHoursDT
            // 
            this.txtSuperintendentDefaultHoursDT.Location = new System.Drawing.Point(237, 186);
            this.txtSuperintendentDefaultHoursDT.Name = "txtSuperintendentDefaultHoursDT";
            this.txtSuperintendentDefaultHoursDT.Properties.DisplayFormat.FormatString = "n2";
            this.txtSuperintendentDefaultHoursDT.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtSuperintendentDefaultHoursDT.Properties.EditFormat.FormatString = "n2";
            this.txtSuperintendentDefaultHoursDT.Properties.EditFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtSuperintendentDefaultHoursDT.Properties.Mask.EditMask = "n2";
            this.txtSuperintendentDefaultHoursDT.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.txtSuperintendentDefaultHoursDT.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.txtSuperintendentDefaultHoursDT.Properties.MaxLength = 20;
            this.txtSuperintendentDefaultHoursDT.Properties.ReadOnly = true;
            this.spellChecker1.SetShowSpellCheckMenu(this.txtSuperintendentDefaultHoursDT, true);
            this.txtSuperintendentDefaultHoursDT.Size = new System.Drawing.Size(65, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.txtSuperintendentDefaultHoursDT, optionsSpelling48);
            this.txtSuperintendentDefaultHoursDT.TabIndex = 620;
            this.txtSuperintendentDefaultHoursDT.TabStop = false;
            this.txtSuperintendentDefaultHoursDT.EditValueChanged += new System.EventHandler(this.AllControls_EditValue);
            // 
            // txtGeneralForemanDefaultHoursDT
            // 
            this.txtGeneralForemanDefaultHoursDT.Location = new System.Drawing.Point(237, 160);
            this.txtGeneralForemanDefaultHoursDT.Name = "txtGeneralForemanDefaultHoursDT";
            this.txtGeneralForemanDefaultHoursDT.Properties.DisplayFormat.FormatString = "n2";
            this.txtGeneralForemanDefaultHoursDT.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtGeneralForemanDefaultHoursDT.Properties.EditFormat.FormatString = "n2";
            this.txtGeneralForemanDefaultHoursDT.Properties.EditFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtGeneralForemanDefaultHoursDT.Properties.Mask.EditMask = "n2";
            this.txtGeneralForemanDefaultHoursDT.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.txtGeneralForemanDefaultHoursDT.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.txtGeneralForemanDefaultHoursDT.Properties.MaxLength = 20;
            this.txtGeneralForemanDefaultHoursDT.Properties.ReadOnly = true;
            this.spellChecker1.SetShowSpellCheckMenu(this.txtGeneralForemanDefaultHoursDT, true);
            this.txtGeneralForemanDefaultHoursDT.Size = new System.Drawing.Size(65, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.txtGeneralForemanDefaultHoursDT, optionsSpelling49);
            this.txtGeneralForemanDefaultHoursDT.TabIndex = 619;
            this.txtGeneralForemanDefaultHoursDT.TabStop = false;
            this.txtGeneralForemanDefaultHoursDT.EditValueChanged += new System.EventHandler(this.AllControls_EditValue);
            // 
            // txtForemanDefaultHoursDT
            // 
            this.txtForemanDefaultHoursDT.Location = new System.Drawing.Point(237, 134);
            this.txtForemanDefaultHoursDT.Name = "txtForemanDefaultHoursDT";
            this.txtForemanDefaultHoursDT.Properties.DisplayFormat.FormatString = "n2";
            this.txtForemanDefaultHoursDT.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtForemanDefaultHoursDT.Properties.EditFormat.FormatString = "n2";
            this.txtForemanDefaultHoursDT.Properties.EditFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtForemanDefaultHoursDT.Properties.Mask.EditMask = "n2";
            this.txtForemanDefaultHoursDT.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.txtForemanDefaultHoursDT.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.txtForemanDefaultHoursDT.Properties.MaxLength = 20;
            this.txtForemanDefaultHoursDT.Properties.ReadOnly = true;
            this.spellChecker1.SetShowSpellCheckMenu(this.txtForemanDefaultHoursDT, true);
            this.txtForemanDefaultHoursDT.Size = new System.Drawing.Size(65, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.txtForemanDefaultHoursDT, optionsSpelling50);
            this.txtForemanDefaultHoursDT.TabIndex = 618;
            this.txtForemanDefaultHoursDT.TabStop = false;
            this.txtForemanDefaultHoursDT.EditValueChanged += new System.EventHandler(this.AllControls_EditValue);
            // 
            // txtProjectEngineerDefaultHoursOT
            // 
            this.txtProjectEngineerDefaultHoursOT.Location = new System.Drawing.Point(166, 238);
            this.txtProjectEngineerDefaultHoursOT.Name = "txtProjectEngineerDefaultHoursOT";
            this.txtProjectEngineerDefaultHoursOT.Properties.DisplayFormat.FormatString = "n2";
            this.txtProjectEngineerDefaultHoursOT.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtProjectEngineerDefaultHoursOT.Properties.EditFormat.FormatString = "n2";
            this.txtProjectEngineerDefaultHoursOT.Properties.EditFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtProjectEngineerDefaultHoursOT.Properties.Mask.EditMask = "n2";
            this.txtProjectEngineerDefaultHoursOT.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.txtProjectEngineerDefaultHoursOT.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.txtProjectEngineerDefaultHoursOT.Properties.MaxLength = 20;
            this.txtProjectEngineerDefaultHoursOT.Properties.ReadOnly = true;
            this.spellChecker1.SetShowSpellCheckMenu(this.txtProjectEngineerDefaultHoursOT, true);
            this.txtProjectEngineerDefaultHoursOT.Size = new System.Drawing.Size(65, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.txtProjectEngineerDefaultHoursOT, optionsSpelling51);
            this.txtProjectEngineerDefaultHoursOT.TabIndex = 617;
            this.txtProjectEngineerDefaultHoursOT.TabStop = false;
            this.txtProjectEngineerDefaultHoursOT.EditValueChanged += new System.EventHandler(this.AllControls_EditValue);
            // 
            // txtProjectManagerDefaultHoursOT
            // 
            this.txtProjectManagerDefaultHoursOT.Location = new System.Drawing.Point(166, 212);
            this.txtProjectManagerDefaultHoursOT.Name = "txtProjectManagerDefaultHoursOT";
            this.txtProjectManagerDefaultHoursOT.Properties.DisplayFormat.FormatString = "n2";
            this.txtProjectManagerDefaultHoursOT.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtProjectManagerDefaultHoursOT.Properties.EditFormat.FormatString = "n2";
            this.txtProjectManagerDefaultHoursOT.Properties.EditFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtProjectManagerDefaultHoursOT.Properties.Mask.EditMask = "n2";
            this.txtProjectManagerDefaultHoursOT.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.txtProjectManagerDefaultHoursOT.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.txtProjectManagerDefaultHoursOT.Properties.MaxLength = 20;
            this.txtProjectManagerDefaultHoursOT.Properties.ReadOnly = true;
            this.spellChecker1.SetShowSpellCheckMenu(this.txtProjectManagerDefaultHoursOT, true);
            this.txtProjectManagerDefaultHoursOT.Size = new System.Drawing.Size(65, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.txtProjectManagerDefaultHoursOT, optionsSpelling52);
            this.txtProjectManagerDefaultHoursOT.TabIndex = 616;
            this.txtProjectManagerDefaultHoursOT.TabStop = false;
            this.txtProjectManagerDefaultHoursOT.EditValueChanged += new System.EventHandler(this.AllControls_EditValue);
            // 
            // txtSuperintendentDefaultHoursOT
            // 
            this.txtSuperintendentDefaultHoursOT.Location = new System.Drawing.Point(166, 186);
            this.txtSuperintendentDefaultHoursOT.Name = "txtSuperintendentDefaultHoursOT";
            this.txtSuperintendentDefaultHoursOT.Properties.DisplayFormat.FormatString = "n2";
            this.txtSuperintendentDefaultHoursOT.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtSuperintendentDefaultHoursOT.Properties.EditFormat.FormatString = "n2";
            this.txtSuperintendentDefaultHoursOT.Properties.EditFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtSuperintendentDefaultHoursOT.Properties.Mask.EditMask = "n2";
            this.txtSuperintendentDefaultHoursOT.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.txtSuperintendentDefaultHoursOT.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.txtSuperintendentDefaultHoursOT.Properties.MaxLength = 20;
            this.txtSuperintendentDefaultHoursOT.Properties.ReadOnly = true;
            this.spellChecker1.SetShowSpellCheckMenu(this.txtSuperintendentDefaultHoursOT, true);
            this.txtSuperintendentDefaultHoursOT.Size = new System.Drawing.Size(65, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.txtSuperintendentDefaultHoursOT, optionsSpelling53);
            this.txtSuperintendentDefaultHoursOT.TabIndex = 615;
            this.txtSuperintendentDefaultHoursOT.TabStop = false;
            this.txtSuperintendentDefaultHoursOT.EditValueChanged += new System.EventHandler(this.AllControls_EditValue);
            // 
            // txtGeneralForemanDefaultHoursOT
            // 
            this.txtGeneralForemanDefaultHoursOT.Location = new System.Drawing.Point(166, 160);
            this.txtGeneralForemanDefaultHoursOT.Name = "txtGeneralForemanDefaultHoursOT";
            this.txtGeneralForemanDefaultHoursOT.Properties.DisplayFormat.FormatString = "n2";
            this.txtGeneralForemanDefaultHoursOT.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtGeneralForemanDefaultHoursOT.Properties.EditFormat.FormatString = "n2";
            this.txtGeneralForemanDefaultHoursOT.Properties.EditFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtGeneralForemanDefaultHoursOT.Properties.Mask.EditMask = "n2";
            this.txtGeneralForemanDefaultHoursOT.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.txtGeneralForemanDefaultHoursOT.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.txtGeneralForemanDefaultHoursOT.Properties.MaxLength = 20;
            this.txtGeneralForemanDefaultHoursOT.Properties.ReadOnly = true;
            this.spellChecker1.SetShowSpellCheckMenu(this.txtGeneralForemanDefaultHoursOT, true);
            this.txtGeneralForemanDefaultHoursOT.Size = new System.Drawing.Size(65, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.txtGeneralForemanDefaultHoursOT, optionsSpelling54);
            this.txtGeneralForemanDefaultHoursOT.TabIndex = 614;
            this.txtGeneralForemanDefaultHoursOT.TabStop = false;
            this.txtGeneralForemanDefaultHoursOT.EditValueChanged += new System.EventHandler(this.AllControls_EditValue);
            // 
            // txtForemanDefaultHoursOT
            // 
            this.txtForemanDefaultHoursOT.Location = new System.Drawing.Point(166, 134);
            this.txtForemanDefaultHoursOT.Name = "txtForemanDefaultHoursOT";
            this.txtForemanDefaultHoursOT.Properties.DisplayFormat.FormatString = "n2";
            this.txtForemanDefaultHoursOT.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtForemanDefaultHoursOT.Properties.EditFormat.FormatString = "n2";
            this.txtForemanDefaultHoursOT.Properties.EditFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtForemanDefaultHoursOT.Properties.Mask.EditMask = "n2";
            this.txtForemanDefaultHoursOT.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.txtForemanDefaultHoursOT.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.txtForemanDefaultHoursOT.Properties.MaxLength = 20;
            this.txtForemanDefaultHoursOT.Properties.ReadOnly = true;
            this.spellChecker1.SetShowSpellCheckMenu(this.txtForemanDefaultHoursOT, true);
            this.txtForemanDefaultHoursOT.Size = new System.Drawing.Size(65, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.txtForemanDefaultHoursOT, optionsSpelling55);
            this.txtForemanDefaultHoursOT.TabIndex = 613;
            this.txtForemanDefaultHoursOT.TabStop = false;
            this.txtForemanDefaultHoursOT.EditValueChanged += new System.EventHandler(this.AllControls_EditValue);
            // 
            // labelControl157
            // 
            this.labelControl157.Location = new System.Drawing.Point(384, 0);
            this.labelControl157.Name = "labelControl157";
            this.labelControl157.Size = new System.Drawing.Size(13, 13);
            this.labelControl157.TabIndex = 612;
            this.labelControl157.Text = "DT";
            // 
            // labelControl158
            // 
            this.labelControl158.Location = new System.Drawing.Point(291, 0);
            this.labelControl158.Name = "labelControl158";
            this.labelControl158.Size = new System.Drawing.Size(14, 13);
            this.labelControl158.TabIndex = 611;
            this.labelControl158.Text = "OT";
            // 
            // labelControl159
            // 
            this.labelControl159.Location = new System.Drawing.Point(199, 0);
            this.labelControl159.Name = "labelControl159";
            this.labelControl159.Size = new System.Drawing.Size(12, 13);
            this.labelControl159.TabIndex = 610;
            this.labelControl159.Text = "ST";
            // 
            // txtEstimatedApprenticeHoursDT
            // 
            this.txtEstimatedApprenticeHoursDT.Location = new System.Drawing.Point(353, 46);
            this.txtEstimatedApprenticeHoursDT.Name = "txtEstimatedApprenticeHoursDT";
            this.txtEstimatedApprenticeHoursDT.Properties.DisplayFormat.FormatString = "n2";
            this.txtEstimatedApprenticeHoursDT.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtEstimatedApprenticeHoursDT.Properties.EditFormat.FormatString = "n2";
            this.txtEstimatedApprenticeHoursDT.Properties.EditFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtEstimatedApprenticeHoursDT.Properties.Mask.EditMask = "n2";
            this.txtEstimatedApprenticeHoursDT.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.txtEstimatedApprenticeHoursDT.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.txtEstimatedApprenticeHoursDT.Properties.MaxLength = 20;
            this.spellChecker1.SetShowSpellCheckMenu(this.txtEstimatedApprenticeHoursDT, true);
            this.txtEstimatedApprenticeHoursDT.Size = new System.Drawing.Size(65, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.txtEstimatedApprenticeHoursDT, optionsSpelling56);
            this.txtEstimatedApprenticeHoursDT.TabIndex = 596;
            this.txtEstimatedApprenticeHoursDT.EditValueChanged += new System.EventHandler(this.AllControls_EditValue);
            // 
            // txtEstimatedElectricianHoursDT
            // 
            this.txtEstimatedElectricianHoursDT.Location = new System.Drawing.Point(353, 67);
            this.txtEstimatedElectricianHoursDT.Name = "txtEstimatedElectricianHoursDT";
            this.txtEstimatedElectricianHoursDT.Properties.DisplayFormat.FormatString = "n2";
            this.txtEstimatedElectricianHoursDT.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtEstimatedElectricianHoursDT.Properties.EditFormat.FormatString = "n2";
            this.txtEstimatedElectricianHoursDT.Properties.EditFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtEstimatedElectricianHoursDT.Properties.Mask.EditMask = "n2";
            this.txtEstimatedElectricianHoursDT.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.txtEstimatedElectricianHoursDT.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.txtEstimatedElectricianHoursDT.Properties.MaxLength = 20;
            this.spellChecker1.SetShowSpellCheckMenu(this.txtEstimatedElectricianHoursDT, true);
            this.txtEstimatedElectricianHoursDT.Size = new System.Drawing.Size(65, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.txtEstimatedElectricianHoursDT, optionsSpelling57);
            this.txtEstimatedElectricianHoursDT.TabIndex = 597;
            this.txtEstimatedElectricianHoursDT.EditValueChanged += new System.EventHandler(this.AllControls_EditValue);
            // 
            // txtEstimatedApprenticeHoursOT
            // 
            this.txtEstimatedApprenticeHoursOT.Location = new System.Drawing.Point(263, 46);
            this.txtEstimatedApprenticeHoursOT.Name = "txtEstimatedApprenticeHoursOT";
            this.txtEstimatedApprenticeHoursOT.Properties.DisplayFormat.FormatString = "n2";
            this.txtEstimatedApprenticeHoursOT.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtEstimatedApprenticeHoursOT.Properties.EditFormat.FormatString = "n2";
            this.txtEstimatedApprenticeHoursOT.Properties.EditFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtEstimatedApprenticeHoursOT.Properties.Mask.EditMask = "n2";
            this.txtEstimatedApprenticeHoursOT.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.txtEstimatedApprenticeHoursOT.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.txtEstimatedApprenticeHoursOT.Properties.MaxLength = 20;
            this.spellChecker1.SetShowSpellCheckMenu(this.txtEstimatedApprenticeHoursOT, true);
            this.txtEstimatedApprenticeHoursOT.Size = new System.Drawing.Size(65, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.txtEstimatedApprenticeHoursOT, optionsSpelling58);
            this.txtEstimatedApprenticeHoursOT.TabIndex = 594;
            this.txtEstimatedApprenticeHoursOT.EditValueChanged += new System.EventHandler(this.AllControls_EditValue);
            // 
            // txtEstimatedElectricianHoursOT
            // 
            this.txtEstimatedElectricianHoursOT.Location = new System.Drawing.Point(263, 67);
            this.txtEstimatedElectricianHoursOT.Name = "txtEstimatedElectricianHoursOT";
            this.txtEstimatedElectricianHoursOT.Properties.DisplayFormat.FormatString = "n2";
            this.txtEstimatedElectricianHoursOT.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtEstimatedElectricianHoursOT.Properties.EditFormat.FormatString = "n2";
            this.txtEstimatedElectricianHoursOT.Properties.EditFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtEstimatedElectricianHoursOT.Properties.Mask.EditMask = "n2";
            this.txtEstimatedElectricianHoursOT.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.txtEstimatedElectricianHoursOT.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.txtEstimatedElectricianHoursOT.Properties.MaxLength = 20;
            this.spellChecker1.SetShowSpellCheckMenu(this.txtEstimatedElectricianHoursOT, true);
            this.txtEstimatedElectricianHoursOT.Size = new System.Drawing.Size(65, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.txtEstimatedElectricianHoursOT, optionsSpelling59);
            this.txtEstimatedElectricianHoursOT.TabIndex = 595;
            this.txtEstimatedElectricianHoursOT.EditValueChanged += new System.EventHandler(this.AllControls_EditValue);
            // 
            // labelControl153
            // 
            this.labelControl153.Location = new System.Drawing.Point(2, 49);
            this.labelControl153.Name = "labelControl153";
            this.labelControl153.Size = new System.Drawing.Size(137, 13);
            this.labelControl153.TabIndex = 593;
            this.labelControl153.Text = "Estimated Apprentice Hours:";
            // 
            // txtEstimatedApprenticeHours
            // 
            this.txtEstimatedApprenticeHours.Location = new System.Drawing.Point(173, 46);
            this.txtEstimatedApprenticeHours.Name = "txtEstimatedApprenticeHours";
            this.txtEstimatedApprenticeHours.Properties.DisplayFormat.FormatString = "n2";
            this.txtEstimatedApprenticeHours.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtEstimatedApprenticeHours.Properties.EditFormat.FormatString = "n2";
            this.txtEstimatedApprenticeHours.Properties.EditFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtEstimatedApprenticeHours.Properties.Mask.EditMask = "n2";
            this.txtEstimatedApprenticeHours.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.txtEstimatedApprenticeHours.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.txtEstimatedApprenticeHours.Properties.MaxLength = 20;
            this.spellChecker1.SetShowSpellCheckMenu(this.txtEstimatedApprenticeHours, true);
            this.txtEstimatedApprenticeHours.Size = new System.Drawing.Size(65, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.txtEstimatedApprenticeHours, optionsSpelling60);
            this.txtEstimatedApprenticeHours.TabIndex = 32;
            this.txtEstimatedApprenticeHours.EditValueChanged += new System.EventHandler(this.AllControls_EditValue);
            // 
            // labelControl145
            // 
            this.labelControl145.Location = new System.Drawing.Point(2, 266);
            this.labelControl145.Name = "labelControl145";
            this.labelControl145.Size = new System.Drawing.Size(75, 13);
            this.labelControl145.TabIndex = 591;
            this.labelControl145.Text = "Premium Hours:";
            // 
            // txtPremiumHoursActualHours
            // 
            this.txtPremiumHoursActualHours.Location = new System.Drawing.Point(308, 264);
            this.txtPremiumHoursActualHours.Name = "txtPremiumHoursActualHours";
            this.txtPremiumHoursActualHours.Properties.DisplayFormat.FormatString = "n2";
            this.txtPremiumHoursActualHours.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtPremiumHoursActualHours.Properties.EditFormat.FormatString = "n2";
            this.txtPremiumHoursActualHours.Properties.EditFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtPremiumHoursActualHours.Properties.Mask.EditMask = "n2";
            this.txtPremiumHoursActualHours.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.txtPremiumHoursActualHours.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.txtPremiumHoursActualHours.Properties.MaxLength = 20;
            this.spellChecker1.SetShowSpellCheckMenu(this.txtPremiumHoursActualHours, true);
            this.txtPremiumHoursActualHours.Size = new System.Drawing.Size(65, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.txtPremiumHoursActualHours, optionsSpelling61);
            this.txtPremiumHoursActualHours.TabIndex = 44;
            this.txtPremiumHoursActualHours.EditValueChanged += new System.EventHandler(this.AllControls_EditValue);
            // 
            // labelControl135
            // 
            this.labelControl135.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.labelControl135.Location = new System.Drawing.Point(316, 96);
            this.labelControl135.Name = "labelControl135";
            this.labelControl135.Size = new System.Drawing.Size(78, 13);
            this.labelControl135.TabIndex = 588;
            this.labelControl135.Text = "Change Hours";
            // 
            // labelControl111
            // 
            this.labelControl111.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.labelControl111.Location = new System.Drawing.Point(110, 96);
            this.labelControl111.Name = "labelControl111";
            this.labelControl111.Size = new System.Drawing.Size(77, 13);
            this.labelControl111.TabIndex = 586;
            this.labelControl111.Text = "Default Hours";
            // 
            // txtProjectEngineerDefaultHours
            // 
            this.txtProjectEngineerDefaultHours.Location = new System.Drawing.Point(95, 237);
            this.txtProjectEngineerDefaultHours.Name = "txtProjectEngineerDefaultHours";
            this.txtProjectEngineerDefaultHours.Properties.DisplayFormat.FormatString = "n2";
            this.txtProjectEngineerDefaultHours.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtProjectEngineerDefaultHours.Properties.EditFormat.FormatString = "n2";
            this.txtProjectEngineerDefaultHours.Properties.EditFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtProjectEngineerDefaultHours.Properties.Mask.EditMask = "n2";
            this.txtProjectEngineerDefaultHours.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.txtProjectEngineerDefaultHours.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.txtProjectEngineerDefaultHours.Properties.MaxLength = 20;
            this.txtProjectEngineerDefaultHours.Properties.ReadOnly = true;
            this.spellChecker1.SetShowSpellCheckMenu(this.txtProjectEngineerDefaultHours, true);
            this.txtProjectEngineerDefaultHours.Size = new System.Drawing.Size(65, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.txtProjectEngineerDefaultHours, optionsSpelling62);
            this.txtProjectEngineerDefaultHours.TabIndex = 38;
            this.txtProjectEngineerDefaultHours.TabStop = false;
            this.txtProjectEngineerDefaultHours.EditValueChanged += new System.EventHandler(this.AllControls_EditValue);
            // 
            // txtProjectManagerDefaultHours
            // 
            this.txtProjectManagerDefaultHours.Location = new System.Drawing.Point(95, 211);
            this.txtProjectManagerDefaultHours.Name = "txtProjectManagerDefaultHours";
            this.txtProjectManagerDefaultHours.Properties.DisplayFormat.FormatString = "n2";
            this.txtProjectManagerDefaultHours.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtProjectManagerDefaultHours.Properties.EditFormat.FormatString = "n2";
            this.txtProjectManagerDefaultHours.Properties.EditFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtProjectManagerDefaultHours.Properties.Mask.EditMask = "n2";
            this.txtProjectManagerDefaultHours.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.txtProjectManagerDefaultHours.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.txtProjectManagerDefaultHours.Properties.MaxLength = 20;
            this.txtProjectManagerDefaultHours.Properties.ReadOnly = true;
            this.spellChecker1.SetShowSpellCheckMenu(this.txtProjectManagerDefaultHours, true);
            this.txtProjectManagerDefaultHours.Size = new System.Drawing.Size(65, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.txtProjectManagerDefaultHours, optionsSpelling63);
            this.txtProjectManagerDefaultHours.TabIndex = 37;
            this.txtProjectManagerDefaultHours.TabStop = false;
            this.txtProjectManagerDefaultHours.EditValueChanged += new System.EventHandler(this.AllControls_EditValue);
            // 
            // txtSuperintendentDefaultHours
            // 
            this.txtSuperintendentDefaultHours.Location = new System.Drawing.Point(95, 185);
            this.txtSuperintendentDefaultHours.Name = "txtSuperintendentDefaultHours";
            this.txtSuperintendentDefaultHours.Properties.DisplayFormat.FormatString = "n2";
            this.txtSuperintendentDefaultHours.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtSuperintendentDefaultHours.Properties.EditFormat.FormatString = "n2";
            this.txtSuperintendentDefaultHours.Properties.EditFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtSuperintendentDefaultHours.Properties.Mask.EditMask = "n2";
            this.txtSuperintendentDefaultHours.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.txtSuperintendentDefaultHours.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.txtSuperintendentDefaultHours.Properties.MaxLength = 20;
            this.txtSuperintendentDefaultHours.Properties.ReadOnly = true;
            this.spellChecker1.SetShowSpellCheckMenu(this.txtSuperintendentDefaultHours, true);
            this.txtSuperintendentDefaultHours.Size = new System.Drawing.Size(65, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.txtSuperintendentDefaultHours, optionsSpelling64);
            this.txtSuperintendentDefaultHours.TabIndex = 36;
            this.txtSuperintendentDefaultHours.TabStop = false;
            this.txtSuperintendentDefaultHours.EditValueChanged += new System.EventHandler(this.AllControls_EditValue);
            // 
            // txtGeneralForemanDefaultHours
            // 
            this.txtGeneralForemanDefaultHours.Location = new System.Drawing.Point(95, 159);
            this.txtGeneralForemanDefaultHours.Name = "txtGeneralForemanDefaultHours";
            this.txtGeneralForemanDefaultHours.Properties.DisplayFormat.FormatString = "n2";
            this.txtGeneralForemanDefaultHours.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtGeneralForemanDefaultHours.Properties.EditFormat.FormatString = "n2";
            this.txtGeneralForemanDefaultHours.Properties.EditFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtGeneralForemanDefaultHours.Properties.Mask.EditMask = "n2";
            this.txtGeneralForemanDefaultHours.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.txtGeneralForemanDefaultHours.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.txtGeneralForemanDefaultHours.Properties.MaxLength = 20;
            this.txtGeneralForemanDefaultHours.Properties.ReadOnly = true;
            this.spellChecker1.SetShowSpellCheckMenu(this.txtGeneralForemanDefaultHours, true);
            this.txtGeneralForemanDefaultHours.Size = new System.Drawing.Size(65, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.txtGeneralForemanDefaultHours, optionsSpelling65);
            this.txtGeneralForemanDefaultHours.TabIndex = 35;
            this.txtGeneralForemanDefaultHours.TabStop = false;
            this.txtGeneralForemanDefaultHours.EditValueChanged += new System.EventHandler(this.AllControls_EditValue);
            // 
            // txtForemanDefaultHours
            // 
            this.txtForemanDefaultHours.Location = new System.Drawing.Point(95, 133);
            this.txtForemanDefaultHours.Name = "txtForemanDefaultHours";
            this.txtForemanDefaultHours.Properties.DisplayFormat.FormatString = "n2";
            this.txtForemanDefaultHours.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtForemanDefaultHours.Properties.EditFormat.FormatString = "n2";
            this.txtForemanDefaultHours.Properties.EditFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtForemanDefaultHours.Properties.Mask.EditMask = "n2";
            this.txtForemanDefaultHours.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.txtForemanDefaultHours.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.txtForemanDefaultHours.Properties.MaxLength = 20;
            this.txtForemanDefaultHours.Properties.ReadOnly = true;
            this.spellChecker1.SetShowSpellCheckMenu(this.txtForemanDefaultHours, true);
            this.txtForemanDefaultHours.Size = new System.Drawing.Size(65, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.txtForemanDefaultHours, optionsSpelling66);
            this.txtForemanDefaultHours.TabIndex = 34;
            this.txtForemanDefaultHours.TabStop = false;
            this.txtForemanDefaultHours.EditValueChanged += new System.EventHandler(this.AllControls_EditValue);
            // 
            // txtEstimatedElectricianHours
            // 
            this.txtEstimatedElectricianHours.Location = new System.Drawing.Point(173, 67);
            this.txtEstimatedElectricianHours.Name = "txtEstimatedElectricianHours";
            this.txtEstimatedElectricianHours.Properties.DisplayFormat.FormatString = "n2";
            this.txtEstimatedElectricianHours.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtEstimatedElectricianHours.Properties.EditFormat.FormatString = "n2";
            this.txtEstimatedElectricianHours.Properties.EditFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtEstimatedElectricianHours.Properties.Mask.EditMask = "n2";
            this.txtEstimatedElectricianHours.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.txtEstimatedElectricianHours.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.txtEstimatedElectricianHours.Properties.MaxLength = 20;
            this.spellChecker1.SetShowSpellCheckMenu(this.txtEstimatedElectricianHours, true);
            this.txtEstimatedElectricianHours.Size = new System.Drawing.Size(65, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.txtEstimatedElectricianHours, optionsSpelling67);
            this.txtEstimatedElectricianHours.TabIndex = 33;
            this.txtEstimatedElectricianHours.EditValueChanged += new System.EventHandler(this.AllControls_EditValue);
            // 
            // labelControl87
            // 
            this.labelControl87.Location = new System.Drawing.Point(1, 70);
            this.labelControl87.Name = "labelControl87";
            this.labelControl87.Size = new System.Drawing.Size(133, 13);
            this.labelControl87.TabIndex = 580;
            this.labelControl87.Text = "Estimated Electrician Hours:";
            // 
            // labelControl121
            // 
            this.labelControl121.Location = new System.Drawing.Point(2, 238);
            this.labelControl121.Name = "labelControl121";
            this.labelControl121.Size = new System.Drawing.Size(83, 13);
            this.labelControl121.TabIndex = 578;
            this.labelControl121.Text = "Project Engineer:";
            // 
            // txtProjectEngineerActualHours
            // 
            this.txtProjectEngineerActualHours.Location = new System.Drawing.Point(308, 238);
            this.txtProjectEngineerActualHours.Name = "txtProjectEngineerActualHours";
            this.txtProjectEngineerActualHours.Properties.DisplayFormat.FormatString = "n2";
            this.txtProjectEngineerActualHours.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtProjectEngineerActualHours.Properties.EditFormat.FormatString = "n2";
            this.txtProjectEngineerActualHours.Properties.EditFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtProjectEngineerActualHours.Properties.Mask.EditMask = "n2";
            this.txtProjectEngineerActualHours.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.txtProjectEngineerActualHours.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.txtProjectEngineerActualHours.Properties.MaxLength = 20;
            this.spellChecker1.SetShowSpellCheckMenu(this.txtProjectEngineerActualHours, true);
            this.txtProjectEngineerActualHours.Size = new System.Drawing.Size(65, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.txtProjectEngineerActualHours, optionsSpelling68);
            this.txtProjectEngineerActualHours.TabIndex = 43;
            this.txtProjectEngineerActualHours.EditValueChanged += new System.EventHandler(this.AllControls_EditValue);
            // 
            // labelControl122
            // 
            this.labelControl122.Location = new System.Drawing.Point(2, 212);
            this.labelControl122.Name = "labelControl122";
            this.labelControl122.Size = new System.Drawing.Size(83, 13);
            this.labelControl122.TabIndex = 576;
            this.labelControl122.Text = "Project Manager:";
            // 
            // txtProjectManagerActualHours
            // 
            this.txtProjectManagerActualHours.Location = new System.Drawing.Point(308, 212);
            this.txtProjectManagerActualHours.Name = "txtProjectManagerActualHours";
            this.txtProjectManagerActualHours.Properties.DisplayFormat.FormatString = "n2";
            this.txtProjectManagerActualHours.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtProjectManagerActualHours.Properties.EditFormat.FormatString = "n2";
            this.txtProjectManagerActualHours.Properties.EditFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtProjectManagerActualHours.Properties.Mask.EditMask = "n2";
            this.txtProjectManagerActualHours.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.txtProjectManagerActualHours.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.txtProjectManagerActualHours.Properties.MaxLength = 20;
            this.spellChecker1.SetShowSpellCheckMenu(this.txtProjectManagerActualHours, true);
            this.txtProjectManagerActualHours.Size = new System.Drawing.Size(65, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.txtProjectManagerActualHours, optionsSpelling69);
            this.txtProjectManagerActualHours.TabIndex = 42;
            this.txtProjectManagerActualHours.EditValueChanged += new System.EventHandler(this.AllControls_EditValue);
            // 
            // txtSuperintendentActualHours
            // 
            this.txtSuperintendentActualHours.Location = new System.Drawing.Point(308, 186);
            this.txtSuperintendentActualHours.Name = "txtSuperintendentActualHours";
            this.txtSuperintendentActualHours.Properties.DisplayFormat.FormatString = "n2";
            this.txtSuperintendentActualHours.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtSuperintendentActualHours.Properties.EditFormat.FormatString = "n2";
            this.txtSuperintendentActualHours.Properties.EditFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtSuperintendentActualHours.Properties.Mask.EditMask = "n2";
            this.txtSuperintendentActualHours.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.txtSuperintendentActualHours.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.txtSuperintendentActualHours.Properties.MaxLength = 20;
            this.spellChecker1.SetShowSpellCheckMenu(this.txtSuperintendentActualHours, true);
            this.txtSuperintendentActualHours.Size = new System.Drawing.Size(65, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.txtSuperintendentActualHours, optionsSpelling70);
            this.txtSuperintendentActualHours.TabIndex = 41;
            this.txtSuperintendentActualHours.EditValueChanged += new System.EventHandler(this.AllControls_EditValue);
            // 
            // labelControl123
            // 
            this.labelControl123.Location = new System.Drawing.Point(2, 188);
            this.labelControl123.Name = "labelControl123";
            this.labelControl123.Size = new System.Drawing.Size(78, 13);
            this.labelControl123.TabIndex = 574;
            this.labelControl123.Text = "Superintendent:";
            // 
            // labelControl124
            // 
            this.labelControl124.Location = new System.Drawing.Point(2, 160);
            this.labelControl124.Name = "labelControl124";
            this.labelControl124.Size = new System.Drawing.Size(86, 13);
            this.labelControl124.TabIndex = 572;
            this.labelControl124.Text = "General Foreman:";
            // 
            // txtGeneralForemanActualHours
            // 
            this.txtGeneralForemanActualHours.Location = new System.Drawing.Point(308, 160);
            this.txtGeneralForemanActualHours.Name = "txtGeneralForemanActualHours";
            this.txtGeneralForemanActualHours.Properties.DisplayFormat.FormatString = "n2";
            this.txtGeneralForemanActualHours.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtGeneralForemanActualHours.Properties.EditFormat.FormatString = "n2";
            this.txtGeneralForemanActualHours.Properties.EditFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtGeneralForemanActualHours.Properties.Mask.EditMask = "n2";
            this.txtGeneralForemanActualHours.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.txtGeneralForemanActualHours.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.txtGeneralForemanActualHours.Properties.MaxLength = 20;
            this.spellChecker1.SetShowSpellCheckMenu(this.txtGeneralForemanActualHours, true);
            this.txtGeneralForemanActualHours.Size = new System.Drawing.Size(65, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.txtGeneralForemanActualHours, optionsSpelling71);
            this.txtGeneralForemanActualHours.TabIndex = 40;
            this.txtGeneralForemanActualHours.EditValueChanged += new System.EventHandler(this.AllControls_EditValue);
            // 
            // txtForemanActualHours
            // 
            this.txtForemanActualHours.Location = new System.Drawing.Point(308, 134);
            this.txtForemanActualHours.Name = "txtForemanActualHours";
            this.txtForemanActualHours.Properties.DisplayFormat.FormatString = "n2";
            this.txtForemanActualHours.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtForemanActualHours.Properties.EditFormat.FormatString = "n2";
            this.txtForemanActualHours.Properties.EditFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtForemanActualHours.Properties.Mask.EditMask = "n2";
            this.txtForemanActualHours.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.txtForemanActualHours.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.txtForemanActualHours.Properties.MaxLength = 20;
            this.spellChecker1.SetShowSpellCheckMenu(this.txtForemanActualHours, true);
            this.txtForemanActualHours.Size = new System.Drawing.Size(65, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.txtForemanActualHours, optionsSpelling72);
            this.txtForemanActualHours.TabIndex = 39;
            this.txtForemanActualHours.EditValueChanged += new System.EventHandler(this.AllControls_EditValue);
            // 
            // labelControl125
            // 
            this.labelControl125.Location = new System.Drawing.Point(2, 136);
            this.labelControl125.Name = "labelControl125";
            this.labelControl125.Size = new System.Drawing.Size(46, 13);
            this.labelControl125.TabIndex = 570;
            this.labelControl125.Text = "Foreman:";
            // 
            // labelControl126
            // 
            this.labelControl126.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))));
            this.labelControl126.Location = new System.Drawing.Point(550, 16);
            this.labelControl126.Name = "labelControl126";
            this.labelControl126.Size = new System.Drawing.Size(89, 13);
            this.labelControl126.TabIndex = 606;
            this.labelControl126.Text = "Expenses Detail";
            // 
            // panelControl11
            // 
            this.panelControl11.Controls.Add(this.labelControl136);
            this.panelControl11.Controls.Add(this.labelControl127);
            this.panelControl11.Controls.Add(this.txtOtherExpenses3Description);
            this.panelControl11.Controls.Add(this.txtOtherExpenses2Description);
            this.panelControl11.Controls.Add(this.txtOtherExpenses1Description);
            this.panelControl11.Controls.Add(this.txtOtherExpenses3);
            this.panelControl11.Controls.Add(this.labelControl128);
            this.panelControl11.Controls.Add(this.labelControl129);
            this.panelControl11.Controls.Add(this.txtOtherExpenses2);
            this.panelControl11.Controls.Add(this.txtOtherExpenses1);
            this.panelControl11.Controls.Add(this.labelControl130);
            this.panelControl11.Location = new System.Drawing.Point(550, 36);
            this.panelControl11.Name = "panelControl11";
            this.panelControl11.Size = new System.Drawing.Size(346, 113);
            this.panelControl11.TabIndex = 605;
            // 
            // labelControl136
            // 
            this.labelControl136.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.labelControl136.Location = new System.Drawing.Point(207, 7);
            this.labelControl136.Name = "labelControl136";
            this.labelControl136.Size = new System.Drawing.Size(64, 13);
            this.labelControl136.TabIndex = 590;
            this.labelControl136.Text = "Description";
            // 
            // labelControl127
            // 
            this.labelControl127.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.labelControl127.Location = new System.Drawing.Point(52, 7);
            this.labelControl127.Name = "labelControl127";
            this.labelControl127.Size = new System.Drawing.Size(17, 13);
            this.labelControl127.TabIndex = 589;
            this.labelControl127.Text = "($)";
            // 
            // txtOtherExpenses3Description
            // 
            this.txtOtherExpenses3Description.Location = new System.Drawing.Point(131, 81);
            this.txtOtherExpenses3Description.Name = "txtOtherExpenses3Description";
            this.txtOtherExpenses3Description.Properties.MaxLength = 35;
            this.spellChecker1.SetShowSpellCheckMenu(this.txtOtherExpenses3Description, true);
            this.txtOtherExpenses3Description.Size = new System.Drawing.Size(206, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.txtOtherExpenses3Description, optionsSpelling73);
            this.txtOtherExpenses3Description.TabIndex = 50;
            this.txtOtherExpenses3Description.EditValueChanged += new System.EventHandler(this.AllControls_EditValue);
            // 
            // txtOtherExpenses2Description
            // 
            this.txtOtherExpenses2Description.Location = new System.Drawing.Point(131, 54);
            this.txtOtherExpenses2Description.Name = "txtOtherExpenses2Description";
            this.txtOtherExpenses2Description.Properties.MaxLength = 35;
            this.spellChecker1.SetShowSpellCheckMenu(this.txtOtherExpenses2Description, true);
            this.txtOtherExpenses2Description.Size = new System.Drawing.Size(206, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.txtOtherExpenses2Description, optionsSpelling74);
            this.txtOtherExpenses2Description.TabIndex = 48;
            this.txtOtherExpenses2Description.EditValueChanged += new System.EventHandler(this.AllControls_EditValue);
            // 
            // txtOtherExpenses1Description
            // 
            this.txtOtherExpenses1Description.Location = new System.Drawing.Point(131, 30);
            this.txtOtherExpenses1Description.Name = "txtOtherExpenses1Description";
            this.txtOtherExpenses1Description.Properties.MaxLength = 35;
            this.spellChecker1.SetShowSpellCheckMenu(this.txtOtherExpenses1Description, true);
            this.txtOtherExpenses1Description.Size = new System.Drawing.Size(206, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.txtOtherExpenses1Description, optionsSpelling75);
            this.txtOtherExpenses1Description.TabIndex = 46;
            this.txtOtherExpenses1Description.EditValueChanged += new System.EventHandler(this.AllControls_EditValue);
            // 
            // txtOtherExpenses3
            // 
            this.txtOtherExpenses3.Location = new System.Drawing.Point(52, 82);
            this.txtOtherExpenses3.Name = "txtOtherExpenses3";
            this.txtOtherExpenses3.Properties.DisplayFormat.FormatString = "c2";
            this.txtOtherExpenses3.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtOtherExpenses3.Properties.EditFormat.FormatString = "c2";
            this.txtOtherExpenses3.Properties.EditFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtOtherExpenses3.Properties.Mask.EditMask = "c2";
            this.txtOtherExpenses3.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.txtOtherExpenses3.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.txtOtherExpenses3.Properties.MaxLength = 20;
            this.spellChecker1.SetShowSpellCheckMenu(this.txtOtherExpenses3, true);
            this.txtOtherExpenses3.Size = new System.Drawing.Size(73, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.txtOtherExpenses3, optionsSpelling76);
            this.txtOtherExpenses3.TabIndex = 49;
            this.txtOtherExpenses3.EditValueChanged += new System.EventHandler(this.AllControls_EditValue);
            // 
            // labelControl128
            // 
            this.labelControl128.Location = new System.Drawing.Point(5, 85);
            this.labelControl128.Name = "labelControl128";
            this.labelControl128.Size = new System.Drawing.Size(41, 13);
            this.labelControl128.TabIndex = 574;
            this.labelControl128.Text = "Other 3:";
            // 
            // labelControl129
            // 
            this.labelControl129.Location = new System.Drawing.Point(5, 57);
            this.labelControl129.Name = "labelControl129";
            this.labelControl129.Size = new System.Drawing.Size(41, 13);
            this.labelControl129.TabIndex = 572;
            this.labelControl129.Text = "Other 2:";
            // 
            // txtOtherExpenses2
            // 
            this.txtOtherExpenses2.Location = new System.Drawing.Point(52, 56);
            this.txtOtherExpenses2.Name = "txtOtherExpenses2";
            this.txtOtherExpenses2.Properties.DisplayFormat.FormatString = "c2";
            this.txtOtherExpenses2.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtOtherExpenses2.Properties.EditFormat.FormatString = "c2";
            this.txtOtherExpenses2.Properties.EditFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtOtherExpenses2.Properties.Mask.EditMask = "c2";
            this.txtOtherExpenses2.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.txtOtherExpenses2.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.txtOtherExpenses2.Properties.MaxLength = 20;
            this.spellChecker1.SetShowSpellCheckMenu(this.txtOtherExpenses2, true);
            this.txtOtherExpenses2.Size = new System.Drawing.Size(73, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.txtOtherExpenses2, optionsSpelling77);
            this.txtOtherExpenses2.TabIndex = 47;
            this.txtOtherExpenses2.EditValueChanged += new System.EventHandler(this.AllControls_EditValue);
            // 
            // txtOtherExpenses1
            // 
            this.txtOtherExpenses1.Location = new System.Drawing.Point(52, 30);
            this.txtOtherExpenses1.Name = "txtOtherExpenses1";
            this.txtOtherExpenses1.Properties.DisplayFormat.FormatString = "c2";
            this.txtOtherExpenses1.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtOtherExpenses1.Properties.EditFormat.FormatString = "c2";
            this.txtOtherExpenses1.Properties.EditFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtOtherExpenses1.Properties.Mask.EditMask = "c2";
            this.txtOtherExpenses1.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.txtOtherExpenses1.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.txtOtherExpenses1.Properties.MaxLength = 20;
            this.spellChecker1.SetShowSpellCheckMenu(this.txtOtherExpenses1, true);
            this.txtOtherExpenses1.Size = new System.Drawing.Size(73, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.txtOtherExpenses1, optionsSpelling78);
            this.txtOtherExpenses1.TabIndex = 45;
            this.txtOtherExpenses1.EditValueChanged += new System.EventHandler(this.AllControls_EditValue);
            // 
            // labelControl130
            // 
            this.labelControl130.Location = new System.Drawing.Point(5, 33);
            this.labelControl130.Name = "labelControl130";
            this.labelControl130.Size = new System.Drawing.Size(41, 13);
            this.labelControl130.TabIndex = 570;
            this.labelControl130.Text = "Other 1:";
            // 
            // panelControl13
            // 
            this.panelControl13.Controls.Add(this.txtDirectMaterials);
            this.panelControl13.Controls.Add(this.labelControl132);
            this.panelControl13.Location = new System.Drawing.Point(16, 36);
            this.panelControl13.Name = "panelControl13";
            this.panelControl13.Size = new System.Drawing.Size(258, 38);
            this.panelControl13.TabIndex = 604;
            // 
            // txtDirectMaterials
            // 
            this.txtDirectMaterials.Location = new System.Drawing.Point(155, 8);
            this.txtDirectMaterials.Name = "txtDirectMaterials";
            this.txtDirectMaterials.Properties.DisplayFormat.FormatString = "c2";
            this.txtDirectMaterials.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtDirectMaterials.Properties.EditFormat.FormatString = "c2";
            this.txtDirectMaterials.Properties.EditFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtDirectMaterials.Properties.Mask.EditMask = "c2";
            this.txtDirectMaterials.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.txtDirectMaterials.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.txtDirectMaterials.Properties.MaxLength = 20;
            this.spellChecker1.SetShowSpellCheckMenu(this.txtDirectMaterials, true);
            this.txtDirectMaterials.Size = new System.Drawing.Size(73, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.txtDirectMaterials, optionsSpelling79);
            this.txtDirectMaterials.TabIndex = 32;
            this.txtDirectMaterials.EditValueChanged += new System.EventHandler(this.AllControls_EditValue);
            // 
            // labelControl132
            // 
            this.labelControl132.Location = new System.Drawing.Point(5, 11);
            this.labelControl132.Name = "labelControl132";
            this.labelControl132.Size = new System.Drawing.Size(78, 13);
            this.labelControl132.TabIndex = 570;
            this.labelControl132.Text = "Direct Materials:";
            // 
            // labelControl133
            // 
            this.labelControl133.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))));
            this.labelControl133.Location = new System.Drawing.Point(17, 16);
            this.labelControl133.Name = "labelControl133";
            this.labelControl133.Size = new System.Drawing.Size(83, 13);
            this.labelControl133.TabIndex = 603;
            this.labelControl133.Text = "Material Detail";
            // 
            // xtraTabPage2
            // 
            this.xtraTabPage2.AutoScroll = true;
            this.xtraTabPage2.Controls.Add(this.labelControl23);
            this.xtraTabPage2.Controls.Add(this.labelControl22);
            this.xtraTabPage2.Controls.Add(this.panelControl5);
            this.xtraTabPage2.Controls.Add(this.panelControl3);
            this.xtraTabPage2.Controls.Add(this.labelControl10);
            this.xtraTabPage2.Controls.Add(this.panelControl2);
            this.xtraTabPage2.Controls.Add(this.panelControl1);
            this.xtraTabPage2.Controls.Add(this.labelControl25);
            this.xtraTabPage2.Name = "xtraTabPage2";
            this.xtraTabPage2.Size = new System.Drawing.Size(921, 398);
            this.xtraTabPage2.Text = "Estimate Values";
            // 
            // labelControl23
            // 
            this.labelControl23.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))));
            this.labelControl23.Location = new System.Drawing.Point(337, 156);
            this.labelControl23.Name = "labelControl23";
            this.labelControl23.Size = new System.Drawing.Size(70, 13);
            this.labelControl23.TabIndex = 602;
            this.labelControl23.Text = "Mark-ups %";
            // 
            // labelControl22
            // 
            this.labelControl22.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))));
            this.labelControl22.Location = new System.Drawing.Point(17, 102);
            this.labelControl22.Name = "labelControl22";
            this.labelControl22.Size = new System.Drawing.Size(32, 13);
            this.labelControl22.TabIndex = 601;
            this.labelControl22.Text = "Labor";
            // 
            // panelControl5
            // 
            this.panelControl5.Controls.Add(this.txtBondPercentText);
            this.panelControl5.Controls.Add(this.txtWarrantyPercentText);
            this.panelControl5.Controls.Add(this.txtSubcontractAdministrationPercentText);
            this.panelControl5.Controls.Add(this.txtProfitPercentText);
            this.panelControl5.Controls.Add(this.txtOverheadPercentText);
            this.panelControl5.Controls.Add(this.txtBondPercent);
            this.panelControl5.Controls.Add(this.txtWarrantyPercent);
            this.panelControl5.Controls.Add(this.txtSubcontractAdministrationPercent);
            this.panelControl5.Controls.Add(this.txtProfitPercent);
            this.panelControl5.Controls.Add(this.txtOverheadPercent);
            this.panelControl5.Location = new System.Drawing.Point(337, 175);
            this.panelControl5.Name = "panelControl5";
            this.panelControl5.Size = new System.Drawing.Size(258, 137);
            this.panelControl5.TabIndex = 600;
            // 
            // txtBondPercent
            // 
            this.txtBondPercent.Location = new System.Drawing.Point(155, 112);
            this.txtBondPercent.Name = "txtBondPercent";
            this.txtBondPercent.Properties.DisplayFormat.FormatString = "p2";
            this.txtBondPercent.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtBondPercent.Properties.EditFormat.FormatString = "p2";
            this.txtBondPercent.Properties.EditFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtBondPercent.Properties.Mask.EditMask = "p2";
            this.txtBondPercent.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.txtBondPercent.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.txtBondPercent.Properties.MaxLength = 20;
            this.spellChecker1.SetShowSpellCheckMenu(this.txtBondPercent, true);
            this.txtBondPercent.Size = new System.Drawing.Size(73, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.txtBondPercent, optionsSpelling85);
            this.txtBondPercent.TabIndex = 69;
            this.txtBondPercent.EditValueChanged += new System.EventHandler(this.AllControls_EditValue);
            // 
            // txtWarrantyPercent
            // 
            this.txtWarrantyPercent.Location = new System.Drawing.Point(155, 86);
            this.txtWarrantyPercent.Name = "txtWarrantyPercent";
            this.txtWarrantyPercent.Properties.DisplayFormat.FormatString = "p2";
            this.txtWarrantyPercent.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtWarrantyPercent.Properties.EditFormat.FormatString = "p2";
            this.txtWarrantyPercent.Properties.EditFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtWarrantyPercent.Properties.Mask.EditMask = "p2";
            this.txtWarrantyPercent.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.txtWarrantyPercent.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.txtWarrantyPercent.Properties.MaxLength = 20;
            this.spellChecker1.SetShowSpellCheckMenu(this.txtWarrantyPercent, true);
            this.txtWarrantyPercent.Size = new System.Drawing.Size(73, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.txtWarrantyPercent, optionsSpelling86);
            this.txtWarrantyPercent.TabIndex = 68;
            this.txtWarrantyPercent.EditValueChanged += new System.EventHandler(this.AllControls_EditValue);
            // 
            // txtSubcontractAdministrationPercent
            // 
            this.txtSubcontractAdministrationPercent.Location = new System.Drawing.Point(155, 60);
            this.txtSubcontractAdministrationPercent.Name = "txtSubcontractAdministrationPercent";
            this.txtSubcontractAdministrationPercent.Properties.DisplayFormat.FormatString = "p2";
            this.txtSubcontractAdministrationPercent.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtSubcontractAdministrationPercent.Properties.EditFormat.FormatString = "p2";
            this.txtSubcontractAdministrationPercent.Properties.EditFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtSubcontractAdministrationPercent.Properties.Mask.EditMask = "p2";
            this.txtSubcontractAdministrationPercent.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.txtSubcontractAdministrationPercent.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.txtSubcontractAdministrationPercent.Properties.MaxLength = 20;
            this.spellChecker1.SetShowSpellCheckMenu(this.txtSubcontractAdministrationPercent, true);
            this.txtSubcontractAdministrationPercent.Size = new System.Drawing.Size(73, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.txtSubcontractAdministrationPercent, optionsSpelling87);
            this.txtSubcontractAdministrationPercent.TabIndex = 67;
            this.txtSubcontractAdministrationPercent.EditValueChanged += new System.EventHandler(this.AllControls_EditValue);
            // 
            // txtProfitPercent
            // 
            this.txtProfitPercent.Location = new System.Drawing.Point(155, 34);
            this.txtProfitPercent.Name = "txtProfitPercent";
            this.txtProfitPercent.Properties.DisplayFormat.FormatString = "p2";
            this.txtProfitPercent.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtProfitPercent.Properties.EditFormat.FormatString = "p2";
            this.txtProfitPercent.Properties.EditFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtProfitPercent.Properties.Mask.EditMask = "p2";
            this.txtProfitPercent.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.txtProfitPercent.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.txtProfitPercent.Properties.MaxLength = 20;
            this.spellChecker1.SetShowSpellCheckMenu(this.txtProfitPercent, true);
            this.txtProfitPercent.Size = new System.Drawing.Size(73, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.txtProfitPercent, optionsSpelling88);
            this.txtProfitPercent.TabIndex = 66;
            this.txtProfitPercent.EditValueChanged += new System.EventHandler(this.AllControls_EditValue);
            // 
            // txtOverheadPercent
            // 
            this.txtOverheadPercent.Location = new System.Drawing.Point(155, 8);
            this.txtOverheadPercent.Name = "txtOverheadPercent";
            this.txtOverheadPercent.Properties.DisplayFormat.FormatString = "p2";
            this.txtOverheadPercent.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtOverheadPercent.Properties.EditFormat.FormatString = "p2";
            this.txtOverheadPercent.Properties.EditFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtOverheadPercent.Properties.Mask.EditMask = "p2";
            this.txtOverheadPercent.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.txtOverheadPercent.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.txtOverheadPercent.Properties.MaxLength = 20;
            this.spellChecker1.SetShowSpellCheckMenu(this.txtOverheadPercent, true);
            this.txtOverheadPercent.Size = new System.Drawing.Size(73, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.txtOverheadPercent, optionsSpelling89);
            this.txtOverheadPercent.TabIndex = 65;
            this.txtOverheadPercent.EditValueChanged += new System.EventHandler(this.AllControls_EditValue);
            // 
            // panelControl3
            // 
            this.panelControl3.Controls.Add(this.labelControl15);
            this.panelControl3.Controls.Add(this.txtFringeBenefitsPercent);
            this.panelControl3.Controls.Add(this.txtSafetyMeetingPercent);
            this.panelControl3.Controls.Add(this.labelControl16);
            this.panelControl3.Controls.Add(this.labelControl17);
            this.panelControl3.Controls.Add(this.txtProjectEngineerPercentOfLabor);
            this.panelControl3.Controls.Add(this.labelControl11);
            this.panelControl3.Controls.Add(this.txtProjectManagerPercentOfLabor);
            this.panelControl3.Controls.Add(this.txtSuperintendentPercentOfLabor);
            this.panelControl3.Controls.Add(this.labelControl12);
            this.panelControl3.Controls.Add(this.labelControl13);
            this.panelControl3.Controls.Add(this.txtGeneralForemanPercentOfLabor);
            this.panelControl3.Controls.Add(this.txtForemanPercentOfLabor);
            this.panelControl3.Controls.Add(this.labelControl14);
            this.panelControl3.Location = new System.Drawing.Point(17, 121);
            this.panelControl3.Name = "panelControl3";
            this.panelControl3.Size = new System.Drawing.Size(258, 192);
            this.panelControl3.TabIndex = 599;
            // 
            // labelControl15
            // 
            this.labelControl15.Location = new System.Drawing.Point(5, 165);
            this.labelControl15.Name = "labelControl15";
            this.labelControl15.Size = new System.Drawing.Size(90, 13);
            this.labelControl15.TabIndex = 582;
            this.labelControl15.Text = "Fringe Benefits %:";
            // 
            // txtFringeBenefitsPercent
            // 
            this.txtFringeBenefitsPercent.Location = new System.Drawing.Point(155, 164);
            this.txtFringeBenefitsPercent.Name = "txtFringeBenefitsPercent";
            this.txtFringeBenefitsPercent.Properties.DisplayFormat.FormatString = "p2";
            this.txtFringeBenefitsPercent.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtFringeBenefitsPercent.Properties.EditFormat.FormatString = "p2";
            this.txtFringeBenefitsPercent.Properties.EditFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtFringeBenefitsPercent.Properties.Mask.EditMask = "p2";
            this.txtFringeBenefitsPercent.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.txtFringeBenefitsPercent.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.txtFringeBenefitsPercent.Properties.MaxLength = 20;
            this.spellChecker1.SetShowSpellCheckMenu(this.txtFringeBenefitsPercent, true);
            this.txtFringeBenefitsPercent.Size = new System.Drawing.Size(73, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.txtFringeBenefitsPercent, optionsSpelling90);
            this.txtFringeBenefitsPercent.TabIndex = 64;
            this.txtFringeBenefitsPercent.EditValueChanged += new System.EventHandler(this.AllControls_EditValue);
            // 
            // txtSafetyMeetingPercent
            // 
            this.txtSafetyMeetingPercent.Location = new System.Drawing.Point(155, 138);
            this.txtSafetyMeetingPercent.Name = "txtSafetyMeetingPercent";
            this.txtSafetyMeetingPercent.Properties.DisplayFormat.FormatString = "p2";
            this.txtSafetyMeetingPercent.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtSafetyMeetingPercent.Properties.EditFormat.FormatString = "p2";
            this.txtSafetyMeetingPercent.Properties.EditFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtSafetyMeetingPercent.Properties.Mask.EditMask = "p2";
            this.txtSafetyMeetingPercent.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.txtSafetyMeetingPercent.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.txtSafetyMeetingPercent.Properties.MaxLength = 20;
            this.spellChecker1.SetShowSpellCheckMenu(this.txtSafetyMeetingPercent, true);
            this.txtSafetyMeetingPercent.Size = new System.Drawing.Size(73, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.txtSafetyMeetingPercent, optionsSpelling91);
            this.txtSafetyMeetingPercent.TabIndex = 63;
            this.txtSafetyMeetingPercent.EditValueChanged += new System.EventHandler(this.AllControls_EditValue);
            // 
            // labelControl16
            // 
            this.labelControl16.Location = new System.Drawing.Point(5, 141);
            this.labelControl16.Name = "labelControl16";
            this.labelControl16.Size = new System.Drawing.Size(91, 13);
            this.labelControl16.TabIndex = 580;
            this.labelControl16.Text = "Safety Meeting %:";
            // 
            // labelControl17
            // 
            this.labelControl17.Location = new System.Drawing.Point(5, 113);
            this.labelControl17.Name = "labelControl17";
            this.labelControl17.Size = new System.Drawing.Size(140, 13);
            this.labelControl17.TabIndex = 578;
            this.labelControl17.Text = "Project Engineer % of Labor:";
            // 
            // txtProjectEngineerPercentOfLabor
            // 
            this.txtProjectEngineerPercentOfLabor.Location = new System.Drawing.Point(155, 112);
            this.txtProjectEngineerPercentOfLabor.Name = "txtProjectEngineerPercentOfLabor";
            this.txtProjectEngineerPercentOfLabor.Properties.DisplayFormat.FormatString = "p2";
            this.txtProjectEngineerPercentOfLabor.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtProjectEngineerPercentOfLabor.Properties.EditFormat.FormatString = "p2";
            this.txtProjectEngineerPercentOfLabor.Properties.EditFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtProjectEngineerPercentOfLabor.Properties.Mask.EditMask = "p2";
            this.txtProjectEngineerPercentOfLabor.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.txtProjectEngineerPercentOfLabor.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.txtProjectEngineerPercentOfLabor.Properties.MaxLength = 20;
            this.spellChecker1.SetShowSpellCheckMenu(this.txtProjectEngineerPercentOfLabor, true);
            this.txtProjectEngineerPercentOfLabor.Size = new System.Drawing.Size(73, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.txtProjectEngineerPercentOfLabor, optionsSpelling92);
            this.txtProjectEngineerPercentOfLabor.TabIndex = 62;
            this.txtProjectEngineerPercentOfLabor.EditValueChanged += new System.EventHandler(this.AllControls_EditValue);
            // 
            // labelControl11
            // 
            this.labelControl11.Location = new System.Drawing.Point(5, 87);
            this.labelControl11.Name = "labelControl11";
            this.labelControl11.Size = new System.Drawing.Size(140, 13);
            this.labelControl11.TabIndex = 576;
            this.labelControl11.Text = "Project Manager % of Labor:";
            // 
            // txtProjectManagerPercentOfLabor
            // 
            this.txtProjectManagerPercentOfLabor.Location = new System.Drawing.Point(155, 86);
            this.txtProjectManagerPercentOfLabor.Name = "txtProjectManagerPercentOfLabor";
            this.txtProjectManagerPercentOfLabor.Properties.DisplayFormat.FormatString = "p2";
            this.txtProjectManagerPercentOfLabor.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtProjectManagerPercentOfLabor.Properties.EditFormat.FormatString = "p2";
            this.txtProjectManagerPercentOfLabor.Properties.EditFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtProjectManagerPercentOfLabor.Properties.Mask.EditMask = "p2";
            this.txtProjectManagerPercentOfLabor.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.txtProjectManagerPercentOfLabor.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.txtProjectManagerPercentOfLabor.Properties.MaxLength = 20;
            this.spellChecker1.SetShowSpellCheckMenu(this.txtProjectManagerPercentOfLabor, true);
            this.txtProjectManagerPercentOfLabor.Size = new System.Drawing.Size(73, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.txtProjectManagerPercentOfLabor, optionsSpelling93);
            this.txtProjectManagerPercentOfLabor.TabIndex = 61;
            this.txtProjectManagerPercentOfLabor.EditValueChanged += new System.EventHandler(this.AllControls_EditValue);
            // 
            // txtSuperintendentPercentOfLabor
            // 
            this.txtSuperintendentPercentOfLabor.Location = new System.Drawing.Point(155, 60);
            this.txtSuperintendentPercentOfLabor.Name = "txtSuperintendentPercentOfLabor";
            this.txtSuperintendentPercentOfLabor.Properties.DisplayFormat.FormatString = "p2";
            this.txtSuperintendentPercentOfLabor.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtSuperintendentPercentOfLabor.Properties.EditFormat.FormatString = "p2";
            this.txtSuperintendentPercentOfLabor.Properties.EditFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtSuperintendentPercentOfLabor.Properties.Mask.EditMask = "p2";
            this.txtSuperintendentPercentOfLabor.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.txtSuperintendentPercentOfLabor.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.txtSuperintendentPercentOfLabor.Properties.MaxLength = 20;
            this.spellChecker1.SetShowSpellCheckMenu(this.txtSuperintendentPercentOfLabor, true);
            this.txtSuperintendentPercentOfLabor.Size = new System.Drawing.Size(73, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.txtSuperintendentPercentOfLabor, optionsSpelling94);
            this.txtSuperintendentPercentOfLabor.TabIndex = 60;
            this.txtSuperintendentPercentOfLabor.EditValueChanged += new System.EventHandler(this.AllControls_EditValue);
            // 
            // labelControl12
            // 
            this.labelControl12.Location = new System.Drawing.Point(5, 63);
            this.labelControl12.Name = "labelControl12";
            this.labelControl12.Size = new System.Drawing.Size(135, 13);
            this.labelControl12.TabIndex = 574;
            this.labelControl12.Text = "Superintendent % of Labor:";
            // 
            // labelControl13
            // 
            this.labelControl13.Location = new System.Drawing.Point(5, 35);
            this.labelControl13.Name = "labelControl13";
            this.labelControl13.Size = new System.Drawing.Size(143, 13);
            this.labelControl13.TabIndex = 572;
            this.labelControl13.Text = "General Foreman % of Labor:";
            // 
            // txtGeneralForemanPercentOfLabor
            // 
            this.txtGeneralForemanPercentOfLabor.Location = new System.Drawing.Point(155, 34);
            this.txtGeneralForemanPercentOfLabor.Name = "txtGeneralForemanPercentOfLabor";
            this.txtGeneralForemanPercentOfLabor.Properties.DisplayFormat.FormatString = "p2";
            this.txtGeneralForemanPercentOfLabor.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtGeneralForemanPercentOfLabor.Properties.EditFormat.FormatString = "p2";
            this.txtGeneralForemanPercentOfLabor.Properties.EditFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtGeneralForemanPercentOfLabor.Properties.Mask.EditMask = "p2";
            this.txtGeneralForemanPercentOfLabor.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.txtGeneralForemanPercentOfLabor.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.txtGeneralForemanPercentOfLabor.Properties.MaxLength = 20;
            this.spellChecker1.SetShowSpellCheckMenu(this.txtGeneralForemanPercentOfLabor, true);
            this.txtGeneralForemanPercentOfLabor.Size = new System.Drawing.Size(73, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.txtGeneralForemanPercentOfLabor, optionsSpelling95);
            this.txtGeneralForemanPercentOfLabor.TabIndex = 59;
            this.txtGeneralForemanPercentOfLabor.EditValueChanged += new System.EventHandler(this.AllControls_EditValue);
            // 
            // txtForemanPercentOfLabor
            // 
            this.txtForemanPercentOfLabor.Location = new System.Drawing.Point(155, 8);
            this.txtForemanPercentOfLabor.Name = "txtForemanPercentOfLabor";
            this.txtForemanPercentOfLabor.Properties.DisplayFormat.FormatString = "p2";
            this.txtForemanPercentOfLabor.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtForemanPercentOfLabor.Properties.EditFormat.FormatString = "p2";
            this.txtForemanPercentOfLabor.Properties.EditFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtForemanPercentOfLabor.Properties.Mask.EditMask = "p2";
            this.txtForemanPercentOfLabor.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.txtForemanPercentOfLabor.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.txtForemanPercentOfLabor.Properties.MaxLength = 20;
            this.spellChecker1.SetShowSpellCheckMenu(this.txtForemanPercentOfLabor, true);
            this.txtForemanPercentOfLabor.Size = new System.Drawing.Size(73, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.txtForemanPercentOfLabor, optionsSpelling96);
            this.txtForemanPercentOfLabor.TabIndex = 58;
            this.txtForemanPercentOfLabor.EditValueChanged += new System.EventHandler(this.AllControls_EditValue);
            // 
            // labelControl14
            // 
            this.labelControl14.Location = new System.Drawing.Point(5, 11);
            this.labelControl14.Name = "labelControl14";
            this.labelControl14.Size = new System.Drawing.Size(103, 13);
            this.labelControl14.TabIndex = 570;
            this.labelControl14.Text = "Foreman % of Labor:";
            // 
            // labelControl10
            // 
            this.labelControl10.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))));
            this.labelControl10.Location = new System.Drawing.Point(337, 16);
            this.labelControl10.Name = "labelControl10";
            this.labelControl10.Size = new System.Drawing.Size(69, 13);
            this.labelControl10.TabIndex = 598;
            this.labelControl10.Text = "Expenses %";
            // 
            // panelControl2
            // 
            this.panelControl2.Controls.Add(this.txtCartigeHandlingPercentText);
            this.panelControl2.Controls.Add(this.txtAsBuiltsEngineeringPercentText);
            this.panelControl2.Controls.Add(this.txtCartigeHandlingPercent);
            this.panelControl2.Controls.Add(this.txtSmallToolsPercentText);
            this.panelControl2.Controls.Add(this.txtSmallToolsPercent);
            this.panelControl2.Controls.Add(this.txtStoragePercentText);
            this.panelControl2.Controls.Add(this.txtStoragePercent);
            this.panelControl2.Controls.Add(this.txtAsBuiltsEngineeringPercent);
            this.panelControl2.Location = new System.Drawing.Point(337, 35);
            this.panelControl2.Name = "panelControl2";
            this.panelControl2.Size = new System.Drawing.Size(258, 113);
            this.panelControl2.TabIndex = 597;
            // 
            // txtCartigeHandlingPercentText
            // 
            this.txtCartigeHandlingPercentText.EditValue = "Cartige Handling";
            this.txtCartigeHandlingPercentText.Location = new System.Drawing.Point(9, 86);
            this.txtCartigeHandlingPercentText.Name = "txtCartigeHandlingPercentText";
            this.txtCartigeHandlingPercentText.Properties.Appearance.BackColor = System.Drawing.Color.White;
            this.txtCartigeHandlingPercentText.Properties.Appearance.Options.UseBackColor = true;
            this.txtCartigeHandlingPercentText.Properties.MaxLength = 35;
            this.spellChecker1.SetShowSpellCheckMenu(this.txtCartigeHandlingPercentText, true);
            this.txtCartigeHandlingPercentText.Size = new System.Drawing.Size(137, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.txtCartigeHandlingPercentText, optionsSpelling97);
            this.txtCartigeHandlingPercentText.TabIndex = 606;
            this.txtCartigeHandlingPercentText.EditValueChanged += new System.EventHandler(this.AllControls_EditValue);
            // 
            // txtAsBuiltsEngineeringPercentText
            // 
            this.txtAsBuiltsEngineeringPercentText.EditValue = "As-Builts/Engineering";
            this.txtAsBuiltsEngineeringPercentText.Location = new System.Drawing.Point(9, 8);
            this.txtAsBuiltsEngineeringPercentText.Name = "txtAsBuiltsEngineeringPercentText";
            this.txtAsBuiltsEngineeringPercentText.Properties.Appearance.BackColor = System.Drawing.Color.White;
            this.txtAsBuiltsEngineeringPercentText.Properties.Appearance.Options.UseBackColor = true;
            this.txtAsBuiltsEngineeringPercentText.Properties.MaxLength = 35;
            this.spellChecker1.SetShowSpellCheckMenu(this.txtAsBuiltsEngineeringPercentText, true);
            this.txtAsBuiltsEngineeringPercentText.Size = new System.Drawing.Size(137, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.txtAsBuiltsEngineeringPercentText, optionsSpelling98);
            this.txtAsBuiltsEngineeringPercentText.TabIndex = 603;
            this.txtAsBuiltsEngineeringPercentText.EditValueChanged += new System.EventHandler(this.AllControls_EditValue);
            // 
            // txtCartigeHandlingPercent
            // 
            this.txtCartigeHandlingPercent.Location = new System.Drawing.Point(155, 86);
            this.txtCartigeHandlingPercent.Name = "txtCartigeHandlingPercent";
            this.txtCartigeHandlingPercent.Properties.DisplayFormat.FormatString = "p2";
            this.txtCartigeHandlingPercent.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtCartigeHandlingPercent.Properties.EditFormat.FormatString = "p2";
            this.txtCartigeHandlingPercent.Properties.EditFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtCartigeHandlingPercent.Properties.Mask.EditMask = "p2";
            this.txtCartigeHandlingPercent.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.txtCartigeHandlingPercent.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.txtCartigeHandlingPercent.Properties.MaxLength = 20;
            this.spellChecker1.SetShowSpellCheckMenu(this.txtCartigeHandlingPercent, true);
            this.txtCartigeHandlingPercent.Size = new System.Drawing.Size(73, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.txtCartigeHandlingPercent, optionsSpelling99);
            this.txtCartigeHandlingPercent.TabIndex = 57;
            this.txtCartigeHandlingPercent.EditValueChanged += new System.EventHandler(this.AllControls_EditValue);
            // 
            // txtSmallToolsPercentText
            // 
            this.txtSmallToolsPercentText.EditValue = "Small Tools";
            this.txtSmallToolsPercentText.Location = new System.Drawing.Point(9, 60);
            this.txtSmallToolsPercentText.Name = "txtSmallToolsPercentText";
            this.txtSmallToolsPercentText.Properties.Appearance.BackColor = System.Drawing.Color.White;
            this.txtSmallToolsPercentText.Properties.Appearance.Options.UseBackColor = true;
            this.txtSmallToolsPercentText.Properties.MaxLength = 35;
            this.spellChecker1.SetShowSpellCheckMenu(this.txtSmallToolsPercentText, true);
            this.txtSmallToolsPercentText.Size = new System.Drawing.Size(137, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.txtSmallToolsPercentText, optionsSpelling100);
            this.txtSmallToolsPercentText.TabIndex = 605;
            this.txtSmallToolsPercentText.EditValueChanged += new System.EventHandler(this.AllControls_EditValue);
            // 
            // txtSmallToolsPercent
            // 
            this.txtSmallToolsPercent.Location = new System.Drawing.Point(155, 60);
            this.txtSmallToolsPercent.Name = "txtSmallToolsPercent";
            this.txtSmallToolsPercent.Properties.DisplayFormat.FormatString = "p2";
            this.txtSmallToolsPercent.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtSmallToolsPercent.Properties.EditFormat.FormatString = "p2";
            this.txtSmallToolsPercent.Properties.EditFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtSmallToolsPercent.Properties.Mask.EditMask = "p2";
            this.txtSmallToolsPercent.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.txtSmallToolsPercent.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.txtSmallToolsPercent.Properties.MaxLength = 20;
            this.spellChecker1.SetShowSpellCheckMenu(this.txtSmallToolsPercent, true);
            this.txtSmallToolsPercent.Size = new System.Drawing.Size(73, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.txtSmallToolsPercent, optionsSpelling101);
            this.txtSmallToolsPercent.TabIndex = 56;
            this.txtSmallToolsPercent.EditValueChanged += new System.EventHandler(this.AllControls_EditValue);
            // 
            // txtStoragePercentText
            // 
            this.txtStoragePercentText.EditValue = "Storage";
            this.txtStoragePercentText.Location = new System.Drawing.Point(9, 34);
            this.txtStoragePercentText.Name = "txtStoragePercentText";
            this.txtStoragePercentText.Properties.Appearance.BackColor = System.Drawing.Color.White;
            this.txtStoragePercentText.Properties.Appearance.Options.UseBackColor = true;
            this.txtStoragePercentText.Properties.MaxLength = 35;
            this.spellChecker1.SetShowSpellCheckMenu(this.txtStoragePercentText, true);
            this.txtStoragePercentText.Size = new System.Drawing.Size(137, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.txtStoragePercentText, optionsSpelling102);
            this.txtStoragePercentText.TabIndex = 604;
            this.txtStoragePercentText.EditValueChanged += new System.EventHandler(this.AllControls_EditValue);
            // 
            // txtStoragePercent
            // 
            this.txtStoragePercent.Location = new System.Drawing.Point(155, 34);
            this.txtStoragePercent.Name = "txtStoragePercent";
            this.txtStoragePercent.Properties.DisplayFormat.FormatString = "p2";
            this.txtStoragePercent.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtStoragePercent.Properties.EditFormat.FormatString = "p2";
            this.txtStoragePercent.Properties.EditFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtStoragePercent.Properties.Mask.EditMask = "p2";
            this.txtStoragePercent.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.txtStoragePercent.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.txtStoragePercent.Properties.MaxLength = 20;
            this.spellChecker1.SetShowSpellCheckMenu(this.txtStoragePercent, true);
            this.txtStoragePercent.Size = new System.Drawing.Size(73, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.txtStoragePercent, optionsSpelling103);
            this.txtStoragePercent.TabIndex = 55;
            this.txtStoragePercent.EditValueChanged += new System.EventHandler(this.AllControls_EditValue);
            // 
            // txtAsBuiltsEngineeringPercent
            // 
            this.txtAsBuiltsEngineeringPercent.Location = new System.Drawing.Point(155, 8);
            this.txtAsBuiltsEngineeringPercent.Name = "txtAsBuiltsEngineeringPercent";
            this.txtAsBuiltsEngineeringPercent.Properties.DisplayFormat.FormatString = "p2";
            this.txtAsBuiltsEngineeringPercent.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtAsBuiltsEngineeringPercent.Properties.EditFormat.FormatString = "p2";
            this.txtAsBuiltsEngineeringPercent.Properties.EditFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtAsBuiltsEngineeringPercent.Properties.Mask.EditMask = "p2";
            this.txtAsBuiltsEngineeringPercent.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.txtAsBuiltsEngineeringPercent.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.txtAsBuiltsEngineeringPercent.Properties.MaxLength = 20;
            this.spellChecker1.SetShowSpellCheckMenu(this.txtAsBuiltsEngineeringPercent, true);
            this.txtAsBuiltsEngineeringPercent.Size = new System.Drawing.Size(73, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.txtAsBuiltsEngineeringPercent, optionsSpelling104);
            this.txtAsBuiltsEngineeringPercent.TabIndex = 54;
            this.txtAsBuiltsEngineeringPercent.EditValueChanged += new System.EventHandler(this.AllControls_EditValue);
            // 
            // panelControl1
            // 
            this.panelControl1.Controls.Add(this.labelControl5);
            this.panelControl1.Controls.Add(this.txtSalesTaxPercent);
            this.panelControl1.Controls.Add(this.txtSundriesPercentOfMaterial);
            this.panelControl1.Controls.Add(this.labelControl4);
            this.panelControl1.Location = new System.Drawing.Point(17, 35);
            this.panelControl1.Name = "panelControl1";
            this.panelControl1.Size = new System.Drawing.Size(258, 60);
            this.panelControl1.TabIndex = 596;
            // 
            // labelControl5
            // 
            this.labelControl5.Location = new System.Drawing.Point(5, 35);
            this.labelControl5.Name = "labelControl5";
            this.labelControl5.Size = new System.Drawing.Size(72, 13);
            this.labelControl5.TabIndex = 572;
            this.labelControl5.Text = "Sales Tax (%):";
            // 
            // txtSalesTaxPercent
            // 
            this.txtSalesTaxPercent.Location = new System.Drawing.Point(155, 34);
            this.txtSalesTaxPercent.Name = "txtSalesTaxPercent";
            this.txtSalesTaxPercent.Properties.DisplayFormat.FormatString = "p2";
            this.txtSalesTaxPercent.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtSalesTaxPercent.Properties.EditFormat.FormatString = "p2";
            this.txtSalesTaxPercent.Properties.EditFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtSalesTaxPercent.Properties.Mask.EditMask = "p2";
            this.txtSalesTaxPercent.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.txtSalesTaxPercent.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.txtSalesTaxPercent.Properties.MaxLength = 20;
            this.spellChecker1.SetShowSpellCheckMenu(this.txtSalesTaxPercent, true);
            this.txtSalesTaxPercent.Size = new System.Drawing.Size(73, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.txtSalesTaxPercent, optionsSpelling105);
            this.txtSalesTaxPercent.TabIndex = 53;
            this.txtSalesTaxPercent.EditValueChanged += new System.EventHandler(this.AllControls_EditValue);
            // 
            // txtSundriesPercentOfMaterial
            // 
            this.txtSundriesPercentOfMaterial.Location = new System.Drawing.Point(155, 8);
            this.txtSundriesPercentOfMaterial.Name = "txtSundriesPercentOfMaterial";
            this.txtSundriesPercentOfMaterial.Properties.DisplayFormat.FormatString = "p2";
            this.txtSundriesPercentOfMaterial.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtSundriesPercentOfMaterial.Properties.EditFormat.FormatString = "p2";
            this.txtSundriesPercentOfMaterial.Properties.EditFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtSundriesPercentOfMaterial.Properties.Mask.EditMask = "p2";
            this.txtSundriesPercentOfMaterial.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.txtSundriesPercentOfMaterial.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.txtSundriesPercentOfMaterial.Properties.MaxLength = 20;
            this.spellChecker1.SetShowSpellCheckMenu(this.txtSundriesPercentOfMaterial, true);
            this.txtSundriesPercentOfMaterial.Size = new System.Drawing.Size(73, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.txtSundriesPercentOfMaterial, optionsSpelling106);
            this.txtSundriesPercentOfMaterial.TabIndex = 52;
            this.txtSundriesPercentOfMaterial.EditValueChanged += new System.EventHandler(this.AllControls_EditValue);
            // 
            // labelControl4
            // 
            this.labelControl4.Location = new System.Drawing.Point(5, 11);
            this.labelControl4.Name = "labelControl4";
            this.labelControl4.Size = new System.Drawing.Size(121, 13);
            this.labelControl4.TabIndex = 570;
            this.labelControl4.Text = "Sundries (% of Material):";
            // 
            // labelControl25
            // 
            this.labelControl25.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))));
            this.labelControl25.Location = new System.Drawing.Point(17, 16);
            this.labelControl25.Name = "labelControl25";
            this.labelControl25.Size = new System.Drawing.Size(47, 13);
            this.labelControl25.TabIndex = 595;
            this.labelControl25.Text = "Material";
            // 
            // xtraTabPage3
            // 
            this.xtraTabPage3.AutoScroll = true;
            this.xtraTabPage3.Controls.Add(this.labelControl112);
            this.xtraTabPage3.Controls.Add(this.panelControl12);
            this.xtraTabPage3.Name = "xtraTabPage3";
            this.xtraTabPage3.Size = new System.Drawing.Size(921, 398);
            this.xtraTabPage3.Text = "Labor Rate Values";
            // 
            // labelControl112
            // 
            this.labelControl112.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))));
            this.labelControl112.Location = new System.Drawing.Point(17, 16);
            this.labelControl112.Name = "labelControl112";
            this.labelControl112.Size = new System.Drawing.Size(62, 13);
            this.labelControl112.TabIndex = 603;
            this.labelControl112.Text = "Labor Rate";
            // 
            // panelControl12
            // 
            this.panelControl12.Controls.Add(this.txtBIMRateDT);
            this.panelControl12.Controls.Add(this.txtBIMRateOT);
            this.panelControl12.Controls.Add(this.labelControl167);
            this.panelControl12.Controls.Add(this.txtBIMRate);
            this.panelControl12.Controls.Add(this.labelControl154);
            this.panelControl12.Controls.Add(this.labelControl155);
            this.panelControl12.Controls.Add(this.labelControl156);
            this.panelControl12.Controls.Add(this.txtApprenticeLaborRateDT);
            this.panelControl12.Controls.Add(this.txtProjectEngineerLaborRateDT);
            this.panelControl12.Controls.Add(this.txtPremiumTimeLaborRateDT);
            this.panelControl12.Controls.Add(this.txtSafetyMeetingsLaborRateDT);
            this.panelControl12.Controls.Add(this.txtProjectManagerLaborRateDT);
            this.panelControl12.Controls.Add(this.txtSuperintendentLaborRateDT);
            this.panelControl12.Controls.Add(this.txtGeneralForemanLaborRateDT);
            this.panelControl12.Controls.Add(this.txtForemanLaborRateDT);
            this.panelControl12.Controls.Add(this.txtElectricianLaborRateDT);
            this.panelControl12.Controls.Add(this.txtApprenticeLaborRateOT);
            this.panelControl12.Controls.Add(this.txtProjectEngineerLaborRateOT);
            this.panelControl12.Controls.Add(this.txtPremiumTimeLaborRateOT);
            this.panelControl12.Controls.Add(this.txtSafetyMeetingsLaborRateOT);
            this.panelControl12.Controls.Add(this.txtProjectManagerLaborRateOT);
            this.panelControl12.Controls.Add(this.txtSuperintendentLaborRateOT);
            this.panelControl12.Controls.Add(this.txtGeneralForemanLaborRateOT);
            this.panelControl12.Controls.Add(this.txtForemanLaborRateOT);
            this.panelControl12.Controls.Add(this.txtElectricianLaborRateOT);
            this.panelControl12.Controls.Add(this.labelControl152);
            this.panelControl12.Controls.Add(this.txtApprenticeLaborRate);
            this.panelControl12.Controls.Add(this.labelControl120);
            this.panelControl12.Controls.Add(this.txtProjectEngineerLaborRate);
            this.panelControl12.Controls.Add(this.labelControl113);
            this.panelControl12.Controls.Add(this.txtPremiumTimeLaborRate);
            this.panelControl12.Controls.Add(this.txtSafetyMeetingsLaborRate);
            this.panelControl12.Controls.Add(this.labelControl114);
            this.panelControl12.Controls.Add(this.labelControl115);
            this.panelControl12.Controls.Add(this.txtProjectManagerLaborRate);
            this.panelControl12.Controls.Add(this.labelControl116);
            this.panelControl12.Controls.Add(this.txtSuperintendentLaborRate);
            this.panelControl12.Controls.Add(this.txtGeneralForemanLaborRate);
            this.panelControl12.Controls.Add(this.labelControl117);
            this.panelControl12.Controls.Add(this.labelControl118);
            this.panelControl12.Controls.Add(this.txtForemanLaborRate);
            this.panelControl12.Controls.Add(this.txtElectricianLaborRate);
            this.panelControl12.Controls.Add(this.labelControl119);
            this.panelControl12.Location = new System.Drawing.Point(17, 35);
            this.panelControl12.Name = "panelControl12";
            this.panelControl12.Size = new System.Drawing.Size(479, 279);
            this.panelControl12.TabIndex = 602;
            // 
            // txtBIMRateDT
            // 
            this.txtBIMRateDT.Location = new System.Drawing.Point(362, 13);
            this.txtBIMRateDT.Name = "txtBIMRateDT";
            this.txtBIMRateDT.Properties.DisplayFormat.FormatString = "c2";
            this.txtBIMRateDT.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtBIMRateDT.Properties.EditFormat.FormatString = "c2";
            this.txtBIMRateDT.Properties.EditFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtBIMRateDT.Properties.Mask.EditMask = "c2";
            this.txtBIMRateDT.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.txtBIMRateDT.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.txtBIMRateDT.Properties.MaxLength = 20;
            this.spellChecker1.SetShowSpellCheckMenu(this.txtBIMRateDT, true);
            this.txtBIMRateDT.Size = new System.Drawing.Size(73, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.txtBIMRateDT, optionsSpelling107);
            this.txtBIMRateDT.TabIndex = 86;
            this.txtBIMRateDT.EditValueChanged += new System.EventHandler(this.AllControls_EditValue);
            // 
            // txtBIMRateOT
            // 
            this.txtBIMRateOT.Location = new System.Drawing.Point(252, 13);
            this.txtBIMRateOT.Name = "txtBIMRateOT";
            this.txtBIMRateOT.Properties.DisplayFormat.FormatString = "c2";
            this.txtBIMRateOT.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtBIMRateOT.Properties.EditFormat.FormatString = "c2";
            this.txtBIMRateOT.Properties.EditFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtBIMRateOT.Properties.Mask.EditMask = "c2";
            this.txtBIMRateOT.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.txtBIMRateOT.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.txtBIMRateOT.Properties.MaxLength = 20;
            this.spellChecker1.SetShowSpellCheckMenu(this.txtBIMRateOT, true);
            this.txtBIMRateOT.Size = new System.Drawing.Size(73, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.txtBIMRateOT, optionsSpelling108);
            this.txtBIMRateOT.TabIndex = 77;
            this.txtBIMRateOT.EditValueChanged += new System.EventHandler(this.AllControls_EditValue);
            // 
            // labelControl167
            // 
            this.labelControl167.Location = new System.Drawing.Point(3, 16);
            this.labelControl167.Name = "labelControl167";
            this.labelControl167.Size = new System.Drawing.Size(48, 13);
            this.labelControl167.TabIndex = 613;
            this.labelControl167.Text = "BIM Rate:";
            // 
            // txtBIMRate
            // 
            this.txtBIMRate.Location = new System.Drawing.Point(153, 13);
            this.txtBIMRate.Name = "txtBIMRate";
            this.txtBIMRate.Properties.DisplayFormat.FormatString = "c2";
            this.txtBIMRate.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtBIMRate.Properties.EditFormat.FormatString = "c2";
            this.txtBIMRate.Properties.EditFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtBIMRate.Properties.Mask.EditMask = "c2";
            this.txtBIMRate.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.txtBIMRate.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.txtBIMRate.Properties.MaxLength = 20;
            this.spellChecker1.SetShowSpellCheckMenu(this.txtBIMRate, true);
            this.txtBIMRate.Size = new System.Drawing.Size(73, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.txtBIMRate, optionsSpelling109);
            this.txtBIMRate.TabIndex = 68;
            this.txtBIMRate.EditValueChanged += new System.EventHandler(this.AllControls_EditValue);
            // 
            // labelControl154
            // 
            this.labelControl154.Location = new System.Drawing.Point(394, 0);
            this.labelControl154.Name = "labelControl154";
            this.labelControl154.Size = new System.Drawing.Size(13, 13);
            this.labelControl154.TabIndex = 609;
            this.labelControl154.Text = "DT";
            // 
            // labelControl155
            // 
            this.labelControl155.Location = new System.Drawing.Point(286, 0);
            this.labelControl155.Name = "labelControl155";
            this.labelControl155.Size = new System.Drawing.Size(14, 13);
            this.labelControl155.TabIndex = 608;
            this.labelControl155.Text = "OT";
            // 
            // labelControl156
            // 
            this.labelControl156.Location = new System.Drawing.Point(189, 0);
            this.labelControl156.Name = "labelControl156";
            this.labelControl156.Size = new System.Drawing.Size(12, 13);
            this.labelControl156.TabIndex = 607;
            this.labelControl156.Text = "ST";
            // 
            // txtApprenticeLaborRateDT
            // 
            this.txtApprenticeLaborRateDT.Location = new System.Drawing.Point(362, 39);
            this.txtApprenticeLaborRateDT.Name = "txtApprenticeLaborRateDT";
            this.txtApprenticeLaborRateDT.Properties.DisplayFormat.FormatString = "c2";
            this.txtApprenticeLaborRateDT.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtApprenticeLaborRateDT.Properties.EditFormat.FormatString = "c2";
            this.txtApprenticeLaborRateDT.Properties.EditFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtApprenticeLaborRateDT.Properties.Mask.EditMask = "c2";
            this.txtApprenticeLaborRateDT.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.txtApprenticeLaborRateDT.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.txtApprenticeLaborRateDT.Properties.MaxLength = 20;
            this.spellChecker1.SetShowSpellCheckMenu(this.txtApprenticeLaborRateDT, true);
            this.txtApprenticeLaborRateDT.Size = new System.Drawing.Size(73, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.txtApprenticeLaborRateDT, optionsSpelling110);
            this.txtApprenticeLaborRateDT.TabIndex = 87;
            this.txtApprenticeLaborRateDT.EditValueChanged += new System.EventHandler(this.AllControls_EditValue);
            // 
            // txtProjectEngineerLaborRateDT
            // 
            this.txtProjectEngineerLaborRateDT.Location = new System.Drawing.Point(362, 195);
            this.txtProjectEngineerLaborRateDT.Name = "txtProjectEngineerLaborRateDT";
            this.txtProjectEngineerLaborRateDT.Properties.DisplayFormat.FormatString = "c2";
            this.txtProjectEngineerLaborRateDT.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtProjectEngineerLaborRateDT.Properties.EditFormat.FormatString = "c2";
            this.txtProjectEngineerLaborRateDT.Properties.EditFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtProjectEngineerLaborRateDT.Properties.Mask.EditMask = "c2";
            this.txtProjectEngineerLaborRateDT.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.txtProjectEngineerLaborRateDT.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.txtProjectEngineerLaborRateDT.Properties.MaxLength = 20;
            this.spellChecker1.SetShowSpellCheckMenu(this.txtProjectEngineerLaborRateDT, true);
            this.txtProjectEngineerLaborRateDT.Size = new System.Drawing.Size(73, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.txtProjectEngineerLaborRateDT, optionsSpelling111);
            this.txtProjectEngineerLaborRateDT.TabIndex = 93;
            this.txtProjectEngineerLaborRateDT.EditValueChanged += new System.EventHandler(this.AllControls_EditValue);
            // 
            // txtPremiumTimeLaborRateDT
            // 
            this.txtPremiumTimeLaborRateDT.Location = new System.Drawing.Point(362, 247);
            this.txtPremiumTimeLaborRateDT.Name = "txtPremiumTimeLaborRateDT";
            this.txtPremiumTimeLaborRateDT.Properties.DisplayFormat.FormatString = "c2";
            this.txtPremiumTimeLaborRateDT.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtPremiumTimeLaborRateDT.Properties.EditFormat.FormatString = "c2";
            this.txtPremiumTimeLaborRateDT.Properties.EditFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtPremiumTimeLaborRateDT.Properties.Mask.EditMask = "c2";
            this.txtPremiumTimeLaborRateDT.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.txtPremiumTimeLaborRateDT.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.txtPremiumTimeLaborRateDT.Properties.MaxLength = 20;
            this.spellChecker1.SetShowSpellCheckMenu(this.txtPremiumTimeLaborRateDT, true);
            this.txtPremiumTimeLaborRateDT.Size = new System.Drawing.Size(73, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.txtPremiumTimeLaborRateDT, optionsSpelling112);
            this.txtPremiumTimeLaborRateDT.TabIndex = 95;
            this.txtPremiumTimeLaborRateDT.EditValueChanged += new System.EventHandler(this.AllControls_EditValue);
            // 
            // txtSafetyMeetingsLaborRateDT
            // 
            this.txtSafetyMeetingsLaborRateDT.Location = new System.Drawing.Point(362, 221);
            this.txtSafetyMeetingsLaborRateDT.Name = "txtSafetyMeetingsLaborRateDT";
            this.txtSafetyMeetingsLaborRateDT.Properties.DisplayFormat.FormatString = "c2";
            this.txtSafetyMeetingsLaborRateDT.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtSafetyMeetingsLaborRateDT.Properties.EditFormat.FormatString = "c2";
            this.txtSafetyMeetingsLaborRateDT.Properties.EditFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtSafetyMeetingsLaborRateDT.Properties.Mask.EditMask = "c2";
            this.txtSafetyMeetingsLaborRateDT.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.txtSafetyMeetingsLaborRateDT.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.txtSafetyMeetingsLaborRateDT.Properties.MaxLength = 20;
            this.spellChecker1.SetShowSpellCheckMenu(this.txtSafetyMeetingsLaborRateDT, true);
            this.txtSafetyMeetingsLaborRateDT.Size = new System.Drawing.Size(73, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.txtSafetyMeetingsLaborRateDT, optionsSpelling113);
            this.txtSafetyMeetingsLaborRateDT.TabIndex = 94;
            this.txtSafetyMeetingsLaborRateDT.EditValueChanged += new System.EventHandler(this.AllControls_EditValue);
            // 
            // txtProjectManagerLaborRateDT
            // 
            this.txtProjectManagerLaborRateDT.Location = new System.Drawing.Point(362, 169);
            this.txtProjectManagerLaborRateDT.Name = "txtProjectManagerLaborRateDT";
            this.txtProjectManagerLaborRateDT.Properties.DisplayFormat.FormatString = "c2";
            this.txtProjectManagerLaborRateDT.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtProjectManagerLaborRateDT.Properties.EditFormat.FormatString = "c2";
            this.txtProjectManagerLaborRateDT.Properties.EditFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtProjectManagerLaborRateDT.Properties.Mask.EditMask = "c2";
            this.txtProjectManagerLaborRateDT.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.txtProjectManagerLaborRateDT.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.txtProjectManagerLaborRateDT.Properties.MaxLength = 20;
            this.spellChecker1.SetShowSpellCheckMenu(this.txtProjectManagerLaborRateDT, true);
            this.txtProjectManagerLaborRateDT.Size = new System.Drawing.Size(73, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.txtProjectManagerLaborRateDT, optionsSpelling114);
            this.txtProjectManagerLaborRateDT.TabIndex = 92;
            this.txtProjectManagerLaborRateDT.EditValueChanged += new System.EventHandler(this.AllControls_EditValue);
            // 
            // txtSuperintendentLaborRateDT
            // 
            this.txtSuperintendentLaborRateDT.Location = new System.Drawing.Point(362, 143);
            this.txtSuperintendentLaborRateDT.Name = "txtSuperintendentLaborRateDT";
            this.txtSuperintendentLaborRateDT.Properties.DisplayFormat.FormatString = "c2";
            this.txtSuperintendentLaborRateDT.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtSuperintendentLaborRateDT.Properties.EditFormat.FormatString = "c2";
            this.txtSuperintendentLaborRateDT.Properties.EditFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtSuperintendentLaborRateDT.Properties.Mask.EditMask = "c2";
            this.txtSuperintendentLaborRateDT.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.txtSuperintendentLaborRateDT.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.txtSuperintendentLaborRateDT.Properties.MaxLength = 20;
            this.spellChecker1.SetShowSpellCheckMenu(this.txtSuperintendentLaborRateDT, true);
            this.txtSuperintendentLaborRateDT.Size = new System.Drawing.Size(73, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.txtSuperintendentLaborRateDT, optionsSpelling115);
            this.txtSuperintendentLaborRateDT.TabIndex = 91;
            this.txtSuperintendentLaborRateDT.EditValueChanged += new System.EventHandler(this.AllControls_EditValue);
            // 
            // txtGeneralForemanLaborRateDT
            // 
            this.txtGeneralForemanLaborRateDT.Location = new System.Drawing.Point(362, 117);
            this.txtGeneralForemanLaborRateDT.Name = "txtGeneralForemanLaborRateDT";
            this.txtGeneralForemanLaborRateDT.Properties.DisplayFormat.FormatString = "c2";
            this.txtGeneralForemanLaborRateDT.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtGeneralForemanLaborRateDT.Properties.EditFormat.FormatString = "c2";
            this.txtGeneralForemanLaborRateDT.Properties.EditFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtGeneralForemanLaborRateDT.Properties.Mask.EditMask = "c2";
            this.txtGeneralForemanLaborRateDT.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.txtGeneralForemanLaborRateDT.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.txtGeneralForemanLaborRateDT.Properties.MaxLength = 20;
            this.spellChecker1.SetShowSpellCheckMenu(this.txtGeneralForemanLaborRateDT, true);
            this.txtGeneralForemanLaborRateDT.Size = new System.Drawing.Size(73, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.txtGeneralForemanLaborRateDT, optionsSpelling116);
            this.txtGeneralForemanLaborRateDT.TabIndex = 90;
            this.txtGeneralForemanLaborRateDT.EditValueChanged += new System.EventHandler(this.AllControls_EditValue);
            // 
            // txtForemanLaborRateDT
            // 
            this.txtForemanLaborRateDT.Location = new System.Drawing.Point(362, 91);
            this.txtForemanLaborRateDT.Name = "txtForemanLaborRateDT";
            this.txtForemanLaborRateDT.Properties.DisplayFormat.FormatString = "c2";
            this.txtForemanLaborRateDT.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtForemanLaborRateDT.Properties.EditFormat.FormatString = "c2";
            this.txtForemanLaborRateDT.Properties.EditFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtForemanLaborRateDT.Properties.Mask.EditMask = "c2";
            this.txtForemanLaborRateDT.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.txtForemanLaborRateDT.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.txtForemanLaborRateDT.Properties.MaxLength = 20;
            this.spellChecker1.SetShowSpellCheckMenu(this.txtForemanLaborRateDT, true);
            this.txtForemanLaborRateDT.Size = new System.Drawing.Size(73, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.txtForemanLaborRateDT, optionsSpelling117);
            this.txtForemanLaborRateDT.TabIndex = 89;
            this.txtForemanLaborRateDT.EditValueChanged += new System.EventHandler(this.AllControls_EditValue);
            // 
            // txtElectricianLaborRateDT
            // 
            this.txtElectricianLaborRateDT.Location = new System.Drawing.Point(362, 65);
            this.txtElectricianLaborRateDT.Name = "txtElectricianLaborRateDT";
            this.txtElectricianLaborRateDT.Properties.DisplayFormat.FormatString = "c2";
            this.txtElectricianLaborRateDT.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtElectricianLaborRateDT.Properties.EditFormat.FormatString = "c2";
            this.txtElectricianLaborRateDT.Properties.EditFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtElectricianLaborRateDT.Properties.Mask.EditMask = "c2";
            this.txtElectricianLaborRateDT.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.txtElectricianLaborRateDT.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.txtElectricianLaborRateDT.Properties.MaxLength = 20;
            this.spellChecker1.SetShowSpellCheckMenu(this.txtElectricianLaborRateDT, true);
            this.txtElectricianLaborRateDT.Size = new System.Drawing.Size(73, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.txtElectricianLaborRateDT, optionsSpelling118);
            this.txtElectricianLaborRateDT.TabIndex = 88;
            this.txtElectricianLaborRateDT.EditValueChanged += new System.EventHandler(this.AllControls_EditValue);
            // 
            // txtApprenticeLaborRateOT
            // 
            this.txtApprenticeLaborRateOT.Location = new System.Drawing.Point(252, 39);
            this.txtApprenticeLaborRateOT.Name = "txtApprenticeLaborRateOT";
            this.txtApprenticeLaborRateOT.Properties.DisplayFormat.FormatString = "c2";
            this.txtApprenticeLaborRateOT.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtApprenticeLaborRateOT.Properties.EditFormat.FormatString = "c2";
            this.txtApprenticeLaborRateOT.Properties.EditFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtApprenticeLaborRateOT.Properties.Mask.EditMask = "c2";
            this.txtApprenticeLaborRateOT.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.txtApprenticeLaborRateOT.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.txtApprenticeLaborRateOT.Properties.MaxLength = 20;
            this.spellChecker1.SetShowSpellCheckMenu(this.txtApprenticeLaborRateOT, true);
            this.txtApprenticeLaborRateOT.Size = new System.Drawing.Size(73, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.txtApprenticeLaborRateOT, optionsSpelling119);
            this.txtApprenticeLaborRateOT.TabIndex = 78;
            this.txtApprenticeLaborRateOT.EditValueChanged += new System.EventHandler(this.AllControls_EditValue);
            // 
            // txtProjectEngineerLaborRateOT
            // 
            this.txtProjectEngineerLaborRateOT.Location = new System.Drawing.Point(252, 195);
            this.txtProjectEngineerLaborRateOT.Name = "txtProjectEngineerLaborRateOT";
            this.txtProjectEngineerLaborRateOT.Properties.DisplayFormat.FormatString = "c2";
            this.txtProjectEngineerLaborRateOT.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtProjectEngineerLaborRateOT.Properties.EditFormat.FormatString = "c2";
            this.txtProjectEngineerLaborRateOT.Properties.EditFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtProjectEngineerLaborRateOT.Properties.Mask.EditMask = "c2";
            this.txtProjectEngineerLaborRateOT.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.txtProjectEngineerLaborRateOT.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.txtProjectEngineerLaborRateOT.Properties.MaxLength = 20;
            this.spellChecker1.SetShowSpellCheckMenu(this.txtProjectEngineerLaborRateOT, true);
            this.txtProjectEngineerLaborRateOT.Size = new System.Drawing.Size(73, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.txtProjectEngineerLaborRateOT, optionsSpelling120);
            this.txtProjectEngineerLaborRateOT.TabIndex = 84;
            this.txtProjectEngineerLaborRateOT.EditValueChanged += new System.EventHandler(this.AllControls_EditValue);
            // 
            // txtPremiumTimeLaborRateOT
            // 
            this.txtPremiumTimeLaborRateOT.Location = new System.Drawing.Point(252, 247);
            this.txtPremiumTimeLaborRateOT.Name = "txtPremiumTimeLaborRateOT";
            this.txtPremiumTimeLaborRateOT.Properties.DisplayFormat.FormatString = "c2";
            this.txtPremiumTimeLaborRateOT.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtPremiumTimeLaborRateOT.Properties.EditFormat.FormatString = "c2";
            this.txtPremiumTimeLaborRateOT.Properties.EditFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtPremiumTimeLaborRateOT.Properties.Mask.EditMask = "c2";
            this.txtPremiumTimeLaborRateOT.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.txtPremiumTimeLaborRateOT.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.txtPremiumTimeLaborRateOT.Properties.MaxLength = 20;
            this.spellChecker1.SetShowSpellCheckMenu(this.txtPremiumTimeLaborRateOT, true);
            this.txtPremiumTimeLaborRateOT.Size = new System.Drawing.Size(73, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.txtPremiumTimeLaborRateOT, optionsSpelling121);
            this.txtPremiumTimeLaborRateOT.TabIndex = 86;
            this.txtPremiumTimeLaborRateOT.EditValueChanged += new System.EventHandler(this.AllControls_EditValue);
            // 
            // txtSafetyMeetingsLaborRateOT
            // 
            this.txtSafetyMeetingsLaborRateOT.Location = new System.Drawing.Point(252, 221);
            this.txtSafetyMeetingsLaborRateOT.Name = "txtSafetyMeetingsLaborRateOT";
            this.txtSafetyMeetingsLaborRateOT.Properties.DisplayFormat.FormatString = "c2";
            this.txtSafetyMeetingsLaborRateOT.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtSafetyMeetingsLaborRateOT.Properties.EditFormat.FormatString = "c2";
            this.txtSafetyMeetingsLaborRateOT.Properties.EditFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtSafetyMeetingsLaborRateOT.Properties.Mask.EditMask = "c2";
            this.txtSafetyMeetingsLaborRateOT.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.txtSafetyMeetingsLaborRateOT.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.txtSafetyMeetingsLaborRateOT.Properties.MaxLength = 20;
            this.spellChecker1.SetShowSpellCheckMenu(this.txtSafetyMeetingsLaborRateOT, true);
            this.txtSafetyMeetingsLaborRateOT.Size = new System.Drawing.Size(73, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.txtSafetyMeetingsLaborRateOT, optionsSpelling122);
            this.txtSafetyMeetingsLaborRateOT.TabIndex = 85;
            this.txtSafetyMeetingsLaborRateOT.EditValueChanged += new System.EventHandler(this.AllControls_EditValue);
            // 
            // txtProjectManagerLaborRateOT
            // 
            this.txtProjectManagerLaborRateOT.Location = new System.Drawing.Point(252, 169);
            this.txtProjectManagerLaborRateOT.Name = "txtProjectManagerLaborRateOT";
            this.txtProjectManagerLaborRateOT.Properties.DisplayFormat.FormatString = "c2";
            this.txtProjectManagerLaborRateOT.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtProjectManagerLaborRateOT.Properties.EditFormat.FormatString = "c2";
            this.txtProjectManagerLaborRateOT.Properties.EditFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtProjectManagerLaborRateOT.Properties.Mask.EditMask = "c2";
            this.txtProjectManagerLaborRateOT.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.txtProjectManagerLaborRateOT.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.txtProjectManagerLaborRateOT.Properties.MaxLength = 20;
            this.spellChecker1.SetShowSpellCheckMenu(this.txtProjectManagerLaborRateOT, true);
            this.txtProjectManagerLaborRateOT.Size = new System.Drawing.Size(73, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.txtProjectManagerLaborRateOT, optionsSpelling123);
            this.txtProjectManagerLaborRateOT.TabIndex = 83;
            this.txtProjectManagerLaborRateOT.EditValueChanged += new System.EventHandler(this.AllControls_EditValue);
            // 
            // txtSuperintendentLaborRateOT
            // 
            this.txtSuperintendentLaborRateOT.Location = new System.Drawing.Point(252, 143);
            this.txtSuperintendentLaborRateOT.Name = "txtSuperintendentLaborRateOT";
            this.txtSuperintendentLaborRateOT.Properties.DisplayFormat.FormatString = "c2";
            this.txtSuperintendentLaborRateOT.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtSuperintendentLaborRateOT.Properties.EditFormat.FormatString = "c2";
            this.txtSuperintendentLaborRateOT.Properties.EditFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtSuperintendentLaborRateOT.Properties.Mask.EditMask = "c2";
            this.txtSuperintendentLaborRateOT.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.txtSuperintendentLaborRateOT.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.txtSuperintendentLaborRateOT.Properties.MaxLength = 20;
            this.spellChecker1.SetShowSpellCheckMenu(this.txtSuperintendentLaborRateOT, true);
            this.txtSuperintendentLaborRateOT.Size = new System.Drawing.Size(73, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.txtSuperintendentLaborRateOT, optionsSpelling124);
            this.txtSuperintendentLaborRateOT.TabIndex = 82;
            this.txtSuperintendentLaborRateOT.EditValueChanged += new System.EventHandler(this.AllControls_EditValue);
            // 
            // txtGeneralForemanLaborRateOT
            // 
            this.txtGeneralForemanLaborRateOT.Location = new System.Drawing.Point(252, 117);
            this.txtGeneralForemanLaborRateOT.Name = "txtGeneralForemanLaborRateOT";
            this.txtGeneralForemanLaborRateOT.Properties.DisplayFormat.FormatString = "c2";
            this.txtGeneralForemanLaborRateOT.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtGeneralForemanLaborRateOT.Properties.EditFormat.FormatString = "c2";
            this.txtGeneralForemanLaborRateOT.Properties.EditFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtGeneralForemanLaborRateOT.Properties.Mask.EditMask = "c2";
            this.txtGeneralForemanLaborRateOT.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.txtGeneralForemanLaborRateOT.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.txtGeneralForemanLaborRateOT.Properties.MaxLength = 20;
            this.spellChecker1.SetShowSpellCheckMenu(this.txtGeneralForemanLaborRateOT, true);
            this.txtGeneralForemanLaborRateOT.Size = new System.Drawing.Size(73, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.txtGeneralForemanLaborRateOT, optionsSpelling125);
            this.txtGeneralForemanLaborRateOT.TabIndex = 81;
            this.txtGeneralForemanLaborRateOT.EditValueChanged += new System.EventHandler(this.AllControls_EditValue);
            // 
            // txtForemanLaborRateOT
            // 
            this.txtForemanLaborRateOT.Location = new System.Drawing.Point(252, 91);
            this.txtForemanLaborRateOT.Name = "txtForemanLaborRateOT";
            this.txtForemanLaborRateOT.Properties.DisplayFormat.FormatString = "c2";
            this.txtForemanLaborRateOT.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtForemanLaborRateOT.Properties.EditFormat.FormatString = "c2";
            this.txtForemanLaborRateOT.Properties.EditFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtForemanLaborRateOT.Properties.Mask.EditMask = "c2";
            this.txtForemanLaborRateOT.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.txtForemanLaborRateOT.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.txtForemanLaborRateOT.Properties.MaxLength = 20;
            this.spellChecker1.SetShowSpellCheckMenu(this.txtForemanLaborRateOT, true);
            this.txtForemanLaborRateOT.Size = new System.Drawing.Size(73, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.txtForemanLaborRateOT, optionsSpelling126);
            this.txtForemanLaborRateOT.TabIndex = 80;
            this.txtForemanLaborRateOT.EditValueChanged += new System.EventHandler(this.AllControls_EditValue);
            // 
            // txtElectricianLaborRateOT
            // 
            this.txtElectricianLaborRateOT.Location = new System.Drawing.Point(252, 65);
            this.txtElectricianLaborRateOT.Name = "txtElectricianLaborRateOT";
            this.txtElectricianLaborRateOT.Properties.DisplayFormat.FormatString = "c2";
            this.txtElectricianLaborRateOT.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtElectricianLaborRateOT.Properties.EditFormat.FormatString = "c2";
            this.txtElectricianLaborRateOT.Properties.EditFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtElectricianLaborRateOT.Properties.Mask.EditMask = "c2";
            this.txtElectricianLaborRateOT.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.txtElectricianLaborRateOT.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.txtElectricianLaborRateOT.Properties.MaxLength = 20;
            this.spellChecker1.SetShowSpellCheckMenu(this.txtElectricianLaborRateOT, true);
            this.txtElectricianLaborRateOT.Size = new System.Drawing.Size(73, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.txtElectricianLaborRateOT, optionsSpelling127);
            this.txtElectricianLaborRateOT.TabIndex = 79;
            this.txtElectricianLaborRateOT.EditValueChanged += new System.EventHandler(this.AllControls_EditValue);
            // 
            // labelControl152
            // 
            this.labelControl152.Location = new System.Drawing.Point(3, 42);
            this.labelControl152.Name = "labelControl152";
            this.labelControl152.Size = new System.Drawing.Size(112, 13);
            this.labelControl152.TabIndex = 586;
            this.labelControl152.Text = "Apprentice Labor Rate:";
            // 
            // txtApprenticeLaborRate
            // 
            this.txtApprenticeLaborRate.Location = new System.Drawing.Point(153, 39);
            this.txtApprenticeLaborRate.Name = "txtApprenticeLaborRate";
            this.txtApprenticeLaborRate.Properties.DisplayFormat.FormatString = "c2";
            this.txtApprenticeLaborRate.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtApprenticeLaborRate.Properties.EditFormat.FormatString = "c2";
            this.txtApprenticeLaborRate.Properties.EditFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtApprenticeLaborRate.Properties.Mask.EditMask = "c2";
            this.txtApprenticeLaborRate.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.txtApprenticeLaborRate.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.txtApprenticeLaborRate.Properties.MaxLength = 20;
            this.spellChecker1.SetShowSpellCheckMenu(this.txtApprenticeLaborRate, true);
            this.txtApprenticeLaborRate.Size = new System.Drawing.Size(73, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.txtApprenticeLaborRate, optionsSpelling128);
            this.txtApprenticeLaborRate.TabIndex = 69;
            this.txtApprenticeLaborRate.EditValueChanged += new System.EventHandler(this.AllControls_EditValue);
            // 
            // labelControl120
            // 
            this.labelControl120.Location = new System.Drawing.Point(3, 198);
            this.labelControl120.Name = "labelControl120";
            this.labelControl120.Size = new System.Drawing.Size(139, 13);
            this.labelControl120.TabIndex = 584;
            this.labelControl120.Text = "Project Engineer Labor Rate:";
            // 
            // txtProjectEngineerLaborRate
            // 
            this.txtProjectEngineerLaborRate.Location = new System.Drawing.Point(153, 195);
            this.txtProjectEngineerLaborRate.Name = "txtProjectEngineerLaborRate";
            this.txtProjectEngineerLaborRate.Properties.DisplayFormat.FormatString = "c2";
            this.txtProjectEngineerLaborRate.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtProjectEngineerLaborRate.Properties.EditFormat.FormatString = "c2";
            this.txtProjectEngineerLaborRate.Properties.EditFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtProjectEngineerLaborRate.Properties.Mask.EditMask = "c2";
            this.txtProjectEngineerLaborRate.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.txtProjectEngineerLaborRate.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.txtProjectEngineerLaborRate.Properties.MaxLength = 20;
            this.spellChecker1.SetShowSpellCheckMenu(this.txtProjectEngineerLaborRate, true);
            this.txtProjectEngineerLaborRate.Size = new System.Drawing.Size(73, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.txtProjectEngineerLaborRate, optionsSpelling129);
            this.txtProjectEngineerLaborRate.TabIndex = 75;
            this.txtProjectEngineerLaborRate.EditValueChanged += new System.EventHandler(this.AllControls_EditValue);
            // 
            // labelControl113
            // 
            this.labelControl113.Location = new System.Drawing.Point(3, 248);
            this.labelControl113.Name = "labelControl113";
            this.labelControl113.Size = new System.Drawing.Size(125, 13);
            this.labelControl113.TabIndex = 582;
            this.labelControl113.Text = "Premium Time Labor Rate:";
            // 
            // txtPremiumTimeLaborRate
            // 
            this.txtPremiumTimeLaborRate.Location = new System.Drawing.Point(153, 247);
            this.txtPremiumTimeLaborRate.Name = "txtPremiumTimeLaborRate";
            this.txtPremiumTimeLaborRate.Properties.DisplayFormat.FormatString = "c2";
            this.txtPremiumTimeLaborRate.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtPremiumTimeLaborRate.Properties.EditFormat.FormatString = "c2";
            this.txtPremiumTimeLaborRate.Properties.EditFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtPremiumTimeLaborRate.Properties.Mask.EditMask = "c2";
            this.txtPremiumTimeLaborRate.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.txtPremiumTimeLaborRate.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.txtPremiumTimeLaborRate.Properties.MaxLength = 20;
            this.spellChecker1.SetShowSpellCheckMenu(this.txtPremiumTimeLaborRate, true);
            this.txtPremiumTimeLaborRate.Size = new System.Drawing.Size(73, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.txtPremiumTimeLaborRate, optionsSpelling130);
            this.txtPremiumTimeLaborRate.TabIndex = 77;
            this.txtPremiumTimeLaborRate.EditValueChanged += new System.EventHandler(this.AllControls_EditValue);
            // 
            // txtSafetyMeetingsLaborRate
            // 
            this.txtSafetyMeetingsLaborRate.Location = new System.Drawing.Point(153, 221);
            this.txtSafetyMeetingsLaborRate.Name = "txtSafetyMeetingsLaborRate";
            this.txtSafetyMeetingsLaborRate.Properties.DisplayFormat.FormatString = "c2";
            this.txtSafetyMeetingsLaborRate.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtSafetyMeetingsLaborRate.Properties.EditFormat.FormatString = "c2";
            this.txtSafetyMeetingsLaborRate.Properties.EditFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtSafetyMeetingsLaborRate.Properties.Mask.EditMask = "c2";
            this.txtSafetyMeetingsLaborRate.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.txtSafetyMeetingsLaborRate.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.txtSafetyMeetingsLaborRate.Properties.MaxLength = 20;
            this.spellChecker1.SetShowSpellCheckMenu(this.txtSafetyMeetingsLaborRate, true);
            this.txtSafetyMeetingsLaborRate.Size = new System.Drawing.Size(73, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.txtSafetyMeetingsLaborRate, optionsSpelling131);
            this.txtSafetyMeetingsLaborRate.TabIndex = 76;
            this.txtSafetyMeetingsLaborRate.EditValueChanged += new System.EventHandler(this.AllControls_EditValue);
            // 
            // labelControl114
            // 
            this.labelControl114.Location = new System.Drawing.Point(3, 224);
            this.labelControl114.Name = "labelControl114";
            this.labelControl114.Size = new System.Drawing.Size(138, 13);
            this.labelControl114.TabIndex = 580;
            this.labelControl114.Text = "Safety Meetings Labor Rate:";
            // 
            // labelControl115
            // 
            this.labelControl115.Location = new System.Drawing.Point(3, 170);
            this.labelControl115.Name = "labelControl115";
            this.labelControl115.Size = new System.Drawing.Size(139, 13);
            this.labelControl115.TabIndex = 578;
            this.labelControl115.Text = "Project Manager Labor Rate:";
            // 
            // txtProjectManagerLaborRate
            // 
            this.txtProjectManagerLaborRate.Location = new System.Drawing.Point(153, 169);
            this.txtProjectManagerLaborRate.Name = "txtProjectManagerLaborRate";
            this.txtProjectManagerLaborRate.Properties.DisplayFormat.FormatString = "c2";
            this.txtProjectManagerLaborRate.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtProjectManagerLaborRate.Properties.EditFormat.FormatString = "c2";
            this.txtProjectManagerLaborRate.Properties.EditFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtProjectManagerLaborRate.Properties.Mask.EditMask = "c2";
            this.txtProjectManagerLaborRate.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.txtProjectManagerLaborRate.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.txtProjectManagerLaborRate.Properties.MaxLength = 20;
            this.spellChecker1.SetShowSpellCheckMenu(this.txtProjectManagerLaborRate, true);
            this.txtProjectManagerLaborRate.Size = new System.Drawing.Size(73, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.txtProjectManagerLaborRate, optionsSpelling132);
            this.txtProjectManagerLaborRate.TabIndex = 74;
            this.txtProjectManagerLaborRate.EditValueChanged += new System.EventHandler(this.AllControls_EditValue);
            // 
            // labelControl116
            // 
            this.labelControl116.Location = new System.Drawing.Point(3, 144);
            this.labelControl116.Name = "labelControl116";
            this.labelControl116.Size = new System.Drawing.Size(134, 13);
            this.labelControl116.TabIndex = 576;
            this.labelControl116.Text = "Superintendent Labor Rate:";
            // 
            // txtSuperintendentLaborRate
            // 
            this.txtSuperintendentLaborRate.Location = new System.Drawing.Point(153, 143);
            this.txtSuperintendentLaborRate.Name = "txtSuperintendentLaborRate";
            this.txtSuperintendentLaborRate.Properties.DisplayFormat.FormatString = "c2";
            this.txtSuperintendentLaborRate.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtSuperintendentLaborRate.Properties.EditFormat.FormatString = "c2";
            this.txtSuperintendentLaborRate.Properties.EditFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtSuperintendentLaborRate.Properties.Mask.EditMask = "c2";
            this.txtSuperintendentLaborRate.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.txtSuperintendentLaborRate.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.txtSuperintendentLaborRate.Properties.MaxLength = 20;
            this.spellChecker1.SetShowSpellCheckMenu(this.txtSuperintendentLaborRate, true);
            this.txtSuperintendentLaborRate.Size = new System.Drawing.Size(73, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.txtSuperintendentLaborRate, optionsSpelling133);
            this.txtSuperintendentLaborRate.TabIndex = 73;
            this.txtSuperintendentLaborRate.EditValueChanged += new System.EventHandler(this.AllControls_EditValue);
            // 
            // txtGeneralForemanLaborRate
            // 
            this.txtGeneralForemanLaborRate.Location = new System.Drawing.Point(153, 117);
            this.txtGeneralForemanLaborRate.Name = "txtGeneralForemanLaborRate";
            this.txtGeneralForemanLaborRate.Properties.DisplayFormat.FormatString = "c2";
            this.txtGeneralForemanLaborRate.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtGeneralForemanLaborRate.Properties.EditFormat.FormatString = "c2";
            this.txtGeneralForemanLaborRate.Properties.EditFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtGeneralForemanLaborRate.Properties.Mask.EditMask = "c2";
            this.txtGeneralForemanLaborRate.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.txtGeneralForemanLaborRate.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.txtGeneralForemanLaborRate.Properties.MaxLength = 20;
            this.spellChecker1.SetShowSpellCheckMenu(this.txtGeneralForemanLaborRate, true);
            this.txtGeneralForemanLaborRate.Size = new System.Drawing.Size(73, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.txtGeneralForemanLaborRate, optionsSpelling134);
            this.txtGeneralForemanLaborRate.TabIndex = 72;
            this.txtGeneralForemanLaborRate.EditValueChanged += new System.EventHandler(this.AllControls_EditValue);
            // 
            // labelControl117
            // 
            this.labelControl117.Location = new System.Drawing.Point(3, 120);
            this.labelControl117.Name = "labelControl117";
            this.labelControl117.Size = new System.Drawing.Size(142, 13);
            this.labelControl117.TabIndex = 574;
            this.labelControl117.Text = "General Foreman Labor Rate:";
            // 
            // labelControl118
            // 
            this.labelControl118.Location = new System.Drawing.Point(3, 92);
            this.labelControl118.Name = "labelControl118";
            this.labelControl118.Size = new System.Drawing.Size(102, 13);
            this.labelControl118.TabIndex = 572;
            this.labelControl118.Text = "Foreman Labor Rate:";
            // 
            // txtForemanLaborRate
            // 
            this.txtForemanLaborRate.Location = new System.Drawing.Point(153, 91);
            this.txtForemanLaborRate.Name = "txtForemanLaborRate";
            this.txtForemanLaborRate.Properties.DisplayFormat.FormatString = "c2";
            this.txtForemanLaborRate.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtForemanLaborRate.Properties.EditFormat.FormatString = "c2";
            this.txtForemanLaborRate.Properties.EditFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtForemanLaborRate.Properties.Mask.EditMask = "c2";
            this.txtForemanLaborRate.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.txtForemanLaborRate.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.txtForemanLaborRate.Properties.MaxLength = 20;
            this.spellChecker1.SetShowSpellCheckMenu(this.txtForemanLaborRate, true);
            this.txtForemanLaborRate.Size = new System.Drawing.Size(73, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.txtForemanLaborRate, optionsSpelling135);
            this.txtForemanLaborRate.TabIndex = 71;
            this.txtForemanLaborRate.EditValueChanged += new System.EventHandler(this.AllControls_EditValue);
            // 
            // txtElectricianLaborRate
            // 
            this.txtElectricianLaborRate.Location = new System.Drawing.Point(153, 65);
            this.txtElectricianLaborRate.Name = "txtElectricianLaborRate";
            this.txtElectricianLaborRate.Properties.DisplayFormat.FormatString = "c2";
            this.txtElectricianLaborRate.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtElectricianLaborRate.Properties.EditFormat.FormatString = "c2";
            this.txtElectricianLaborRate.Properties.EditFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtElectricianLaborRate.Properties.Mask.EditMask = "c2";
            this.txtElectricianLaborRate.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.txtElectricianLaborRate.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.txtElectricianLaborRate.Properties.MaxLength = 20;
            this.spellChecker1.SetShowSpellCheckMenu(this.txtElectricianLaborRate, true);
            this.txtElectricianLaborRate.Size = new System.Drawing.Size(73, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.txtElectricianLaborRate, optionsSpelling136);
            this.txtElectricianLaborRate.TabIndex = 70;
            this.txtElectricianLaborRate.EditValueChanged += new System.EventHandler(this.AllControls_EditValue);
            // 
            // labelControl119
            // 
            this.labelControl119.Location = new System.Drawing.Point(3, 68);
            this.labelControl119.Name = "labelControl119";
            this.labelControl119.Size = new System.Drawing.Size(108, 13);
            this.labelControl119.TabIndex = 570;
            this.labelControl119.Text = "Electrician Labor Rate:";
            // 
            // xtraTabPage5
            // 
            this.xtraTabPage5.AutoScroll = true;
            this.xtraTabPage5.Controls.Add(this.txtLetterExclusion);
            this.xtraTabPage5.Controls.Add(this.txtLetterWorkDescription);
            this.xtraTabPage5.Controls.Add(this.txtCompany);
            this.xtraTabPage5.Controls.Add(this.labelControl151);
            this.xtraTabPage5.Controls.Add(this.txtFrom);
            this.xtraTabPage5.Controls.Add(this.labelControl149);
            this.xtraTabPage5.Controls.Add(this.labelControl150);
            this.xtraTabPage5.Controls.Add(this.cboContact);
            this.xtraTabPage5.Controls.Add(this.txtLetterTimeExtension);
            this.xtraTabPage5.Controls.Add(this.labelControl148);
            this.xtraTabPage5.Controls.Add(this.labelControl147);
            this.xtraTabPage5.Controls.Add(this.labelControl146);
            this.xtraTabPage5.Name = "xtraTabPage5";
            this.xtraTabPage5.Size = new System.Drawing.Size(921, 398);
            this.xtraTabPage5.Text = "Change Order Letter";
            // 
            // txtLetterExclusion
            // 
            this.txtLetterExclusion.Location = new System.Drawing.Point(126, 194);
            this.txtLetterExclusion.Name = "txtLetterExclusion";
            this.txtLetterExclusion.ReadOnly = true;
            this.txtLetterExclusion.Size = new System.Drawing.Size(609, 127);
            this.txtLetterExclusion.TabIndex = 3;
            this.txtLetterExclusion.OnTextChanged += new ControlsLibrary.TextChangedHandler(this.AllControls_EditValue);
            // 
            // txtLetterWorkDescription
            // 
            this.txtLetterWorkDescription.Location = new System.Drawing.Point(126, 61);
            this.txtLetterWorkDescription.Name = "txtLetterWorkDescription";
            this.txtLetterWorkDescription.ReadOnly = false;
            this.txtLetterWorkDescription.Size = new System.Drawing.Size(609, 127);
            this.txtLetterWorkDescription.TabIndex = 2;
            this.txtLetterWorkDescription.ReadOnly = true;
            this.txtLetterWorkDescription.OnTextChanged += new ControlsLibrary.TextChangedHandler(this.AllControls_EditValue);
            // 
            // txtCompany
            // 
            this.txtCompany.Location = new System.Drawing.Point(127, 5);
            this.txtCompany.Name = "txtCompany";
            this.txtCompany.Properties.MaxLength = 50;
            this.txtCompany.Properties.ReadOnly = true;
            this.spellChecker1.SetShowSpellCheckMenu(this.txtCompany, true);
            this.txtCompany.Size = new System.Drawing.Size(229, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.txtCompany, optionsSpelling137);
            this.txtCompany.TabIndex = 670;
            this.txtCompany.TabStop = false;
            // 
            // labelControl151
            // 
            this.labelControl151.Location = new System.Drawing.Point(4, 12);
            this.labelControl151.Name = "labelControl151";
            this.labelControl151.Size = new System.Drawing.Size(72, 13);
            this.labelControl151.TabIndex = 671;
            this.labelControl151.Text = "To (Company):";
            // 
            // txtFrom
            // 
            this.txtFrom.Location = new System.Drawing.Point(598, 9);
            this.txtFrom.Name = "txtFrom";
            this.txtFrom.Properties.MaxLength = 50;
            this.spellChecker1.SetShowSpellCheckMenu(this.txtFrom, true);
            this.txtFrom.Size = new System.Drawing.Size(224, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.txtFrom, optionsSpelling138);
            this.txtFrom.TabIndex = 2;
            this.txtFrom.Visible = false;
            this.txtFrom.EditValueChanged += new System.EventHandler(this.AllControls_EditValue);
            // 
            // labelControl149
            // 
            this.labelControl149.Location = new System.Drawing.Point(543, 16);
            this.labelControl149.Name = "labelControl149";
            this.labelControl149.Size = new System.Drawing.Size(28, 13);
            this.labelControl149.TabIndex = 669;
            this.labelControl149.Text = "From:";
            this.labelControl149.Visible = false;
            // 
            // labelControl150
            // 
            this.labelControl150.Location = new System.Drawing.Point(7, 35);
            this.labelControl150.Name = "labelControl150";
            this.labelControl150.Size = new System.Drawing.Size(60, 13);
            this.labelControl150.TabIndex = 668;
            this.labelControl150.Text = "To (Person):";
            // 
            // cboContact
            // 
            this.cboContact.Location = new System.Drawing.Point(126, 32);
            this.cboContact.Name = "cboContact";
            this.cboContact.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.cboContact.Properties.NullText = "";
            this.cboContact.Size = new System.Drawing.Size(296, 20);
            this.cboContact.TabIndex = 1;
            this.cboContact.EditValueChanged += new System.EventHandler(this.cboContact_EditValueChanged);
            // 
            // txtLetterTimeExtension
            // 
            this.txtLetterTimeExtension.Location = new System.Drawing.Point(127, 333);
            this.txtLetterTimeExtension.Name = "txtLetterTimeExtension";
            this.txtLetterTimeExtension.Properties.Mask.EditMask = "n0";
            this.txtLetterTimeExtension.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.txtLetterTimeExtension.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.spellChecker1.SetShowSpellCheckMenu(this.txtLetterTimeExtension, true);
            this.txtLetterTimeExtension.Size = new System.Drawing.Size(83, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.txtLetterTimeExtension, optionsSpelling139);
            this.txtLetterTimeExtension.TabIndex = 4;
            this.txtLetterTimeExtension.EditValueChanged += new System.EventHandler(this.AllControls_EditValue);
            // 
            // labelControl148
            // 
            this.labelControl148.Location = new System.Drawing.Point(8, 336);
            this.labelControl148.Name = "labelControl148";
            this.labelControl148.Size = new System.Drawing.Size(114, 13);
            this.labelControl148.TabIndex = 4;
            this.labelControl148.Text = "Time Extension in Days:";
            // 
            // labelControl147
            // 
            this.labelControl147.Location = new System.Drawing.Point(8, 205);
            this.labelControl147.Name = "labelControl147";
            this.labelControl147.Size = new System.Drawing.Size(44, 13);
            this.labelControl147.TabIndex = 3;
            this.labelControl147.Text = "Exclusion";
            this.labelControl147.Cursor = System.Windows.Forms.Cursors.Hand;
            this.labelControl147.Click += new System.EventHandler(this.labelControl147_Click);
            // 
            // labelControl146
            // 
            this.labelControl146.Location = new System.Drawing.Point(8, 65);
            this.labelControl146.Name = "labelControl146";
            this.labelControl146.Size = new System.Drawing.Size(98, 13);
            this.labelControl146.TabIndex = 0;
            this.labelControl146.Text = "Description of Work:";
            this.labelControl146.Cursor = System.Windows.Forms.Cursors.Hand;
            this.labelControl146.Click += new System.EventHandler(this.labelControl146_Click);

            // 
            // grdCostCode
            // 
            this.grdCostCode.Dock = System.Windows.Forms.DockStyle.Fill;
            this.grdCostCode.Location = new System.Drawing.Point(0, 31);
            this.grdCostCode.MainView = this.gridView1;
            this.grdCostCode.Name = "grdCostCode";
            this.grdCostCode.RepositoryItems.AddRange(new DevExpress.XtraEditors.Repository.RepositoryItem[] {
            this.chkSelectedItem,
            this.txtUserDescription,
            this.txtMaterialCost,
            this.txtLaborCost,
            this.txtOtherCost,
            this.txtQuantity,
            this.txtHours,
            this.cboUnit,
            this.txtUserDescription1});
            this.grdCostCode.Size = new System.Drawing.Size(927, 170);
            this.grdCostCode.TabIndex = 451;
            this.grdCostCode.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.gridView1});
            // 
            // gridView1
            // 
            this.gridView1.Appearance.FooterPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.gridView1.Appearance.FooterPanel.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.gridView1.Appearance.FooterPanel.Options.UseBackColor = true;
            this.gridView1.Appearance.FooterPanel.Options.UseFont = true;
            this.gridView1.GridControl = this.grdCostCode;
            this.gridView1.Name = "gridView1";
            this.gridView1.OptionsCustomization.AllowGroup = false;
            this.gridView1.OptionsMenu.EnableColumnMenu = false;
            this.gridView1.OptionsMenu.EnableFooterMenu = false;
            this.gridView1.OptionsMenu.EnableGroupPanelMenu = false;
            this.gridView1.OptionsView.ColumnAutoWidth = false;
            this.gridView1.OptionsView.ShowFooter = true;
            this.gridView1.OptionsView.ShowGroupPanel = false;
            this.gridView1.ColumnWidthChanged += new DevExpress.XtraGrid.Views.Base.ColumnEventHandler(this.gridView1_ColumnWidthChanged);
            this.gridView1.FocusedRowChanged += new DevExpress.XtraGrid.Views.Base.FocusedRowChangedEventHandler(this.gridView1_FocusedRowChanged);
            this.gridView1.CellValueChanged += new DevExpress.XtraGrid.Views.Base.CellValueChangedEventHandler(this.gridView1_CellValueChanged);
            this.gridView1.RowUpdated += new DevExpress.XtraGrid.Views.Base.RowObjectEventHandler(this.gridView1_RowUpdated);
            // 
            // chkSelectedItem
            // 
            this.chkSelectedItem.AutoHeight = false;
            this.chkSelectedItem.Name = "chkSelectedItem";
            // 
            // txtUserDescription
            // 
            this.txtUserDescription.AutoHeight = false;
            this.txtUserDescription.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.Office2003;
            this.txtUserDescription.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.txtUserDescription.MaxLength = 128;
            this.txtUserDescription.Name = "txtUserDescription";
            // 
            // txtMaterialCost
            // 
            this.txtMaterialCost.AutoHeight = false;
            this.txtMaterialCost.Mask.EditMask = "c2";
            this.txtMaterialCost.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.txtMaterialCost.Mask.UseMaskAsDisplayFormat = true;
            this.txtMaterialCost.Name = "txtMaterialCost";
            // 
            // txtLaborCost
            // 
            this.txtLaborCost.AutoHeight = false;
            this.txtLaborCost.Mask.EditMask = "c2";
            this.txtLaborCost.Mask.UseMaskAsDisplayFormat = true;
            this.txtLaborCost.Name = "txtLaborCost";
            // 
            // txtOtherCost
            // 
            this.txtOtherCost.AutoHeight = false;
            this.txtOtherCost.Mask.EditMask = "c2";
            this.txtOtherCost.Mask.UseMaskAsDisplayFormat = true;
            this.txtOtherCost.Name = "txtOtherCost";
            // 
            // txtQuantity
            // 
            this.txtQuantity.AutoHeight = false;
            this.txtQuantity.Mask.EditMask = "n0";
            this.txtQuantity.Mask.UseMaskAsDisplayFormat = true;
            this.txtQuantity.Name = "txtQuantity";
            // 
            // txtHours
            // 
            this.txtHours.AutoHeight = false;
            this.txtHours.Mask.EditMask = "n0";
            this.txtHours.Mask.UseMaskAsDisplayFormat = true;
            this.txtHours.Name = "txtHours";
            // 
            // cboUnit
            // 
            this.cboUnit.AutoHeight = false;
            this.cboUnit.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.cboUnit.Items.AddRange(new object[] {
            "C",
            "E",
            "H",
            "M"});
            this.cboUnit.Name = "cboUnit";
            this.cboUnit.ShowDropDown = DevExpress.XtraEditors.Controls.ShowDropDown.Never;
            this.cboUnit.TextEditStyle = DevExpress.XtraEditors.Controls.TextEditStyles.DisableTextEditor;
            // 
            // txtUserDescription1
            // 
            this.txtUserDescription1.AutoHeight = false;
            this.txtUserDescription1.MaxLength = 100;
            this.txtUserDescription1.Name = "txtUserDescription1";
            // 
            // panCostCodes
            // 
            this.panCostCodes.Controls.Add(this.btnSaveCostCodes);
            this.panCostCodes.Controls.Add(this.btnProcess);
            this.panCostCodes.Controls.Add(this.labelControl18);
            this.panCostCodes.Controls.Add(this.cboPhase);
            this.panCostCodes.Controls.Add(this.chkSelected);
            this.panCostCodes.Dock = System.Windows.Forms.DockStyle.Top;
            this.panCostCodes.Location = new System.Drawing.Point(0, 0);
            this.panCostCodes.Name = "panCostCodes";
            this.panCostCodes.Size = new System.Drawing.Size(927, 31);
            this.panCostCodes.TabIndex = 452;
            // 
            // btnSaveCostCodes
            // 
            this.btnSaveCostCodes.Location = new System.Drawing.Point(601, 4);
            this.btnSaveCostCodes.Name = "btnSaveCostCodes";
            this.btnSaveCostCodes.Size = new System.Drawing.Size(57, 19);
            this.btnSaveCostCodes.TabIndex = 5;
            this.btnSaveCostCodes.Text = "&Save";
            this.btnSaveCostCodes.Click += new System.EventHandler(this.btnSaveCostCodes_Click);
            // 
            // btnProcess
            // 
            this.btnProcess.Location = new System.Drawing.Point(517, 4);
            this.btnProcess.Name = "btnProcess";
            this.btnProcess.Size = new System.Drawing.Size(57, 19);
            this.btnProcess.TabIndex = 4;
            this.btnProcess.Text = "&Process";
            this.btnProcess.Click += new System.EventHandler(this.btnProcess_Click);
            // 
            // labelControl18
            // 
            this.labelControl18.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.labelControl18.Location = new System.Drawing.Point(161, 10);
            this.labelControl18.Name = "labelControl18";
            this.labelControl18.Size = new System.Drawing.Size(85, 13);
            this.labelControl18.TabIndex = 3;
            this.labelControl18.Text = "Select a Phase:";
            // 
            // cboPhase
            // 
            this.cboPhase.Location = new System.Drawing.Point(285, 5);
            this.cboPhase.Name = "cboPhase";
            this.cboPhase.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.cboPhase.Properties.NullText = "";
            this.cboPhase.Properties.TextEditStyle = DevExpress.XtraEditors.Controls.TextEditStyles.Standard;
            this.cboPhase.Size = new System.Drawing.Size(226, 20);
            this.cboPhase.TabIndex = 2;
            // 
            // chkSelected
            // 
            this.chkSelected.Location = new System.Drawing.Point(5, 7);
            this.chkSelected.Name = "chkSelected";
            this.chkSelected.Properties.Caption = "Selected Cost Codes";
            this.chkSelected.Size = new System.Drawing.Size(130, 19);
            this.chkSelected.TabIndex = 0;
            this.chkSelected.CheckedChanged += new System.EventHandler(this.chkSelected_CheckedChanged);
            // 
            // spellChecker1
            // 
            this.spellChecker1.Culture = new System.Globalization.CultureInfo("en-US");
            this.spellChecker1.ParentContainer = null;
            // 
            // comboBoxEdit2
            // 
            this.comboBoxEdit2.Location = new System.Drawing.Point(601, 3);
            this.comboBoxEdit2.Name = "comboBoxEdit2";
            this.comboBoxEdit2.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.comboBoxEdit2.Size = new System.Drawing.Size(130, 20);
            this.comboBoxEdit2.TabIndex = 5;
            // 
            // labelControl164
            // 
            this.labelControl164.Location = new System.Drawing.Point(542, 5);
            this.labelControl164.Name = "labelControl164";
            this.labelControl164.Size = new System.Drawing.Size(49, 13);
            this.labelControl164.TabIndex = 6;
            this.labelControl164.Text = "Revisions:";
            // 
            // labelControl165
            // 
            this.labelControl165.Location = new System.Drawing.Point(555, 4);
            this.labelControl165.Name = "labelControl165";
            this.labelControl165.Size = new System.Drawing.Size(75, 13);
            this.labelControl165.TabIndex = 5;
            this.labelControl165.Text = "labelControl165";
            // 
            // labelControl166
            // 
            this.labelControl166.Location = new System.Drawing.Point(210, 110);
            this.labelControl166.Name = "labelControl166";
            this.labelControl166.Size = new System.Drawing.Size(49, 13);
            this.labelControl166.TabIndex = 606;
            this.labelControl166.Text = "Revisions:";
            // 
            // cboRevision
            // 
            this.cboRevision.Location = new System.Drawing.Point(265, 107);
            this.cboRevision.Name = "cboRevision";
            this.cboRevision.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.cboRevision.Properties.TextEditStyle = DevExpress.XtraEditors.Controls.TextEditStyles.DisableTextEditor;
            this.cboRevision.Size = new System.Drawing.Size(100, 20);
            this.cboRevision.TabIndex = 651;
            this.cboRevision.SelectedIndexChanged += new System.EventHandler(this.cboRevision_SelectedIndexChanged);
            // 
            // txtOverheadPercentText
            // 
            this.txtOverheadPercentText.EditValue = "Overhead";
            this.txtOverheadPercentText.Location = new System.Drawing.Point(5, 8);
            this.txtOverheadPercentText.Name = "txtOverheadPercentText";
            this.txtOverheadPercentText.Properties.Appearance.BackColor = System.Drawing.Color.White;
            this.txtOverheadPercentText.Properties.Appearance.Options.UseBackColor = true;
            this.txtOverheadPercentText.Properties.MaxLength = 35;
            this.spellChecker1.SetShowSpellCheckMenu(this.txtOverheadPercentText, true);
            this.txtOverheadPercentText.Size = new System.Drawing.Size(137, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.txtOverheadPercentText, optionsSpelling84);
            this.txtOverheadPercentText.TabIndex = 604;
            this.txtOverheadPercentText.EditValueChanged += new System.EventHandler(this.AllControls_EditValue);
            // 
            // txtProfitPercentText
            // 
            this.txtProfitPercentText.EditValue = "Profit";
            this.txtProfitPercentText.Location = new System.Drawing.Point(5, 34);
            this.txtProfitPercentText.Name = "txtProfitPercentText";
            this.txtProfitPercentText.Properties.Appearance.BackColor = System.Drawing.Color.White;
            this.txtProfitPercentText.Properties.Appearance.Options.UseBackColor = true;
            this.txtProfitPercentText.Properties.MaxLength = 35;
            this.spellChecker1.SetShowSpellCheckMenu(this.txtProfitPercentText, true);
            this.txtProfitPercentText.Size = new System.Drawing.Size(137, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.txtProfitPercentText, optionsSpelling83);
            this.txtProfitPercentText.TabIndex = 605;
            this.txtProfitPercentText.EditValueChanged += new System.EventHandler(this.AllControls_EditValue);
            // 
            // txtSubcontractAdministrationPercentText
            // 
            this.txtSubcontractAdministrationPercentText.EditValue = "Subcontract Administration ";
            this.txtSubcontractAdministrationPercentText.Location = new System.Drawing.Point(5, 60);
            this.txtSubcontractAdministrationPercentText.Name = "txtSubcontractAdministrationPercentText";
            this.txtSubcontractAdministrationPercentText.Properties.Appearance.BackColor = System.Drawing.Color.White;
            this.txtSubcontractAdministrationPercentText.Properties.Appearance.Options.UseBackColor = true;
            this.txtSubcontractAdministrationPercentText.Properties.MaxLength = 35;
            this.spellChecker1.SetShowSpellCheckMenu(this.txtSubcontractAdministrationPercentText, true);
            this.txtSubcontractAdministrationPercentText.Size = new System.Drawing.Size(137, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.txtSubcontractAdministrationPercentText, optionsSpelling82);
            this.txtSubcontractAdministrationPercentText.TabIndex = 606;
            this.txtSubcontractAdministrationPercentText.EditValueChanged += new System.EventHandler(this.AllControls_EditValue);
            // 
            // txtWarrantyPercentText
            // 
            this.txtWarrantyPercentText.EditValue = "Warranty";
            this.txtWarrantyPercentText.Location = new System.Drawing.Point(5, 84);
            this.txtWarrantyPercentText.Name = "txtWarrantyPercentText";
            this.txtWarrantyPercentText.Properties.Appearance.BackColor = System.Drawing.Color.White;
            this.txtWarrantyPercentText.Properties.Appearance.Options.UseBackColor = true;
            this.txtWarrantyPercentText.Properties.MaxLength = 35;
            this.spellChecker1.SetShowSpellCheckMenu(this.txtWarrantyPercentText, true);
            this.txtWarrantyPercentText.Size = new System.Drawing.Size(137, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.txtWarrantyPercentText, optionsSpelling81);
            this.txtWarrantyPercentText.TabIndex = 607;
            this.txtWarrantyPercentText.EditValueChanged += new System.EventHandler(this.AllControls_EditValue);

            // 
            // txtBondPercentText
            // 
            this.txtBondPercentText.EditValue = "Bond";
            this.txtBondPercentText.Location = new System.Drawing.Point(5, 112);
            this.txtBondPercentText.Name = "txtBondPercentText";
            this.txtBondPercentText.Properties.Appearance.BackColor = System.Drawing.Color.White;
            this.txtBondPercentText.Properties.Appearance.Options.UseBackColor = true;
            this.txtBondPercentText.Properties.MaxLength = 35;
            this.spellChecker1.SetShowSpellCheckMenu(this.txtBondPercentText, true);
            this.txtBondPercentText.Size = new System.Drawing.Size(137, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.txtBondPercentText, optionsSpelling80);
            this.txtBondPercentText.TabIndex = 608;
            this.txtBondPercentText.EditValueChanged += new System.EventHandler(this.AllControls_EditValue);
            // 
            // frmChangeOrder
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(927, 775);
            this.Controls.Add(this.cboRevision);
            this.Controls.Add(this.labelControl166);
            this.Controls.Add(this.splitContainerControl1);
            this.Controls.Add(this.textEdit30);
            this.Controls.Add(this.labelControl66);
            this.Controls.Add(this.labelControl65);
            this.Controls.Add(this.labelControl63);
            this.Controls.Add(this.labelControl61);
            this.Controls.Add(this.labelControl49);
            this.Controls.Add(this.textEdit32);
            this.Controls.Add(this.textEdit31);
            this.Controls.Add(this.labelControl48);
            this.Controls.Add(this.labelControl60);
            this.Controls.Add(this.labelControl59);
            this.Controls.Add(this.labelControl68);
            this.Controls.Add(this.labelControl99);
            this.Controls.Add(this.labelControl98);
            this.Controls.Add(this.labelControl100);
            this.Controls.Add(this.labelControl97);
            this.Controls.Add(this.labelControl101);
            this.Controls.Add(this.labelControl102);
            this.Controls.Add(this.labelControl104);
            this.Controls.Add(this.labelControl96);
            this.Controls.Add(this.labelControl103);
            this.Controls.Add(this.textEdit78);
            this.Controls.Add(this.textEdit77);
            this.Controls.Add(this.textEdit76);
            this.Controls.Add(this.labelControl78);
            this.Controls.Add(this.labelControl77);
            this.Controls.Add(this.labelControl75);
            this.Controls.Add(this.labelControl79);
            this.Controls.Add(this.labelControl74);
            this.Controls.Add(this.labelControl70);
            this.Controls.Add(this.labelControl69);
            this.Controls.Add(this.labelControl72);
            this.Controls.Add(this.labelControl95);
            this.Controls.Add(this.labelControl94);
            this.Controls.Add(this.textEdit68);
            this.Controls.Add(this.labelControl93);
            this.Controls.Add(this.textEdit67);
            this.Controls.Add(this.textEdit69);
            this.Controls.Add(this.textEdit70);
            this.Controls.Add(this.textEdit75);
            this.Controls.Add(this.textEdit74);
            this.Controls.Add(this.textEdit73);
            this.Controls.Add(this.textEdit72);
            this.Controls.Add(this.textEdit71);
            this.Controls.Add(this.labelControl92);
            this.Controls.Add(this.labelControl91);
            this.Controls.Add(this.labelControl84);
            this.Controls.Add(this.labelControl83);
            this.Controls.Add(this.labelControl81);
            this.Controls.Add(this.labelControl86);
            this.Controls.Add(this.lookUpEdit3);
            this.Controls.Add(this.labelControl90);
            this.Controls.Add(this.labelControl89);
            this.Controls.Add(this.labelControl88);
            this.Controls.Add(this.textEdit66);
            this.Controls.Add(this.ribProjectOpportunity);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "frmChangeOrder";
            this.Ribbon = this.ribProjectOpportunity;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.frmChangeOrder_FormClosed);
            this.Load += new System.EventHandler(this.frmChangeOrder_Load);
            ((System.ComponentModel.ISupportInitialize)(this.imgCollection)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.imageCollection1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dxErrorProvider)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.textEdit30.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.textEdit32.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.textEdit31.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.imageCollection2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ribProjectOpportunity)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.textEdit78.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.textEdit77.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.textEdit76.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.textEdit68.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.textEdit67.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.textEdit69.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.textEdit70.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.textEdit75.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.textEdit74.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.textEdit73.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.textEdit72.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.textEdit71.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lookUpEdit3.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.textEdit66.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radioGroup1.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.panelControl4)).EndInit();
            this.panelControl4.ResumeLayout(false);
            this.panelControl4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.textEdit4.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.textEdit5.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.textEdit6.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.textEdit7.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.memoEdit1.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.panelControl6)).EndInit();
            this.panelControl6.ResumeLayout(false);
            this.panelControl6.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dateEdit1.Properties.CalendarTimeProperties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dateEdit1.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lookUpEdit1.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lookUpEdit2.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lookUpEdit4.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lookUpEdit5.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.textEdit8.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.textEdit9.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dateEdit2.Properties.CalendarTimeProperties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dateEdit2.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.comboBoxEdit1.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lookUpEdit6.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dateEdit3.Properties.CalendarTimeProperties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dateEdit3.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dateEdit4.Properties.CalendarTimeProperties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dateEdit4.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.textEdit10.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.textEdit11.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.textEdit12.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.textEdit13.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.panelControl7)).EndInit();
            this.panelControl7.ResumeLayout(false);
            this.panelControl7.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dateEdit5.Properties.CalendarTimeProperties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dateEdit5.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dateEdit6.Properties.CalendarTimeProperties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dateEdit6.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.textEdit14.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.textEdit15.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainerControl1)).EndInit();
            this.splitContainerControl1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.xtraTabControl1)).EndInit();
            this.xtraTabControl1.ResumeLayout(false);
            this.xtraTabPage4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.panelControl14)).EndInit();
            this.panelControl14.ResumeLayout(false);
            this.panelControl14.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtRecordID.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtJobChangeOrderApprovedAmount.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtJobChangeOrderApprovedDate.Properties.CalendarTimeProperties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtJobChangeOrderApprovedDate.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtJobChangeOrderRequestedAmount.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtJobChangeOrderRequestDate.Properties.CalendarTimeProperties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtJobChangeOrderRequestDate.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtPriceAdjustment.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtChangeOrderAmount.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cboJobChangeOrderStatus.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtJobChangeOrderOwnerNumber.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtJobChangeOrderCCENumber.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtJobChangeOrderUserDescription.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cboJobChangeOrderDescription.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtJobChangeOrderNumber.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.panelControl8)).EndInit();
            this.panelControl8.ResumeLayout(false);
            this.panelControl8.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtProfitPercentBudgetTotals.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtProfitDollarBudgetTotals.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtProfitPercentEstimateDefaults.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtProfitDollarEstimateDefaults.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtSubcontractsBudgetTotals.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtContractDollarBudgetTotals.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtTotalCostBudgetTotals.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtOtherBudgetTotals.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtMaterialsBudgetTotals.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtLaborRateBudgetTotals.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtLaborDollarBudgetTotals.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtLaborHoursBudgetTotals.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtSubcontractsEstimateDefaults.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtContractDollarEstimateDefaults.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtTotalCostEstimateDefaults.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtOtherEstimateDefaults.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtMaterialsEstimateDefaults.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtLaborRateEstimateDefaults.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtLaborDollarEstimateDefaults.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtLaborHoursEstimateDefaults.Properties)).EndInit();
            this.xtraTabPage1.ResumeLayout(false);
            this.xtraTabPage1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.panelControl9)).EndInit();
            this.panelControl9.ResumeLayout(false);
            this.panelControl9.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtSubcontractsAmount.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.panelControl10)).EndInit();
            this.panelControl10.ResumeLayout(false);
            this.panelControl10.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtEstimatedBIMHoursDT.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtEstimatedBIMHoursOT.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtEstimatedBIMHours.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtPremiumHoursActualHoursDT.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtProjectEngineerActualHoursDT.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtProjectManagerActualHoursDT.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtSuperintendentActualHoursDT.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtGeneralForemanActualHoursDT.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtForemanActualHoursDT.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtPremiumHoursActualHoursOT.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtProjectEngineerActualHoursOT.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtProjectManagerActualHoursOT.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtSuperintendentActualHoursOT.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtGeneralForemanActualHoursOT.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtForemanActualHoursOT.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtProjectEngineerDefaultHoursDT.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtProjectManagerDefaultHoursDT.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtSuperintendentDefaultHoursDT.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtGeneralForemanDefaultHoursDT.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtForemanDefaultHoursDT.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtProjectEngineerDefaultHoursOT.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtProjectManagerDefaultHoursOT.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtSuperintendentDefaultHoursOT.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtGeneralForemanDefaultHoursOT.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtForemanDefaultHoursOT.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtEstimatedApprenticeHoursDT.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtEstimatedElectricianHoursDT.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtEstimatedApprenticeHoursOT.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtEstimatedElectricianHoursOT.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtEstimatedApprenticeHours.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtPremiumHoursActualHours.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtProjectEngineerDefaultHours.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtProjectManagerDefaultHours.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtSuperintendentDefaultHours.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtGeneralForemanDefaultHours.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtForemanDefaultHours.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtEstimatedElectricianHours.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtProjectEngineerActualHours.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtProjectManagerActualHours.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtSuperintendentActualHours.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtGeneralForemanActualHours.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtForemanActualHours.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.panelControl11)).EndInit();
            this.panelControl11.ResumeLayout(false);
            this.panelControl11.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtOtherExpenses3Description.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtOtherExpenses2Description.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtOtherExpenses1Description.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtOtherExpenses3.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtOtherExpenses2.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtOtherExpenses1.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.panelControl13)).EndInit();
            this.panelControl13.ResumeLayout(false);
            this.panelControl13.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtDirectMaterials.Properties)).EndInit();
            this.xtraTabPage2.ResumeLayout(false);
            this.xtraTabPage2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.panelControl5)).EndInit();
            this.panelControl5.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.txtBondPercent.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtWarrantyPercent.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtSubcontractAdministrationPercent.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtProfitPercent.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtOverheadPercent.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.panelControl3)).EndInit();
            this.panelControl3.ResumeLayout(false);
            this.panelControl3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtFringeBenefitsPercent.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtSafetyMeetingPercent.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtProjectEngineerPercentOfLabor.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtProjectManagerPercentOfLabor.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtSuperintendentPercentOfLabor.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtGeneralForemanPercentOfLabor.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtForemanPercentOfLabor.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.panelControl2)).EndInit();
            this.panelControl2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.txtCartigeHandlingPercentText.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtAsBuiltsEngineeringPercentText.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtCartigeHandlingPercent.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtSmallToolsPercentText.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtSmallToolsPercent.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtStoragePercentText.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtStoragePercent.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtAsBuiltsEngineeringPercent.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.panelControl1)).EndInit();
            this.panelControl1.ResumeLayout(false);
            this.panelControl1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtSalesTaxPercent.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtSundriesPercentOfMaterial.Properties)).EndInit();
            this.xtraTabPage3.ResumeLayout(false);
            this.xtraTabPage3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.panelControl12)).EndInit();
            this.panelControl12.ResumeLayout(false);
            this.panelControl12.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtBIMRateDT.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtBIMRateOT.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtBIMRate.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtApprenticeLaborRateDT.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtProjectEngineerLaborRateDT.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtPremiumTimeLaborRateDT.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtSafetyMeetingsLaborRateDT.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtProjectManagerLaborRateDT.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtSuperintendentLaborRateDT.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtGeneralForemanLaborRateDT.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtForemanLaborRateDT.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtElectricianLaborRateDT.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtApprenticeLaborRateOT.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtProjectEngineerLaborRateOT.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtPremiumTimeLaborRateOT.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtSafetyMeetingsLaborRateOT.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtProjectManagerLaborRateOT.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtSuperintendentLaborRateOT.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtGeneralForemanLaborRateOT.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtForemanLaborRateOT.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtElectricianLaborRateOT.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtApprenticeLaborRate.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtProjectEngineerLaborRate.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtPremiumTimeLaborRate.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtSafetyMeetingsLaborRate.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtProjectManagerLaborRate.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtSuperintendentLaborRate.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtGeneralForemanLaborRate.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtForemanLaborRate.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtElectricianLaborRate.Properties)).EndInit();
            this.xtraTabPage5.ResumeLayout(false);
            this.xtraTabPage5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtCompany.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtFrom.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cboContact.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtLetterTimeExtension.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.grdCostCode)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkSelectedItem)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtUserDescription)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtMaterialCost)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtLaborCost)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtOtherCost)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtQuantity)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtHours)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cboUnit)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtUserDescription1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.panCostCodes)).EndInit();
            this.panCostCodes.ResumeLayout(false);
            this.panCostCodes.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.cboPhase.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkSelected.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.comboBoxEdit2.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cboRevision.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtOverheadPercentText.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtProfitPercentText.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtSubcontractAdministrationPercentText.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtWarrantyPercentText.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtBondPercentText.Properties)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private DevExpress.Utils.ImageCollection imgCollection;
        private DevExpress.XtraBars.BarButtonItem btnToolInspectionsReport;
        private DevExpress.XtraBars.BarButtonItem btnToolRepairPartsReport;
        private DevExpress.XtraBars.BarButtonItem btnToolComponentsReport;
        private DevExpress.XtraBars.BarButtonItem btnToolAccessoriesReport;
        private DevExpress.XtraBars.BarButtonItem btnProjectInfoSheetReport;
        private DevExpress.XtraBars.BarButtonItem btnToolEventScheduledReport;
        private DevExpress.XtraBars.BarButtonItem btnAccessories;
        private DevExpress.XtraBars.BarButtonItem btnComponents;
        private DevExpress.XtraBars.BarButtonItem btnRepairParts;
        private DevExpress.XtraBars.BarButtonItem btnInspections;
        private DevExpress.XtraBars.BarButtonItem btnGeneral;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup ribbonGroup2;
        private DevExpress.XtraBars.BarButtonItem btnNew;
        private DevExpress.XtraBars.BarButtonItem btnSave;
        private DevExpress.XtraBars.BarButtonItem btnUndo;
        private DevExpress.XtraBars.BarButtonItem btnDelete;
        private DevExpress.XtraBars.Ribbon.RibbonPage ribbonPage1;
        private DevExpress.XtraBars.BarSubItem barSubItemReports;
        private DevExpress.Utils.ImageCollection imageCollection1;
        private DevExpress.XtraBars.BarButtonGroup barButtonGroup5;
        private DevExpress.XtraBars.BarButtonItem btnTimeCard;
        private DevExpress.XtraBars.BarButtonItem btnCostToComplete;
        private DevExpress.XtraBars.BarButtonItem btnJobProgress;
        private DevExpress.XtraBars.BarButtonItem btnLaborProd;
        private DevExpress.XtraBars.BarButtonItem btnExcelQuantity;
        private DevExpress.XtraBars.BarButtonItem barButtonItem2;
        private DevExpress.XtraBars.BarButtonItem btnDown;
        private DevExpress.XtraBars.BarButtonGroup barButtonGroup4;
        private DevExpress.XtraEditors.DXErrorProvider.DXErrorProvider dxErrorProvider;
        private DevExpress.XtraEditors.TextEdit textEdit30;
        private DevExpress.XtraEditors.LabelControl labelControl66;
        private DevExpress.XtraEditors.LabelControl labelControl65;
        private DevExpress.XtraEditors.LabelControl labelControl63;
        private DevExpress.XtraEditors.LabelControl labelControl61;
        private DevExpress.XtraEditors.LabelControl labelControl49;
        private DevExpress.XtraEditors.TextEdit textEdit32;
        private DevExpress.XtraEditors.TextEdit textEdit31;
        private DevExpress.XtraEditors.LabelControl labelControl48;
        private DevExpress.XtraEditors.LabelControl labelControl60;
        private DevExpress.XtraEditors.LabelControl labelControl59;
        private DevExpress.XtraBars.Ribbon.RibbonControl ribProjectOpportunity;
        private DevExpress.Utils.ImageCollection imageCollection2;
        private DevExpress.XtraBars.BarButtonItem btnUp;
        private DevExpress.XtraBars.BarButtonItem btnRev;
        private DevExpress.XtraBars.BarButtonItem iSaveAs;
        private DevExpress.XtraBars.BarButtonItem btnCostCodesWeekly;
        private DevExpress.XtraBars.BarButtonItem btnCostCodes;
        private DevExpress.XtraBars.BarButtonItem btnstrategic;
        private DevExpress.XtraBars.BarButtonItem btnTimeSheet;
        private DevExpress.XtraBars.BarButtonItem iSelectAll;
        private DevExpress.XtraBars.BarButtonItem btnGeneralOld;
        private DevExpress.XtraBars.BarButtonItem iFont;
        private DevExpress.XtraBars.BarButtonItem iBullets;
        private DevExpress.XtraBars.BarButtonItem iProtected;
        private DevExpress.XtraBars.BarButtonItem iWeb;
        private DevExpress.XtraBars.BarButtonItem iAbout;
        private DevExpress.XtraBars.BarButtonItem iBold;
        private DevExpress.XtraBars.BarButtonItem iUnderline;
        private DevExpress.XtraBars.BarButtonItem iAlignLeft;
        private DevExpress.XtraBars.BarButtonItem iCenter;
        private DevExpress.XtraBars.BarButtonItem iAlignRight;
        private DevExpress.XtraBars.BarButtonItem iFontColor;
        private DevExpress.XtraBars.BarButtonItem siPosition;
        private DevExpress.XtraBars.BarButtonItem siModified;
        private DevExpress.XtraBars.BarStaticItem siDocName;
        private DevExpress.XtraBars.BarButtonGroup bgFontStyle;
        private DevExpress.XtraBars.BarButtonGroup bgAlign;
        private DevExpress.XtraBars.BarButtonGroup bgFont;
        private DevExpress.XtraBars.BarButtonGroup bgBullets;
        private DevExpress.XtraBars.BarSubItem sbiPaste;
        private DevExpress.XtraBars.BarButtonItem iPasteSpecial;
        private DevExpress.XtraBars.BarButtonItem btnCopy;
        private DevExpress.XtraBars.BarLargeButtonItem iLargeUndo;
        private DevExpress.XtraBars.BarButtonItem iTemplate;
        private DevExpress.XtraBars.RibbonGalleryBarItem rgbiSkins;
        private DevExpress.XtraBars.BarEditItem beiFontSize;
        private DevExpress.XtraBars.RibbonGalleryBarItem rgbiFont;
        private DevExpress.XtraBars.BarButtonItem bbiFontColorPopup;
        private DevExpress.XtraBars.RibbonGalleryBarItem rgbiFontColor;
        private DevExpress.XtraBars.BarButtonItem btnPersonnel;
        private DevExpress.XtraBars.BarSubItem iGeneral;
        private DevExpress.XtraBars.BarButtonItem btnNote;
        private DevExpress.XtraBars.BarButtonItem barButtonItem5;
        private DevExpress.XtraBars.BarButtonItem barButtonItem6;
        private DevExpress.XtraBars.BarButtonGroup barButtonGroup1;
        private DevExpress.XtraBars.BarButtonGroup barButtonGroup2;
        private DevExpress.XtraBars.BarButtonGroup barButtonGroup3;
        private DevExpress.XtraBars.BarLinkContainerItem barLinkContainerItem1;
        private DevExpress.XtraBars.BarMdiChildrenListItem barMdiChildrenListItem1;
        private DevExpress.XtraBars.BarButtonItem barButtonItem1;
        private DevExpress.XtraBars.BarButtonItem btnLaborFeedback;
        private DevExpress.XtraBars.BarButtonItem btnLaborFeedbackReport;
        private DevExpress.XtraBars.BarButtonItem btnExcelHours;
        private DevExpress.XtraEditors.LabelControl labelControl68;
        private DevExpress.XtraEditors.LabelControl labelControl99;
        private DevExpress.XtraEditors.LabelControl labelControl98;
        private DevExpress.XtraEditors.LabelControl labelControl100;
        private DevExpress.XtraEditors.LabelControl labelControl97;
        private DevExpress.XtraEditors.LabelControl labelControl101;
        private DevExpress.XtraEditors.LabelControl labelControl102;
        private DevExpress.XtraEditors.LabelControl labelControl104;
        private DevExpress.XtraEditors.LabelControl labelControl96;
        private DevExpress.XtraEditors.LabelControl labelControl103;
        private DevExpress.XtraEditors.TextEdit textEdit78;
        private DevExpress.XtraEditors.TextEdit textEdit77;
        private DevExpress.XtraEditors.TextEdit textEdit76;
        private DevExpress.XtraEditors.LabelControl labelControl78;
        private DevExpress.XtraEditors.LabelControl labelControl77;
        private DevExpress.XtraEditors.LabelControl labelControl75;
        private DevExpress.XtraEditors.LabelControl labelControl79;
        private DevExpress.XtraEditors.LabelControl labelControl74;
        private DevExpress.XtraEditors.LabelControl labelControl70;
        private DevExpress.XtraEditors.LabelControl labelControl69;
        private DevExpress.XtraEditors.LabelControl labelControl72;
        private DevExpress.XtraEditors.LabelControl labelControl95;
        private DevExpress.XtraEditors.LabelControl labelControl94;
        private DevExpress.XtraEditors.TextEdit textEdit68;
        private DevExpress.XtraEditors.LabelControl labelControl93;
        private DevExpress.XtraEditors.TextEdit textEdit67;
        private DevExpress.XtraEditors.TextEdit textEdit69;
        private DevExpress.XtraEditors.TextEdit textEdit70;
        private DevExpress.XtraEditors.TextEdit textEdit75;
        private DevExpress.XtraEditors.TextEdit textEdit74;
        private DevExpress.XtraEditors.TextEdit textEdit73;
        private DevExpress.XtraEditors.TextEdit textEdit72;
        private DevExpress.XtraEditors.TextEdit textEdit71;
        private DevExpress.XtraEditors.LabelControl labelControl92;
        private DevExpress.XtraEditors.LabelControl labelControl91;
        private DevExpress.XtraEditors.LabelControl labelControl84;
        private DevExpress.XtraEditors.LabelControl labelControl83;
        private DevExpress.XtraEditors.LabelControl labelControl81;
        private DevExpress.XtraEditors.LabelControl labelControl86;
        private DevExpress.XtraEditors.LookUpEdit lookUpEdit3;
        private DevExpress.XtraEditors.LabelControl labelControl90;
        private DevExpress.XtraEditors.LabelControl labelControl89;
        private DevExpress.XtraEditors.LabelControl labelControl88;
        private DevExpress.XtraEditors.TextEdit textEdit66;
        private DevExpress.XtraEditors.LabelControl labelControl30;
        private DevExpress.XtraEditors.RadioGroup radioGroup1;
        private DevExpress.XtraEditors.LabelControl labelControl31;
        private DevExpress.XtraEditors.PanelControl panelControl4;
        private DevExpress.XtraEditors.TextEdit textEdit4;
        private DevExpress.XtraEditors.LabelControl labelControl32;
        private DevExpress.XtraEditors.TextEdit textEdit5;
        private DevExpress.XtraEditors.TextEdit textEdit6;
        private DevExpress.XtraEditors.LabelControl labelControl33;
        private DevExpress.XtraEditors.LabelControl labelControl34;
        private DevExpress.XtraEditors.LabelControl labelControl35;
        private DevExpress.XtraEditors.TextEdit textEdit7;
        private DevExpress.XtraEditors.MemoEdit memoEdit1;
        private DevExpress.XtraEditors.LabelControl labelControl36;
        private DevExpress.XtraEditors.PanelControl panelControl6;
        private DevExpress.XtraEditors.DateEdit dateEdit1;
        private DevExpress.XtraEditors.LookUpEdit lookUpEdit1;
        private DevExpress.XtraEditors.LabelControl labelControl38;
        private DevExpress.XtraEditors.LookUpEdit lookUpEdit2;
        private DevExpress.XtraEditors.LookUpEdit lookUpEdit4;
        private DevExpress.XtraEditors.LookUpEdit lookUpEdit5;
        private DevExpress.XtraEditors.TextEdit textEdit8;
        private DevExpress.XtraEditors.TextEdit textEdit9;
        private DevExpress.XtraEditors.DateEdit dateEdit2;
        private DevExpress.XtraEditors.ComboBoxEdit comboBoxEdit1;
        private DevExpress.XtraEditors.LabelControl labelControl39;
        private DevExpress.XtraEditors.LabelControl labelControl40;
        private DevExpress.XtraEditors.LabelControl labelControl41;
        private DevExpress.XtraEditors.LabelControl labelControl42;
        private DevExpress.XtraEditors.LabelControl labelControl43;
        private DevExpress.XtraEditors.LookUpEdit lookUpEdit6;
        private DevExpress.XtraEditors.DateEdit dateEdit3;
        private DevExpress.XtraEditors.LabelControl labelControl44;
        private DevExpress.XtraEditors.DateEdit dateEdit4;
        private DevExpress.XtraEditors.TextEdit textEdit10;
        private DevExpress.XtraEditors.TextEdit textEdit11;
        private DevExpress.XtraEditors.LabelControl labelControl45;
        private DevExpress.XtraEditors.TextEdit textEdit12;
        private DevExpress.XtraEditors.TextEdit textEdit13;
        private DevExpress.XtraEditors.LabelControl labelControl46;
        private DevExpress.XtraEditors.LabelControl labelControl47;
        private DevExpress.XtraEditors.LabelControl labelControl52;
        private DevExpress.XtraEditors.LabelControl labelControl55;
        private DevExpress.XtraEditors.LabelControl labelControl57;
        private DevExpress.XtraEditors.LabelControl labelControl58;
        private DevExpress.XtraEditors.LabelControl labelControl105;
        private DevExpress.XtraEditors.LabelControl labelControl106;
        private DevExpress.XtraEditors.PanelControl panelControl7;
        private DevExpress.XtraEditors.DateEdit dateEdit5;
        private DevExpress.XtraEditors.DateEdit dateEdit6;
        private DevExpress.XtraEditors.TextEdit textEdit14;
        private DevExpress.XtraEditors.TextEdit textEdit15;
        private DevExpress.XtraEditors.LabelControl labelControl107;
        private DevExpress.XtraEditors.LabelControl labelControl108;
        private DevExpress.XtraEditors.LabelControl labelControl109;
        private DevExpress.XtraEditors.LabelControl labelControl110;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup ribbonReport;
        private DevExpress.XtraBars.BarButtonGroup barButtonGroup6;
        private DevExpress.XtraBars.BarButtonGroup barButtonGroup7;
        private DevExpress.XtraBars.BarButtonGroup barButtonGroup8;
        private DevExpress.XtraBars.BarSubItem barSubItem1;
        private DevExpress.XtraBars.BarSubItem barSubItem2;
        private DevExpress.XtraBars.BarButtonItem btnChangeOrderSheet;
        private DevExpress.XtraBars.BarButtonItem barButtonInspectionTicket;
        private DevExpress.XtraEditors.SplitContainerControl splitContainerControl1;
        private DevExpress.XtraGrid.GridControl grdCostCode;
        private DevExpress.XtraGrid.Views.Grid.GridView gridView1;
        private DevExpress.XtraEditors.Repository.RepositoryItemCheckEdit chkSelectedItem;
        private DevExpress.XtraEditors.Repository.RepositoryItemMemoExEdit txtUserDescription;
        private DevExpress.XtraEditors.Repository.RepositoryItemTextEdit txtMaterialCost;
        private DevExpress.XtraEditors.Repository.RepositoryItemTextEdit txtLaborCost;
        private DevExpress.XtraEditors.Repository.RepositoryItemTextEdit txtOtherCost;
        private DevExpress.XtraEditors.Repository.RepositoryItemTextEdit txtQuantity;
        private DevExpress.XtraEditors.Repository.RepositoryItemTextEdit txtHours;
        private DevExpress.XtraEditors.Repository.RepositoryItemComboBox cboUnit;
        private DevExpress.XtraEditors.Repository.RepositoryItemTextEdit txtUserDescription1;
        private DevExpress.XtraEditors.PanelControl panCostCodes;
        private DevExpress.XtraEditors.SimpleButton btnProcess;
        private DevExpress.XtraEditors.LabelControl labelControl18;
        private DevExpress.XtraEditors.LookUpEdit cboPhase;
        private DevExpress.XtraEditors.CheckEdit chkSelected;
        private DevExpress.XtraTab.XtraTabControl xtraTabControl1;
        private DevExpress.XtraTab.XtraTabPage xtraTabPage1;
        private DevExpress.XtraTab.XtraTabPage xtraTabPage2;
        private DevExpress.XtraEditors.LabelControl labelControl23;
        private DevExpress.XtraEditors.LabelControl labelControl22;
        private DevExpress.XtraEditors.PanelControl panelControl5;
        private DevExpress.XtraEditors.TextEdit txtBondPercent;
        private DevExpress.XtraEditors.TextEdit txtWarrantyPercent;
        private DevExpress.XtraEditors.TextEdit txtSubcontractAdministrationPercent;
        private DevExpress.XtraEditors.TextEdit txtProfitPercent;
        private DevExpress.XtraEditors.TextEdit txtOverheadPercent;
        private DevExpress.XtraEditors.PanelControl panelControl3;
        private DevExpress.XtraEditors.LabelControl labelControl15;
        private DevExpress.XtraEditors.TextEdit txtFringeBenefitsPercent;
        private DevExpress.XtraEditors.TextEdit txtSafetyMeetingPercent;
        private DevExpress.XtraEditors.LabelControl labelControl16;
        private DevExpress.XtraEditors.LabelControl labelControl17;
        private DevExpress.XtraEditors.TextEdit txtProjectEngineerPercentOfLabor;
        private DevExpress.XtraEditors.LabelControl labelControl11;
        private DevExpress.XtraEditors.TextEdit txtProjectManagerPercentOfLabor;
        private DevExpress.XtraEditors.TextEdit txtSuperintendentPercentOfLabor;
        private DevExpress.XtraEditors.LabelControl labelControl12;
        private DevExpress.XtraEditors.LabelControl labelControl13;
        private DevExpress.XtraEditors.TextEdit txtGeneralForemanPercentOfLabor;
        private DevExpress.XtraEditors.TextEdit txtForemanPercentOfLabor;
        private DevExpress.XtraEditors.LabelControl labelControl14;
        private DevExpress.XtraEditors.LabelControl labelControl10;
        private DevExpress.XtraEditors.PanelControl panelControl2;
        private DevExpress.XtraEditors.TextEdit txtCartigeHandlingPercent;
        private DevExpress.XtraEditors.TextEdit txtSmallToolsPercent;
        private DevExpress.XtraEditors.TextEdit txtStoragePercent;
        private DevExpress.XtraEditors.TextEdit txtAsBuiltsEngineeringPercent;
        private DevExpress.XtraEditors.PanelControl panelControl1;
        private DevExpress.XtraEditors.LabelControl labelControl5;
        private DevExpress.XtraEditors.TextEdit txtSalesTaxPercent;
        private DevExpress.XtraEditors.TextEdit txtSundriesPercentOfMaterial;
        private DevExpress.XtraEditors.LabelControl labelControl4;
        private DevExpress.XtraEditors.LabelControl labelControl25;
        private DevExpress.XtraTab.XtraTabPage xtraTabPage3;
        private DevExpress.XtraEditors.LabelControl labelControl112;
        private DevExpress.XtraEditors.PanelControl panelControl12;
        private DevExpress.XtraEditors.LabelControl labelControl120;
        private DevExpress.XtraEditors.TextEdit txtProjectEngineerLaborRate;
        private DevExpress.XtraEditors.LabelControl labelControl113;
        private DevExpress.XtraEditors.TextEdit txtPremiumTimeLaborRate;
        private DevExpress.XtraEditors.TextEdit txtSafetyMeetingsLaborRate;
        private DevExpress.XtraEditors.LabelControl labelControl114;
        private DevExpress.XtraEditors.LabelControl labelControl115;
        private DevExpress.XtraEditors.TextEdit txtProjectManagerLaborRate;
        private DevExpress.XtraEditors.LabelControl labelControl116;
        private DevExpress.XtraEditors.TextEdit txtSuperintendentLaborRate;
        private DevExpress.XtraEditors.TextEdit txtGeneralForemanLaborRate;
        private DevExpress.XtraEditors.LabelControl labelControl117;
        private DevExpress.XtraEditors.LabelControl labelControl118;
        private DevExpress.XtraEditors.TextEdit txtForemanLaborRate;
        private DevExpress.XtraEditors.TextEdit txtElectricianLaborRate;
        private DevExpress.XtraEditors.LabelControl labelControl119;
        private DevExpress.XtraTab.XtraTabPage xtraTabPage4;
        private DevExpress.XtraEditors.PanelControl panelControl8;
        private DevExpress.XtraEditors.LabelControl labelControl2;
        private DevExpress.XtraEditors.TextEdit txtSubcontractsEstimateDefaults;
        private DevExpress.XtraEditors.LabelControl labelControl26;
        private DevExpress.XtraEditors.TextEdit txtContractDollarEstimateDefaults;
        private DevExpress.XtraEditors.TextEdit txtTotalCostEstimateDefaults;
        private DevExpress.XtraEditors.LabelControl labelControl27;
        private DevExpress.XtraEditors.LabelControl labelControl28;
        private DevExpress.XtraEditors.TextEdit txtOtherEstimateDefaults;
        private DevExpress.XtraEditors.LabelControl labelControl29;
        private DevExpress.XtraEditors.TextEdit txtMaterialsEstimateDefaults;
        private DevExpress.XtraEditors.TextEdit txtLaborRateEstimateDefaults;
        private DevExpress.XtraEditors.LabelControl labelControl37;
        private DevExpress.XtraEditors.LabelControl labelControl50;
        private DevExpress.XtraEditors.TextEdit txtLaborDollarEstimateDefaults;
        private DevExpress.XtraEditors.TextEdit txtLaborHoursEstimateDefaults;
        private DevExpress.XtraEditors.LabelControl labelControl51;
        private DevExpress.XtraEditors.LabelControl labelControl56;
        private DevExpress.XtraEditors.LabelControl labelControl1;
        private DevExpress.XtraEditors.TextEdit txtProfitPercentBudgetTotals;
        private DevExpress.XtraEditors.TextEdit txtProfitDollarBudgetTotals;
        private DevExpress.XtraEditors.LabelControl labelControl53;
        private DevExpress.XtraEditors.TextEdit txtProfitPercentEstimateDefaults;
        private DevExpress.XtraEditors.TextEdit txtProfitDollarEstimateDefaults;
        private DevExpress.XtraEditors.LabelControl labelControl54;
        private DevExpress.XtraEditors.TextEdit txtSubcontractsBudgetTotals;
        private DevExpress.XtraEditors.TextEdit txtContractDollarBudgetTotals;
        private DevExpress.XtraEditors.TextEdit txtTotalCostBudgetTotals;
        private DevExpress.XtraEditors.TextEdit txtOtherBudgetTotals;
        private DevExpress.XtraEditors.TextEdit txtMaterialsBudgetTotals;
        private DevExpress.XtraEditors.TextEdit txtLaborRateBudgetTotals;
        private DevExpress.XtraEditors.TextEdit txtLaborDollarBudgetTotals;
        private DevExpress.XtraEditors.TextEdit txtLaborHoursBudgetTotals;
        private DevExpress.XtraEditors.LabelControl labelControl64;
        private DevExpress.XtraEditors.LabelControl labelControl62;
        private DevExpress.XtraEditors.LabelControl labelControl67;
        private DevExpress.XtraEditors.LabelControl labelControl71;
        private DevExpress.XtraEditors.PanelControl panelControl9;
        private DevExpress.XtraEditors.TextEdit txtSubcontractsAmount;
        private DevExpress.XtraEditors.LabelControl labelControl85;
        private DevExpress.XtraEditors.PanelControl panelControl10;
        private DevExpress.XtraEditors.LabelControl labelControl121;
        private DevExpress.XtraEditors.TextEdit txtProjectEngineerActualHours;
        private DevExpress.XtraEditors.LabelControl labelControl122;
        private DevExpress.XtraEditors.TextEdit txtProjectManagerActualHours;
        private DevExpress.XtraEditors.TextEdit txtSuperintendentActualHours;
        private DevExpress.XtraEditors.LabelControl labelControl123;
        private DevExpress.XtraEditors.LabelControl labelControl124;
        private DevExpress.XtraEditors.TextEdit txtGeneralForemanActualHours;
        private DevExpress.XtraEditors.TextEdit txtForemanActualHours;
        private DevExpress.XtraEditors.LabelControl labelControl125;
        private DevExpress.XtraEditors.LabelControl labelControl126;
        private DevExpress.XtraEditors.PanelControl panelControl11;
        private DevExpress.XtraEditors.TextEdit txtOtherExpenses3;
        private DevExpress.XtraEditors.LabelControl labelControl128;
        private DevExpress.XtraEditors.LabelControl labelControl129;
        private DevExpress.XtraEditors.TextEdit txtOtherExpenses2;
        private DevExpress.XtraEditors.TextEdit txtOtherExpenses1;
        private DevExpress.XtraEditors.LabelControl labelControl130;
        private DevExpress.XtraEditors.PanelControl panelControl13;
        private DevExpress.XtraEditors.TextEdit txtDirectMaterials;
        private DevExpress.XtraEditors.LabelControl labelControl132;
        private DevExpress.XtraEditors.LabelControl labelControl133;
        private DevExpress.XtraEditors.TextEdit txtProjectEngineerDefaultHours;
        private DevExpress.XtraEditors.TextEdit txtProjectManagerDefaultHours;
        private DevExpress.XtraEditors.TextEdit txtSuperintendentDefaultHours;
        private DevExpress.XtraEditors.TextEdit txtGeneralForemanDefaultHours;
        private DevExpress.XtraEditors.TextEdit txtForemanDefaultHours;
        private DevExpress.XtraEditors.TextEdit txtEstimatedElectricianHours;
        private DevExpress.XtraEditors.LabelControl labelControl87;
        private DevExpress.XtraEditors.LabelControl labelControl135;
        private DevExpress.XtraEditors.LabelControl labelControl111;
        private DevExpress.XtraEditors.LabelControl labelControl127;
        private DevExpress.XtraEditors.TextEdit txtOtherExpenses3Description;
        private DevExpress.XtraEditors.TextEdit txtOtherExpenses2Description;
        private DevExpress.XtraEditors.TextEdit txtOtherExpenses1Description;
        private DevExpress.XtraEditors.LabelControl labelControl136;
        private DevExpress.XtraEditors.PanelControl panelControl14;
        private DevExpress.XtraEditors.LabelControl labelControl138;
        private DevExpress.XtraEditors.LabelControl labelControl137;
        private DevExpress.XtraEditors.LabelControl labelControl82;
        private DevExpress.XtraEditors.LabelControl labelControl80;
        private DevExpress.XtraEditors.LabelControl labelControl76;
        private DevExpress.XtraEditors.LabelControl labelControl73;
        private DevExpress.XtraEditors.LabelControl labelControl142;
        private DevExpress.XtraEditors.LabelControl labelControl141;
        private DevExpress.XtraEditors.LabelControl labelControl140;
        private DevExpress.XtraEditors.LabelControl labelControl139;
        private DevExpress.XtraEditors.ComboBoxEdit cboJobChangeOrderDescription;
        private DevExpress.XtraEditors.TextEdit txtJobChangeOrderNumber;
        private DevExpress.XtraEditors.LabelControl labelControl144;
        private DevExpress.XtraEditors.LabelControl labelControl143;
        private DevExpress.XtraEditors.ComboBoxEdit cboJobChangeOrderStatus;
        private DevExpress.XtraEditors.TextEdit txtJobChangeOrderOwnerNumber;
        private DevExpress.XtraEditors.TextEdit txtJobChangeOrderCCENumber;
        private DevExpress.XtraEditors.TextEdit txtJobChangeOrderUserDescription;
        private DevExpress.XtraEditors.TextEdit txtJobChangeOrderApprovedAmount;
        private DevExpress.XtraEditors.DateEdit txtJobChangeOrderApprovedDate;
        private DevExpress.XtraEditors.TextEdit txtJobChangeOrderRequestedAmount;
        private DevExpress.XtraEditors.DateEdit txtJobChangeOrderRequestDate;
        private DevExpress.XtraEditors.TextEdit txtPriceAdjustment;
        private DevExpress.XtraEditors.TextEdit txtChangeOrderAmount;
        private DevExpress.XtraEditors.TextEdit txtPremiumHoursActualHours;
        private DevExpress.XtraEditors.LabelControl labelControl145;
        private DevExpress.XtraEditors.TextEdit txtRecordID;
        private DevExpress.XtraEditors.SimpleButton btnSaveCostCodes;
        private DevExpress.XtraTab.XtraTabPage xtraTabPage5;
        private DevExpress.XtraEditors.LabelControl labelControl148;
        private DevExpress.XtraEditors.HyperlinkLabelControl labelControl147;
        private DevExpress.XtraEditors.HyperlinkLabelControl labelControl146;
        private DevExpress.XtraEditors.TextEdit txtLetterTimeExtension;
        private DevExpress.XtraBars.BarButtonItem btnChangeOrderLetter;
        private DevExpress.XtraBars.BarButtonItem barButtonItem3;
        private DevExpress.XtraBars.BarButtonItem barButtonItem4;
        private DevExpress.XtraSpellChecker.SpellChecker spellChecker1;
        private DevExpress.XtraEditors.TextEdit txtFrom;
        private DevExpress.XtraEditors.LabelControl labelControl149;
        private DevExpress.XtraEditors.LabelControl labelControl150;
        private DevExpress.XtraEditors.LookUpEdit cboContact;
        private DevExpress.XtraEditors.TextEdit txtCompany;
        private DevExpress.XtraEditors.LabelControl labelControl151;
        private DevExpress.XtraEditors.LabelControl labelControl152;
        private DevExpress.XtraEditors.TextEdit txtApprenticeLaborRate;
        private DevExpress.XtraEditors.TextEdit txtEstimatedApprenticeHours;
        private DevExpress.XtraEditors.LabelControl labelControl153;
        private ControlsLibrary.RichBoxEditor txtLetterExclusion;
        private ControlsLibrary.RichBoxEditor txtLetterWorkDescription;
        private DevExpress.XtraEditors.TextEdit txtApprenticeLaborRateDT;
        private DevExpress.XtraEditors.TextEdit txtProjectEngineerLaborRateDT;
        private DevExpress.XtraEditors.TextEdit txtPremiumTimeLaborRateDT;
        private DevExpress.XtraEditors.TextEdit txtSafetyMeetingsLaborRateDT;
        private DevExpress.XtraEditors.TextEdit txtProjectManagerLaborRateDT;
        private DevExpress.XtraEditors.TextEdit txtSuperintendentLaborRateDT;
        private DevExpress.XtraEditors.TextEdit txtGeneralForemanLaborRateDT;
        private DevExpress.XtraEditors.TextEdit txtForemanLaborRateDT;
        private DevExpress.XtraEditors.TextEdit txtElectricianLaborRateDT;
        private DevExpress.XtraEditors.TextEdit txtApprenticeLaborRateOT;
        private DevExpress.XtraEditors.TextEdit txtProjectEngineerLaborRateOT;
        private DevExpress.XtraEditors.TextEdit txtPremiumTimeLaborRateOT;
        private DevExpress.XtraEditors.TextEdit txtSafetyMeetingsLaborRateOT;
        private DevExpress.XtraEditors.TextEdit txtProjectManagerLaborRateOT;
        private DevExpress.XtraEditors.TextEdit txtSuperintendentLaborRateOT;
        private DevExpress.XtraEditors.TextEdit txtGeneralForemanLaborRateOT;
        private DevExpress.XtraEditors.TextEdit txtForemanLaborRateOT;
        private DevExpress.XtraEditors.TextEdit txtElectricianLaborRateOT;
        private DevExpress.XtraEditors.LabelControl labelControl154;
        private DevExpress.XtraEditors.LabelControl labelControl155;
        private DevExpress.XtraEditors.LabelControl labelControl156;
        private DevExpress.XtraEditors.TextEdit txtEstimatedApprenticeHoursOT;
        private DevExpress.XtraEditors.TextEdit txtEstimatedElectricianHoursOT;
        private DevExpress.XtraEditors.TextEdit txtEstimatedApprenticeHoursDT;
        private DevExpress.XtraEditors.TextEdit txtEstimatedElectricianHoursDT;
        private DevExpress.XtraEditors.LabelControl labelControl157;
        private DevExpress.XtraEditors.LabelControl labelControl158;
        private DevExpress.XtraEditors.LabelControl labelControl159;
        private DevExpress.XtraEditors.TextEdit txtProjectEngineerDefaultHoursDT;
        private DevExpress.XtraEditors.TextEdit txtProjectManagerDefaultHoursDT;
        private DevExpress.XtraEditors.TextEdit txtSuperintendentDefaultHoursDT;
        private DevExpress.XtraEditors.TextEdit txtGeneralForemanDefaultHoursDT;
        private DevExpress.XtraEditors.TextEdit txtForemanDefaultHoursDT;
        private DevExpress.XtraEditors.TextEdit txtProjectEngineerDefaultHoursOT;
        private DevExpress.XtraEditors.TextEdit txtProjectManagerDefaultHoursOT;
        private DevExpress.XtraEditors.TextEdit txtSuperintendentDefaultHoursOT;
        private DevExpress.XtraEditors.TextEdit txtGeneralForemanDefaultHoursOT;
        private DevExpress.XtraEditors.TextEdit txtForemanDefaultHoursOT;
        private DevExpress.XtraEditors.TextEdit txtPremiumHoursActualHoursDT;
        private DevExpress.XtraEditors.TextEdit txtProjectEngineerActualHoursDT;
        private DevExpress.XtraEditors.TextEdit txtProjectManagerActualHoursDT;
        private DevExpress.XtraEditors.TextEdit txtSuperintendentActualHoursDT;
        private DevExpress.XtraEditors.TextEdit txtGeneralForemanActualHoursDT;
        private DevExpress.XtraEditors.TextEdit txtForemanActualHoursDT;
        private DevExpress.XtraEditors.TextEdit txtPremiumHoursActualHoursOT;
        private DevExpress.XtraEditors.TextEdit txtProjectEngineerActualHoursOT;
        private DevExpress.XtraEditors.TextEdit txtProjectManagerActualHoursOT;
        private DevExpress.XtraEditors.TextEdit txtSuperintendentActualHoursOT;
        private DevExpress.XtraEditors.TextEdit txtGeneralForemanActualHoursOT;
        private DevExpress.XtraEditors.TextEdit txtForemanActualHoursOT;
        private DevExpress.XtraEditors.LabelControl labelControl161;
        private DevExpress.XtraEditors.LabelControl labelControl162;
        private DevExpress.XtraEditors.LabelControl labelControl163;
        private DevExpress.XtraEditors.LabelControl labelControl131;
        private DevExpress.XtraEditors.LabelControl labelControl134;
        private DevExpress.XtraEditors.LabelControl labelControl160;
        private DevExpress.XtraEditors.ComboBoxEdit comboBoxEdit2;
        private DevExpress.XtraEditors.LabelControl labelControl164;
        private DevExpress.XtraEditors.LabelControl labelControl165;
        private DevExpress.XtraEditors.LabelControl labelControl166;
        private DevExpress.XtraEditors.ComboBoxEdit cboRevision;
        private DevExpress.XtraEditors.TextEdit txtBIMRateDT;
        private DevExpress.XtraEditors.TextEdit txtBIMRateOT;
        private DevExpress.XtraEditors.LabelControl labelControl167;
        private DevExpress.XtraEditors.TextEdit txtBIMRate;
        private DevExpress.XtraEditors.TextEdit txtEstimatedBIMHoursDT;
        private DevExpress.XtraEditors.TextEdit txtEstimatedBIMHoursOT;
        private DevExpress.XtraEditors.LabelControl labelControl168;
        private DevExpress.XtraEditors.TextEdit txtEstimatedBIMHours;
        private DevExpress.XtraEditors.TextEdit txtAsBuiltsEngineeringPercentText;
        private DevExpress.XtraEditors.TextEdit txtCartigeHandlingPercentText;
        private DevExpress.XtraEditors.TextEdit txtSmallToolsPercentText;
        private DevExpress.XtraEditors.TextEdit txtStoragePercentText;
        private DevExpress.XtraEditors.TextEdit txtBondPercentText;
        private DevExpress.XtraEditors.TextEdit txtWarrantyPercentText;
        private DevExpress.XtraEditors.TextEdit txtSubcontractAdministrationPercentText;
        private DevExpress.XtraEditors.TextEdit txtProfitPercentText;
        private DevExpress.XtraEditors.TextEdit txtOverheadPercentText;
    }
}