namespace CCEJobs.PresentationLayer
{
    partial class frmJobSystemDefaultValues
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmJobSystemDefaultValues));
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling51 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling52 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling53 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraBars.Ribbon.GalleryItemGroup galleryItemGroup1 = new DevExpress.XtraBars.Ribbon.GalleryItemGroup();
            DevExpress.XtraBars.Ribbon.GalleryItemGroup galleryItemGroup2 = new DevExpress.XtraBars.Ribbon.GalleryItemGroup();
            DevExpress.XtraBars.Ribbon.GalleryItemGroup galleryItemGroup3 = new DevExpress.XtraBars.Ribbon.GalleryItemGroup();
            DevExpress.XtraBars.Ribbon.GalleryItemGroup galleryItemGroup4 = new DevExpress.XtraBars.Ribbon.GalleryItemGroup();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling54 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling55 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling56 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling57 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling58 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling59 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling60 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling61 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling62 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling63 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling64 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling65 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling66 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling67 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling68 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling69 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling70 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling71 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling72 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling73 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling74 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling75 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling76 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling77 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling78 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling79 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling1 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling2 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling3 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling4 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling5 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling6 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling7 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling8 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling9 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling10 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling11 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling12 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling13 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling14 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling15 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling16 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling17 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling18 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling19 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling20 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling21 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling22 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling23 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling24 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling25 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling26 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling27 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling28 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling29 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling30 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling31 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling32 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling33 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling34 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling35 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling36 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling37 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling38 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling39 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling40 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling41 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling42 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling43 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling44 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling45 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling46 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling47 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling48 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling49 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling50 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling80 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling81 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling82 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling83 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling84 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling85 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling86 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling87 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling88 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling89 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling90 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling91 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling92 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling93 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling94 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling95 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling96 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            DevExpress.XtraSpellChecker.OptionsSpelling optionsSpelling97 = new DevExpress.XtraSpellChecker.OptionsSpelling();
            this.imgCollection = new DevExpress.Utils.ImageCollection();
            this.btnToolInspectionsReport = new DevExpress.XtraBars.BarButtonItem();
            this.btnToolRepairPartsReport = new DevExpress.XtraBars.BarButtonItem();
            this.btnToolComponentsReport = new DevExpress.XtraBars.BarButtonItem();
            this.btnToolAccessoriesReport = new DevExpress.XtraBars.BarButtonItem();
            this.btnProjectInfoSheetReport = new DevExpress.XtraBars.BarButtonItem();
            this.btnToolEventScheduledReport = new DevExpress.XtraBars.BarButtonItem();
            this.btnAccessories = new DevExpress.XtraBars.BarButtonItem();
            this.btnComponents = new DevExpress.XtraBars.BarButtonItem();
            this.btnRepairParts = new DevExpress.XtraBars.BarButtonItem();
            this.btnInspections = new DevExpress.XtraBars.BarButtonItem();
            this.btnGeneral = new DevExpress.XtraBars.BarButtonItem();
            this.ribbonAction = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.btnSave = new DevExpress.XtraBars.BarButtonItem();
            this.btnUndo = new DevExpress.XtraBars.BarButtonItem();
            this.ribbonPage1 = new DevExpress.XtraBars.Ribbon.RibbonPage();
            this.barSubItemReports = new DevExpress.XtraBars.BarSubItem();
            this.imageCollection1 = new DevExpress.Utils.ImageCollection();
            this.barButtonGroup5 = new DevExpress.XtraBars.BarButtonGroup();
            this.btnTimeCard = new DevExpress.XtraBars.BarButtonItem();
            this.btnCostToComplete = new DevExpress.XtraBars.BarButtonItem();
            this.btnJobProgress = new DevExpress.XtraBars.BarButtonItem();
            this.btnLaborProd = new DevExpress.XtraBars.BarButtonItem();
            this.btnExcelQuantity = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItem2 = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonGroup4 = new DevExpress.XtraBars.BarButtonGroup();
            this.dxErrorProvider = new DevExpress.XtraEditors.DXErrorProvider.DXErrorProvider();
            this.textEdit30 = new DevExpress.XtraEditors.TextEdit();
            this.labelControl66 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl65 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl63 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl61 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl49 = new DevExpress.XtraEditors.LabelControl();
            this.textEdit32 = new DevExpress.XtraEditors.TextEdit();
            this.textEdit31 = new DevExpress.XtraEditors.TextEdit();
            this.labelControl48 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl60 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl59 = new DevExpress.XtraEditors.LabelControl();
            this.btnExcelHours = new DevExpress.XtraBars.BarButtonItem();
            this.btnLaborFeedbackReport = new DevExpress.XtraBars.BarButtonItem();
            this.btnLaborFeedback = new DevExpress.XtraBars.BarButtonItem();
            this.iWeb = new DevExpress.XtraBars.BarButtonItem();
            this.iProtected = new DevExpress.XtraBars.BarButtonItem();
            this.iBullets = new DevExpress.XtraBars.BarButtonItem();
            this.iFont = new DevExpress.XtraBars.BarButtonItem();
            this.btnGeneralOld = new DevExpress.XtraBars.BarButtonItem();
            this.iAbout = new DevExpress.XtraBars.BarButtonItem();
            this.iBold = new DevExpress.XtraBars.BarButtonItem();
            this.iAlignRight = new DevExpress.XtraBars.BarButtonItem();
            this.iCenter = new DevExpress.XtraBars.BarButtonItem();
            this.iAlignLeft = new DevExpress.XtraBars.BarButtonItem();
            this.iUnderline = new DevExpress.XtraBars.BarButtonItem();
            this.iSelectAll = new DevExpress.XtraBars.BarButtonItem();
            this.btnTimeSheet = new DevExpress.XtraBars.BarButtonItem();
            this.imageCollection2 = new DevExpress.Utils.ImageCollection();
            this.ribProjectOpportunity = new DevExpress.XtraBars.Ribbon.RibbonControl();
            this.iSaveAs = new DevExpress.XtraBars.BarButtonItem();
            this.btnCostCodesWeekly = new DevExpress.XtraBars.BarButtonItem();
            this.btnCostCodes = new DevExpress.XtraBars.BarButtonItem();
            this.btnstrategic = new DevExpress.XtraBars.BarButtonItem();
            this.iFontColor = new DevExpress.XtraBars.BarButtonItem();
            this.siPosition = new DevExpress.XtraBars.BarButtonItem();
            this.siModified = new DevExpress.XtraBars.BarButtonItem();
            this.siDocName = new DevExpress.XtraBars.BarStaticItem();
            this.bgFontStyle = new DevExpress.XtraBars.BarButtonGroup();
            this.bgAlign = new DevExpress.XtraBars.BarButtonGroup();
            this.bgFont = new DevExpress.XtraBars.BarButtonGroup();
            this.bgBullets = new DevExpress.XtraBars.BarButtonGroup();
            this.sbiPaste = new DevExpress.XtraBars.BarSubItem();
            this.iPasteSpecial = new DevExpress.XtraBars.BarButtonItem();
            this.iNew = new DevExpress.XtraBars.BarButtonItem();
            this.iLargeUndo = new DevExpress.XtraBars.BarLargeButtonItem();
            this.iTemplate = new DevExpress.XtraBars.BarButtonItem();
            this.rgbiSkins = new DevExpress.XtraBars.RibbonGalleryBarItem();
            this.beiFontSize = new DevExpress.XtraBars.BarEditItem();
            this.rgbiFont = new DevExpress.XtraBars.RibbonGalleryBarItem();
            this.bbiFontColorPopup = new DevExpress.XtraBars.BarButtonItem();
            this.rgbiFontColor = new DevExpress.XtraBars.RibbonGalleryBarItem();
            this.btnPersonnel = new DevExpress.XtraBars.BarButtonItem();
            this.iGeneral = new DevExpress.XtraBars.BarSubItem();
            this.btnNote = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItem5 = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItem6 = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonGroup1 = new DevExpress.XtraBars.BarButtonGroup();
            this.barButtonGroup2 = new DevExpress.XtraBars.BarButtonGroup();
            this.barButtonGroup3 = new DevExpress.XtraBars.BarButtonGroup();
            this.barLinkContainerItem1 = new DevExpress.XtraBars.BarLinkContainerItem();
            this.barMdiChildrenListItem1 = new DevExpress.XtraBars.BarMdiChildrenListItem();
            this.barButtonItem1 = new DevExpress.XtraBars.BarButtonItem();
            this.labelControl68 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl99 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl98 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl100 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl97 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl101 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl102 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl104 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl96 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl103 = new DevExpress.XtraEditors.LabelControl();
            this.textEdit78 = new DevExpress.XtraEditors.TextEdit();
            this.textEdit77 = new DevExpress.XtraEditors.TextEdit();
            this.textEdit76 = new DevExpress.XtraEditors.TextEdit();
            this.labelControl78 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl77 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl75 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl79 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl74 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl70 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl69 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl72 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl95 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl94 = new DevExpress.XtraEditors.LabelControl();
            this.textEdit68 = new DevExpress.XtraEditors.TextEdit();
            this.labelControl93 = new DevExpress.XtraEditors.LabelControl();
            this.textEdit67 = new DevExpress.XtraEditors.TextEdit();
            this.textEdit69 = new DevExpress.XtraEditors.TextEdit();
            this.textEdit70 = new DevExpress.XtraEditors.TextEdit();
            this.textEdit75 = new DevExpress.XtraEditors.TextEdit();
            this.textEdit74 = new DevExpress.XtraEditors.TextEdit();
            this.textEdit73 = new DevExpress.XtraEditors.TextEdit();
            this.textEdit72 = new DevExpress.XtraEditors.TextEdit();
            this.textEdit71 = new DevExpress.XtraEditors.TextEdit();
            this.labelControl92 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl91 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl84 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl83 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl81 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl86 = new DevExpress.XtraEditors.LabelControl();
            this.lookUpEdit3 = new DevExpress.XtraEditors.LookUpEdit();
            this.labelControl90 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl89 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl88 = new DevExpress.XtraEditors.LabelControl();
            this.textEdit66 = new DevExpress.XtraEditors.TextEdit();
            this.labelControl30 = new DevExpress.XtraEditors.LabelControl();
            this.radioGroup1 = new DevExpress.XtraEditors.RadioGroup();
            this.labelControl31 = new DevExpress.XtraEditors.LabelControl();
            this.panelControl4 = new DevExpress.XtraEditors.PanelControl();
            this.textEdit4 = new DevExpress.XtraEditors.TextEdit();
            this.labelControl32 = new DevExpress.XtraEditors.LabelControl();
            this.textEdit5 = new DevExpress.XtraEditors.TextEdit();
            this.textEdit6 = new DevExpress.XtraEditors.TextEdit();
            this.labelControl33 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl34 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl35 = new DevExpress.XtraEditors.LabelControl();
            this.textEdit7 = new DevExpress.XtraEditors.TextEdit();
            this.memoEdit1 = new DevExpress.XtraEditors.MemoEdit();
            this.labelControl36 = new DevExpress.XtraEditors.LabelControl();
            this.panelControl6 = new DevExpress.XtraEditors.PanelControl();
            this.dateEdit1 = new DevExpress.XtraEditors.DateEdit();
            this.lookUpEdit1 = new DevExpress.XtraEditors.LookUpEdit();
            this.labelControl38 = new DevExpress.XtraEditors.LabelControl();
            this.lookUpEdit2 = new DevExpress.XtraEditors.LookUpEdit();
            this.lookUpEdit4 = new DevExpress.XtraEditors.LookUpEdit();
            this.lookUpEdit5 = new DevExpress.XtraEditors.LookUpEdit();
            this.textEdit8 = new DevExpress.XtraEditors.TextEdit();
            this.textEdit9 = new DevExpress.XtraEditors.TextEdit();
            this.dateEdit2 = new DevExpress.XtraEditors.DateEdit();
            this.comboBoxEdit1 = new DevExpress.XtraEditors.ComboBoxEdit();
            this.labelControl39 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl40 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl41 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl42 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl43 = new DevExpress.XtraEditors.LabelControl();
            this.lookUpEdit6 = new DevExpress.XtraEditors.LookUpEdit();
            this.dateEdit3 = new DevExpress.XtraEditors.DateEdit();
            this.labelControl44 = new DevExpress.XtraEditors.LabelControl();
            this.dateEdit4 = new DevExpress.XtraEditors.DateEdit();
            this.textEdit10 = new DevExpress.XtraEditors.TextEdit();
            this.textEdit11 = new DevExpress.XtraEditors.TextEdit();
            this.labelControl45 = new DevExpress.XtraEditors.LabelControl();
            this.textEdit12 = new DevExpress.XtraEditors.TextEdit();
            this.textEdit13 = new DevExpress.XtraEditors.TextEdit();
            this.labelControl46 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl47 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl52 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl55 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl57 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl58 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl105 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl106 = new DevExpress.XtraEditors.LabelControl();
            this.panelControl7 = new DevExpress.XtraEditors.PanelControl();
            this.dateEdit5 = new DevExpress.XtraEditors.DateEdit();
            this.dateEdit6 = new DevExpress.XtraEditors.DateEdit();
            this.textEdit14 = new DevExpress.XtraEditors.TextEdit();
            this.textEdit15 = new DevExpress.XtraEditors.TextEdit();
            this.labelControl107 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl108 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl109 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl110 = new DevExpress.XtraEditors.LabelControl();
            this.xtraTabControl1 = new DevExpress.XtraTab.XtraTabControl();
            this.xtraTabPage1 = new DevExpress.XtraTab.XtraTabPage();
            this.Paragraph2 = new DevExpress.XtraEditors.HyperlinkLabelControl();
            this.Paragraph1 = new DevExpress.XtraEditors.HyperlinkLabelControl();
            this.txtChangeOrderStipulationsParagraph2 = new ControlsLibrary.RichBoxEditor();
            this.txtChangeOrderStipulationsParagraph1 = new ControlsLibrary.RichBoxEditor();
            this.xtraTabPage2 = new DevExpress.XtraTab.XtraTabPage();
            this.labelControl23 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl22 = new DevExpress.XtraEditors.LabelControl();
            this.panelControl5 = new DevExpress.XtraEditors.PanelControl();
            this.labelControl24 = new DevExpress.XtraEditors.LabelControl();
            this.txtBondPercent = new DevExpress.XtraEditors.TextEdit();
            this.labelControl18 = new DevExpress.XtraEditors.LabelControl();
            this.txtWarrantyPercent = new DevExpress.XtraEditors.TextEdit();
            this.txtSubcontractAdministrationPercent = new DevExpress.XtraEditors.TextEdit();
            this.labelControl19 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl20 = new DevExpress.XtraEditors.LabelControl();
            this.txtProfitPercent = new DevExpress.XtraEditors.TextEdit();
            this.txtOverheadPercent = new DevExpress.XtraEditors.TextEdit();
            this.labelControl21 = new DevExpress.XtraEditors.LabelControl();
            this.panelControl3 = new DevExpress.XtraEditors.PanelControl();
            this.labelControl15 = new DevExpress.XtraEditors.LabelControl();
            this.txtFringeBenefitsPercent = new DevExpress.XtraEditors.TextEdit();
            this.txtSafetyMeetingPercent = new DevExpress.XtraEditors.TextEdit();
            this.labelControl16 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl17 = new DevExpress.XtraEditors.LabelControl();
            this.txtProjectEngineerPercentOfLabor = new DevExpress.XtraEditors.TextEdit();
            this.labelControl11 = new DevExpress.XtraEditors.LabelControl();
            this.txtProjectManagerPercentOfLabor = new DevExpress.XtraEditors.TextEdit();
            this.txtSuperintendentPercentOfLabor = new DevExpress.XtraEditors.TextEdit();
            this.labelControl12 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl13 = new DevExpress.XtraEditors.LabelControl();
            this.txtGeneralForemanPercentOfLabor = new DevExpress.XtraEditors.TextEdit();
            this.txtForemanPercentOfLabor = new DevExpress.XtraEditors.TextEdit();
            this.labelControl14 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl10 = new DevExpress.XtraEditors.LabelControl();
            this.panelControl2 = new DevExpress.XtraEditors.PanelControl();
            this.labelControl8 = new DevExpress.XtraEditors.LabelControl();
            this.txtCartigeHandlingPercent = new DevExpress.XtraEditors.TextEdit();
            this.txtSmallToolsPercent = new DevExpress.XtraEditors.TextEdit();
            this.labelControl9 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl6 = new DevExpress.XtraEditors.LabelControl();
            this.txtStoragePercent = new DevExpress.XtraEditors.TextEdit();
            this.txtAsBuiltsEngineeringPercent = new DevExpress.XtraEditors.TextEdit();
            this.labelControl7 = new DevExpress.XtraEditors.LabelControl();
            this.panelControl1 = new DevExpress.XtraEditors.PanelControl();
            this.labelControl5 = new DevExpress.XtraEditors.LabelControl();
            this.txtSalesTaxPercent = new DevExpress.XtraEditors.TextEdit();
            this.txtSundriesPercentOfMaterial = new DevExpress.XtraEditors.TextEdit();
            this.labelControl4 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl3 = new DevExpress.XtraEditors.LabelControl();
            this.xtraTabPage3 = new DevExpress.XtraTab.XtraTabPage();
            this.labelControl112 = new DevExpress.XtraEditors.LabelControl();
            this.panelControl12 = new DevExpress.XtraEditors.PanelControl();
            this.txtBIMRateDT = new DevExpress.XtraEditors.TextEdit();
            this.txtBIMRateOT = new DevExpress.XtraEditors.TextEdit();
            this.txtBIMRate = new DevExpress.XtraEditors.TextEdit();
            this.labelControl134 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl133 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl132 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl131 = new DevExpress.XtraEditors.LabelControl();
            this.txtApprenticeLaborRateDT = new DevExpress.XtraEditors.TextEdit();
            this.txtProjectEngineerLaborRateDT = new DevExpress.XtraEditors.TextEdit();
            this.txtPremiumTimeLaborRateDT = new DevExpress.XtraEditors.TextEdit();
            this.txtSafetyMeetingsLaborRateDT = new DevExpress.XtraEditors.TextEdit();
            this.txtProjectManagerLaborRateDT = new DevExpress.XtraEditors.TextEdit();
            this.txtSuperintendentLaborRateDT = new DevExpress.XtraEditors.TextEdit();
            this.txtGeneralForemanLaborRateDT = new DevExpress.XtraEditors.TextEdit();
            this.txtForemanLaborRateDT = new DevExpress.XtraEditors.TextEdit();
            this.txtElectricianLaborRateDT = new DevExpress.XtraEditors.TextEdit();
            this.txtApprenticeLaborRateOT = new DevExpress.XtraEditors.TextEdit();
            this.txtProjectEngineerLaborRateOT = new DevExpress.XtraEditors.TextEdit();
            this.txtPremiumTimeLaborRateOT = new DevExpress.XtraEditors.TextEdit();
            this.txtSafetyMeetingsLaborRateOT = new DevExpress.XtraEditors.TextEdit();
            this.txtProjectManagerLaborRateOT = new DevExpress.XtraEditors.TextEdit();
            this.txtSuperintendentLaborRateOT = new DevExpress.XtraEditors.TextEdit();
            this.txtGeneralForemanLaborRateOT = new DevExpress.XtraEditors.TextEdit();
            this.txtForemanLaborRateOT = new DevExpress.XtraEditors.TextEdit();
            this.txtElectricianLaborRateOT = new DevExpress.XtraEditors.TextEdit();
            this.txtApprenticeLaborRate = new DevExpress.XtraEditors.TextEdit();
            this.labelControl130 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl120 = new DevExpress.XtraEditors.LabelControl();
            this.txtProjectEngineerLaborRate = new DevExpress.XtraEditors.TextEdit();
            this.labelControl113 = new DevExpress.XtraEditors.LabelControl();
            this.txtPremiumTimeLaborRate = new DevExpress.XtraEditors.TextEdit();
            this.txtSafetyMeetingsLaborRate = new DevExpress.XtraEditors.TextEdit();
            this.labelControl114 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl115 = new DevExpress.XtraEditors.LabelControl();
            this.txtProjectManagerLaborRate = new DevExpress.XtraEditors.TextEdit();
            this.labelControl116 = new DevExpress.XtraEditors.LabelControl();
            this.txtSuperintendentLaborRate = new DevExpress.XtraEditors.TextEdit();
            this.txtGeneralForemanLaborRate = new DevExpress.XtraEditors.TextEdit();
            this.labelControl117 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl118 = new DevExpress.XtraEditors.LabelControl();
            this.txtForemanLaborRate = new DevExpress.XtraEditors.TextEdit();
            this.txtElectricianLaborRate = new DevExpress.XtraEditors.TextEdit();
            this.labelControl119 = new DevExpress.XtraEditors.LabelControl();
            this.pagContactDefaultValues = new DevExpress.XtraTab.XtraTabPage();
            this.labelControl121 = new DevExpress.XtraEditors.LabelControl();
            this.panelControl13 = new DevExpress.XtraEditors.PanelControl();
            this.cboForeman = new DevExpress.XtraEditors.LookUpEdit();
            this.labelControl128 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl126 = new DevExpress.XtraEditors.LabelControl();
            this.cboDefaultFrom = new DevExpress.XtraEditors.LookUpEdit();
            this.cboChangeOrderDefaultContact = new DevExpress.XtraEditors.LookUpEdit();
            this.cboRFIDefaultContact = new DevExpress.XtraEditors.LookUpEdit();
            this.labelControl122 = new DevExpress.XtraEditors.LabelControl();
            this.txtChangeOrderDefaultContactCompany = new DevExpress.XtraEditors.TextEdit();
            this.labelControl123 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl124 = new DevExpress.XtraEditors.LabelControl();
            this.txtRFIDefaultContactCompany = new DevExpress.XtraEditors.TextEdit();
            this.labelControl125 = new DevExpress.XtraEditors.LabelControl();
            this.pagMajorPONote = new DevExpress.XtraTab.XtraTabPage();
            this.MajorPONote = new DevExpress.XtraEditors.HyperlinkLabelControl();
            this.txtMajorPONote = new ControlsLibrary.RichBoxEditor();
            this.pagSmallPONote = new DevExpress.XtraTab.XtraTabPage();
            this.SmallPONote = new DevExpress.XtraEditors.HyperlinkLabelControl();
            this.txtSmallPONote = new ControlsLibrary.RichBoxEditor();
            this.pagSubmittalSpec = new DevExpress.XtraTab.XtraTabPage();
            this.grdSubmittal = new DevExpress.XtraGrid.GridControl();
            this.gridSubmittal = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.repDescription = new DevExpress.XtraEditors.Repository.RepositoryItemTextEdit();
            this.repSection = new DevExpress.XtraEditors.Repository.RepositoryItemTextEdit();
            this.labelControl25 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl26 = new DevExpress.XtraEditors.LabelControl();
            this.panelControl8 = new DevExpress.XtraEditors.PanelControl();
            this.labelControl27 = new DevExpress.XtraEditors.LabelControl();
            this.textEdit34 = new DevExpress.XtraEditors.TextEdit();
            this.labelControl28 = new DevExpress.XtraEditors.LabelControl();
            this.textEdit35 = new DevExpress.XtraEditors.TextEdit();
            this.textEdit36 = new DevExpress.XtraEditors.TextEdit();
            this.labelControl29 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl37 = new DevExpress.XtraEditors.LabelControl();
            this.textEdit37 = new DevExpress.XtraEditors.TextEdit();
            this.textEdit38 = new DevExpress.XtraEditors.TextEdit();
            this.labelControl50 = new DevExpress.XtraEditors.LabelControl();
            this.panelControl9 = new DevExpress.XtraEditors.PanelControl();
            this.labelControl51 = new DevExpress.XtraEditors.LabelControl();
            this.textEdit39 = new DevExpress.XtraEditors.TextEdit();
            this.textEdit40 = new DevExpress.XtraEditors.TextEdit();
            this.labelControl53 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl54 = new DevExpress.XtraEditors.LabelControl();
            this.textEdit41 = new DevExpress.XtraEditors.TextEdit();
            this.labelControl56 = new DevExpress.XtraEditors.LabelControl();
            this.textEdit42 = new DevExpress.XtraEditors.TextEdit();
            this.textEdit43 = new DevExpress.XtraEditors.TextEdit();
            this.labelControl62 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl64 = new DevExpress.XtraEditors.LabelControl();
            this.textEdit44 = new DevExpress.XtraEditors.TextEdit();
            this.textEdit45 = new DevExpress.XtraEditors.TextEdit();
            this.labelControl67 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl71 = new DevExpress.XtraEditors.LabelControl();
            this.panelControl10 = new DevExpress.XtraEditors.PanelControl();
            this.labelControl73 = new DevExpress.XtraEditors.LabelControl();
            this.textEdit46 = new DevExpress.XtraEditors.TextEdit();
            this.textEdit47 = new DevExpress.XtraEditors.TextEdit();
            this.labelControl76 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl80 = new DevExpress.XtraEditors.LabelControl();
            this.textEdit48 = new DevExpress.XtraEditors.TextEdit();
            this.textEdit49 = new DevExpress.XtraEditors.TextEdit();
            this.labelControl82 = new DevExpress.XtraEditors.LabelControl();
            this.panelControl11 = new DevExpress.XtraEditors.PanelControl();
            this.labelControl85 = new DevExpress.XtraEditors.LabelControl();
            this.textEdit50 = new DevExpress.XtraEditors.TextEdit();
            this.textEdit51 = new DevExpress.XtraEditors.TextEdit();
            this.labelControl87 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl111 = new DevExpress.XtraEditors.LabelControl();
            this.spellChecker1 = new DevExpress.XtraSpellChecker.SpellChecker();
            ((System.ComponentModel.ISupportInitialize)(this.imgCollection)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.imageCollection1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dxErrorProvider)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.textEdit30.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.textEdit32.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.textEdit31.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.imageCollection2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ribProjectOpportunity)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.textEdit78.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.textEdit77.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.textEdit76.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.textEdit68.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.textEdit67.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.textEdit69.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.textEdit70.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.textEdit75.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.textEdit74.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.textEdit73.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.textEdit72.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.textEdit71.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lookUpEdit3.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.textEdit66.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radioGroup1.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.panelControl4)).BeginInit();
            this.panelControl4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.textEdit4.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.textEdit5.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.textEdit6.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.textEdit7.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.memoEdit1.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.panelControl6)).BeginInit();
            this.panelControl6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dateEdit1.Properties.CalendarTimeProperties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dateEdit1.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lookUpEdit1.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lookUpEdit2.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lookUpEdit4.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lookUpEdit5.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.textEdit8.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.textEdit9.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dateEdit2.Properties.CalendarTimeProperties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dateEdit2.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.comboBoxEdit1.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lookUpEdit6.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dateEdit3.Properties.CalendarTimeProperties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dateEdit3.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dateEdit4.Properties.CalendarTimeProperties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dateEdit4.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.textEdit10.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.textEdit11.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.textEdit12.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.textEdit13.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.panelControl7)).BeginInit();
            this.panelControl7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dateEdit5.Properties.CalendarTimeProperties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dateEdit5.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dateEdit6.Properties.CalendarTimeProperties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dateEdit6.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.textEdit14.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.textEdit15.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.xtraTabControl1)).BeginInit();
            this.xtraTabControl1.SuspendLayout();
            this.xtraTabPage1.SuspendLayout();
            this.xtraTabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.panelControl5)).BeginInit();
            this.panelControl5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtBondPercent.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtWarrantyPercent.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtSubcontractAdministrationPercent.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtProfitPercent.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtOverheadPercent.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.panelControl3)).BeginInit();
            this.panelControl3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtFringeBenefitsPercent.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtSafetyMeetingPercent.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtProjectEngineerPercentOfLabor.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtProjectManagerPercentOfLabor.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtSuperintendentPercentOfLabor.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtGeneralForemanPercentOfLabor.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtForemanPercentOfLabor.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.panelControl2)).BeginInit();
            this.panelControl2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtCartigeHandlingPercent.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtSmallToolsPercent.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtStoragePercent.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtAsBuiltsEngineeringPercent.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.panelControl1)).BeginInit();
            this.panelControl1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtSalesTaxPercent.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtSundriesPercentOfMaterial.Properties)).BeginInit();
            this.xtraTabPage3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.panelControl12)).BeginInit();
            this.panelControl12.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtBIMRateDT.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtBIMRateOT.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtBIMRate.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtApprenticeLaborRateDT.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtProjectEngineerLaborRateDT.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtPremiumTimeLaborRateDT.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtSafetyMeetingsLaborRateDT.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtProjectManagerLaborRateDT.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtSuperintendentLaborRateDT.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtGeneralForemanLaborRateDT.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtForemanLaborRateDT.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtElectricianLaborRateDT.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtApprenticeLaborRateOT.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtProjectEngineerLaborRateOT.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtPremiumTimeLaborRateOT.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtSafetyMeetingsLaborRateOT.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtProjectManagerLaborRateOT.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtSuperintendentLaborRateOT.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtGeneralForemanLaborRateOT.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtForemanLaborRateOT.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtElectricianLaborRateOT.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtApprenticeLaborRate.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtProjectEngineerLaborRate.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtPremiumTimeLaborRate.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtSafetyMeetingsLaborRate.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtProjectManagerLaborRate.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtSuperintendentLaborRate.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtGeneralForemanLaborRate.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtForemanLaborRate.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtElectricianLaborRate.Properties)).BeginInit();
            this.pagContactDefaultValues.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.panelControl13)).BeginInit();
            this.panelControl13.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.cboForeman.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cboDefaultFrom.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cboChangeOrderDefaultContact.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cboRFIDefaultContact.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtChangeOrderDefaultContactCompany.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtRFIDefaultContactCompany.Properties)).BeginInit();
            this.pagMajorPONote.SuspendLayout();
            this.pagSmallPONote.SuspendLayout();
            this.pagSubmittalSpec.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.grdSubmittal)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridSubmittal)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repDescription)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repSection)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.panelControl8)).BeginInit();
            this.panelControl8.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.textEdit34.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.textEdit35.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.textEdit36.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.textEdit37.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.textEdit38.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.panelControl9)).BeginInit();
            this.panelControl9.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.textEdit39.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.textEdit40.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.textEdit41.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.textEdit42.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.textEdit43.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.textEdit44.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.textEdit45.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.panelControl10)).BeginInit();
            this.panelControl10.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.textEdit46.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.textEdit47.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.textEdit48.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.textEdit49.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.panelControl11)).BeginInit();
            this.panelControl11.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.textEdit50.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.textEdit51.Properties)).BeginInit();
            this.SuspendLayout();
            // 
            // imgCollection
            // 
            this.imgCollection.ImageStream = ((DevExpress.Utils.ImageCollectionStreamer)(resources.GetObject("imgCollection.ImageStream")));
            // 
            // btnToolInspectionsReport
            // 
            this.btnToolInspectionsReport.Id = 155;
            this.btnToolInspectionsReport.Name = "btnToolInspectionsReport";
            // 
            // btnToolRepairPartsReport
            // 
            this.btnToolRepairPartsReport.Id = 154;
            this.btnToolRepairPartsReport.Name = "btnToolRepairPartsReport";
            // 
            // btnToolComponentsReport
            // 
            this.btnToolComponentsReport.Id = 153;
            this.btnToolComponentsReport.Name = "btnToolComponentsReport";
            // 
            // btnToolAccessoriesReport
            // 
            this.btnToolAccessoriesReport.Id = 158;
            this.btnToolAccessoriesReport.Name = "btnToolAccessoriesReport";
            // 
            // btnProjectInfoSheetReport
            // 
            this.btnProjectInfoSheetReport.Id = 152;
            this.btnProjectInfoSheetReport.Name = "btnProjectInfoSheetReport";
            // 
            // btnToolEventScheduledReport
            // 
            this.btnToolEventScheduledReport.Id = 156;
            this.btnToolEventScheduledReport.Name = "btnToolEventScheduledReport";
            // 
            // btnAccessories
            // 
            this.btnAccessories.Id = 157;
            this.btnAccessories.Name = "btnAccessories";
            // 
            // btnComponents
            // 
            this.btnComponents.Id = 149;
            this.btnComponents.Name = "btnComponents";
            // 
            // btnRepairParts
            // 
            this.btnRepairParts.Id = 151;
            this.btnRepairParts.Name = "btnRepairParts";
            // 
            // btnInspections
            // 
            this.btnInspections.Id = 150;
            this.btnInspections.Name = "btnInspections";
            // 
            // btnGeneral
            // 
            this.btnGeneral.Id = 148;
            this.btnGeneral.Name = "btnGeneral";
            // 
            // ribbonAction
            // 
            this.ribbonAction.ImageIndex = 1;
            this.ribbonAction.ItemLinks.Add(this.btnSave);
            this.ribbonAction.ItemLinks.Add(this.btnUndo);
            this.ribbonAction.Name = "ribbonAction";
            this.ribbonAction.ShowCaptionButton = false;
            this.ribbonAction.Text = "Action";
            // 
            // btnSave
            // 
            this.btnSave.Caption = "&Save";
            this.btnSave.Description = "Save System Default Values";
            this.btnSave.Enabled = false;
            this.btnSave.Hint = "Save System Default Values";
            this.btnSave.Id = 3;
            this.btnSave.ImageIndex = 10;
            this.btnSave.LargeImageIndex = 7;
            this.btnSave.Name = "btnSave";
            this.btnSave.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithText;
            this.btnSave.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.allButtons_ItemClick);
            // 
            // btnUndo
            // 
            this.btnUndo.Caption = "&Undo";
            this.btnUndo.Description = "Undo System Default Values Changes";
            this.btnUndo.Hint = "Undo System Default Values Changes";
            this.btnUndo.Id = 8;
            this.btnUndo.ImageIndex = 11;
            this.btnUndo.Name = "btnUndo";
            this.btnUndo.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithText;
            this.btnUndo.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.allButtons_ItemClick);
            // 
            // ribbonPage1
            // 
            this.ribbonPage1.Groups.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPageGroup[] {
            this.ribbonAction});
            this.ribbonPage1.Name = "ribbonPage1";
            this.ribbonPage1.Text = "Default Values";
            // 
            // barSubItemReports
            // 
            this.barSubItemReports.Caption = "Reports";
            this.barSubItemReports.Id = 140;
            this.barSubItemReports.LargeImageIndex = 6;
            this.barSubItemReports.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.btnProjectInfoSheetReport),
            new DevExpress.XtraBars.LinkPersistInfo(this.btnToolAccessoriesReport),
            new DevExpress.XtraBars.LinkPersistInfo(this.btnToolComponentsReport),
            new DevExpress.XtraBars.LinkPersistInfo(this.btnToolRepairPartsReport),
            new DevExpress.XtraBars.LinkPersistInfo(this.btnToolInspectionsReport),
            new DevExpress.XtraBars.LinkPersistInfo(this.btnToolEventScheduledReport)});
            this.barSubItemReports.Name = "barSubItemReports";
            // 
            // imageCollection1
            // 
            this.imageCollection1.ImageSize = new System.Drawing.Size(32, 32);
            this.imageCollection1.ImageStream = ((DevExpress.Utils.ImageCollectionStreamer)(resources.GetObject("imageCollection1.ImageStream")));
            // 
            // barButtonGroup5
            // 
            this.barButtonGroup5.Caption = "barButtonGroup5";
            this.barButtonGroup5.Id = 137;
            this.barButtonGroup5.Name = "barButtonGroup5";
            // 
            // btnTimeCard
            // 
            this.btnTimeCard.Id = 124;
            this.btnTimeCard.Name = "btnTimeCard";
            // 
            // btnCostToComplete
            // 
            this.btnCostToComplete.Id = 123;
            this.btnCostToComplete.Name = "btnCostToComplete";
            // 
            // btnJobProgress
            // 
            this.btnJobProgress.Id = 122;
            this.btnJobProgress.Name = "btnJobProgress";
            // 
            // btnLaborProd
            // 
            this.btnLaborProd.Id = 121;
            this.btnLaborProd.Name = "btnLaborProd";
            // 
            // btnExcelQuantity
            // 
            this.btnExcelQuantity.Id = 120;
            this.btnExcelQuantity.Name = "btnExcelQuantity";
            // 
            // barButtonItem2
            // 
            this.barButtonItem2.Caption = "barButtonItem2";
            this.barButtonItem2.Id = 125;
            this.barButtonItem2.Name = "barButtonItem2";
            // 
            // barButtonGroup4
            // 
            this.barButtonGroup4.Caption = "barButtonGroup4";
            this.barButtonGroup4.Id = 127;
            this.barButtonGroup4.Name = "barButtonGroup4";
            // 
            // dxErrorProvider
            // 
            this.dxErrorProvider.ContainerControl = this;
            // 
            // textEdit30
            // 
            this.textEdit30.Location = new System.Drawing.Point(-192, 494);
            this.textEdit30.Name = "textEdit30";
            this.spellChecker1.SetShowSpellCheckMenu(this.textEdit30, true);
            this.textEdit30.Size = new System.Drawing.Size(64, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.textEdit30, optionsSpelling51);
            this.textEdit30.TabIndex = 236;
            // 
            // labelControl66
            // 
            this.labelControl66.Location = new System.Drawing.Point(-247, 332);
            this.labelControl66.Name = "labelControl66";
            this.labelControl66.Size = new System.Drawing.Size(49, 13);
            this.labelControl66.TabIndex = 216;
            this.labelControl66.Text = "Address1:";
            // 
            // labelControl65
            // 
            this.labelControl65.Location = new System.Drawing.Point(-221, 378);
            this.labelControl65.Name = "labelControl65";
            this.labelControl65.Size = new System.Drawing.Size(23, 13);
            this.labelControl65.TabIndex = 217;
            this.labelControl65.Text = "City:";
            // 
            // labelControl63
            // 
            this.labelControl63.Location = new System.Drawing.Point(-221, 404);
            this.labelControl63.Name = "labelControl63";
            this.labelControl63.Size = new System.Drawing.Size(23, 13);
            this.labelControl63.TabIndex = 219;
            this.labelControl63.Text = "Rep:";
            // 
            // labelControl61
            // 
            this.labelControl61.Location = new System.Drawing.Point(-250, 358);
            this.labelControl61.Name = "labelControl61";
            this.labelControl61.Size = new System.Drawing.Size(52, 13);
            this.labelControl61.TabIndex = 228;
            this.labelControl61.Text = "Address 2:";
            // 
            // labelControl49
            // 
            this.labelControl49.Location = new System.Drawing.Point(-262, 471);
            this.labelControl49.Name = "labelControl49";
            this.labelControl49.Size = new System.Drawing.Size(64, 13);
            this.labelControl49.TabIndex = 232;
            this.labelControl49.Text = "Alpha Codes:";
            // 
            // textEdit32
            // 
            this.textEdit32.Location = new System.Drawing.Point(-192, 446);
            this.textEdit32.Name = "textEdit32";
            this.spellChecker1.SetShowSpellCheckMenu(this.textEdit32, true);
            this.textEdit32.Size = new System.Drawing.Size(64, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.textEdit32, optionsSpelling52);
            this.textEdit32.TabIndex = 233;
            // 
            // textEdit31
            // 
            this.textEdit31.Location = new System.Drawing.Point(-192, 468);
            this.textEdit31.Name = "textEdit31";
            this.spellChecker1.SetShowSpellCheckMenu(this.textEdit31, true);
            this.textEdit31.Size = new System.Drawing.Size(64, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.textEdit31, optionsSpelling53);
            this.textEdit31.TabIndex = 234;
            // 
            // labelControl48
            // 
            this.labelControl48.Location = new System.Drawing.Point(-250, 501);
            this.labelControl48.Name = "labelControl48";
            this.labelControl48.Size = new System.Drawing.Size(32, 13);
            this.labelControl48.TabIndex = 235;
            this.labelControl48.Text = "Other:";
            // 
            // labelControl60
            // 
            this.labelControl60.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl60.Location = new System.Drawing.Point(-255, 427);
            this.labelControl60.Name = "labelControl60";
            this.labelControl60.Size = new System.Drawing.Size(68, 13);
            this.labelControl60.TabIndex = 230;
            this.labelControl60.Text = "Pricing Data";
            // 
            // labelControl59
            // 
            this.labelControl59.Location = new System.Drawing.Point(-250, 449);
            this.labelControl59.Name = "labelControl59";
            this.labelControl59.Size = new System.Drawing.Size(57, 13);
            this.labelControl59.TabIndex = 231;
            this.labelControl59.Text = "Labor Rate:";
            // 
            // btnExcelHours
            // 
            this.btnExcelHours.Id = 119;
            this.btnExcelHours.Name = "btnExcelHours";
            // 
            // btnLaborFeedbackReport
            // 
            this.btnLaborFeedbackReport.Caption = "&Labor Feedback";
            this.btnLaborFeedbackReport.Description = "Print Labor Feedback";
            this.btnLaborFeedbackReport.Hint = "Print Labor Feedback for Selected Report";
            this.btnLaborFeedbackReport.Id = 112;
            this.btnLaborFeedbackReport.ImageIndex = 9;
            this.btnLaborFeedbackReport.LargeImageIndex = 6;
            this.btnLaborFeedbackReport.Name = "btnLaborFeedbackReport";
            // 
            // btnLaborFeedback
            // 
            this.btnLaborFeedback.Caption = "Labor Feedback";
            this.btnLaborFeedback.Description = "Labor Feedback";
            this.btnLaborFeedback.Hint = "Labor Feedback Related Information";
            this.btnLaborFeedback.Id = 111;
            this.btnLaborFeedback.ImageIndex = 6;
            this.btnLaborFeedback.LargeImageIndex = 0;
            this.btnLaborFeedback.Name = "btnLaborFeedback";
            // 
            // iWeb
            // 
            this.iWeb.Caption = "&Developer Express on the Web";
            this.iWeb.Description = "Opens the web page.";
            this.iWeb.Hint = "Developer Express on the Web";
            this.iWeb.Id = 21;
            this.iWeb.ImageIndex = 24;
            this.iWeb.Name = "iWeb";
            // 
            // iProtected
            // 
            this.iProtected.ButtonStyle = DevExpress.XtraBars.BarButtonStyle.Check;
            this.iProtected.Caption = "P&rotected";
            this.iProtected.Description = "Protects the selected text.";
            this.iProtected.Hint = "Protects the selected text";
            this.iProtected.Id = 19;
            this.iProtected.Name = "iProtected";
            // 
            // iBullets
            // 
            this.iBullets.ButtonStyle = DevExpress.XtraBars.BarButtonStyle.Check;
            this.iBullets.Caption = "&Bullets";
            this.iBullets.Description = "Adds bullets to or removes bullets from selected paragraphs.";
            this.iBullets.Hint = "Bullets";
            this.iBullets.Id = 18;
            this.iBullets.ImageIndex = 0;
            this.iBullets.Name = "iBullets";
            // 
            // iFont
            // 
            this.iFont.ButtonStyle = DevExpress.XtraBars.BarButtonStyle.DropDown;
            this.iFont.Caption = "&Font...";
            this.iFont.Description = "Changes the font and character spacing formats of the selected text.";
            this.iFont.Hint = "Font Dialog";
            this.iFont.Id = 17;
            this.iFont.ImageIndex = 4;
            this.iFont.Name = "iFont";
            this.iFont.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithText;
            // 
            // btnGeneralOld
            // 
            this.btnGeneralOld.Caption = "General";
            this.btnGeneralOld.Description = "Account General Information";
            this.btnGeneralOld.Hint = "Account General Information";
            this.btnGeneralOld.Id = 14;
            this.btnGeneralOld.ImageIndex = 3;
            this.btnGeneralOld.LargeImageIndex = 4;
            this.btnGeneralOld.Name = "btnGeneralOld";
            // 
            // iAbout
            // 
            this.iAbout.Alignment = DevExpress.XtraBars.BarItemLinkAlignment.Right;
            this.iAbout.Caption = "&About";
            this.iAbout.Description = "Displays the description of this program.";
            this.iAbout.Hint = "Displays the About dialog";
            this.iAbout.Id = 22;
            this.iAbout.Name = "iAbout";
            // 
            // iBold
            // 
            this.iBold.ButtonStyle = DevExpress.XtraBars.BarButtonStyle.Check;
            this.iBold.Caption = "&Bold";
            this.iBold.Description = "Makes selected text and numbers bold. If the selection is already bold, clicking " +
    "button removes bold formatting.";
            this.iBold.Hint = "Bold";
            this.iBold.Id = 24;
            this.iBold.ImageIndex = 15;
            this.iBold.Name = "iBold";
            // 
            // iAlignRight
            // 
            this.iAlignRight.ButtonStyle = DevExpress.XtraBars.BarButtonStyle.Check;
            this.iAlignRight.Caption = "Align &Right";
            this.iAlignRight.Description = "Aligns the selected text to the right.";
            this.iAlignRight.GroupIndex = 1;
            this.iAlignRight.Hint = "Align Right";
            this.iAlignRight.Id = 29;
            this.iAlignRight.ImageIndex = 20;
            this.iAlignRight.Name = "iAlignRight";
            // 
            // iCenter
            // 
            this.iCenter.ButtonStyle = DevExpress.XtraBars.BarButtonStyle.Check;
            this.iCenter.Caption = "&Center";
            this.iCenter.Description = "Centers the selected text.";
            this.iCenter.GroupIndex = 1;
            this.iCenter.Hint = "Center";
            this.iCenter.Id = 28;
            this.iCenter.ImageIndex = 19;
            this.iCenter.Name = "iCenter";
            // 
            // iAlignLeft
            // 
            this.iAlignLeft.ButtonStyle = DevExpress.XtraBars.BarButtonStyle.Check;
            this.iAlignLeft.Caption = "Align &Left";
            this.iAlignLeft.Description = "Aligns the selected text to the left.";
            this.iAlignLeft.GroupIndex = 1;
            this.iAlignLeft.Hint = "Align Left";
            this.iAlignLeft.Id = 27;
            this.iAlignLeft.ImageIndex = 18;
            this.iAlignLeft.Name = "iAlignLeft";
            // 
            // iUnderline
            // 
            this.iUnderline.ButtonStyle = DevExpress.XtraBars.BarButtonStyle.Check;
            this.iUnderline.Caption = "&Underline";
            this.iUnderline.Description = "Underlines selected text and numbers. If the selection is already underlined, cli" +
    "cking button removes underlining.";
            this.iUnderline.Hint = "Underline";
            this.iUnderline.Id = 26;
            this.iUnderline.ImageIndex = 17;
            this.iUnderline.Name = "iUnderline";
            // 
            // iSelectAll
            // 
            this.iSelectAll.Caption = "Select A&ll";
            this.iSelectAll.Description = "Selects all text in the active document.";
            this.iSelectAll.Hint = "Selects all text in the active document.";
            this.iSelectAll.Id = 13;
            this.iSelectAll.Name = "iSelectAll";
            // 
            // btnTimeSheet
            // 
            this.btnTimeSheet.Caption = "&Time Sheet";
            this.btnTimeSheet.Description = "Print Time Sheet";
            this.btnTimeSheet.Hint = "Print Time Sheet";
            this.btnTimeSheet.Id = 12;
            this.btnTimeSheet.ImageIndex = 9;
            this.btnTimeSheet.LargeImageIndex = 6;
            this.btnTimeSheet.Name = "btnTimeSheet";
            this.btnTimeSheet.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large;
            // 
            // imageCollection2
            // 
            this.imageCollection2.ImageStream = ((DevExpress.Utils.ImageCollectionStreamer)(resources.GetObject("imageCollection2.ImageStream")));
            // 
            // ribProjectOpportunity
            // 
            this.ribProjectOpportunity.ApplicationIcon = ((System.Drawing.Bitmap)(resources.GetObject("ribProjectOpportunity.ApplicationIcon")));
            this.ribProjectOpportunity.Categories.AddRange(new DevExpress.XtraBars.BarManagerCategory[] {
            new DevExpress.XtraBars.BarManagerCategory("File", new System.Guid("4b511317-d784-42ba-b4ed-0d2a746d6c1f")),
            new DevExpress.XtraBars.BarManagerCategory("Edit", new System.Guid("7c2486e1-92ea-4293-ad55-b819f61ff7f1")),
            new DevExpress.XtraBars.BarManagerCategory("Format", new System.Guid("d3052f28-4b3e-4bae-b581-b3bb1c432258")),
            new DevExpress.XtraBars.BarManagerCategory("Help", new System.Guid("e07a4c24-66ac-4de6-bbcb-c0b6cfa7798b")),
            new DevExpress.XtraBars.BarManagerCategory("Status", new System.Guid("77795bb7-9bc5-4dd2-a297-cc758682e23d"))});
            this.ribProjectOpportunity.ExpandCollapseItem.Id = 0;
            this.ribProjectOpportunity.Images = this.imageCollection2;
            this.ribProjectOpportunity.Items.AddRange(new DevExpress.XtraBars.BarItem[] {
            this.ribProjectOpportunity.ExpandCollapseItem,
            this.btnSave,
            this.btnUndo,
            this.iSaveAs,
            this.btnCostCodesWeekly,
            this.btnCostCodes,
            this.btnstrategic,
            this.btnGeneral,
            this.btnTimeSheet,
            this.iSelectAll,
            this.btnGeneralOld,
            this.iFont,
            this.iBullets,
            this.iProtected,
            this.iWeb,
            this.iAbout,
            this.iBold,
            this.iUnderline,
            this.iAlignLeft,
            this.iCenter,
            this.iAlignRight,
            this.iFontColor,
            this.siPosition,
            this.siModified,
            this.siDocName,
            this.bgFontStyle,
            this.bgAlign,
            this.bgFont,
            this.bgBullets,
            this.sbiPaste,
            this.iPasteSpecial,
            this.iNew,
            this.iLargeUndo,
            this.iTemplate,
            this.rgbiSkins,
            this.beiFontSize,
            this.rgbiFont,
            this.bbiFontColorPopup,
            this.rgbiFontColor,
            this.btnPersonnel,
            this.iGeneral,
            this.btnNote,
            this.barButtonItem5,
            this.barButtonItem6,
            this.barButtonGroup1,
            this.barButtonGroup2,
            this.barButtonGroup3,
            this.barLinkContainerItem1,
            this.barMdiChildrenListItem1,
            this.barButtonItem1,
            this.btnLaborFeedback,
            this.btnLaborFeedbackReport,
            this.btnExcelHours,
            this.btnExcelQuantity,
            this.btnLaborProd,
            this.btnJobProgress,
            this.btnCostToComplete,
            this.btnTimeCard,
            this.barButtonItem2,
            this.barButtonGroup4,
            this.btnComponents,
            this.btnInspections,
            this.btnRepairParts,
            this.barButtonGroup5,
            this.barSubItemReports,
            this.btnProjectInfoSheetReport,
            this.btnToolComponentsReport,
            this.btnToolRepairPartsReport,
            this.btnToolInspectionsReport,
            this.btnToolEventScheduledReport,
            this.btnAccessories,
            this.btnToolAccessoriesReport});
            this.ribProjectOpportunity.LargeImages = this.imageCollection1;
            this.ribProjectOpportunity.Location = new System.Drawing.Point(0, 0);
            this.ribProjectOpportunity.MaxItemId = 159;
            this.ribProjectOpportunity.Name = "ribProjectOpportunity";
            this.ribProjectOpportunity.PageCategoryAlignment = DevExpress.XtraBars.Ribbon.RibbonPageCategoryAlignment.Right;
            this.ribProjectOpportunity.Pages.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPage[] {
            this.ribbonPage1});
            this.ribProjectOpportunity.ShowPageHeadersMode = DevExpress.XtraBars.Ribbon.ShowPageHeadersMode.Hide;
            this.ribProjectOpportunity.ShowToolbarCustomizeItem = false;
            this.ribProjectOpportunity.Size = new System.Drawing.Size(891, 147);
            this.ribProjectOpportunity.Toolbar.ShowCustomizeItem = false;
            this.ribProjectOpportunity.ToolbarLocation = DevExpress.XtraBars.Ribbon.RibbonQuickAccessToolbarLocation.Above;
            // 
            // iSaveAs
            // 
            this.iSaveAs.Caption = "Save &As...";
            this.iSaveAs.Description = "Saves the active document with a different file name.";
            this.iSaveAs.Hint = "Saves the active document with a different file name";
            this.iSaveAs.Id = 4;
            this.iSaveAs.ImageIndex = 21;
            this.iSaveAs.LargeImageIndex = 2;
            this.iSaveAs.Name = "iSaveAs";
            // 
            // btnCostCodesWeekly
            // 
            this.btnCostCodesWeekly.Caption = "Cost Codes Weekly";
            this.btnCostCodesWeekly.Description = "Cost Codes Weekly";
            this.btnCostCodesWeekly.Hint = "Cost Codes Weekly Related Information";
            this.btnCostCodesWeekly.Id = 6;
            this.btnCostCodesWeekly.ImageIndex = 26;
            this.btnCostCodesWeekly.LargeImageIndex = 0;
            this.btnCostCodesWeekly.Name = "btnCostCodesWeekly";
            // 
            // btnCostCodes
            // 
            this.btnCostCodes.Caption = "Cost Codes";
            this.btnCostCodes.Description = "Cost Codes";
            this.btnCostCodes.Hint = "Cost Codes Related Information";
            this.btnCostCodes.Id = 9;
            this.btnCostCodes.ImageIndex = 0;
            this.btnCostCodes.LargeImageIndex = 0;
            this.btnCostCodes.Name = "btnCostCodes";
            // 
            // btnstrategic
            // 
            this.btnstrategic.Caption = "Strategic";
            this.btnstrategic.Description = "Account Strategic";
            this.btnstrategic.Hint = "Account Strategic";
            this.btnstrategic.Id = 10;
            this.btnstrategic.ImageIndex = 1;
            this.btnstrategic.LargeImageIndex = 0;
            this.btnstrategic.Name = "btnstrategic";
            // 
            // iFontColor
            // 
            this.iFontColor.ButtonStyle = DevExpress.XtraBars.BarButtonStyle.DropDown;
            this.iFontColor.Caption = "Font C&olor";
            this.iFontColor.Description = "Formats the selected text with the color you click.";
            this.iFontColor.Hint = "Font Color";
            this.iFontColor.Id = 30;
            this.iFontColor.ImageIndex = 5;
            this.iFontColor.Name = "iFontColor";
            // 
            // siPosition
            // 
            this.siPosition.Id = 0;
            this.siPosition.Name = "siPosition";
            // 
            // siModified
            // 
            this.siModified.Id = 1;
            this.siModified.ImageIndex = 27;
            this.siModified.Name = "siModified";
            // 
            // siDocName
            // 
            this.siDocName.Id = 2;
            this.siDocName.Name = "siDocName";
            this.siDocName.TextAlignment = System.Drawing.StringAlignment.Near;
            // 
            // bgFontStyle
            // 
            this.bgFontStyle.Caption = "FontStyle";
            this.bgFontStyle.Id = 0;
            this.bgFontStyle.Name = "bgFontStyle";
            // 
            // bgAlign
            // 
            this.bgAlign.Caption = "Align";
            this.bgAlign.Id = 0;
            this.bgAlign.Name = "bgAlign";
            // 
            // bgFont
            // 
            this.bgFont.Caption = "Font";
            this.bgFont.Id = 0;
            this.bgFont.Name = "bgFont";
            // 
            // bgBullets
            // 
            this.bgBullets.Caption = "Bullets";
            this.bgBullets.Id = 1;
            this.bgBullets.Name = "bgBullets";
            // 
            // sbiPaste
            // 
            this.sbiPaste.Caption = "Contact";
            this.sbiPaste.Description = "Inserts the contents of the Clipboard at the insertion point";
            this.sbiPaste.Hint = "Inserts the contents of the Clipboard at the insertion point";
            this.sbiPaste.Id = 1;
            this.sbiPaste.ImageIndex = 8;
            this.sbiPaste.LargeImageIndex = 3;
            this.sbiPaste.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.btnGeneral),
            new DevExpress.XtraBars.LinkPersistInfo(this.iPasteSpecial)});
            this.sbiPaste.Name = "sbiPaste";
            // 
            // iPasteSpecial
            // 
            this.iPasteSpecial.Caption = "Paste &Special...";
            this.iPasteSpecial.Description = "Opens the Paste Special dialog";
            this.iPasteSpecial.Enabled = false;
            this.iPasteSpecial.Hint = "Opens the Paste Special dialog";
            this.iPasteSpecial.Id = 3;
            this.iPasteSpecial.ImageIndex = 8;
            this.iPasteSpecial.Name = "iPasteSpecial";
            // 
            // iNew
            // 
            this.iNew.Caption = "&New";
            this.iNew.Description = "Creates a new, blank file.";
            this.iNew.Hint = "Creates a new, blank file";
            this.iNew.Id = 0;
            this.iNew.ImageIndex = 6;
            this.iNew.LargeImageIndex = 0;
            this.iNew.Name = "iNew";
            // 
            // iLargeUndo
            // 
            this.iLargeUndo.Caption = "&Undo";
            this.iLargeUndo.Hint = "Undo";
            this.iLargeUndo.Id = 0;
            this.iLargeUndo.ImageIndex = 11;
            this.iLargeUndo.LargeImageIndex = 5;
            this.iLargeUndo.Name = "iLargeUndo";
            // 
            // iTemplate
            // 
            this.iTemplate.Caption = "Template...";
            this.iTemplate.Description = "Creates a new template";
            this.iTemplate.Enabled = false;
            this.iTemplate.Hint = "Creates a new template";
            this.iTemplate.Id = 1;
            this.iTemplate.ImageIndex = 6;
            this.iTemplate.Name = "iTemplate";
            // 
            // rgbiSkins
            // 
            this.rgbiSkins.Caption = "Skins";
            // 
            // 
            // 
            this.rgbiSkins.Gallery.AllowHoverImages = true;
            this.rgbiSkins.Gallery.Appearance.ItemCaptionAppearance.Normal.Options.UseFont = true;
            this.rgbiSkins.Gallery.Appearance.ItemCaptionAppearance.Normal.Options.UseTextOptions = true;
            this.rgbiSkins.Gallery.Appearance.ItemCaptionAppearance.Normal.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.rgbiSkins.Gallery.ColumnCount = 4;
            this.rgbiSkins.Gallery.FixedHoverImageSize = false;
            galleryItemGroup1.Caption = "Main Skins";
            galleryItemGroup2.Caption = "Office Skins";
            this.rgbiSkins.Gallery.Groups.AddRange(new DevExpress.XtraBars.Ribbon.GalleryItemGroup[] {
            galleryItemGroup1,
            galleryItemGroup2});
            this.rgbiSkins.Gallery.ImageSize = new System.Drawing.Size(32, 17);
            this.rgbiSkins.Gallery.ItemImageLocation = DevExpress.Utils.Locations.Top;
            this.rgbiSkins.Gallery.RowCount = 4;
            this.rgbiSkins.Id = 13;
            this.rgbiSkins.Name = "rgbiSkins";
            // 
            // beiFontSize
            // 
            this.beiFontSize.Caption = "Font Size";
            this.beiFontSize.Edit = null;
            this.beiFontSize.Hint = "Font Size";
            this.beiFontSize.Id = 27;
            this.beiFontSize.Name = "beiFontSize";
            // 
            // rgbiFont
            // 
            this.rgbiFont.Caption = "Font";
            // 
            // 
            // 
            this.rgbiFont.Gallery.AllowHoverImages = true;
            galleryItemGroup3.Caption = "Main";
            this.rgbiFont.Gallery.Groups.AddRange(new DevExpress.XtraBars.Ribbon.GalleryItemGroup[] {
            galleryItemGroup3});
            this.rgbiFont.Id = 29;
            this.rgbiFont.Name = "rgbiFont";
            // 
            // bbiFontColorPopup
            // 
            this.bbiFontColorPopup.ActAsDropDown = true;
            this.bbiFontColorPopup.ButtonStyle = DevExpress.XtraBars.BarButtonStyle.DropDown;
            this.bbiFontColorPopup.Caption = "Font Color";
            this.bbiFontColorPopup.Description = "Formats the selected text with the color you click";
            this.bbiFontColorPopup.Hint = "Formats the selected text with the color you click";
            this.bbiFontColorPopup.Id = 36;
            this.bbiFontColorPopup.Name = "bbiFontColorPopup";
            // 
            // rgbiFontColor
            // 
            this.rgbiFontColor.Caption = "Color";
            // 
            // 
            // 
            this.rgbiFontColor.Gallery.ColumnCount = 10;
            galleryItemGroup4.Caption = "Main";
            this.rgbiFontColor.Gallery.Groups.AddRange(new DevExpress.XtraBars.Ribbon.GalleryItemGroup[] {
            galleryItemGroup4});
            this.rgbiFontColor.Gallery.ImageSize = new System.Drawing.Size(10, 7);
            this.rgbiFontColor.Id = 37;
            this.rgbiFontColor.Name = "rgbiFontColor";
            // 
            // btnPersonnel
            // 
            this.btnPersonnel.Caption = "&Time Sheet";
            this.btnPersonnel.Description = "Print Time Sheet ";
            this.btnPersonnel.Hint = "Print Time Sheet for Selected Week";
            this.btnPersonnel.Id = 92;
            this.btnPersonnel.ImageIndex = 9;
            this.btnPersonnel.LargeImageIndex = 6;
            this.btnPersonnel.Name = "btnPersonnel";
            // 
            // iGeneral
            // 
            this.iGeneral.Caption = "General";
            this.iGeneral.Description = "Account General Information";
            this.iGeneral.Hint = "Account General Information";
            this.iGeneral.Id = 96;
            this.iGeneral.ImageIndex = 6;
            this.iGeneral.LargeImageIndex = 0;
            this.iGeneral.Name = "iGeneral";
            // 
            // btnNote
            // 
            this.btnNote.Caption = "Note";
            this.btnNote.Description = "Account Notes";
            this.btnNote.Hint = "Account Notes";
            this.btnNote.Id = 98;
            this.btnNote.LargeImageIndex = 0;
            this.btnNote.Name = "btnNote";
            // 
            // barButtonItem5
            // 
            this.barButtonItem5.Caption = "barButtonItem1";
            this.barButtonItem5.Id = 100;
            this.barButtonItem5.Name = "barButtonItem5";
            // 
            // barButtonItem6
            // 
            this.barButtonItem6.Caption = "barButtonItem3";
            this.barButtonItem6.Id = 101;
            this.barButtonItem6.Name = "barButtonItem6";
            // 
            // barButtonGroup1
            // 
            this.barButtonGroup1.Caption = "barButtonGroup1";
            this.barButtonGroup1.Id = 102;
            this.barButtonGroup1.Name = "barButtonGroup1";
            // 
            // barButtonGroup2
            // 
            this.barButtonGroup2.Caption = "barButtonGroup2";
            this.barButtonGroup2.Id = 105;
            this.barButtonGroup2.Name = "barButtonGroup2";
            // 
            // barButtonGroup3
            // 
            this.barButtonGroup3.Caption = "barButtonGroup3";
            this.barButtonGroup3.Id = 106;
            this.barButtonGroup3.Name = "barButtonGroup3";
            // 
            // barLinkContainerItem1
            // 
            this.barLinkContainerItem1.Caption = "barLinkContainerItem1";
            this.barLinkContainerItem1.Id = 108;
            this.barLinkContainerItem1.Name = "barLinkContainerItem1";
            // 
            // barMdiChildrenListItem1
            // 
            this.barMdiChildrenListItem1.Caption = "barMdiChildrenListItem1";
            this.barMdiChildrenListItem1.Id = 109;
            this.barMdiChildrenListItem1.Name = "barMdiChildrenListItem1";
            // 
            // barButtonItem1
            // 
            this.barButtonItem1.Caption = "barButtonItem1";
            this.barButtonItem1.Id = 110;
            this.barButtonItem1.Name = "barButtonItem1";
            // 
            // labelControl68
            // 
            this.labelControl68.Location = new System.Drawing.Point(-229, 306);
            this.labelControl68.Name = "labelControl68";
            this.labelControl68.Size = new System.Drawing.Size(31, 13);
            this.labelControl68.TabIndex = 214;
            this.labelControl68.Text = "Name:";
            // 
            // labelControl99
            // 
            this.labelControl99.Location = new System.Drawing.Point(-221, -103);
            this.labelControl99.Name = "labelControl99";
            this.labelControl99.Size = new System.Drawing.Size(23, 13);
            this.labelControl99.TabIndex = 152;
            this.labelControl99.Text = "City:";
            // 
            // labelControl98
            // 
            this.labelControl98.Location = new System.Drawing.Point(189, -103);
            this.labelControl98.Name = "labelControl98";
            this.labelControl98.Size = new System.Drawing.Size(18, 13);
            this.labelControl98.TabIndex = 153;
            this.labelControl98.Text = "Zip:";
            // 
            // labelControl100
            // 
            this.labelControl100.Location = new System.Drawing.Point(-247, -149);
            this.labelControl100.Name = "labelControl100";
            this.labelControl100.Size = new System.Drawing.Size(49, 13);
            this.labelControl100.TabIndex = 151;
            this.labelControl100.Text = "Address1:";
            // 
            // labelControl97
            // 
            this.labelControl97.Location = new System.Drawing.Point(-255, -77);
            this.labelControl97.Name = "labelControl97";
            this.labelControl97.Size = new System.Drawing.Size(57, 13);
            this.labelControl97.TabIndex = 154;
            this.labelControl97.Text = "Description:";
            // 
            // labelControl101
            // 
            this.labelControl101.Location = new System.Drawing.Point(89, -103);
            this.labelControl101.Name = "labelControl101";
            this.labelControl101.Size = new System.Drawing.Size(30, 13);
            this.labelControl101.TabIndex = 150;
            this.labelControl101.Text = "State:";
            // 
            // labelControl102
            // 
            this.labelControl102.Location = new System.Drawing.Point(-229, -175);
            this.labelControl102.Name = "labelControl102";
            this.labelControl102.Size = new System.Drawing.Size(31, 13);
            this.labelControl102.TabIndex = 149;
            this.labelControl102.Text = "Name:";
            // 
            // labelControl104
            // 
            this.labelControl104.Location = new System.Drawing.Point(61, -179);
            this.labelControl104.Name = "labelControl104";
            this.labelControl104.Size = new System.Drawing.Size(56, 13);
            this.labelControl104.TabIndex = 147;
            this.labelControl104.Text = "Estimate #:";
            // 
            // labelControl96
            // 
            this.labelControl96.Location = new System.Drawing.Point(85, -153);
            this.labelControl96.Name = "labelControl96";
            this.labelControl96.Size = new System.Drawing.Size(34, 13);
            this.labelControl96.TabIndex = 155;
            this.labelControl96.Text = "Phone:";
            // 
            // labelControl103
            // 
            this.labelControl103.Location = new System.Drawing.Point(189, -231);
            this.labelControl103.Name = "labelControl103";
            this.labelControl103.Size = new System.Drawing.Size(32, 13);
            this.labelControl103.TabIndex = 148;
            this.labelControl103.Text = "Job #:";
            // 
            // textEdit78
            // 
            this.textEdit78.Location = new System.Drawing.Point(123, -182);
            this.textEdit78.Name = "textEdit78";
            this.spellChecker1.SetShowSpellCheckMenu(this.textEdit78, true);
            this.textEdit78.Size = new System.Drawing.Size(84, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.textEdit78, optionsSpelling54);
            this.textEdit78.TabIndex = 156;
            // 
            // textEdit77
            // 
            this.textEdit77.Location = new System.Drawing.Point(227, -234);
            this.textEdit77.Name = "textEdit77";
            this.spellChecker1.SetShowSpellCheckMenu(this.textEdit77, true);
            this.textEdit77.Size = new System.Drawing.Size(84, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.textEdit77, optionsSpelling55);
            this.textEdit77.TabIndex = 157;
            // 
            // textEdit76
            // 
            this.textEdit76.Location = new System.Drawing.Point(-192, -178);
            this.textEdit76.Name = "textEdit76";
            this.spellChecker1.SetShowSpellCheckMenu(this.textEdit76, true);
            this.textEdit76.Size = new System.Drawing.Size(221, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.textEdit76, optionsSpelling56);
            this.textEdit76.TabIndex = 158;
            // 
            // labelControl78
            // 
            this.labelControl78.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl78.Location = new System.Drawing.Point(-255, 137);
            this.labelControl78.Name = "labelControl78";
            this.labelControl78.Size = new System.Drawing.Size(108, 13);
            this.labelControl78.TabIndex = 196;
            this.labelControl78.Text = "General Contractor";
            // 
            // labelControl77
            // 
            this.labelControl77.Location = new System.Drawing.Point(-229, 159);
            this.labelControl77.Name = "labelControl77";
            this.labelControl77.Size = new System.Drawing.Size(31, 13);
            this.labelControl77.TabIndex = 197;
            this.labelControl77.Text = "Name:";
            // 
            // labelControl75
            // 
            this.labelControl75.Location = new System.Drawing.Point(-247, 185);
            this.labelControl75.Name = "labelControl75";
            this.labelControl75.Size = new System.Drawing.Size(49, 13);
            this.labelControl75.TabIndex = 199;
            this.labelControl75.Text = "Address1:";
            // 
            // labelControl79
            // 
            this.labelControl79.Location = new System.Drawing.Point(-250, 68);
            this.labelControl79.Name = "labelControl79";
            this.labelControl79.Size = new System.Drawing.Size(52, 13);
            this.labelControl79.TabIndex = 194;
            this.labelControl79.Text = "Address 2:";
            // 
            // labelControl74
            // 
            this.labelControl74.Location = new System.Drawing.Point(-221, 231);
            this.labelControl74.Name = "labelControl74";
            this.labelControl74.Size = new System.Drawing.Size(23, 13);
            this.labelControl74.TabIndex = 200;
            this.labelControl74.Text = "City:";
            // 
            // labelControl70
            // 
            this.labelControl70.Location = new System.Drawing.Point(-250, 211);
            this.labelControl70.Name = "labelControl70";
            this.labelControl70.Size = new System.Drawing.Size(52, 13);
            this.labelControl70.TabIndex = 211;
            this.labelControl70.Text = "Address 2:";
            // 
            // labelControl69
            // 
            this.labelControl69.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl69.Location = new System.Drawing.Point(-255, 284);
            this.labelControl69.Name = "labelControl69";
            this.labelControl69.Size = new System.Drawing.Size(66, 13);
            this.labelControl69.TabIndex = 213;
            this.labelControl69.Text = "Owner Data";
            // 
            // labelControl72
            // 
            this.labelControl72.Location = new System.Drawing.Point(-221, 257);
            this.labelControl72.Name = "labelControl72";
            this.labelControl72.Size = new System.Drawing.Size(23, 13);
            this.labelControl72.TabIndex = 202;
            this.labelControl72.Text = "Rep:";
            // 
            // labelControl95
            // 
            this.labelControl95.Location = new System.Drawing.Point(402, -231);
            this.labelControl95.Name = "labelControl95";
            this.labelControl95.Size = new System.Drawing.Size(49, 13);
            this.labelControl95.TabIndex = 166;
            this.labelControl95.Text = "Record #:";
            // 
            // labelControl94
            // 
            this.labelControl94.Location = new System.Drawing.Point(-268, -231);
            this.labelControl94.Name = "labelControl94";
            this.labelControl94.Size = new System.Drawing.Size(70, 13);
            this.labelControl94.TabIndex = 167;
            this.labelControl94.Text = "Completed by:";
            // 
            // textEdit68
            // 
            this.textEdit68.Location = new System.Drawing.Point(-192, -234);
            this.textEdit68.Name = "textEdit68";
            this.spellChecker1.SetShowSpellCheckMenu(this.textEdit68, true);
            this.textEdit68.Size = new System.Drawing.Size(173, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.textEdit68, optionsSpelling57);
            this.textEdit68.TabIndex = 168;
            // 
            // labelControl93
            // 
            this.labelControl93.Location = new System.Drawing.Point(56, -231);
            this.labelControl93.Name = "labelControl93";
            this.labelControl93.Size = new System.Drawing.Size(27, 13);
            this.labelControl93.TabIndex = 169;
            this.labelControl93.Text = "Date:";
            // 
            // textEdit67
            // 
            this.textEdit67.Location = new System.Drawing.Point(89, -234);
            this.textEdit67.Name = "textEdit67";
            this.spellChecker1.SetShowSpellCheckMenu(this.textEdit67, true);
            this.textEdit67.Size = new System.Drawing.Size(72, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.textEdit67, optionsSpelling58);
            this.textEdit67.TabIndex = 170;
            // 
            // textEdit69
            // 
            this.textEdit69.Location = new System.Drawing.Point(485, -234);
            this.textEdit69.Name = "textEdit69";
            this.spellChecker1.SetShowSpellCheckMenu(this.textEdit69, true);
            this.textEdit69.Size = new System.Drawing.Size(84, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.textEdit69, optionsSpelling59);
            this.textEdit69.TabIndex = 165;
            // 
            // textEdit70
            // 
            this.textEdit70.Location = new System.Drawing.Point(213, -106);
            this.textEdit70.Name = "textEdit70";
            this.spellChecker1.SetShowSpellCheckMenu(this.textEdit70, true);
            this.textEdit70.Size = new System.Drawing.Size(89, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.textEdit70, optionsSpelling60);
            this.textEdit70.TabIndex = 164;
            // 
            // textEdit75
            // 
            this.textEdit75.Location = new System.Drawing.Point(-192, -80);
            this.textEdit75.Name = "textEdit75";
            this.spellChecker1.SetShowSpellCheckMenu(this.textEdit75, true);
            this.textEdit75.Size = new System.Drawing.Size(494, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.textEdit75, optionsSpelling61);
            this.textEdit75.TabIndex = 159;
            // 
            // textEdit74
            // 
            this.textEdit74.Location = new System.Drawing.Point(-192, -156);
            this.textEdit74.Name = "textEdit74";
            this.spellChecker1.SetShowSpellCheckMenu(this.textEdit74, true);
            this.textEdit74.Size = new System.Drawing.Size(221, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.textEdit74, optionsSpelling62);
            this.textEdit74.TabIndex = 160;
            // 
            // textEdit73
            // 
            this.textEdit73.Location = new System.Drawing.Point(-192, -106);
            this.textEdit73.Name = "textEdit73";
            this.spellChecker1.SetShowSpellCheckMenu(this.textEdit73, true);
            this.textEdit73.Size = new System.Drawing.Size(221, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.textEdit73, optionsSpelling63);
            this.textEdit73.TabIndex = 161;
            // 
            // textEdit72
            // 
            this.textEdit72.Location = new System.Drawing.Point(123, -156);
            this.textEdit72.Name = "textEdit72";
            this.spellChecker1.SetShowSpellCheckMenu(this.textEdit72, true);
            this.textEdit72.Size = new System.Drawing.Size(84, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.textEdit72, optionsSpelling64);
            this.textEdit72.TabIndex = 162;
            // 
            // textEdit71
            // 
            this.textEdit71.Location = new System.Drawing.Point(123, -106);
            this.textEdit71.Name = "textEdit71";
            this.spellChecker1.SetShowSpellCheckMenu(this.textEdit71, true);
            this.textEdit71.Size = new System.Drawing.Size(51, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.textEdit71, optionsSpelling65);
            this.textEdit71.TabIndex = 163;
            // 
            // labelControl92
            // 
            this.labelControl92.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl92.Location = new System.Drawing.Point(-254, -199);
            this.labelControl92.Name = "labelControl92";
            this.labelControl92.Size = new System.Drawing.Size(113, 13);
            this.labelControl92.TabIndex = 171;
            this.labelControl92.Text = "Job Date && Location";
            // 
            // labelControl91
            // 
            this.labelControl91.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl91.Location = new System.Drawing.Point(-254, -54);
            this.labelControl91.Name = "labelControl91";
            this.labelControl91.Size = new System.Drawing.Size(68, 13);
            this.labelControl91.TabIndex = 172;
            this.labelControl91.Text = "Owner Class";
            // 
            // labelControl84
            // 
            this.labelControl84.Location = new System.Drawing.Point(-247, 42);
            this.labelControl84.Name = "labelControl84";
            this.labelControl84.Size = new System.Drawing.Size(49, 13);
            this.labelControl84.TabIndex = 181;
            this.labelControl84.Text = "Address1:";
            // 
            // labelControl83
            // 
            this.labelControl83.Location = new System.Drawing.Point(-221, 88);
            this.labelControl83.Name = "labelControl83";
            this.labelControl83.Size = new System.Drawing.Size(23, 13);
            this.labelControl83.TabIndex = 182;
            this.labelControl83.Text = "City:";
            // 
            // labelControl81
            // 
            this.labelControl81.Location = new System.Drawing.Point(-221, 114);
            this.labelControl81.Name = "labelControl81";
            this.labelControl81.Size = new System.Drawing.Size(23, 13);
            this.labelControl81.TabIndex = 184;
            this.labelControl81.Text = "Rep:";
            // 
            // labelControl86
            // 
            this.labelControl86.Location = new System.Drawing.Point(-229, 16);
            this.labelControl86.Name = "labelControl86";
            this.labelControl86.Size = new System.Drawing.Size(31, 13);
            this.labelControl86.TabIndex = 179;
            this.labelControl86.Text = "Name:";
            // 
            // lookUpEdit3
            // 
            this.lookUpEdit3.Location = new System.Drawing.Point(-192, -32);
            this.lookUpEdit3.Name = "lookUpEdit3";
            this.lookUpEdit3.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.lookUpEdit3.Size = new System.Drawing.Size(144, 20);
            this.lookUpEdit3.TabIndex = 173;
            // 
            // labelControl90
            // 
            this.labelControl90.Location = new System.Drawing.Point(-262, -29);
            this.labelControl90.Name = "labelControl90";
            this.labelControl90.Size = new System.Drawing.Size(64, 13);
            this.labelControl90.TabIndex = 174;
            this.labelControl90.Text = "Class Owner:";
            // 
            // labelControl89
            // 
            this.labelControl89.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl89.Location = new System.Drawing.Point(-255, -6);
            this.labelControl89.Name = "labelControl89";
            this.labelControl89.Size = new System.Drawing.Size(170, 13);
            this.labelControl89.TabIndex = 175;
            this.labelControl89.Text = "Customer Data Billing Address";
            // 
            // labelControl88
            // 
            this.labelControl88.Location = new System.Drawing.Point(-250, -123);
            this.labelControl88.Name = "labelControl88";
            this.labelControl88.Size = new System.Drawing.Size(52, 13);
            this.labelControl88.TabIndex = 176;
            this.labelControl88.Text = "Address 2:";
            // 
            // textEdit66
            // 
            this.textEdit66.Location = new System.Drawing.Point(-192, -130);
            this.textEdit66.Name = "textEdit66";
            this.spellChecker1.SetShowSpellCheckMenu(this.textEdit66, true);
            this.textEdit66.Size = new System.Drawing.Size(221, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.textEdit66, optionsSpelling66);
            this.textEdit66.TabIndex = 177;
            // 
            // labelControl30
            // 
            this.labelControl30.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))));
            this.labelControl30.Location = new System.Drawing.Point(6, 274);
            this.labelControl30.Name = "labelControl30";
            this.labelControl30.Size = new System.Drawing.Size(52, 13);
            this.labelControl30.TabIndex = 556;
            this.labelControl30.Text = "Purchase";
            // 
            // radioGroup1
            // 
            this.radioGroup1.Location = new System.Drawing.Point(9, 86);
            this.radioGroup1.Name = "radioGroup1";
            this.radioGroup1.Properties.Appearance.BackColor = System.Drawing.Color.Transparent;
            this.radioGroup1.Properties.Appearance.Options.UseBackColor = true;
            this.radioGroup1.Properties.Items.AddRange(new DevExpress.XtraEditors.Controls.RadioGroupItem[] {
            new DevExpress.XtraEditors.Controls.RadioGroupItem(0, "By Day"),
            new DevExpress.XtraEditors.Controls.RadioGroupItem(1, "By Meter"),
            new DevExpress.XtraEditors.Controls.RadioGroupItem(2, "Whichever Occurs First")});
            this.radioGroup1.Size = new System.Drawing.Size(173, 65);
            this.radioGroup1.TabIndex = 0;
            // 
            // labelControl31
            // 
            this.labelControl31.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))));
            this.labelControl31.Location = new System.Drawing.Point(9, 63);
            this.labelControl31.Name = "labelControl31";
            this.labelControl31.Size = new System.Drawing.Size(82, 13);
            this.labelControl31.TabIndex = 577;
            this.labelControl31.Text = "Schedule Type";
            // 
            // panelControl4
            // 
            this.panelControl4.Controls.Add(this.textEdit4);
            this.panelControl4.Controls.Add(this.labelControl32);
            this.panelControl4.Controls.Add(this.textEdit5);
            this.panelControl4.Controls.Add(this.textEdit6);
            this.panelControl4.Controls.Add(this.labelControl33);
            this.panelControl4.Controls.Add(this.labelControl34);
            this.panelControl4.Location = new System.Drawing.Point(9, 20);
            this.panelControl4.Name = "panelControl4";
            this.panelControl4.Size = new System.Drawing.Size(564, 37);
            this.panelControl4.TabIndex = 576;
            // 
            // textEdit4
            // 
            this.textEdit4.Location = new System.Drawing.Point(491, 8);
            this.textEdit4.Name = "textEdit4";
            this.textEdit4.Properties.DisplayFormat.FormatString = "n2";
            this.textEdit4.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.textEdit4.Properties.EditFormat.FormatString = "n2";
            this.textEdit4.Properties.EditFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.textEdit4.Properties.Mask.EditMask = "n2";
            this.textEdit4.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.textEdit4.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.textEdit4.Properties.MaxLength = 20;
            this.textEdit4.Properties.ReadOnly = true;
            this.spellChecker1.SetShowSpellCheckMenu(this.textEdit4, true);
            this.textEdit4.Size = new System.Drawing.Size(59, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.textEdit4, optionsSpelling67);
            this.textEdit4.TabIndex = 576;
            // 
            // labelControl32
            // 
            this.labelControl32.Location = new System.Drawing.Point(423, 12);
            this.labelControl32.Name = "labelControl32";
            this.labelControl32.Size = new System.Drawing.Size(62, 13);
            this.labelControl32.TabIndex = 575;
            this.labelControl32.Text = "Crrent Meter";
            // 
            // textEdit5
            // 
            this.textEdit5.Location = new System.Drawing.Point(209, 9);
            this.textEdit5.Name = "textEdit5";
            this.textEdit5.Properties.DisplayFormat.FormatString = "c2";
            this.textEdit5.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.textEdit5.Properties.EditFormat.FormatString = "c2";
            this.textEdit5.Properties.EditFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.textEdit5.Properties.Mask.EditMask = "c2";
            this.textEdit5.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.textEdit5.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.textEdit5.Properties.MaxLength = 20;
            this.textEdit5.Properties.ReadOnly = true;
            this.spellChecker1.SetShowSpellCheckMenu(this.textEdit5, true);
            this.textEdit5.Size = new System.Drawing.Size(208, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.textEdit5, optionsSpelling68);
            this.textEdit5.TabIndex = 574;
            // 
            // textEdit6
            // 
            this.textEdit6.Location = new System.Drawing.Point(55, 8);
            this.textEdit6.Name = "textEdit6";
            this.textEdit6.Properties.MaxLength = 15;
            this.textEdit6.Properties.ReadOnly = true;
            this.spellChecker1.SetShowSpellCheckMenu(this.textEdit6, true);
            this.textEdit6.Size = new System.Drawing.Size(82, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.textEdit6, optionsSpelling69);
            this.textEdit6.TabIndex = 573;
            // 
            // labelControl33
            // 
            this.labelControl33.Location = new System.Drawing.Point(143, 12);
            this.labelControl33.Name = "labelControl33";
            this.labelControl33.Size = new System.Drawing.Size(57, 13);
            this.labelControl33.TabIndex = 568;
            this.labelControl33.Text = "Description:";
            // 
            // labelControl34
            // 
            this.labelControl34.Location = new System.Drawing.Point(5, 11);
            this.labelControl34.Name = "labelControl34";
            this.labelControl34.Size = new System.Drawing.Size(44, 13);
            this.labelControl34.TabIndex = 24;
            this.labelControl34.Text = "Tool No.:";
            // 
            // labelControl35
            // 
            this.labelControl35.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))));
            this.labelControl35.Location = new System.Drawing.Point(9, 3);
            this.labelControl35.Name = "labelControl35";
            this.labelControl35.Size = new System.Drawing.Size(53, 13);
            this.labelControl35.TabIndex = 575;
            this.labelControl35.Text = "Tool Info.";
            // 
            // textEdit7
            // 
            this.textEdit7.Location = new System.Drawing.Point(349, 296);
            this.textEdit7.Name = "textEdit7";
            this.textEdit7.Properties.MaxLength = 50;
            this.spellChecker1.SetShowSpellCheckMenu(this.textEdit7, true);
            this.textEdit7.Size = new System.Drawing.Size(0, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.textEdit7, optionsSpelling70);
            this.textEdit7.TabIndex = 564;
            // 
            // memoEdit1
            // 
            this.memoEdit1.Location = new System.Drawing.Point(8, 428);
            this.memoEdit1.Name = "memoEdit1";
            this.spellChecker1.SetShowSpellCheckMenu(this.memoEdit1, true);
            this.memoEdit1.Size = new System.Drawing.Size(682, 59);
            this.spellChecker1.SetSpellCheckerOptions(this.memoEdit1, optionsSpelling71);
            this.memoEdit1.TabIndex = 563;
            // 
            // labelControl36
            // 
            this.labelControl36.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))));
            this.labelControl36.Location = new System.Drawing.Point(6, 409);
            this.labelControl36.Name = "labelControl36";
            this.labelControl36.Size = new System.Drawing.Size(35, 13);
            this.labelControl36.TabIndex = 562;
            this.labelControl36.Text = "Notes:";
            // 
            // panelControl6
            // 
            this.panelControl6.Controls.Add(this.dateEdit1);
            this.panelControl6.Controls.Add(this.lookUpEdit1);
            this.panelControl6.Controls.Add(this.labelControl38);
            this.panelControl6.Controls.Add(this.lookUpEdit2);
            this.panelControl6.Controls.Add(this.lookUpEdit4);
            this.panelControl6.Controls.Add(this.lookUpEdit5);
            this.panelControl6.Controls.Add(this.textEdit8);
            this.panelControl6.Controls.Add(this.textEdit9);
            this.panelControl6.Controls.Add(this.dateEdit2);
            this.panelControl6.Controls.Add(this.comboBoxEdit1);
            this.panelControl6.Controls.Add(this.labelControl39);
            this.panelControl6.Controls.Add(this.labelControl40);
            this.panelControl6.Controls.Add(this.labelControl41);
            this.panelControl6.Controls.Add(this.labelControl42);
            this.panelControl6.Controls.Add(this.labelControl43);
            this.panelControl6.Controls.Add(this.lookUpEdit6);
            this.panelControl6.Controls.Add(this.dateEdit3);
            this.panelControl6.Controls.Add(this.labelControl44);
            this.panelControl6.Controls.Add(this.dateEdit4);
            this.panelControl6.Controls.Add(this.textEdit10);
            this.panelControl6.Controls.Add(this.textEdit11);
            this.panelControl6.Controls.Add(this.labelControl45);
            this.panelControl6.Controls.Add(this.textEdit12);
            this.panelControl6.Controls.Add(this.textEdit13);
            this.panelControl6.Controls.Add(this.labelControl46);
            this.panelControl6.Controls.Add(this.labelControl47);
            this.panelControl6.Controls.Add(this.labelControl52);
            this.panelControl6.Controls.Add(this.labelControl55);
            this.panelControl6.Controls.Add(this.labelControl57);
            this.panelControl6.Controls.Add(this.labelControl58);
            this.panelControl6.Controls.Add(this.labelControl105);
            this.panelControl6.Location = new System.Drawing.Point(258, 294);
            this.panelControl6.Name = "panelControl6";
            this.panelControl6.Size = new System.Drawing.Size(432, 113);
            this.panelControl6.TabIndex = 561;
            // 
            // dateEdit1
            // 
            this.dateEdit1.EditValue = null;
            this.dateEdit1.Location = new System.Drawing.Point(285, 25);
            this.dateEdit1.Name = "dateEdit1";
            this.dateEdit1.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.dateEdit1.Properties.CalendarTimeProperties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton()});
            this.dateEdit1.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.dateEdit1.Size = new System.Drawing.Size(142, 20);
            this.dateEdit1.TabIndex = 595;
            // 
            // lookUpEdit1
            // 
            this.lookUpEdit1.Location = new System.Drawing.Point(89, 45);
            this.lookUpEdit1.Name = "lookUpEdit1";
            this.lookUpEdit1.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.lookUpEdit1.Properties.NullText = "";
            this.lookUpEdit1.Properties.TextEditStyle = DevExpress.XtraEditors.Controls.TextEditStyles.Standard;
            this.lookUpEdit1.Size = new System.Drawing.Size(123, 20);
            this.lookUpEdit1.TabIndex = 594;
            // 
            // labelControl38
            // 
            this.labelControl38.Location = new System.Drawing.Point(109, 10);
            this.labelControl38.Name = "labelControl38";
            this.labelControl38.Size = new System.Drawing.Size(33, 13);
            this.labelControl38.TabIndex = 574;
            this.labelControl38.Text = "Office:";
            // 
            // lookUpEdit2
            // 
            this.lookUpEdit2.Location = new System.Drawing.Point(285, 6);
            this.lookUpEdit2.Name = "lookUpEdit2";
            this.lookUpEdit2.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.lookUpEdit2.Properties.NullText = "";
            this.lookUpEdit2.Properties.TextEditStyle = DevExpress.XtraEditors.Controls.TextEditStyles.Standard;
            this.lookUpEdit2.Size = new System.Drawing.Size(142, 20);
            this.lookUpEdit2.TabIndex = 593;
            // 
            // lookUpEdit4
            // 
            this.lookUpEdit4.Location = new System.Drawing.Point(189, 7);
            this.lookUpEdit4.Name = "lookUpEdit4";
            this.lookUpEdit4.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.lookUpEdit4.Properties.NullText = "";
            this.lookUpEdit4.Properties.TextEditStyle = DevExpress.XtraEditors.Controls.TextEditStyles.Standard;
            this.lookUpEdit4.Size = new System.Drawing.Size(160, 20);
            this.lookUpEdit4.TabIndex = 573;
            // 
            // lookUpEdit5
            // 
            this.lookUpEdit5.Location = new System.Drawing.Point(188, 67);
            this.lookUpEdit5.Name = "lookUpEdit5";
            this.lookUpEdit5.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.lookUpEdit5.Properties.NullText = "";
            this.lookUpEdit5.Properties.TextEditStyle = DevExpress.XtraEditors.Controls.TextEditStyles.Standard;
            this.lookUpEdit5.Size = new System.Drawing.Size(162, 20);
            this.lookUpEdit5.TabIndex = 565;
            // 
            // textEdit8
            // 
            this.textEdit8.Location = new System.Drawing.Point(285, 67);
            this.textEdit8.Name = "textEdit8";
            this.textEdit8.Properties.MaxLength = 12;
            this.spellChecker1.SetShowSpellCheckMenu(this.textEdit8, true);
            this.textEdit8.Size = new System.Drawing.Size(142, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.textEdit8, optionsSpelling72);
            this.textEdit8.TabIndex = 592;
            // 
            // textEdit9
            // 
            this.textEdit9.Location = new System.Drawing.Point(285, 47);
            this.textEdit9.Name = "textEdit9";
            this.textEdit9.Properties.DisplayFormat.FormatString = "n2";
            this.textEdit9.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.textEdit9.Properties.EditFormat.FormatString = "n2";
            this.textEdit9.Properties.EditFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.textEdit9.Properties.Mask.EditMask = "n2";
            this.textEdit9.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.textEdit9.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.textEdit9.Properties.MaxLength = 20;
            this.spellChecker1.SetShowSpellCheckMenu(this.textEdit9, true);
            this.textEdit9.Size = new System.Drawing.Size(75, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.textEdit9, optionsSpelling73);
            this.textEdit9.TabIndex = 574;
            // 
            // dateEdit2
            // 
            this.dateEdit2.EditValue = null;
            this.dateEdit2.Location = new System.Drawing.Point(285, 87);
            this.dateEdit2.Name = "dateEdit2";
            this.dateEdit2.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.dateEdit2.Properties.CalendarTimeProperties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton()});
            this.dateEdit2.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.dateEdit2.Size = new System.Drawing.Size(142, 20);
            this.dateEdit2.TabIndex = 590;
            // 
            // comboBoxEdit1
            // 
            this.comboBoxEdit1.EditValue = "";
            this.comboBoxEdit1.Location = new System.Drawing.Point(363, 47);
            this.comboBoxEdit1.Name = "comboBoxEdit1";
            this.comboBoxEdit1.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.comboBoxEdit1.Properties.Items.AddRange(new object[] {
            "BX",
            "C",
            "CN",
            "D",
            "DZ",
            "EA",
            "FT",
            "GAL",
            "IN",
            "K",
            "M",
            "PK",
            "PR",
            "W"});
            this.comboBoxEdit1.Properties.MaxLength = 10;
            this.comboBoxEdit1.Size = new System.Drawing.Size(64, 20);
            this.comboBoxEdit1.TabIndex = 588;
            // 
            // labelControl39
            // 
            this.labelControl39.Location = new System.Drawing.Point(218, 94);
            this.labelControl39.Name = "labelControl39";
            this.labelControl39.Size = new System.Drawing.Size(59, 13);
            this.labelControl39.TabIndex = 585;
            this.labelControl39.Text = "Next Count:";
            // 
            // labelControl40
            // 
            this.labelControl40.Location = new System.Drawing.Point(218, 74);
            this.labelControl40.Name = "labelControl40";
            this.labelControl40.Size = new System.Drawing.Size(18, 13);
            this.labelControl40.TabIndex = 584;
            this.labelControl40.Text = "Bin:";
            // 
            // labelControl41
            // 
            this.labelControl41.Location = new System.Drawing.Point(218, 54);
            this.labelControl41.Name = "labelControl41";
            this.labelControl41.Size = new System.Drawing.Size(32, 13);
            this.labelControl41.TabIndex = 583;
            this.labelControl41.Text = "Meter:";
            // 
            // labelControl42
            // 
            this.labelControl42.Location = new System.Drawing.Point(218, 14);
            this.labelControl42.Name = "labelControl42";
            this.labelControl42.Size = new System.Drawing.Size(35, 13);
            this.labelControl42.TabIndex = 582;
            this.labelControl42.Text = "Status:";
            this.labelControl42.Visible = false;
            // 
            // labelControl43
            // 
            this.labelControl43.Location = new System.Drawing.Point(218, 33);
            this.labelControl43.Name = "labelControl43";
            this.labelControl43.Size = new System.Drawing.Size(52, 13);
            this.labelControl43.TabIndex = 581;
            this.labelControl43.Text = "Expiration:";
            // 
            // lookUpEdit6
            // 
            this.lookUpEdit6.Location = new System.Drawing.Point(188, 87);
            this.lookUpEdit6.Name = "lookUpEdit6";
            this.lookUpEdit6.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.lookUpEdit6.Properties.NullText = "";
            this.lookUpEdit6.Properties.TextEditStyle = DevExpress.XtraEditors.Controls.TextEditStyles.Standard;
            this.lookUpEdit6.Size = new System.Drawing.Size(162, 20);
            this.lookUpEdit6.TabIndex = 34;
            // 
            // dateEdit3
            // 
            this.dateEdit3.EditValue = null;
            this.dateEdit3.Location = new System.Drawing.Point(89, 85);
            this.dateEdit3.Name = "dateEdit3";
            this.dateEdit3.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.dateEdit3.Properties.CalendarTimeProperties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton()});
            this.dateEdit3.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.dateEdit3.Size = new System.Drawing.Size(123, 20);
            this.dateEdit3.TabIndex = 580;
            // 
            // labelControl44
            // 
            this.labelControl44.Location = new System.Drawing.Point(111, 30);
            this.labelControl44.Name = "labelControl44";
            this.labelControl44.Size = new System.Drawing.Size(44, 13);
            this.labelControl44.TabIndex = 23;
            this.labelControl44.Text = "Tool No.:";
            // 
            // dateEdit4
            // 
            this.dateEdit4.EditValue = null;
            this.dateEdit4.Location = new System.Drawing.Point(89, 65);
            this.dateEdit4.Name = "dateEdit4";
            this.dateEdit4.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.dateEdit4.Properties.CalendarTimeProperties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton()});
            this.dateEdit4.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.dateEdit4.Properties.ReadOnly = true;
            this.dateEdit4.Size = new System.Drawing.Size(123, 20);
            this.dateEdit4.TabIndex = 579;
            // 
            // textEdit10
            // 
            this.textEdit10.Location = new System.Drawing.Point(188, 27);
            this.textEdit10.Name = "textEdit10";
            this.textEdit10.Properties.MaxLength = 15;
            this.spellChecker1.SetShowSpellCheckMenu(this.textEdit10, true);
            this.textEdit10.Size = new System.Drawing.Size(161, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.textEdit10, optionsSpelling74);
            this.textEdit10.TabIndex = 24;
            // 
            // textEdit11
            // 
            this.textEdit11.Location = new System.Drawing.Point(89, 5);
            this.textEdit11.Name = "textEdit11";
            this.textEdit11.Properties.MaxLength = 20;
            this.spellChecker1.SetShowSpellCheckMenu(this.textEdit11, true);
            this.textEdit11.Size = new System.Drawing.Size(123, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.textEdit11, optionsSpelling75);
            this.textEdit11.TabIndex = 577;
            // 
            // labelControl45
            // 
            this.labelControl45.Location = new System.Drawing.Point(111, 49);
            this.labelControl45.Name = "labelControl45";
            this.labelControl45.Size = new System.Drawing.Size(48, 13);
            this.labelControl45.TabIndex = 535;
            this.labelControl45.Text = "Bar Code:";
            // 
            // textEdit12
            // 
            this.textEdit12.Location = new System.Drawing.Point(89, 25);
            this.textEdit12.Name = "textEdit12";
            this.textEdit12.Properties.MaxLength = 15;
            this.spellChecker1.SetShowSpellCheckMenu(this.textEdit12, true);
            this.textEdit12.Size = new System.Drawing.Size(123, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.textEdit12, optionsSpelling76);
            this.textEdit12.TabIndex = 573;
            // 
            // textEdit13
            // 
            this.textEdit13.Location = new System.Drawing.Point(188, 47);
            this.textEdit13.Name = "textEdit13";
            this.textEdit13.Properties.MaxLength = 15;
            this.spellChecker1.SetShowSpellCheckMenu(this.textEdit13, true);
            this.textEdit13.Size = new System.Drawing.Size(161, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.textEdit13, optionsSpelling77);
            this.textEdit13.TabIndex = 25;
            // 
            // labelControl46
            // 
            this.labelControl46.Location = new System.Drawing.Point(11, 91);
            this.labelControl46.Name = "labelControl46";
            this.labelControl46.Size = new System.Drawing.Size(71, 13);
            this.labelControl46.TabIndex = 570;
            this.labelControl46.Text = "Date Counted:";
            // 
            // labelControl47
            // 
            this.labelControl47.Location = new System.Drawing.Point(111, 76);
            this.labelControl47.Name = "labelControl47";
            this.labelControl47.Size = new System.Drawing.Size(61, 13);
            this.labelControl47.TabIndex = 536;
            this.labelControl47.Text = "Department:";
            // 
            // labelControl52
            // 
            this.labelControl52.Location = new System.Drawing.Point(11, 71);
            this.labelControl52.Name = "labelControl52";
            this.labelControl52.Size = new System.Drawing.Size(63, 13);
            this.labelControl52.TabIndex = 569;
            this.labelControl52.Text = "Return Date:";
            // 
            // labelControl55
            // 
            this.labelControl55.Location = new System.Drawing.Point(111, 96);
            this.labelControl55.Name = "labelControl55";
            this.labelControl55.Size = new System.Drawing.Size(29, 13);
            this.labelControl55.TabIndex = 554;
            this.labelControl55.Text = "Class:";
            // 
            // labelControl57
            // 
            this.labelControl57.Location = new System.Drawing.Point(11, 51);
            this.labelControl57.Name = "labelControl57";
            this.labelControl57.Size = new System.Drawing.Size(62, 13);
            this.labelControl57.TabIndex = 568;
            this.labelControl57.Text = "Assigned To:";
            // 
            // labelControl58
            // 
            this.labelControl58.Location = new System.Drawing.Point(11, 11);
            this.labelControl58.Name = "labelControl58";
            this.labelControl58.Size = new System.Drawing.Size(50, 13);
            this.labelControl58.TabIndex = 567;
            this.labelControl58.Text = "Serial No.:";
            this.labelControl58.Visible = false;
            // 
            // labelControl105
            // 
            this.labelControl105.Location = new System.Drawing.Point(11, 30);
            this.labelControl105.Name = "labelControl105";
            this.labelControl105.Size = new System.Drawing.Size(66, 13);
            this.labelControl105.TabIndex = 24;
            this.labelControl105.Text = "License Plate:";
            // 
            // labelControl106
            // 
            this.labelControl106.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))));
            this.labelControl106.Location = new System.Drawing.Point(265, 277);
            this.labelControl106.Name = "labelControl106";
            this.labelControl106.Size = new System.Drawing.Size(50, 13);
            this.labelControl106.TabIndex = 560;
            this.labelControl106.Text = "Tool Info";
            // 
            // panelControl7
            // 
            this.panelControl7.Controls.Add(this.dateEdit5);
            this.panelControl7.Controls.Add(this.dateEdit6);
            this.panelControl7.Controls.Add(this.textEdit14);
            this.panelControl7.Controls.Add(this.textEdit15);
            this.panelControl7.Controls.Add(this.labelControl107);
            this.panelControl7.Controls.Add(this.labelControl108);
            this.panelControl7.Controls.Add(this.labelControl109);
            this.panelControl7.Controls.Add(this.labelControl110);
            this.panelControl7.Location = new System.Drawing.Point(8, 294);
            this.panelControl7.Name = "panelControl7";
            this.panelControl7.Size = new System.Drawing.Size(239, 113);
            this.panelControl7.TabIndex = 557;
            // 
            // dateEdit5
            // 
            this.dateEdit5.EditValue = null;
            this.dateEdit5.Location = new System.Drawing.Point(78, 69);
            this.dateEdit5.Name = "dateEdit5";
            this.dateEdit5.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.dateEdit5.Properties.CalendarTimeProperties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton()});
            this.dateEdit5.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.dateEdit5.Size = new System.Drawing.Size(116, 20);
            this.dateEdit5.TabIndex = 578;
            // 
            // dateEdit6
            // 
            this.dateEdit6.EditValue = null;
            this.dateEdit6.Location = new System.Drawing.Point(78, 49);
            this.dateEdit6.Name = "dateEdit6";
            this.dateEdit6.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.dateEdit6.Properties.CalendarTimeProperties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton()});
            this.dateEdit6.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.dateEdit6.Size = new System.Drawing.Size(116, 20);
            this.dateEdit6.TabIndex = 577;
            // 
            // textEdit14
            // 
            this.textEdit14.Location = new System.Drawing.Point(78, 29);
            this.textEdit14.Name = "textEdit14";
            this.textEdit14.Properties.DisplayFormat.FormatString = "c2";
            this.textEdit14.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.textEdit14.Properties.EditFormat.FormatString = "c2";
            this.textEdit14.Properties.EditFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.textEdit14.Properties.Mask.EditMask = "c2";
            this.textEdit14.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.textEdit14.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.textEdit14.Properties.MaxLength = 20;
            this.spellChecker1.SetShowSpellCheckMenu(this.textEdit14, true);
            this.textEdit14.Size = new System.Drawing.Size(116, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.textEdit14, optionsSpelling78);
            this.textEdit14.TabIndex = 574;
            // 
            // textEdit15
            // 
            this.textEdit15.Location = new System.Drawing.Point(78, 9);
            this.textEdit15.Name = "textEdit15";
            this.textEdit15.Properties.MaxLength = 15;
            this.spellChecker1.SetShowSpellCheckMenu(this.textEdit15, true);
            this.textEdit15.Size = new System.Drawing.Size(116, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.textEdit15, optionsSpelling79);
            this.textEdit15.TabIndex = 573;
            // 
            // labelControl107
            // 
            this.labelControl107.Location = new System.Drawing.Point(11, 72);
            this.labelControl107.Name = "labelControl107";
            this.labelControl107.Size = new System.Drawing.Size(46, 13);
            this.labelControl107.TabIndex = 570;
            this.labelControl107.Text = "Warranty";
            // 
            // labelControl108
            // 
            this.labelControl108.Location = new System.Drawing.Point(11, 52);
            this.labelControl108.Name = "labelControl108";
            this.labelControl108.Size = new System.Drawing.Size(27, 13);
            this.labelControl108.TabIndex = 569;
            this.labelControl108.Text = "Date:";
            // 
            // labelControl109
            // 
            this.labelControl109.Location = new System.Drawing.Point(11, 32);
            this.labelControl109.Name = "labelControl109";
            this.labelControl109.Size = new System.Drawing.Size(26, 13);
            this.labelControl109.TabIndex = 568;
            this.labelControl109.Text = "Cost:";
            // 
            // labelControl110
            // 
            this.labelControl110.Location = new System.Drawing.Point(11, 11);
            this.labelControl110.Name = "labelControl110";
            this.labelControl110.Size = new System.Drawing.Size(38, 13);
            this.labelControl110.TabIndex = 24;
            this.labelControl110.Text = "PO No.:";
            // 
            // xtraTabControl1
            // 
            this.xtraTabControl1.Location = new System.Drawing.Point(12, 160);
            this.xtraTabControl1.Name = "xtraTabControl1";
            this.xtraTabControl1.SelectedTabPage = this.xtraTabPage1;
            this.xtraTabControl1.Size = new System.Drawing.Size(854, 377);
            this.xtraTabControl1.TabIndex = 597;
            this.xtraTabControl1.TabPages.AddRange(new DevExpress.XtraTab.XtraTabPage[] {
            this.xtraTabPage1,
            this.xtraTabPage2,
            this.xtraTabPage3,
            this.pagContactDefaultValues,
            this.pagMajorPONote,
            this.pagSmallPONote,
            this.pagSubmittalSpec});
            // 
            // xtraTabPage1
            // 
            this.xtraTabPage1.Controls.Add(this.Paragraph2);
            this.xtraTabPage1.Controls.Add(this.Paragraph1);
            this.xtraTabPage1.Controls.Add(this.txtChangeOrderStipulationsParagraph2);
            this.xtraTabPage1.Controls.Add(this.txtChangeOrderStipulationsParagraph1);
            this.xtraTabPage1.Name = "xtraTabPage1";
            this.xtraTabPage1.Size = new System.Drawing.Size(852, 352);
            this.xtraTabPage1.Text = "Change Order Letter Stipulations";
            // 
            // Paragraph2
            // 
            this.Paragraph2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Paragraph2.Location = new System.Drawing.Point(14, 184);
            this.Paragraph2.Name = "Paragraph2";
            this.Paragraph2.Size = new System.Drawing.Size(63, 13);
            this.Paragraph2.TabIndex = 575;
            this.Paragraph2.Text = "Paragraph 2:";
            this.Paragraph2.Click += new System.EventHandler(this.Paragraph2_Click);
            // 
            // Paragraph1
            // 
            this.Paragraph1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Paragraph1.Location = new System.Drawing.Point(14, 14);
            this.Paragraph1.Name = "Paragraph1";
            this.Paragraph1.Size = new System.Drawing.Size(63, 13);
            this.Paragraph1.TabIndex = 574;
            this.Paragraph1.Text = "Paragraph 1:";
            this.Paragraph1.Click += new System.EventHandler(this.Paragraph1_Click);
            // 
            // txtChangeOrderStipulationsParagraph2
            // 
            this.txtChangeOrderStipulationsParagraph2.Location = new System.Drawing.Point(90, 184);
            this.txtChangeOrderStipulationsParagraph2.Name = "txtChangeOrderStipulationsParagraph2";
            this.txtChangeOrderStipulationsParagraph2.ReadOnly = true;
            this.txtChangeOrderStipulationsParagraph2.Size = new System.Drawing.Size(738, 153);
            this.txtChangeOrderStipulationsParagraph2.TabIndex = 573;
            this.txtChangeOrderStipulationsParagraph2.OnTextChanged += new ControlsLibrary.TextChangedHandler(this.txtChangeOrderStipulationsParagraph2_OnTextChanged);
            // 
            // txtChangeOrderStipulationsParagraph1
            // 
            this.txtChangeOrderStipulationsParagraph1.Location = new System.Drawing.Point(90, 12);
            this.txtChangeOrderStipulationsParagraph1.Name = "txtChangeOrderStipulationsParagraph1";
            this.txtChangeOrderStipulationsParagraph1.ReadOnly = true;
            this.txtChangeOrderStipulationsParagraph1.Size = new System.Drawing.Size(738, 153);
            this.txtChangeOrderStipulationsParagraph1.TabIndex = 0;
            this.txtChangeOrderStipulationsParagraph1.OnTextChanged += new ControlsLibrary.TextChangedHandler(this.txtChangeOrderStipulationsParagraph1_OnTextChanged);
            // 
            // xtraTabPage2
            // 
            this.xtraTabPage2.Controls.Add(this.labelControl23);
            this.xtraTabPage2.Controls.Add(this.labelControl22);
            this.xtraTabPage2.Controls.Add(this.panelControl5);
            this.xtraTabPage2.Controls.Add(this.panelControl3);
            this.xtraTabPage2.Controls.Add(this.labelControl10);
            this.xtraTabPage2.Controls.Add(this.panelControl2);
            this.xtraTabPage2.Controls.Add(this.panelControl1);
            this.xtraTabPage2.Controls.Add(this.labelControl3);
            this.xtraTabPage2.Name = "xtraTabPage2";
            this.xtraTabPage2.Size = new System.Drawing.Size(852, 352);
            this.xtraTabPage2.Text = "Estimate Default Values";
            // 
            // labelControl23
            // 
            this.labelControl23.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))));
            this.labelControl23.Location = new System.Drawing.Point(337, 156);
            this.labelControl23.Name = "labelControl23";
            this.labelControl23.Size = new System.Drawing.Size(54, 13);
            this.labelControl23.TabIndex = 602;
            this.labelControl23.Text = "Mark-ups";
            // 
            // labelControl22
            // 
            this.labelControl22.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))));
            this.labelControl22.Location = new System.Drawing.Point(17, 102);
            this.labelControl22.Name = "labelControl22";
            this.labelControl22.Size = new System.Drawing.Size(32, 13);
            this.labelControl22.TabIndex = 601;
            this.labelControl22.Text = "Labor";
            // 
            // panelControl5
            // 
            this.panelControl5.Controls.Add(this.labelControl24);
            this.panelControl5.Controls.Add(this.txtBondPercent);
            this.panelControl5.Controls.Add(this.labelControl18);
            this.panelControl5.Controls.Add(this.txtWarrantyPercent);
            this.panelControl5.Controls.Add(this.txtSubcontractAdministrationPercent);
            this.panelControl5.Controls.Add(this.labelControl19);
            this.panelControl5.Controls.Add(this.labelControl20);
            this.panelControl5.Controls.Add(this.txtProfitPercent);
            this.panelControl5.Controls.Add(this.txtOverheadPercent);
            this.panelControl5.Controls.Add(this.labelControl21);
            this.panelControl5.Location = new System.Drawing.Point(337, 175);
            this.panelControl5.Name = "panelControl5";
            this.panelControl5.Size = new System.Drawing.Size(258, 137);
            this.panelControl5.TabIndex = 600;
            // 
            // labelControl24
            // 
            this.labelControl24.Location = new System.Drawing.Point(5, 113);
            this.labelControl24.Name = "labelControl24";
            this.labelControl24.Size = new System.Drawing.Size(42, 13);
            this.labelControl24.TabIndex = 578;
            this.labelControl24.Text = "Bond %:";
            // 
            // txtBondPercent
            // 
            this.txtBondPercent.Location = new System.Drawing.Point(155, 112);
            this.txtBondPercent.Name = "txtBondPercent";
            this.txtBondPercent.Properties.DisplayFormat.FormatString = "p2";
            this.txtBondPercent.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtBondPercent.Properties.EditFormat.FormatString = "p2";
            this.txtBondPercent.Properties.EditFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtBondPercent.Properties.Mask.EditMask = "p2";
            this.txtBondPercent.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.txtBondPercent.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.txtBondPercent.Properties.MaxLength = 20;
            this.spellChecker1.SetShowSpellCheckMenu(this.txtBondPercent, true);
            this.txtBondPercent.Size = new System.Drawing.Size(73, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.txtBondPercent, optionsSpelling1);
            this.txtBondPercent.TabIndex = 19;
            this.txtBondPercent.EditValueChanged += new System.EventHandler(this.AllControls_EditValue);
            // 
            // labelControl18
            // 
            this.labelControl18.Location = new System.Drawing.Point(5, 87);
            this.labelControl18.Name = "labelControl18";
            this.labelControl18.Size = new System.Drawing.Size(64, 13);
            this.labelControl18.TabIndex = 576;
            this.labelControl18.Text = "Warranty %:";
            // 
            // txtWarrantyPercent
            // 
            this.txtWarrantyPercent.Location = new System.Drawing.Point(155, 86);
            this.txtWarrantyPercent.Name = "txtWarrantyPercent";
            this.txtWarrantyPercent.Properties.DisplayFormat.FormatString = "p2";
            this.txtWarrantyPercent.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtWarrantyPercent.Properties.EditFormat.FormatString = "p2";
            this.txtWarrantyPercent.Properties.EditFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtWarrantyPercent.Properties.Mask.EditMask = "p2";
            this.txtWarrantyPercent.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.txtWarrantyPercent.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.txtWarrantyPercent.Properties.MaxLength = 20;
            this.spellChecker1.SetShowSpellCheckMenu(this.txtWarrantyPercent, true);
            this.txtWarrantyPercent.Size = new System.Drawing.Size(73, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.txtWarrantyPercent, optionsSpelling2);
            this.txtWarrantyPercent.TabIndex = 18;
            this.txtWarrantyPercent.EditValueChanged += new System.EventHandler(this.AllControls_EditValue);
            // 
            // txtSubcontractAdministrationPercent
            // 
            this.txtSubcontractAdministrationPercent.Location = new System.Drawing.Point(155, 60);
            this.txtSubcontractAdministrationPercent.Name = "txtSubcontractAdministrationPercent";
            this.txtSubcontractAdministrationPercent.Properties.DisplayFormat.FormatString = "p2";
            this.txtSubcontractAdministrationPercent.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtSubcontractAdministrationPercent.Properties.EditFormat.FormatString = "p2";
            this.txtSubcontractAdministrationPercent.Properties.EditFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtSubcontractAdministrationPercent.Properties.Mask.EditMask = "p2";
            this.txtSubcontractAdministrationPercent.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.txtSubcontractAdministrationPercent.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.txtSubcontractAdministrationPercent.Properties.MaxLength = 20;
            this.spellChecker1.SetShowSpellCheckMenu(this.txtSubcontractAdministrationPercent, true);
            this.txtSubcontractAdministrationPercent.Size = new System.Drawing.Size(73, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.txtSubcontractAdministrationPercent, optionsSpelling3);
            this.txtSubcontractAdministrationPercent.TabIndex = 17;
            this.txtSubcontractAdministrationPercent.EditValueChanged += new System.EventHandler(this.AllControls_EditValue);
            // 
            // labelControl19
            // 
            this.labelControl19.Location = new System.Drawing.Point(5, 63);
            this.labelControl19.Name = "labelControl19";
            this.labelControl19.Size = new System.Drawing.Size(147, 13);
            this.labelControl19.TabIndex = 574;
            this.labelControl19.Text = "Subcontract Administration %:";
            // 
            // labelControl20
            // 
            this.labelControl20.Location = new System.Drawing.Point(5, 35);
            this.labelControl20.Name = "labelControl20";
            this.labelControl20.Size = new System.Drawing.Size(44, 13);
            this.labelControl20.TabIndex = 572;
            this.labelControl20.Text = "Profit %:";
            // 
            // txtProfitPercent
            // 
            this.txtProfitPercent.Location = new System.Drawing.Point(155, 34);
            this.txtProfitPercent.Name = "txtProfitPercent";
            this.txtProfitPercent.Properties.DisplayFormat.FormatString = "p2";
            this.txtProfitPercent.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtProfitPercent.Properties.EditFormat.FormatString = "p2";
            this.txtProfitPercent.Properties.EditFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtProfitPercent.Properties.Mask.EditMask = "p2";
            this.txtProfitPercent.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.txtProfitPercent.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.txtProfitPercent.Properties.MaxLength = 20;
            this.spellChecker1.SetShowSpellCheckMenu(this.txtProfitPercent, true);
            this.txtProfitPercent.Size = new System.Drawing.Size(73, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.txtProfitPercent, optionsSpelling4);
            this.txtProfitPercent.TabIndex = 16;
            this.txtProfitPercent.EditValueChanged += new System.EventHandler(this.AllControls_EditValue);
            // 
            // txtOverheadPercent
            // 
            this.txtOverheadPercent.Location = new System.Drawing.Point(155, 8);
            this.txtOverheadPercent.Name = "txtOverheadPercent";
            this.txtOverheadPercent.Properties.DisplayFormat.FormatString = "p2";
            this.txtOverheadPercent.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtOverheadPercent.Properties.EditFormat.FormatString = "p2";
            this.txtOverheadPercent.Properties.EditFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtOverheadPercent.Properties.Mask.EditMask = "p2";
            this.txtOverheadPercent.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.txtOverheadPercent.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.txtOverheadPercent.Properties.MaxLength = 20;
            this.spellChecker1.SetShowSpellCheckMenu(this.txtOverheadPercent, true);
            this.txtOverheadPercent.Size = new System.Drawing.Size(73, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.txtOverheadPercent, optionsSpelling5);
            this.txtOverheadPercent.TabIndex = 15;
            this.txtOverheadPercent.EditValueChanged += new System.EventHandler(this.AllControls_EditValue);
            // 
            // labelControl21
            // 
            this.labelControl21.Location = new System.Drawing.Point(5, 11);
            this.labelControl21.Name = "labelControl21";
            this.labelControl21.Size = new System.Drawing.Size(66, 13);
            this.labelControl21.TabIndex = 570;
            this.labelControl21.Text = "Overhead %:";
            // 
            // panelControl3
            // 
            this.panelControl3.Controls.Add(this.labelControl15);
            this.panelControl3.Controls.Add(this.txtFringeBenefitsPercent);
            this.panelControl3.Controls.Add(this.txtSafetyMeetingPercent);
            this.panelControl3.Controls.Add(this.labelControl16);
            this.panelControl3.Controls.Add(this.labelControl17);
            this.panelControl3.Controls.Add(this.txtProjectEngineerPercentOfLabor);
            this.panelControl3.Controls.Add(this.labelControl11);
            this.panelControl3.Controls.Add(this.txtProjectManagerPercentOfLabor);
            this.panelControl3.Controls.Add(this.txtSuperintendentPercentOfLabor);
            this.panelControl3.Controls.Add(this.labelControl12);
            this.panelControl3.Controls.Add(this.labelControl13);
            this.panelControl3.Controls.Add(this.txtGeneralForemanPercentOfLabor);
            this.panelControl3.Controls.Add(this.txtForemanPercentOfLabor);
            this.panelControl3.Controls.Add(this.labelControl14);
            this.panelControl3.Location = new System.Drawing.Point(17, 121);
            this.panelControl3.Name = "panelControl3";
            this.panelControl3.Size = new System.Drawing.Size(258, 192);
            this.panelControl3.TabIndex = 599;
            // 
            // labelControl15
            // 
            this.labelControl15.Location = new System.Drawing.Point(5, 165);
            this.labelControl15.Name = "labelControl15";
            this.labelControl15.Size = new System.Drawing.Size(90, 13);
            this.labelControl15.TabIndex = 582;
            this.labelControl15.Text = "Fringe Benefits %:";
            // 
            // txtFringeBenefitsPercent
            // 
            this.txtFringeBenefitsPercent.Location = new System.Drawing.Point(155, 164);
            this.txtFringeBenefitsPercent.Name = "txtFringeBenefitsPercent";
            this.txtFringeBenefitsPercent.Properties.DisplayFormat.FormatString = "p2";
            this.txtFringeBenefitsPercent.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtFringeBenefitsPercent.Properties.EditFormat.FormatString = "p2";
            this.txtFringeBenefitsPercent.Properties.EditFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtFringeBenefitsPercent.Properties.Mask.EditMask = "p2";
            this.txtFringeBenefitsPercent.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.txtFringeBenefitsPercent.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.txtFringeBenefitsPercent.Properties.MaxLength = 20;
            this.spellChecker1.SetShowSpellCheckMenu(this.txtFringeBenefitsPercent, true);
            this.txtFringeBenefitsPercent.Size = new System.Drawing.Size(73, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.txtFringeBenefitsPercent, optionsSpelling6);
            this.txtFringeBenefitsPercent.TabIndex = 14;
            this.txtFringeBenefitsPercent.EditValueChanged += new System.EventHandler(this.AllControls_EditValue);
            // 
            // txtSafetyMeetingPercent
            // 
            this.txtSafetyMeetingPercent.Location = new System.Drawing.Point(155, 138);
            this.txtSafetyMeetingPercent.Name = "txtSafetyMeetingPercent";
            this.txtSafetyMeetingPercent.Properties.DisplayFormat.FormatString = "p2";
            this.txtSafetyMeetingPercent.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtSafetyMeetingPercent.Properties.EditFormat.FormatString = "p2";
            this.txtSafetyMeetingPercent.Properties.EditFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtSafetyMeetingPercent.Properties.Mask.EditMask = "p2";
            this.txtSafetyMeetingPercent.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.txtSafetyMeetingPercent.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.txtSafetyMeetingPercent.Properties.MaxLength = 20;
            this.spellChecker1.SetShowSpellCheckMenu(this.txtSafetyMeetingPercent, true);
            this.txtSafetyMeetingPercent.Size = new System.Drawing.Size(73, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.txtSafetyMeetingPercent, optionsSpelling7);
            this.txtSafetyMeetingPercent.TabIndex = 13;
            this.txtSafetyMeetingPercent.EditValueChanged += new System.EventHandler(this.AllControls_EditValue);
            // 
            // labelControl16
            // 
            this.labelControl16.Location = new System.Drawing.Point(5, 141);
            this.labelControl16.Name = "labelControl16";
            this.labelControl16.Size = new System.Drawing.Size(91, 13);
            this.labelControl16.TabIndex = 580;
            this.labelControl16.Text = "Safety Meeting %:";
            // 
            // labelControl17
            // 
            this.labelControl17.Location = new System.Drawing.Point(5, 113);
            this.labelControl17.Name = "labelControl17";
            this.labelControl17.Size = new System.Drawing.Size(140, 13);
            this.labelControl17.TabIndex = 578;
            this.labelControl17.Text = "Project Engineer % of Labor:";
            // 
            // txtProjectEngineerPercentOfLabor
            // 
            this.txtProjectEngineerPercentOfLabor.Location = new System.Drawing.Point(155, 112);
            this.txtProjectEngineerPercentOfLabor.Name = "txtProjectEngineerPercentOfLabor";
            this.txtProjectEngineerPercentOfLabor.Properties.DisplayFormat.FormatString = "p2";
            this.txtProjectEngineerPercentOfLabor.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtProjectEngineerPercentOfLabor.Properties.EditFormat.FormatString = "p2";
            this.txtProjectEngineerPercentOfLabor.Properties.EditFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtProjectEngineerPercentOfLabor.Properties.Mask.EditMask = "p2";
            this.txtProjectEngineerPercentOfLabor.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.txtProjectEngineerPercentOfLabor.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.txtProjectEngineerPercentOfLabor.Properties.MaxLength = 20;
            this.spellChecker1.SetShowSpellCheckMenu(this.txtProjectEngineerPercentOfLabor, true);
            this.txtProjectEngineerPercentOfLabor.Size = new System.Drawing.Size(73, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.txtProjectEngineerPercentOfLabor, optionsSpelling8);
            this.txtProjectEngineerPercentOfLabor.TabIndex = 12;
            this.txtProjectEngineerPercentOfLabor.EditValueChanged += new System.EventHandler(this.AllControls_EditValue);
            // 
            // labelControl11
            // 
            this.labelControl11.Location = new System.Drawing.Point(5, 87);
            this.labelControl11.Name = "labelControl11";
            this.labelControl11.Size = new System.Drawing.Size(140, 13);
            this.labelControl11.TabIndex = 576;
            this.labelControl11.Text = "Project Manager % of Labor:";
            // 
            // txtProjectManagerPercentOfLabor
            // 
            this.txtProjectManagerPercentOfLabor.Location = new System.Drawing.Point(155, 86);
            this.txtProjectManagerPercentOfLabor.Name = "txtProjectManagerPercentOfLabor";
            this.txtProjectManagerPercentOfLabor.Properties.DisplayFormat.FormatString = "p2";
            this.txtProjectManagerPercentOfLabor.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtProjectManagerPercentOfLabor.Properties.EditFormat.FormatString = "p2";
            this.txtProjectManagerPercentOfLabor.Properties.EditFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtProjectManagerPercentOfLabor.Properties.Mask.EditMask = "p2";
            this.txtProjectManagerPercentOfLabor.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.txtProjectManagerPercentOfLabor.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.txtProjectManagerPercentOfLabor.Properties.MaxLength = 20;
            this.spellChecker1.SetShowSpellCheckMenu(this.txtProjectManagerPercentOfLabor, true);
            this.txtProjectManagerPercentOfLabor.Size = new System.Drawing.Size(73, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.txtProjectManagerPercentOfLabor, optionsSpelling9);
            this.txtProjectManagerPercentOfLabor.TabIndex = 11;
            this.txtProjectManagerPercentOfLabor.EditValueChanged += new System.EventHandler(this.AllControls_EditValue);
            // 
            // txtSuperintendentPercentOfLabor
            // 
            this.txtSuperintendentPercentOfLabor.Location = new System.Drawing.Point(155, 60);
            this.txtSuperintendentPercentOfLabor.Name = "txtSuperintendentPercentOfLabor";
            this.txtSuperintendentPercentOfLabor.Properties.DisplayFormat.FormatString = "p2";
            this.txtSuperintendentPercentOfLabor.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtSuperintendentPercentOfLabor.Properties.EditFormat.FormatString = "p2";
            this.txtSuperintendentPercentOfLabor.Properties.EditFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtSuperintendentPercentOfLabor.Properties.Mask.EditMask = "p2";
            this.txtSuperintendentPercentOfLabor.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.txtSuperintendentPercentOfLabor.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.txtSuperintendentPercentOfLabor.Properties.MaxLength = 20;
            this.spellChecker1.SetShowSpellCheckMenu(this.txtSuperintendentPercentOfLabor, true);
            this.txtSuperintendentPercentOfLabor.Size = new System.Drawing.Size(73, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.txtSuperintendentPercentOfLabor, optionsSpelling10);
            this.txtSuperintendentPercentOfLabor.TabIndex = 10;
            this.txtSuperintendentPercentOfLabor.EditValueChanged += new System.EventHandler(this.AllControls_EditValue);
            // 
            // labelControl12
            // 
            this.labelControl12.Location = new System.Drawing.Point(5, 63);
            this.labelControl12.Name = "labelControl12";
            this.labelControl12.Size = new System.Drawing.Size(135, 13);
            this.labelControl12.TabIndex = 574;
            this.labelControl12.Text = "Superintendent % of Labor:";
            // 
            // labelControl13
            // 
            this.labelControl13.Location = new System.Drawing.Point(5, 35);
            this.labelControl13.Name = "labelControl13";
            this.labelControl13.Size = new System.Drawing.Size(143, 13);
            this.labelControl13.TabIndex = 572;
            this.labelControl13.Text = "General Foreman % of Labor:";
            // 
            // txtGeneralForemanPercentOfLabor
            // 
            this.txtGeneralForemanPercentOfLabor.Location = new System.Drawing.Point(155, 34);
            this.txtGeneralForemanPercentOfLabor.Name = "txtGeneralForemanPercentOfLabor";
            this.txtGeneralForemanPercentOfLabor.Properties.DisplayFormat.FormatString = "p2";
            this.txtGeneralForemanPercentOfLabor.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtGeneralForemanPercentOfLabor.Properties.EditFormat.FormatString = "p2";
            this.txtGeneralForemanPercentOfLabor.Properties.EditFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtGeneralForemanPercentOfLabor.Properties.Mask.EditMask = "p2";
            this.txtGeneralForemanPercentOfLabor.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.txtGeneralForemanPercentOfLabor.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.txtGeneralForemanPercentOfLabor.Properties.MaxLength = 20;
            this.spellChecker1.SetShowSpellCheckMenu(this.txtGeneralForemanPercentOfLabor, true);
            this.txtGeneralForemanPercentOfLabor.Size = new System.Drawing.Size(73, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.txtGeneralForemanPercentOfLabor, optionsSpelling11);
            this.txtGeneralForemanPercentOfLabor.TabIndex = 9;
            this.txtGeneralForemanPercentOfLabor.EditValueChanged += new System.EventHandler(this.AllControls_EditValue);
            // 
            // txtForemanPercentOfLabor
            // 
            this.txtForemanPercentOfLabor.Location = new System.Drawing.Point(155, 8);
            this.txtForemanPercentOfLabor.Name = "txtForemanPercentOfLabor";
            this.txtForemanPercentOfLabor.Properties.DisplayFormat.FormatString = "p2";
            this.txtForemanPercentOfLabor.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtForemanPercentOfLabor.Properties.EditFormat.FormatString = "p2";
            this.txtForemanPercentOfLabor.Properties.EditFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtForemanPercentOfLabor.Properties.Mask.EditMask = "p2";
            this.txtForemanPercentOfLabor.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.txtForemanPercentOfLabor.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.txtForemanPercentOfLabor.Properties.MaxLength = 20;
            this.spellChecker1.SetShowSpellCheckMenu(this.txtForemanPercentOfLabor, true);
            this.txtForemanPercentOfLabor.Size = new System.Drawing.Size(73, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.txtForemanPercentOfLabor, optionsSpelling12);
            this.txtForemanPercentOfLabor.TabIndex = 8;
            this.txtForemanPercentOfLabor.EditValueChanged += new System.EventHandler(this.AllControls_EditValue);
            // 
            // labelControl14
            // 
            this.labelControl14.Location = new System.Drawing.Point(5, 11);
            this.labelControl14.Name = "labelControl14";
            this.labelControl14.Size = new System.Drawing.Size(103, 13);
            this.labelControl14.TabIndex = 570;
            this.labelControl14.Text = "Foreman % of Labor:";
            // 
            // labelControl10
            // 
            this.labelControl10.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))));
            this.labelControl10.Location = new System.Drawing.Point(337, 16);
            this.labelControl10.Name = "labelControl10";
            this.labelControl10.Size = new System.Drawing.Size(53, 13);
            this.labelControl10.TabIndex = 598;
            this.labelControl10.Text = "Expenses";
            // 
            // panelControl2
            // 
            this.panelControl2.Controls.Add(this.labelControl8);
            this.panelControl2.Controls.Add(this.txtCartigeHandlingPercent);
            this.panelControl2.Controls.Add(this.txtSmallToolsPercent);
            this.panelControl2.Controls.Add(this.labelControl9);
            this.panelControl2.Controls.Add(this.labelControl6);
            this.panelControl2.Controls.Add(this.txtStoragePercent);
            this.panelControl2.Controls.Add(this.txtAsBuiltsEngineeringPercent);
            this.panelControl2.Controls.Add(this.labelControl7);
            this.panelControl2.Location = new System.Drawing.Point(337, 35);
            this.panelControl2.Name = "panelControl2";
            this.panelControl2.Size = new System.Drawing.Size(258, 113);
            this.panelControl2.TabIndex = 597;
            // 
            // labelControl8
            // 
            this.labelControl8.Location = new System.Drawing.Point(5, 87);
            this.labelControl8.Name = "labelControl8";
            this.labelControl8.Size = new System.Drawing.Size(97, 13);
            this.labelControl8.TabIndex = 576;
            this.labelControl8.Text = "Cartige Handling %:";
            // 
            // txtCartigeHandlingPercent
            // 
            this.txtCartigeHandlingPercent.Location = new System.Drawing.Point(155, 86);
            this.txtCartigeHandlingPercent.Name = "txtCartigeHandlingPercent";
            this.txtCartigeHandlingPercent.Properties.DisplayFormat.FormatString = "p2";
            this.txtCartigeHandlingPercent.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtCartigeHandlingPercent.Properties.EditFormat.FormatString = "p2";
            this.txtCartigeHandlingPercent.Properties.EditFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtCartigeHandlingPercent.Properties.Mask.EditMask = "p2";
            this.txtCartigeHandlingPercent.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.txtCartigeHandlingPercent.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.txtCartigeHandlingPercent.Properties.MaxLength = 20;
            this.spellChecker1.SetShowSpellCheckMenu(this.txtCartigeHandlingPercent, true);
            this.txtCartigeHandlingPercent.Size = new System.Drawing.Size(73, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.txtCartigeHandlingPercent, optionsSpelling13);
            this.txtCartigeHandlingPercent.TabIndex = 7;
            this.txtCartigeHandlingPercent.EditValueChanged += new System.EventHandler(this.AllControls_EditValue);
            // 
            // txtSmallToolsPercent
            // 
            this.txtSmallToolsPercent.Location = new System.Drawing.Point(155, 60);
            this.txtSmallToolsPercent.Name = "txtSmallToolsPercent";
            this.txtSmallToolsPercent.Properties.DisplayFormat.FormatString = "p2";
            this.txtSmallToolsPercent.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtSmallToolsPercent.Properties.EditFormat.FormatString = "p2";
            this.txtSmallToolsPercent.Properties.EditFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtSmallToolsPercent.Properties.Mask.EditMask = "p2";
            this.txtSmallToolsPercent.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.txtSmallToolsPercent.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.txtSmallToolsPercent.Properties.MaxLength = 20;
            this.spellChecker1.SetShowSpellCheckMenu(this.txtSmallToolsPercent, true);
            this.txtSmallToolsPercent.Size = new System.Drawing.Size(73, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.txtSmallToolsPercent, optionsSpelling14);
            this.txtSmallToolsPercent.TabIndex = 6;
            this.txtSmallToolsPercent.EditValueChanged += new System.EventHandler(this.AllControls_EditValue);
            // 
            // labelControl9
            // 
            this.labelControl9.Location = new System.Drawing.Point(5, 63);
            this.labelControl9.Name = "labelControl9";
            this.labelControl9.Size = new System.Drawing.Size(70, 13);
            this.labelControl9.TabIndex = 574;
            this.labelControl9.Text = "Small Tools %:";
            // 
            // labelControl6
            // 
            this.labelControl6.Location = new System.Drawing.Point(5, 35);
            this.labelControl6.Name = "labelControl6";
            this.labelControl6.Size = new System.Drawing.Size(56, 13);
            this.labelControl6.TabIndex = 572;
            this.labelControl6.Text = "Storage %:";
            // 
            // txtStoragePercent
            // 
            this.txtStoragePercent.Location = new System.Drawing.Point(155, 34);
            this.txtStoragePercent.Name = "txtStoragePercent";
            this.txtStoragePercent.Properties.DisplayFormat.FormatString = "p2";
            this.txtStoragePercent.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtStoragePercent.Properties.EditFormat.FormatString = "p2";
            this.txtStoragePercent.Properties.EditFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtStoragePercent.Properties.Mask.EditMask = "p2";
            this.txtStoragePercent.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.txtStoragePercent.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.txtStoragePercent.Properties.MaxLength = 20;
            this.spellChecker1.SetShowSpellCheckMenu(this.txtStoragePercent, true);
            this.txtStoragePercent.Size = new System.Drawing.Size(73, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.txtStoragePercent, optionsSpelling15);
            this.txtStoragePercent.TabIndex = 5;
            this.txtStoragePercent.EditValueChanged += new System.EventHandler(this.AllControls_EditValue);
            // 
            // txtAsBuiltsEngineeringPercent
            // 
            this.txtAsBuiltsEngineeringPercent.Location = new System.Drawing.Point(155, 8);
            this.txtAsBuiltsEngineeringPercent.Name = "txtAsBuiltsEngineeringPercent";
            this.txtAsBuiltsEngineeringPercent.Properties.DisplayFormat.FormatString = "p2";
            this.txtAsBuiltsEngineeringPercent.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtAsBuiltsEngineeringPercent.Properties.EditFormat.FormatString = "p2";
            this.txtAsBuiltsEngineeringPercent.Properties.EditFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtAsBuiltsEngineeringPercent.Properties.Mask.EditMask = "p2";
            this.txtAsBuiltsEngineeringPercent.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.txtAsBuiltsEngineeringPercent.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.txtAsBuiltsEngineeringPercent.Properties.MaxLength = 20;
            this.spellChecker1.SetShowSpellCheckMenu(this.txtAsBuiltsEngineeringPercent, true);
            this.txtAsBuiltsEngineeringPercent.Size = new System.Drawing.Size(73, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.txtAsBuiltsEngineeringPercent, optionsSpelling16);
            this.txtAsBuiltsEngineeringPercent.TabIndex = 4;
            this.txtAsBuiltsEngineeringPercent.EditValueChanged += new System.EventHandler(this.AllControls_EditValue);
            // 
            // labelControl7
            // 
            this.labelControl7.Location = new System.Drawing.Point(5, 11);
            this.labelControl7.Name = "labelControl7";
            this.labelControl7.Size = new System.Drawing.Size(119, 13);
            this.labelControl7.TabIndex = 570;
            this.labelControl7.Text = "As-Builts/Engineering %:";
            // 
            // panelControl1
            // 
            this.panelControl1.Controls.Add(this.labelControl5);
            this.panelControl1.Controls.Add(this.txtSalesTaxPercent);
            this.panelControl1.Controls.Add(this.txtSundriesPercentOfMaterial);
            this.panelControl1.Controls.Add(this.labelControl4);
            this.panelControl1.Location = new System.Drawing.Point(17, 35);
            this.panelControl1.Name = "panelControl1";
            this.panelControl1.Size = new System.Drawing.Size(258, 60);
            this.panelControl1.TabIndex = 596;
            // 
            // labelControl5
            // 
            this.labelControl5.Location = new System.Drawing.Point(5, 35);
            this.labelControl5.Name = "labelControl5";
            this.labelControl5.Size = new System.Drawing.Size(72, 13);
            this.labelControl5.TabIndex = 572;
            this.labelControl5.Text = "Sales Tax (%):";
            // 
            // txtSalesTaxPercent
            // 
            this.txtSalesTaxPercent.Location = new System.Drawing.Point(155, 34);
            this.txtSalesTaxPercent.Name = "txtSalesTaxPercent";
            this.txtSalesTaxPercent.Properties.DisplayFormat.FormatString = "p2";
            this.txtSalesTaxPercent.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtSalesTaxPercent.Properties.EditFormat.FormatString = "p2";
            this.txtSalesTaxPercent.Properties.EditFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtSalesTaxPercent.Properties.Mask.EditMask = "p2";
            this.txtSalesTaxPercent.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.txtSalesTaxPercent.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.txtSalesTaxPercent.Properties.MaxLength = 20;
            this.spellChecker1.SetShowSpellCheckMenu(this.txtSalesTaxPercent, true);
            this.txtSalesTaxPercent.Size = new System.Drawing.Size(73, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.txtSalesTaxPercent, optionsSpelling17);
            this.txtSalesTaxPercent.TabIndex = 3;
            this.txtSalesTaxPercent.EditValueChanged += new System.EventHandler(this.AllControls_EditValue);
            // 
            // txtSundriesPercentOfMaterial
            // 
            this.txtSundriesPercentOfMaterial.Location = new System.Drawing.Point(155, 8);
            this.txtSundriesPercentOfMaterial.Name = "txtSundriesPercentOfMaterial";
            this.txtSundriesPercentOfMaterial.Properties.DisplayFormat.FormatString = "p2";
            this.txtSundriesPercentOfMaterial.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtSundriesPercentOfMaterial.Properties.EditFormat.FormatString = "p2";
            this.txtSundriesPercentOfMaterial.Properties.EditFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtSundriesPercentOfMaterial.Properties.Mask.EditMask = "p2";
            this.txtSundriesPercentOfMaterial.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.txtSundriesPercentOfMaterial.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.txtSundriesPercentOfMaterial.Properties.MaxLength = 20;
            this.spellChecker1.SetShowSpellCheckMenu(this.txtSundriesPercentOfMaterial, true);
            this.txtSundriesPercentOfMaterial.Size = new System.Drawing.Size(73, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.txtSundriesPercentOfMaterial, optionsSpelling18);
            this.txtSundriesPercentOfMaterial.TabIndex = 2;
            this.txtSundriesPercentOfMaterial.EditValueChanged += new System.EventHandler(this.AllControls_EditValue);
            // 
            // labelControl4
            // 
            this.labelControl4.Location = new System.Drawing.Point(5, 11);
            this.labelControl4.Name = "labelControl4";
            this.labelControl4.Size = new System.Drawing.Size(121, 13);
            this.labelControl4.TabIndex = 570;
            this.labelControl4.Text = "Sundries (% of Material):";
            // 
            // labelControl3
            // 
            this.labelControl3.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))));
            this.labelControl3.Location = new System.Drawing.Point(17, 16);
            this.labelControl3.Name = "labelControl3";
            this.labelControl3.Size = new System.Drawing.Size(47, 13);
            this.labelControl3.TabIndex = 595;
            this.labelControl3.Text = "Material";
            // 
            // xtraTabPage3
            // 
            this.xtraTabPage3.Controls.Add(this.labelControl112);
            this.xtraTabPage3.Controls.Add(this.panelControl12);
            this.xtraTabPage3.Name = "xtraTabPage3";
            this.xtraTabPage3.Size = new System.Drawing.Size(852, 352);
            this.xtraTabPage3.Text = "Labor Rate Default Values";
            // 
            // labelControl112
            // 
            this.labelControl112.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))));
            this.labelControl112.Location = new System.Drawing.Point(17, 16);
            this.labelControl112.Name = "labelControl112";
            this.labelControl112.Size = new System.Drawing.Size(62, 13);
            this.labelControl112.TabIndex = 603;
            this.labelControl112.Text = "Labor Rate";
            // 
            // panelControl12
            // 
            this.panelControl12.Controls.Add(this.txtBIMRateDT);
            this.panelControl12.Controls.Add(this.txtBIMRateOT);
            this.panelControl12.Controls.Add(this.txtBIMRate);
            this.panelControl12.Controls.Add(this.labelControl134);
            this.panelControl12.Controls.Add(this.labelControl133);
            this.panelControl12.Controls.Add(this.labelControl132);
            this.panelControl12.Controls.Add(this.labelControl131);
            this.panelControl12.Controls.Add(this.txtApprenticeLaborRateDT);
            this.panelControl12.Controls.Add(this.txtProjectEngineerLaborRateDT);
            this.panelControl12.Controls.Add(this.txtPremiumTimeLaborRateDT);
            this.panelControl12.Controls.Add(this.txtSafetyMeetingsLaborRateDT);
            this.panelControl12.Controls.Add(this.txtProjectManagerLaborRateDT);
            this.panelControl12.Controls.Add(this.txtSuperintendentLaborRateDT);
            this.panelControl12.Controls.Add(this.txtGeneralForemanLaborRateDT);
            this.panelControl12.Controls.Add(this.txtForemanLaborRateDT);
            this.panelControl12.Controls.Add(this.txtElectricianLaborRateDT);
            this.panelControl12.Controls.Add(this.txtApprenticeLaborRateOT);
            this.panelControl12.Controls.Add(this.txtProjectEngineerLaborRateOT);
            this.panelControl12.Controls.Add(this.txtPremiumTimeLaborRateOT);
            this.panelControl12.Controls.Add(this.txtSafetyMeetingsLaborRateOT);
            this.panelControl12.Controls.Add(this.txtProjectManagerLaborRateOT);
            this.panelControl12.Controls.Add(this.txtSuperintendentLaborRateOT);
            this.panelControl12.Controls.Add(this.txtGeneralForemanLaborRateOT);
            this.panelControl12.Controls.Add(this.txtForemanLaborRateOT);
            this.panelControl12.Controls.Add(this.txtElectricianLaborRateOT);
            this.panelControl12.Controls.Add(this.txtApprenticeLaborRate);
            this.panelControl12.Controls.Add(this.labelControl130);
            this.panelControl12.Controls.Add(this.labelControl120);
            this.panelControl12.Controls.Add(this.txtProjectEngineerLaborRate);
            this.panelControl12.Controls.Add(this.labelControl113);
            this.panelControl12.Controls.Add(this.txtPremiumTimeLaborRate);
            this.panelControl12.Controls.Add(this.txtSafetyMeetingsLaborRate);
            this.panelControl12.Controls.Add(this.labelControl114);
            this.panelControl12.Controls.Add(this.labelControl115);
            this.panelControl12.Controls.Add(this.txtProjectManagerLaborRate);
            this.panelControl12.Controls.Add(this.labelControl116);
            this.panelControl12.Controls.Add(this.txtSuperintendentLaborRate);
            this.panelControl12.Controls.Add(this.txtGeneralForemanLaborRate);
            this.panelControl12.Controls.Add(this.labelControl117);
            this.panelControl12.Controls.Add(this.labelControl118);
            this.panelControl12.Controls.Add(this.txtForemanLaborRate);
            this.panelControl12.Controls.Add(this.txtElectricianLaborRate);
            this.panelControl12.Controls.Add(this.labelControl119);
            this.panelControl12.Location = new System.Drawing.Point(17, 35);
            this.panelControl12.Name = "panelControl12";
            this.panelControl12.Size = new System.Drawing.Size(599, 282);
            this.panelControl12.TabIndex = 602;
            // 
            // txtBIMRateDT
            // 
            this.txtBIMRateDT.Location = new System.Drawing.Point(366, 19);
            this.txtBIMRateDT.Name = "txtBIMRateDT";
            this.txtBIMRateDT.Properties.DisplayFormat.FormatString = "c2";
            this.txtBIMRateDT.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtBIMRateDT.Properties.EditFormat.FormatString = "c2";
            this.txtBIMRateDT.Properties.EditFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtBIMRateDT.Properties.Mask.EditMask = "c2";
            this.txtBIMRateDT.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.txtBIMRateDT.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.txtBIMRateDT.Properties.MaxLength = 20;
            this.spellChecker1.SetShowSpellCheckMenu(this.txtBIMRateDT, true);
            this.txtBIMRateDT.Size = new System.Drawing.Size(73, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.txtBIMRateDT, optionsSpelling19);
            this.txtBIMRateDT.TabIndex = 36;
            this.txtBIMRateDT.EditValueChanged += new System.EventHandler(this.AllControls_EditValue);
            // 
            // txtBIMRateOT
            // 
            this.txtBIMRateOT.Location = new System.Drawing.Point(256, 19);
            this.txtBIMRateOT.Name = "txtBIMRateOT";
            this.txtBIMRateOT.Properties.DisplayFormat.FormatString = "c2";
            this.txtBIMRateOT.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtBIMRateOT.Properties.EditFormat.FormatString = "c2";
            this.txtBIMRateOT.Properties.EditFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtBIMRateOT.Properties.Mask.EditMask = "c2";
            this.txtBIMRateOT.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.txtBIMRateOT.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.txtBIMRateOT.Properties.MaxLength = 20;
            this.spellChecker1.SetShowSpellCheckMenu(this.txtBIMRateOT, true);
            this.txtBIMRateOT.Size = new System.Drawing.Size(73, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.txtBIMRateOT, optionsSpelling20);
            this.txtBIMRateOT.TabIndex = 27;
            this.txtBIMRateOT.EditValueChanged += new System.EventHandler(this.AllControls_EditValue);
            // 
            // txtBIMRate
            // 
            this.txtBIMRate.Location = new System.Drawing.Point(161, 19);
            this.txtBIMRate.Name = "txtBIMRate";
            this.txtBIMRate.Properties.DisplayFormat.FormatString = "c2";
            this.txtBIMRate.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtBIMRate.Properties.EditFormat.FormatString = "c2";
            this.txtBIMRate.Properties.EditFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtBIMRate.Properties.Mask.EditMask = "c2";
            this.txtBIMRate.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.txtBIMRate.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.txtBIMRate.Properties.MaxLength = 20;
            this.spellChecker1.SetShowSpellCheckMenu(this.txtBIMRate, true);
            this.txtBIMRate.Size = new System.Drawing.Size(73, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.txtBIMRate, optionsSpelling21);
            this.txtBIMRate.TabIndex = 18;
            this.txtBIMRate.EditValueChanged += new System.EventHandler(this.AllControls_EditValue);
            // 
            // labelControl134
            // 
            this.labelControl134.Location = new System.Drawing.Point(11, 22);
            this.labelControl134.Name = "labelControl134";
            this.labelControl134.Size = new System.Drawing.Size(48, 13);
            this.labelControl134.TabIndex = 610;
            this.labelControl134.Text = "BIM Rate:";
            // 
            // labelControl133
            // 
            this.labelControl133.Location = new System.Drawing.Point(393, 0);
            this.labelControl133.Name = "labelControl133";
            this.labelControl133.Size = new System.Drawing.Size(13, 13);
            this.labelControl133.TabIndex = 606;
            this.labelControl133.Text = "DT";
            // 
            // labelControl132
            // 
            this.labelControl132.Location = new System.Drawing.Point(285, 0);
            this.labelControl132.Name = "labelControl132";
            this.labelControl132.Size = new System.Drawing.Size(14, 13);
            this.labelControl132.TabIndex = 605;
            this.labelControl132.Text = "OT";
            // 
            // labelControl131
            // 
            this.labelControl131.Location = new System.Drawing.Point(188, 0);
            this.labelControl131.Name = "labelControl131";
            this.labelControl131.Size = new System.Drawing.Size(12, 13);
            this.labelControl131.TabIndex = 604;
            this.labelControl131.Text = "ST";
            // 
            // txtApprenticeLaborRateDT
            // 
            this.txtApprenticeLaborRateDT.Location = new System.Drawing.Point(366, 43);
            this.txtApprenticeLaborRateDT.Name = "txtApprenticeLaborRateDT";
            this.txtApprenticeLaborRateDT.Properties.DisplayFormat.FormatString = "c2";
            this.txtApprenticeLaborRateDT.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtApprenticeLaborRateDT.Properties.EditFormat.FormatString = "c2";
            this.txtApprenticeLaborRateDT.Properties.EditFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtApprenticeLaborRateDT.Properties.Mask.EditMask = "c2";
            this.txtApprenticeLaborRateDT.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.txtApprenticeLaborRateDT.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.txtApprenticeLaborRateDT.Properties.MaxLength = 20;
            this.spellChecker1.SetShowSpellCheckMenu(this.txtApprenticeLaborRateDT, true);
            this.txtApprenticeLaborRateDT.Size = new System.Drawing.Size(73, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.txtApprenticeLaborRateDT, optionsSpelling22);
            this.txtApprenticeLaborRateDT.TabIndex = 37;
            this.txtApprenticeLaborRateDT.EditValueChanged += new System.EventHandler(this.AllControls_EditValue);
            // 
            // txtProjectEngineerLaborRateDT
            // 
            this.txtProjectEngineerLaborRateDT.Location = new System.Drawing.Point(366, 199);
            this.txtProjectEngineerLaborRateDT.Name = "txtProjectEngineerLaborRateDT";
            this.txtProjectEngineerLaborRateDT.Properties.DisplayFormat.FormatString = "c2";
            this.txtProjectEngineerLaborRateDT.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtProjectEngineerLaborRateDT.Properties.EditFormat.FormatString = "c2";
            this.txtProjectEngineerLaborRateDT.Properties.EditFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtProjectEngineerLaborRateDT.Properties.Mask.EditMask = "c2";
            this.txtProjectEngineerLaborRateDT.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.txtProjectEngineerLaborRateDT.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.txtProjectEngineerLaborRateDT.Properties.MaxLength = 20;
            this.spellChecker1.SetShowSpellCheckMenu(this.txtProjectEngineerLaborRateDT, true);
            this.txtProjectEngineerLaborRateDT.Size = new System.Drawing.Size(73, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.txtProjectEngineerLaborRateDT, optionsSpelling23);
            this.txtProjectEngineerLaborRateDT.TabIndex = 43;
            this.txtProjectEngineerLaborRateDT.EditValueChanged += new System.EventHandler(this.AllControls_EditValue);
            // 
            // txtPremiumTimeLaborRateDT
            // 
            this.txtPremiumTimeLaborRateDT.Location = new System.Drawing.Point(366, 251);
            this.txtPremiumTimeLaborRateDT.Name = "txtPremiumTimeLaborRateDT";
            this.txtPremiumTimeLaborRateDT.Properties.DisplayFormat.FormatString = "c2";
            this.txtPremiumTimeLaborRateDT.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtPremiumTimeLaborRateDT.Properties.EditFormat.FormatString = "c2";
            this.txtPremiumTimeLaborRateDT.Properties.EditFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtPremiumTimeLaborRateDT.Properties.Mask.EditMask = "c2";
            this.txtPremiumTimeLaborRateDT.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.txtPremiumTimeLaborRateDT.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.txtPremiumTimeLaborRateDT.Properties.MaxLength = 20;
            this.spellChecker1.SetShowSpellCheckMenu(this.txtPremiumTimeLaborRateDT, true);
            this.txtPremiumTimeLaborRateDT.Size = new System.Drawing.Size(73, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.txtPremiumTimeLaborRateDT, optionsSpelling24);
            this.txtPremiumTimeLaborRateDT.TabIndex = 45;
            this.txtPremiumTimeLaborRateDT.EditValueChanged += new System.EventHandler(this.AllControls_EditValue);
            // 
            // txtSafetyMeetingsLaborRateDT
            // 
            this.txtSafetyMeetingsLaborRateDT.Location = new System.Drawing.Point(366, 225);
            this.txtSafetyMeetingsLaborRateDT.Name = "txtSafetyMeetingsLaborRateDT";
            this.txtSafetyMeetingsLaborRateDT.Properties.DisplayFormat.FormatString = "c2";
            this.txtSafetyMeetingsLaborRateDT.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtSafetyMeetingsLaborRateDT.Properties.EditFormat.FormatString = "c2";
            this.txtSafetyMeetingsLaborRateDT.Properties.EditFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtSafetyMeetingsLaborRateDT.Properties.Mask.EditMask = "c2";
            this.txtSafetyMeetingsLaborRateDT.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.txtSafetyMeetingsLaborRateDT.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.txtSafetyMeetingsLaborRateDT.Properties.MaxLength = 20;
            this.spellChecker1.SetShowSpellCheckMenu(this.txtSafetyMeetingsLaborRateDT, true);
            this.txtSafetyMeetingsLaborRateDT.Size = new System.Drawing.Size(73, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.txtSafetyMeetingsLaborRateDT, optionsSpelling25);
            this.txtSafetyMeetingsLaborRateDT.TabIndex = 44;
            this.txtSafetyMeetingsLaborRateDT.EditValueChanged += new System.EventHandler(this.AllControls_EditValue);
            // 
            // txtProjectManagerLaborRateDT
            // 
            this.txtProjectManagerLaborRateDT.Location = new System.Drawing.Point(366, 173);
            this.txtProjectManagerLaborRateDT.Name = "txtProjectManagerLaborRateDT";
            this.txtProjectManagerLaborRateDT.Properties.DisplayFormat.FormatString = "c2";
            this.txtProjectManagerLaborRateDT.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtProjectManagerLaborRateDT.Properties.EditFormat.FormatString = "c2";
            this.txtProjectManagerLaborRateDT.Properties.EditFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtProjectManagerLaborRateDT.Properties.Mask.EditMask = "c2";
            this.txtProjectManagerLaborRateDT.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.txtProjectManagerLaborRateDT.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.txtProjectManagerLaborRateDT.Properties.MaxLength = 20;
            this.spellChecker1.SetShowSpellCheckMenu(this.txtProjectManagerLaborRateDT, true);
            this.txtProjectManagerLaborRateDT.Size = new System.Drawing.Size(73, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.txtProjectManagerLaborRateDT, optionsSpelling26);
            this.txtProjectManagerLaborRateDT.TabIndex = 42;
            this.txtProjectManagerLaborRateDT.EditValueChanged += new System.EventHandler(this.AllControls_EditValue);
            // 
            // txtSuperintendentLaborRateDT
            // 
            this.txtSuperintendentLaborRateDT.Location = new System.Drawing.Point(366, 147);
            this.txtSuperintendentLaborRateDT.Name = "txtSuperintendentLaborRateDT";
            this.txtSuperintendentLaborRateDT.Properties.DisplayFormat.FormatString = "c2";
            this.txtSuperintendentLaborRateDT.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtSuperintendentLaborRateDT.Properties.EditFormat.FormatString = "c2";
            this.txtSuperintendentLaborRateDT.Properties.EditFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtSuperintendentLaborRateDT.Properties.Mask.EditMask = "c2";
            this.txtSuperintendentLaborRateDT.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.txtSuperintendentLaborRateDT.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.txtSuperintendentLaborRateDT.Properties.MaxLength = 20;
            this.spellChecker1.SetShowSpellCheckMenu(this.txtSuperintendentLaborRateDT, true);
            this.txtSuperintendentLaborRateDT.Size = new System.Drawing.Size(73, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.txtSuperintendentLaborRateDT, optionsSpelling27);
            this.txtSuperintendentLaborRateDT.TabIndex = 41;
            this.txtSuperintendentLaborRateDT.EditValueChanged += new System.EventHandler(this.AllControls_EditValue);
            // 
            // txtGeneralForemanLaborRateDT
            // 
            this.txtGeneralForemanLaborRateDT.Location = new System.Drawing.Point(366, 121);
            this.txtGeneralForemanLaborRateDT.Name = "txtGeneralForemanLaborRateDT";
            this.txtGeneralForemanLaborRateDT.Properties.DisplayFormat.FormatString = "c2";
            this.txtGeneralForemanLaborRateDT.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtGeneralForemanLaborRateDT.Properties.EditFormat.FormatString = "c2";
            this.txtGeneralForemanLaborRateDT.Properties.EditFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtGeneralForemanLaborRateDT.Properties.Mask.EditMask = "c2";
            this.txtGeneralForemanLaborRateDT.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.txtGeneralForemanLaborRateDT.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.txtGeneralForemanLaborRateDT.Properties.MaxLength = 20;
            this.spellChecker1.SetShowSpellCheckMenu(this.txtGeneralForemanLaborRateDT, true);
            this.txtGeneralForemanLaborRateDT.Size = new System.Drawing.Size(73, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.txtGeneralForemanLaborRateDT, optionsSpelling28);
            this.txtGeneralForemanLaborRateDT.TabIndex = 40;
            this.txtGeneralForemanLaborRateDT.EditValueChanged += new System.EventHandler(this.AllControls_EditValue);
            // 
            // txtForemanLaborRateDT
            // 
            this.txtForemanLaborRateDT.Location = new System.Drawing.Point(366, 95);
            this.txtForemanLaborRateDT.Name = "txtForemanLaborRateDT";
            this.txtForemanLaborRateDT.Properties.DisplayFormat.FormatString = "c2";
            this.txtForemanLaborRateDT.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtForemanLaborRateDT.Properties.EditFormat.FormatString = "c2";
            this.txtForemanLaborRateDT.Properties.EditFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtForemanLaborRateDT.Properties.Mask.EditMask = "c2";
            this.txtForemanLaborRateDT.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.txtForemanLaborRateDT.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.txtForemanLaborRateDT.Properties.MaxLength = 20;
            this.spellChecker1.SetShowSpellCheckMenu(this.txtForemanLaborRateDT, true);
            this.txtForemanLaborRateDT.Size = new System.Drawing.Size(73, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.txtForemanLaborRateDT, optionsSpelling29);
            this.txtForemanLaborRateDT.TabIndex = 39;
            this.txtForemanLaborRateDT.EditValueChanged += new System.EventHandler(this.AllControls_EditValue);
            // 
            // txtElectricianLaborRateDT
            // 
            this.txtElectricianLaborRateDT.Location = new System.Drawing.Point(366, 69);
            this.txtElectricianLaborRateDT.Name = "txtElectricianLaborRateDT";
            this.txtElectricianLaborRateDT.Properties.DisplayFormat.FormatString = "c2";
            this.txtElectricianLaborRateDT.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtElectricianLaborRateDT.Properties.EditFormat.FormatString = "c2";
            this.txtElectricianLaborRateDT.Properties.EditFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtElectricianLaborRateDT.Properties.Mask.EditMask = "c2";
            this.txtElectricianLaborRateDT.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.txtElectricianLaborRateDT.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.txtElectricianLaborRateDT.Properties.MaxLength = 20;
            this.spellChecker1.SetShowSpellCheckMenu(this.txtElectricianLaborRateDT, true);
            this.txtElectricianLaborRateDT.Size = new System.Drawing.Size(73, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.txtElectricianLaborRateDT, optionsSpelling30);
            this.txtElectricianLaborRateDT.TabIndex = 38;
            this.txtElectricianLaborRateDT.EditValueChanged += new System.EventHandler(this.AllControls_EditValue);
            // 
            // txtApprenticeLaborRateOT
            // 
            this.txtApprenticeLaborRateOT.Location = new System.Drawing.Point(256, 43);
            this.txtApprenticeLaborRateOT.Name = "txtApprenticeLaborRateOT";
            this.txtApprenticeLaborRateOT.Properties.DisplayFormat.FormatString = "c2";
            this.txtApprenticeLaborRateOT.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtApprenticeLaborRateOT.Properties.EditFormat.FormatString = "c2";
            this.txtApprenticeLaborRateOT.Properties.EditFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtApprenticeLaborRateOT.Properties.Mask.EditMask = "c2";
            this.txtApprenticeLaborRateOT.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.txtApprenticeLaborRateOT.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.txtApprenticeLaborRateOT.Properties.MaxLength = 20;
            this.spellChecker1.SetShowSpellCheckMenu(this.txtApprenticeLaborRateOT, true);
            this.txtApprenticeLaborRateOT.Size = new System.Drawing.Size(73, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.txtApprenticeLaborRateOT, optionsSpelling31);
            this.txtApprenticeLaborRateOT.TabIndex = 28;
            this.txtApprenticeLaborRateOT.EditValueChanged += new System.EventHandler(this.AllControls_EditValue);
            // 
            // txtProjectEngineerLaborRateOT
            // 
            this.txtProjectEngineerLaborRateOT.Location = new System.Drawing.Point(256, 199);
            this.txtProjectEngineerLaborRateOT.Name = "txtProjectEngineerLaborRateOT";
            this.txtProjectEngineerLaborRateOT.Properties.DisplayFormat.FormatString = "c2";
            this.txtProjectEngineerLaborRateOT.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtProjectEngineerLaborRateOT.Properties.EditFormat.FormatString = "c2";
            this.txtProjectEngineerLaborRateOT.Properties.EditFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtProjectEngineerLaborRateOT.Properties.Mask.EditMask = "c2";
            this.txtProjectEngineerLaborRateOT.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.txtProjectEngineerLaborRateOT.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.txtProjectEngineerLaborRateOT.Properties.MaxLength = 20;
            this.spellChecker1.SetShowSpellCheckMenu(this.txtProjectEngineerLaborRateOT, true);
            this.txtProjectEngineerLaborRateOT.Size = new System.Drawing.Size(73, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.txtProjectEngineerLaborRateOT, optionsSpelling32);
            this.txtProjectEngineerLaborRateOT.TabIndex = 34;
            this.txtProjectEngineerLaborRateOT.EditValueChanged += new System.EventHandler(this.AllControls_EditValue);
            // 
            // txtPremiumTimeLaborRateOT
            // 
            this.txtPremiumTimeLaborRateOT.Location = new System.Drawing.Point(256, 251);
            this.txtPremiumTimeLaborRateOT.Name = "txtPremiumTimeLaborRateOT";
            this.txtPremiumTimeLaborRateOT.Properties.DisplayFormat.FormatString = "c2";
            this.txtPremiumTimeLaborRateOT.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtPremiumTimeLaborRateOT.Properties.EditFormat.FormatString = "c2";
            this.txtPremiumTimeLaborRateOT.Properties.EditFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtPremiumTimeLaborRateOT.Properties.Mask.EditMask = "c2";
            this.txtPremiumTimeLaborRateOT.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.txtPremiumTimeLaborRateOT.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.txtPremiumTimeLaborRateOT.Properties.MaxLength = 20;
            this.spellChecker1.SetShowSpellCheckMenu(this.txtPremiumTimeLaborRateOT, true);
            this.txtPremiumTimeLaborRateOT.Size = new System.Drawing.Size(73, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.txtPremiumTimeLaborRateOT, optionsSpelling33);
            this.txtPremiumTimeLaborRateOT.TabIndex = 36;
            this.txtPremiumTimeLaborRateOT.EditValueChanged += new System.EventHandler(this.AllControls_EditValue);
            // 
            // txtSafetyMeetingsLaborRateOT
            // 
            this.txtSafetyMeetingsLaborRateOT.Location = new System.Drawing.Point(256, 225);
            this.txtSafetyMeetingsLaborRateOT.Name = "txtSafetyMeetingsLaborRateOT";
            this.txtSafetyMeetingsLaborRateOT.Properties.DisplayFormat.FormatString = "c2";
            this.txtSafetyMeetingsLaborRateOT.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtSafetyMeetingsLaborRateOT.Properties.EditFormat.FormatString = "c2";
            this.txtSafetyMeetingsLaborRateOT.Properties.EditFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtSafetyMeetingsLaborRateOT.Properties.Mask.EditMask = "c2";
            this.txtSafetyMeetingsLaborRateOT.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.txtSafetyMeetingsLaborRateOT.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.txtSafetyMeetingsLaborRateOT.Properties.MaxLength = 20;
            this.spellChecker1.SetShowSpellCheckMenu(this.txtSafetyMeetingsLaborRateOT, true);
            this.txtSafetyMeetingsLaborRateOT.Size = new System.Drawing.Size(73, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.txtSafetyMeetingsLaborRateOT, optionsSpelling34);
            this.txtSafetyMeetingsLaborRateOT.TabIndex = 35;
            this.txtSafetyMeetingsLaborRateOT.EditValueChanged += new System.EventHandler(this.AllControls_EditValue);
            // 
            // txtProjectManagerLaborRateOT
            // 
            this.txtProjectManagerLaborRateOT.Location = new System.Drawing.Point(256, 173);
            this.txtProjectManagerLaborRateOT.Name = "txtProjectManagerLaborRateOT";
            this.txtProjectManagerLaborRateOT.Properties.DisplayFormat.FormatString = "c2";
            this.txtProjectManagerLaborRateOT.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtProjectManagerLaborRateOT.Properties.EditFormat.FormatString = "c2";
            this.txtProjectManagerLaborRateOT.Properties.EditFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtProjectManagerLaborRateOT.Properties.Mask.EditMask = "c2";
            this.txtProjectManagerLaborRateOT.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.txtProjectManagerLaborRateOT.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.txtProjectManagerLaborRateOT.Properties.MaxLength = 20;
            this.spellChecker1.SetShowSpellCheckMenu(this.txtProjectManagerLaborRateOT, true);
            this.txtProjectManagerLaborRateOT.Size = new System.Drawing.Size(73, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.txtProjectManagerLaborRateOT, optionsSpelling35);
            this.txtProjectManagerLaborRateOT.TabIndex = 33;
            this.txtProjectManagerLaborRateOT.EditValueChanged += new System.EventHandler(this.AllControls_EditValue);
            // 
            // txtSuperintendentLaborRateOT
            // 
            this.txtSuperintendentLaborRateOT.Location = new System.Drawing.Point(256, 147);
            this.txtSuperintendentLaborRateOT.Name = "txtSuperintendentLaborRateOT";
            this.txtSuperintendentLaborRateOT.Properties.DisplayFormat.FormatString = "c2";
            this.txtSuperintendentLaborRateOT.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtSuperintendentLaborRateOT.Properties.EditFormat.FormatString = "c2";
            this.txtSuperintendentLaborRateOT.Properties.EditFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtSuperintendentLaborRateOT.Properties.Mask.EditMask = "c2";
            this.txtSuperintendentLaborRateOT.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.txtSuperintendentLaborRateOT.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.txtSuperintendentLaborRateOT.Properties.MaxLength = 20;
            this.spellChecker1.SetShowSpellCheckMenu(this.txtSuperintendentLaborRateOT, true);
            this.txtSuperintendentLaborRateOT.Size = new System.Drawing.Size(73, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.txtSuperintendentLaborRateOT, optionsSpelling36);
            this.txtSuperintendentLaborRateOT.TabIndex = 32;
            this.txtSuperintendentLaborRateOT.EditValueChanged += new System.EventHandler(this.AllControls_EditValue);
            // 
            // txtGeneralForemanLaborRateOT
            // 
            this.txtGeneralForemanLaborRateOT.Location = new System.Drawing.Point(256, 121);
            this.txtGeneralForemanLaborRateOT.Name = "txtGeneralForemanLaborRateOT";
            this.txtGeneralForemanLaborRateOT.Properties.DisplayFormat.FormatString = "c2";
            this.txtGeneralForemanLaborRateOT.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtGeneralForemanLaborRateOT.Properties.EditFormat.FormatString = "c2";
            this.txtGeneralForemanLaborRateOT.Properties.EditFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtGeneralForemanLaborRateOT.Properties.Mask.EditMask = "c2";
            this.txtGeneralForemanLaborRateOT.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.txtGeneralForemanLaborRateOT.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.txtGeneralForemanLaborRateOT.Properties.MaxLength = 20;
            this.spellChecker1.SetShowSpellCheckMenu(this.txtGeneralForemanLaborRateOT, true);
            this.txtGeneralForemanLaborRateOT.Size = new System.Drawing.Size(73, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.txtGeneralForemanLaborRateOT, optionsSpelling37);
            this.txtGeneralForemanLaborRateOT.TabIndex = 31;
            this.txtGeneralForemanLaborRateOT.EditValueChanged += new System.EventHandler(this.AllControls_EditValue);
            // 
            // txtForemanLaborRateOT
            // 
            this.txtForemanLaborRateOT.Location = new System.Drawing.Point(256, 95);
            this.txtForemanLaborRateOT.Name = "txtForemanLaborRateOT";
            this.txtForemanLaborRateOT.Properties.DisplayFormat.FormatString = "c2";
            this.txtForemanLaborRateOT.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtForemanLaborRateOT.Properties.EditFormat.FormatString = "c2";
            this.txtForemanLaborRateOT.Properties.EditFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtForemanLaborRateOT.Properties.Mask.EditMask = "c2";
            this.txtForemanLaborRateOT.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.txtForemanLaborRateOT.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.txtForemanLaborRateOT.Properties.MaxLength = 20;
            this.spellChecker1.SetShowSpellCheckMenu(this.txtForemanLaborRateOT, true);
            this.txtForemanLaborRateOT.Size = new System.Drawing.Size(73, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.txtForemanLaborRateOT, optionsSpelling38);
            this.txtForemanLaborRateOT.TabIndex = 30;
            this.txtForemanLaborRateOT.EditValueChanged += new System.EventHandler(this.AllControls_EditValue);
            // 
            // txtElectricianLaborRateOT
            // 
            this.txtElectricianLaborRateOT.Location = new System.Drawing.Point(256, 69);
            this.txtElectricianLaborRateOT.Name = "txtElectricianLaborRateOT";
            this.txtElectricianLaborRateOT.Properties.DisplayFormat.FormatString = "c2";
            this.txtElectricianLaborRateOT.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtElectricianLaborRateOT.Properties.EditFormat.FormatString = "c2";
            this.txtElectricianLaborRateOT.Properties.EditFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtElectricianLaborRateOT.Properties.Mask.EditMask = "c2";
            this.txtElectricianLaborRateOT.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.txtElectricianLaborRateOT.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.txtElectricianLaborRateOT.Properties.MaxLength = 20;
            this.spellChecker1.SetShowSpellCheckMenu(this.txtElectricianLaborRateOT, true);
            this.txtElectricianLaborRateOT.Size = new System.Drawing.Size(73, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.txtElectricianLaborRateOT, optionsSpelling39);
            this.txtElectricianLaborRateOT.TabIndex = 29;
            this.txtElectricianLaborRateOT.EditValueChanged += new System.EventHandler(this.AllControls_EditValue);
            // 
            // txtApprenticeLaborRate
            // 
            this.txtApprenticeLaborRate.Location = new System.Drawing.Point(161, 43);
            this.txtApprenticeLaborRate.Name = "txtApprenticeLaborRate";
            this.txtApprenticeLaborRate.Properties.DisplayFormat.FormatString = "c2";
            this.txtApprenticeLaborRate.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtApprenticeLaborRate.Properties.EditFormat.FormatString = "c2";
            this.txtApprenticeLaborRate.Properties.EditFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtApprenticeLaborRate.Properties.Mask.EditMask = "c2";
            this.txtApprenticeLaborRate.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.txtApprenticeLaborRate.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.txtApprenticeLaborRate.Properties.MaxLength = 20;
            this.spellChecker1.SetShowSpellCheckMenu(this.txtApprenticeLaborRate, true);
            this.txtApprenticeLaborRate.Size = new System.Drawing.Size(73, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.txtApprenticeLaborRate, optionsSpelling40);
            this.txtApprenticeLaborRate.TabIndex = 19;
            this.txtApprenticeLaborRate.EditValueChanged += new System.EventHandler(this.AllControls_EditValue);
            // 
            // labelControl130
            // 
            this.labelControl130.Location = new System.Drawing.Point(11, 46);
            this.labelControl130.Name = "labelControl130";
            this.labelControl130.Size = new System.Drawing.Size(112, 13);
            this.labelControl130.TabIndex = 585;
            this.labelControl130.Text = "Apprentice Labor Rate:";
            // 
            // labelControl120
            // 
            this.labelControl120.Location = new System.Drawing.Point(11, 202);
            this.labelControl120.Name = "labelControl120";
            this.labelControl120.Size = new System.Drawing.Size(139, 13);
            this.labelControl120.TabIndex = 584;
            this.labelControl120.Text = "Project Engineer Labor Rate:";
            // 
            // txtProjectEngineerLaborRate
            // 
            this.txtProjectEngineerLaborRate.Location = new System.Drawing.Point(161, 199);
            this.txtProjectEngineerLaborRate.Name = "txtProjectEngineerLaborRate";
            this.txtProjectEngineerLaborRate.Properties.DisplayFormat.FormatString = "c2";
            this.txtProjectEngineerLaborRate.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtProjectEngineerLaborRate.Properties.EditFormat.FormatString = "c2";
            this.txtProjectEngineerLaborRate.Properties.EditFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtProjectEngineerLaborRate.Properties.Mask.EditMask = "c2";
            this.txtProjectEngineerLaborRate.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.txtProjectEngineerLaborRate.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.txtProjectEngineerLaborRate.Properties.MaxLength = 20;
            this.spellChecker1.SetShowSpellCheckMenu(this.txtProjectEngineerLaborRate, true);
            this.txtProjectEngineerLaborRate.Size = new System.Drawing.Size(73, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.txtProjectEngineerLaborRate, optionsSpelling41);
            this.txtProjectEngineerLaborRate.TabIndex = 25;
            this.txtProjectEngineerLaborRate.EditValueChanged += new System.EventHandler(this.AllControls_EditValue);
            // 
            // labelControl113
            // 
            this.labelControl113.Location = new System.Drawing.Point(11, 252);
            this.labelControl113.Name = "labelControl113";
            this.labelControl113.Size = new System.Drawing.Size(125, 13);
            this.labelControl113.TabIndex = 582;
            this.labelControl113.Text = "Premium Time Labor Rate:";
            // 
            // txtPremiumTimeLaborRate
            // 
            this.txtPremiumTimeLaborRate.Location = new System.Drawing.Point(161, 251);
            this.txtPremiumTimeLaborRate.Name = "txtPremiumTimeLaborRate";
            this.txtPremiumTimeLaborRate.Properties.DisplayFormat.FormatString = "c2";
            this.txtPremiumTimeLaborRate.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtPremiumTimeLaborRate.Properties.EditFormat.FormatString = "c2";
            this.txtPremiumTimeLaborRate.Properties.EditFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtPremiumTimeLaborRate.Properties.Mask.EditMask = "c2";
            this.txtPremiumTimeLaborRate.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.txtPremiumTimeLaborRate.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.txtPremiumTimeLaborRate.Properties.MaxLength = 20;
            this.spellChecker1.SetShowSpellCheckMenu(this.txtPremiumTimeLaborRate, true);
            this.txtPremiumTimeLaborRate.Size = new System.Drawing.Size(73, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.txtPremiumTimeLaborRate, optionsSpelling42);
            this.txtPremiumTimeLaborRate.TabIndex = 27;
            this.txtPremiumTimeLaborRate.EditValueChanged += new System.EventHandler(this.AllControls_EditValue);
            // 
            // txtSafetyMeetingsLaborRate
            // 
            this.txtSafetyMeetingsLaborRate.Location = new System.Drawing.Point(161, 225);
            this.txtSafetyMeetingsLaborRate.Name = "txtSafetyMeetingsLaborRate";
            this.txtSafetyMeetingsLaborRate.Properties.DisplayFormat.FormatString = "c2";
            this.txtSafetyMeetingsLaborRate.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtSafetyMeetingsLaborRate.Properties.EditFormat.FormatString = "c2";
            this.txtSafetyMeetingsLaborRate.Properties.EditFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtSafetyMeetingsLaborRate.Properties.Mask.EditMask = "c2";
            this.txtSafetyMeetingsLaborRate.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.txtSafetyMeetingsLaborRate.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.txtSafetyMeetingsLaborRate.Properties.MaxLength = 20;
            this.spellChecker1.SetShowSpellCheckMenu(this.txtSafetyMeetingsLaborRate, true);
            this.txtSafetyMeetingsLaborRate.Size = new System.Drawing.Size(73, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.txtSafetyMeetingsLaborRate, optionsSpelling43);
            this.txtSafetyMeetingsLaborRate.TabIndex = 26;
            this.txtSafetyMeetingsLaborRate.EditValueChanged += new System.EventHandler(this.AllControls_EditValue);
            // 
            // labelControl114
            // 
            this.labelControl114.Location = new System.Drawing.Point(11, 228);
            this.labelControl114.Name = "labelControl114";
            this.labelControl114.Size = new System.Drawing.Size(138, 13);
            this.labelControl114.TabIndex = 580;
            this.labelControl114.Text = "Safety Meetings Labor Rate:";
            // 
            // labelControl115
            // 
            this.labelControl115.Location = new System.Drawing.Point(11, 174);
            this.labelControl115.Name = "labelControl115";
            this.labelControl115.Size = new System.Drawing.Size(139, 13);
            this.labelControl115.TabIndex = 578;
            this.labelControl115.Text = "Project Manager Labor Rate:";
            // 
            // txtProjectManagerLaborRate
            // 
            this.txtProjectManagerLaborRate.Location = new System.Drawing.Point(161, 173);
            this.txtProjectManagerLaborRate.Name = "txtProjectManagerLaborRate";
            this.txtProjectManagerLaborRate.Properties.DisplayFormat.FormatString = "c2";
            this.txtProjectManagerLaborRate.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtProjectManagerLaborRate.Properties.EditFormat.FormatString = "c2";
            this.txtProjectManagerLaborRate.Properties.EditFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtProjectManagerLaborRate.Properties.Mask.EditMask = "c2";
            this.txtProjectManagerLaborRate.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.txtProjectManagerLaborRate.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.txtProjectManagerLaborRate.Properties.MaxLength = 20;
            this.spellChecker1.SetShowSpellCheckMenu(this.txtProjectManagerLaborRate, true);
            this.txtProjectManagerLaborRate.Size = new System.Drawing.Size(73, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.txtProjectManagerLaborRate, optionsSpelling44);
            this.txtProjectManagerLaborRate.TabIndex = 24;
            this.txtProjectManagerLaborRate.EditValueChanged += new System.EventHandler(this.AllControls_EditValue);
            // 
            // labelControl116
            // 
            this.labelControl116.Location = new System.Drawing.Point(11, 148);
            this.labelControl116.Name = "labelControl116";
            this.labelControl116.Size = new System.Drawing.Size(134, 13);
            this.labelControl116.TabIndex = 576;
            this.labelControl116.Text = "Superintendent Labor Rate:";
            // 
            // txtSuperintendentLaborRate
            // 
            this.txtSuperintendentLaborRate.Location = new System.Drawing.Point(161, 147);
            this.txtSuperintendentLaborRate.Name = "txtSuperintendentLaborRate";
            this.txtSuperintendentLaborRate.Properties.DisplayFormat.FormatString = "c2";
            this.txtSuperintendentLaborRate.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtSuperintendentLaborRate.Properties.EditFormat.FormatString = "c2";
            this.txtSuperintendentLaborRate.Properties.EditFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtSuperintendentLaborRate.Properties.Mask.EditMask = "c2";
            this.txtSuperintendentLaborRate.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.txtSuperintendentLaborRate.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.txtSuperintendentLaborRate.Properties.MaxLength = 20;
            this.spellChecker1.SetShowSpellCheckMenu(this.txtSuperintendentLaborRate, true);
            this.txtSuperintendentLaborRate.Size = new System.Drawing.Size(73, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.txtSuperintendentLaborRate, optionsSpelling45);
            this.txtSuperintendentLaborRate.TabIndex = 23;
            this.txtSuperintendentLaborRate.EditValueChanged += new System.EventHandler(this.AllControls_EditValue);
            // 
            // txtGeneralForemanLaborRate
            // 
            this.txtGeneralForemanLaborRate.Location = new System.Drawing.Point(161, 121);
            this.txtGeneralForemanLaborRate.Name = "txtGeneralForemanLaborRate";
            this.txtGeneralForemanLaborRate.Properties.DisplayFormat.FormatString = "c2";
            this.txtGeneralForemanLaborRate.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtGeneralForemanLaborRate.Properties.EditFormat.FormatString = "c2";
            this.txtGeneralForemanLaborRate.Properties.EditFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtGeneralForemanLaborRate.Properties.Mask.EditMask = "c2";
            this.txtGeneralForemanLaborRate.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.txtGeneralForemanLaborRate.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.txtGeneralForemanLaborRate.Properties.MaxLength = 20;
            this.spellChecker1.SetShowSpellCheckMenu(this.txtGeneralForemanLaborRate, true);
            this.txtGeneralForemanLaborRate.Size = new System.Drawing.Size(73, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.txtGeneralForemanLaborRate, optionsSpelling46);
            this.txtGeneralForemanLaborRate.TabIndex = 22;
            this.txtGeneralForemanLaborRate.EditValueChanged += new System.EventHandler(this.AllControls_EditValue);
            // 
            // labelControl117
            // 
            this.labelControl117.Location = new System.Drawing.Point(11, 124);
            this.labelControl117.Name = "labelControl117";
            this.labelControl117.Size = new System.Drawing.Size(142, 13);
            this.labelControl117.TabIndex = 574;
            this.labelControl117.Text = "General Foreman Labor Rate:";
            // 
            // labelControl118
            // 
            this.labelControl118.Location = new System.Drawing.Point(11, 96);
            this.labelControl118.Name = "labelControl118";
            this.labelControl118.Size = new System.Drawing.Size(102, 13);
            this.labelControl118.TabIndex = 572;
            this.labelControl118.Text = "Foreman Labor Rate:";
            // 
            // txtForemanLaborRate
            // 
            this.txtForemanLaborRate.Location = new System.Drawing.Point(161, 95);
            this.txtForemanLaborRate.Name = "txtForemanLaborRate";
            this.txtForemanLaborRate.Properties.DisplayFormat.FormatString = "c2";
            this.txtForemanLaborRate.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtForemanLaborRate.Properties.EditFormat.FormatString = "c2";
            this.txtForemanLaborRate.Properties.EditFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtForemanLaborRate.Properties.Mask.EditMask = "c2";
            this.txtForemanLaborRate.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.txtForemanLaborRate.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.txtForemanLaborRate.Properties.MaxLength = 20;
            this.spellChecker1.SetShowSpellCheckMenu(this.txtForemanLaborRate, true);
            this.txtForemanLaborRate.Size = new System.Drawing.Size(73, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.txtForemanLaborRate, optionsSpelling47);
            this.txtForemanLaborRate.TabIndex = 21;
            this.txtForemanLaborRate.EditValueChanged += new System.EventHandler(this.AllControls_EditValue);
            // 
            // txtElectricianLaborRate
            // 
            this.txtElectricianLaborRate.Location = new System.Drawing.Point(161, 69);
            this.txtElectricianLaborRate.Name = "txtElectricianLaborRate";
            this.txtElectricianLaborRate.Properties.DisplayFormat.FormatString = "c2";
            this.txtElectricianLaborRate.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtElectricianLaborRate.Properties.EditFormat.FormatString = "c2";
            this.txtElectricianLaborRate.Properties.EditFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtElectricianLaborRate.Properties.Mask.EditMask = "c2";
            this.txtElectricianLaborRate.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.txtElectricianLaborRate.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.txtElectricianLaborRate.Properties.MaxLength = 20;
            this.spellChecker1.SetShowSpellCheckMenu(this.txtElectricianLaborRate, true);
            this.txtElectricianLaborRate.Size = new System.Drawing.Size(73, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.txtElectricianLaborRate, optionsSpelling48);
            this.txtElectricianLaborRate.TabIndex = 20;
            this.txtElectricianLaborRate.EditValueChanged += new System.EventHandler(this.AllControls_EditValue);
            // 
            // labelControl119
            // 
            this.labelControl119.Location = new System.Drawing.Point(11, 72);
            this.labelControl119.Name = "labelControl119";
            this.labelControl119.Size = new System.Drawing.Size(108, 13);
            this.labelControl119.TabIndex = 570;
            this.labelControl119.Text = "Electrician Labor Rate:";
            // 
            // pagContactDefaultValues
            // 
            this.pagContactDefaultValues.Controls.Add(this.labelControl121);
            this.pagContactDefaultValues.Controls.Add(this.panelControl13);
            this.pagContactDefaultValues.Name = "pagContactDefaultValues";
            this.pagContactDefaultValues.Size = new System.Drawing.Size(852, 352);
            this.pagContactDefaultValues.Text = "Contact Default Values";
            // 
            // labelControl121
            // 
            this.labelControl121.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))));
            this.labelControl121.Location = new System.Drawing.Point(17, 16);
            this.labelControl121.Name = "labelControl121";
            this.labelControl121.Size = new System.Drawing.Size(88, 13);
            this.labelControl121.TabIndex = 607;
            this.labelControl121.Text = "Contact Default";
            // 
            // panelControl13
            // 
            this.panelControl13.Controls.Add(this.cboForeman);
            this.panelControl13.Controls.Add(this.labelControl128);
            this.panelControl13.Controls.Add(this.labelControl126);
            this.panelControl13.Controls.Add(this.cboDefaultFrom);
            this.panelControl13.Controls.Add(this.cboChangeOrderDefaultContact);
            this.panelControl13.Controls.Add(this.cboRFIDefaultContact);
            this.panelControl13.Controls.Add(this.labelControl122);
            this.panelControl13.Controls.Add(this.txtChangeOrderDefaultContactCompany);
            this.panelControl13.Controls.Add(this.labelControl123);
            this.panelControl13.Controls.Add(this.labelControl124);
            this.panelControl13.Controls.Add(this.txtRFIDefaultContactCompany);
            this.panelControl13.Controls.Add(this.labelControl125);
            this.panelControl13.Location = new System.Drawing.Point(17, 35);
            this.panelControl13.Name = "panelControl13";
            this.panelControl13.Size = new System.Drawing.Size(506, 221);
            this.panelControl13.TabIndex = 606;
            // 
            // cboForeman
            // 
            this.cboForeman.Location = new System.Drawing.Point(214, 140);
            this.cboForeman.Name = "cboForeman";
            this.cboForeman.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.cboForeman.Properties.NullText = "";
            this.cboForeman.Properties.TextEditStyle = DevExpress.XtraEditors.Controls.TextEditStyles.Standard;
            this.cboForeman.Size = new System.Drawing.Size(260, 20);
            this.cboForeman.TabIndex = 582;
            this.cboForeman.EditValueChanged += new System.EventHandler(this.AllControls_EditValue);
            // 
            // labelControl128
            // 
            this.labelControl128.Location = new System.Drawing.Point(8, 143);
            this.labelControl128.Name = "labelControl128";
            this.labelControl128.Size = new System.Drawing.Size(46, 13);
            this.labelControl128.TabIndex = 581;
            this.labelControl128.Text = "Foreman:";
            // 
            // labelControl126
            // 
            this.labelControl126.Location = new System.Drawing.Point(5, 115);
            this.labelControl126.Name = "labelControl126";
            this.labelControl126.Size = new System.Drawing.Size(83, 13);
            this.labelControl126.TabIndex = 580;
            this.labelControl126.Text = "Project Manager:";
            // 
            // cboDefaultFrom
            // 
            this.cboDefaultFrom.Location = new System.Drawing.Point(214, 112);
            this.cboDefaultFrom.Name = "cboDefaultFrom";
            this.cboDefaultFrom.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.cboDefaultFrom.Properties.NullText = "";
            this.cboDefaultFrom.Properties.TextEditStyle = DevExpress.XtraEditors.Controls.TextEditStyles.Standard;
            this.cboDefaultFrom.Size = new System.Drawing.Size(260, 20);
            this.cboDefaultFrom.TabIndex = 579;
            this.cboDefaultFrom.EditValueChanged += new System.EventHandler(this.AllControls_EditValue);
            // 
            // cboChangeOrderDefaultContact
            // 
            this.cboChangeOrderDefaultContact.Location = new System.Drawing.Point(214, 60);
            this.cboChangeOrderDefaultContact.Name = "cboChangeOrderDefaultContact";
            this.cboChangeOrderDefaultContact.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.cboChangeOrderDefaultContact.Properties.NullText = "";
            this.cboChangeOrderDefaultContact.Properties.TextEditStyle = DevExpress.XtraEditors.Controls.TextEditStyles.Standard;
            this.cboChangeOrderDefaultContact.Size = new System.Drawing.Size(260, 20);
            this.cboChangeOrderDefaultContact.TabIndex = 578;
            this.cboChangeOrderDefaultContact.EditValueChanged += new System.EventHandler(this.cboChangeOrderDefaultContact_EditValueChanged_1);
            // 
            // cboRFIDefaultContact
            // 
            this.cboRFIDefaultContact.Location = new System.Drawing.Point(214, 10);
            this.cboRFIDefaultContact.Name = "cboRFIDefaultContact";
            this.cboRFIDefaultContact.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.cboRFIDefaultContact.Properties.NullText = "";
            this.cboRFIDefaultContact.Properties.TextEditStyle = DevExpress.XtraEditors.Controls.TextEditStyles.Standard;
            this.cboRFIDefaultContact.Size = new System.Drawing.Size(260, 20);
            this.cboRFIDefaultContact.TabIndex = 577;
            this.cboRFIDefaultContact.EditValueChanged += new System.EventHandler(this.cboRFIDefaultContact_EditValueChanged);
            // 
            // labelControl122
            // 
            this.labelControl122.Location = new System.Drawing.Point(5, 87);
            this.labelControl122.Name = "labelControl122";
            this.labelControl122.Size = new System.Drawing.Size(199, 13);
            this.labelControl122.TabIndex = 576;
            this.labelControl122.Text = "Change Order Default Contact Company:";
            // 
            // txtChangeOrderDefaultContactCompany
            // 
            this.txtChangeOrderDefaultContactCompany.Location = new System.Drawing.Point(214, 86);
            this.txtChangeOrderDefaultContactCompany.Name = "txtChangeOrderDefaultContactCompany";
            this.txtChangeOrderDefaultContactCompany.Properties.MaxLength = 100;
            this.txtChangeOrderDefaultContactCompany.Properties.ReadOnly = true;
            this.spellChecker1.SetShowSpellCheckMenu(this.txtChangeOrderDefaultContactCompany, true);
            this.txtChangeOrderDefaultContactCompany.Size = new System.Drawing.Size(260, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.txtChangeOrderDefaultContactCompany, optionsSpelling49);
            this.txtChangeOrderDefaultContactCompany.TabIndex = 23;
            // 
            // labelControl123
            // 
            this.labelControl123.Location = new System.Drawing.Point(5, 63);
            this.labelControl123.Name = "labelControl123";
            this.labelControl123.Size = new System.Drawing.Size(151, 13);
            this.labelControl123.TabIndex = 574;
            this.labelControl123.Text = "Change Order Default Contact:";
            // 
            // labelControl124
            // 
            this.labelControl124.Location = new System.Drawing.Point(5, 35);
            this.labelControl124.Name = "labelControl124";
            this.labelControl124.Size = new System.Drawing.Size(148, 13);
            this.labelControl124.TabIndex = 572;
            this.labelControl124.Text = "RFI Default Contact Company:";
            // 
            // txtRFIDefaultContactCompany
            // 
            this.txtRFIDefaultContactCompany.Location = new System.Drawing.Point(214, 34);
            this.txtRFIDefaultContactCompany.Name = "txtRFIDefaultContactCompany";
            this.txtRFIDefaultContactCompany.Properties.MaxLength = 100;
            this.txtRFIDefaultContactCompany.Properties.ReadOnly = true;
            this.spellChecker1.SetShowSpellCheckMenu(this.txtRFIDefaultContactCompany, true);
            this.txtRFIDefaultContactCompany.Size = new System.Drawing.Size(260, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.txtRFIDefaultContactCompany, optionsSpelling50);
            this.txtRFIDefaultContactCompany.TabIndex = 21;
            // 
            // labelControl125
            // 
            this.labelControl125.Location = new System.Drawing.Point(5, 11);
            this.labelControl125.Name = "labelControl125";
            this.labelControl125.Size = new System.Drawing.Size(100, 13);
            this.labelControl125.TabIndex = 570;
            this.labelControl125.Text = "RFI Default Contact:";
            // 
            // pagMajorPONote
            // 
            this.pagMajorPONote.Controls.Add(this.MajorPONote);
            this.pagMajorPONote.Controls.Add(this.txtMajorPONote);
            this.pagMajorPONote.Name = "pagMajorPONote";
            this.pagMajorPONote.Size = new System.Drawing.Size(852, 352);
            this.pagMajorPONote.Text = "Major PO Note";
            // 
            // MajorPONote
            // 
            this.MajorPONote.Cursor = System.Windows.Forms.Cursors.Hand;
            this.MajorPONote.Location = new System.Drawing.Point(13, 21);
            this.MajorPONote.Name = "MajorPONote";
            this.MajorPONote.Size = new System.Drawing.Size(70, 13);
            this.MajorPONote.TabIndex = 574;
            this.MajorPONote.Text = "Major PO Note";
            this.MajorPONote.Click += new System.EventHandler(this.MajorPONote_Click);
            // 
            // txtMajorPONote
            // 
            this.txtMajorPONote.Location = new System.Drawing.Point(13, 40);
            this.txtMajorPONote.Name = "txtMajorPONote";
            this.txtMajorPONote.ReadOnly = true;
            this.txtMajorPONote.Size = new System.Drawing.Size(800, 291);
            this.txtMajorPONote.TabIndex = 573;
            this.txtMajorPONote.OnTextChanged += new ControlsLibrary.TextChangedHandler(this.txtMajorPONote_OnTextChanged);
            // 
            // pagSmallPONote
            // 
            this.pagSmallPONote.Controls.Add(this.SmallPONote);
            this.pagSmallPONote.Controls.Add(this.txtSmallPONote);
            this.pagSmallPONote.Name = "pagSmallPONote";
            this.pagSmallPONote.Size = new System.Drawing.Size(852, 352);
            this.pagSmallPONote.Text = "Small PO Note";
            // 
            // SmallPONote
            // 
            this.SmallPONote.Cursor = System.Windows.Forms.Cursors.Hand;
            this.SmallPONote.Location = new System.Drawing.Point(14, 21);
            this.SmallPONote.Name = "SmallPONote";
            this.SmallPONote.Size = new System.Drawing.Size(67, 13);
            this.SmallPONote.TabIndex = 576;
            this.SmallPONote.Text = "Small PO Note";
            this.SmallPONote.Click += new System.EventHandler(this.SmallPONote_Click);
            // 
            // txtSmallPONote
            // 
            this.txtSmallPONote.Location = new System.Drawing.Point(14, 40);
            this.txtSmallPONote.Name = "txtSmallPONote";
            this.txtSmallPONote.ReadOnly = true;
            this.txtSmallPONote.Size = new System.Drawing.Size(793, 291);
            this.txtSmallPONote.TabIndex = 575;
            this.txtSmallPONote.OnTextChanged += new ControlsLibrary.TextChangedHandler(this.txtSmallPONote_OnTextChanged);
            // 
            // pagSubmittalSpec
            // 
            this.pagSubmittalSpec.Controls.Add(this.grdSubmittal);
            this.pagSubmittalSpec.Name = "pagSubmittalSpec";
            this.pagSubmittalSpec.Size = new System.Drawing.Size(852, 352);
            this.pagSubmittalSpec.Text = "Submittal Spec";
            // 
            // grdSubmittal
            // 
            this.grdSubmittal.Dock = System.Windows.Forms.DockStyle.Fill;
            this.grdSubmittal.Location = new System.Drawing.Point(0, 0);
            this.grdSubmittal.MainView = this.gridSubmittal;
            this.grdSubmittal.Name = "grdSubmittal";
            this.grdSubmittal.RepositoryItems.AddRange(new DevExpress.XtraEditors.Repository.RepositoryItem[] {
            this.repDescription,
            this.repSection});
            this.grdSubmittal.Size = new System.Drawing.Size(852, 352);
            this.grdSubmittal.TabIndex = 452;
            this.grdSubmittal.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.gridSubmittal});
            // 
            // gridSubmittal
            // 
            this.gridSubmittal.Appearance.FooterPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.gridSubmittal.Appearance.FooterPanel.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.gridSubmittal.Appearance.FooterPanel.Options.UseBackColor = true;
            this.gridSubmittal.Appearance.FooterPanel.Options.UseFont = true;
            this.gridSubmittal.GridControl = this.grdSubmittal;
            this.gridSubmittal.Name = "gridSubmittal";
            this.gridSubmittal.OptionsCustomization.AllowFilter = false;
            this.gridSubmittal.OptionsCustomization.AllowGroup = false;
            this.gridSubmittal.OptionsMenu.EnableColumnMenu = false;
            this.gridSubmittal.OptionsMenu.EnableFooterMenu = false;
            this.gridSubmittal.OptionsMenu.EnableGroupPanelMenu = false;
            this.gridSubmittal.OptionsView.ColumnAutoWidth = false;
            this.gridSubmittal.OptionsView.ShowFooter = true;
            this.gridSubmittal.OptionsView.ShowGroupPanel = false;
            this.gridSubmittal.RowUpdated += new DevExpress.XtraGrid.Views.Base.RowObjectEventHandler(this.gridSubmittal_RowUpdated);
            // 
            // repDescription
            // 
            this.repDescription.AutoHeight = false;
            this.repDescription.MaxLength = 60;
            this.repDescription.Name = "repDescription";
            // 
            // repSection
            // 
            this.repSection.AutoHeight = false;
            this.repSection.Mask.EditMask = "############";
            this.repSection.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.repSection.Mask.UseMaskAsDisplayFormat = true;
            this.repSection.MaxLength = 12;
            this.repSection.Name = "repSection";
            // 
            // labelControl25
            // 
            this.labelControl25.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))));
            this.labelControl25.Location = new System.Drawing.Point(17, 102);
            this.labelControl25.Name = "labelControl25";
            this.labelControl25.Size = new System.Drawing.Size(32, 13);
            this.labelControl25.TabIndex = 601;
            this.labelControl25.Text = "Labor";
            // 
            // labelControl26
            // 
            this.labelControl26.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))));
            this.labelControl26.Location = new System.Drawing.Point(337, 156);
            this.labelControl26.Name = "labelControl26";
            this.labelControl26.Size = new System.Drawing.Size(54, 13);
            this.labelControl26.TabIndex = 602;
            this.labelControl26.Text = "Mark-ups";
            // 
            // panelControl8
            // 
            this.panelControl8.Controls.Add(this.labelControl27);
            this.panelControl8.Controls.Add(this.textEdit34);
            this.panelControl8.Controls.Add(this.labelControl28);
            this.panelControl8.Controls.Add(this.textEdit35);
            this.panelControl8.Controls.Add(this.textEdit36);
            this.panelControl8.Controls.Add(this.labelControl29);
            this.panelControl8.Controls.Add(this.labelControl37);
            this.panelControl8.Controls.Add(this.textEdit37);
            this.panelControl8.Controls.Add(this.textEdit38);
            this.panelControl8.Controls.Add(this.labelControl50);
            this.panelControl8.Location = new System.Drawing.Point(337, 175);
            this.panelControl8.Name = "panelControl8";
            this.panelControl8.Size = new System.Drawing.Size(258, 137);
            this.panelControl8.TabIndex = 600;
            // 
            // labelControl27
            // 
            this.labelControl27.Location = new System.Drawing.Point(5, 113);
            this.labelControl27.Name = "labelControl27";
            this.labelControl27.Size = new System.Drawing.Size(42, 13);
            this.labelControl27.TabIndex = 578;
            this.labelControl27.Text = "Bond %:";
            // 
            // textEdit34
            // 
            this.textEdit34.Location = new System.Drawing.Point(155, 112);
            this.textEdit34.Name = "textEdit34";
            this.textEdit34.Properties.DisplayFormat.FormatString = "n2";
            this.textEdit34.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.textEdit34.Properties.EditFormat.FormatString = "n2";
            this.textEdit34.Properties.EditFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.textEdit34.Properties.Mask.EditMask = "n2";
            this.textEdit34.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.textEdit34.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.textEdit34.Properties.MaxLength = 20;
            this.spellChecker1.SetShowSpellCheckMenu(this.textEdit34, true);
            this.textEdit34.Size = new System.Drawing.Size(73, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.textEdit34, optionsSpelling80);
            this.textEdit34.TabIndex = 577;
            // 
            // labelControl28
            // 
            this.labelControl28.Location = new System.Drawing.Point(5, 87);
            this.labelControl28.Name = "labelControl28";
            this.labelControl28.Size = new System.Drawing.Size(64, 13);
            this.labelControl28.TabIndex = 576;
            this.labelControl28.Text = "Warranty %:";
            // 
            // textEdit35
            // 
            this.textEdit35.Location = new System.Drawing.Point(155, 86);
            this.textEdit35.Name = "textEdit35";
            this.textEdit35.Properties.DisplayFormat.FormatString = "n2";
            this.textEdit35.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.textEdit35.Properties.EditFormat.FormatString = "n2";
            this.textEdit35.Properties.EditFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.textEdit35.Properties.Mask.EditMask = "n2";
            this.textEdit35.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.textEdit35.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.textEdit35.Properties.MaxLength = 20;
            this.spellChecker1.SetShowSpellCheckMenu(this.textEdit35, true);
            this.textEdit35.Size = new System.Drawing.Size(73, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.textEdit35, optionsSpelling81);
            this.textEdit35.TabIndex = 575;
            // 
            // textEdit36
            // 
            this.textEdit36.Location = new System.Drawing.Point(155, 60);
            this.textEdit36.Name = "textEdit36";
            this.textEdit36.Properties.DisplayFormat.FormatString = "n2";
            this.textEdit36.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.textEdit36.Properties.EditFormat.FormatString = "n2";
            this.textEdit36.Properties.EditFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.textEdit36.Properties.Mask.EditMask = "n2";
            this.textEdit36.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.textEdit36.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.textEdit36.Properties.MaxLength = 20;
            this.spellChecker1.SetShowSpellCheckMenu(this.textEdit36, true);
            this.textEdit36.Size = new System.Drawing.Size(73, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.textEdit36, optionsSpelling82);
            this.textEdit36.TabIndex = 573;
            // 
            // labelControl29
            // 
            this.labelControl29.Location = new System.Drawing.Point(5, 63);
            this.labelControl29.Name = "labelControl29";
            this.labelControl29.Size = new System.Drawing.Size(147, 13);
            this.labelControl29.TabIndex = 574;
            this.labelControl29.Text = "Subcontract Administration %:";
            // 
            // labelControl37
            // 
            this.labelControl37.Location = new System.Drawing.Point(5, 35);
            this.labelControl37.Name = "labelControl37";
            this.labelControl37.Size = new System.Drawing.Size(44, 13);
            this.labelControl37.TabIndex = 572;
            this.labelControl37.Text = "Profit %:";
            // 
            // textEdit37
            // 
            this.textEdit37.Location = new System.Drawing.Point(155, 34);
            this.textEdit37.Name = "textEdit37";
            this.textEdit37.Properties.DisplayFormat.FormatString = "n2";
            this.textEdit37.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.textEdit37.Properties.EditFormat.FormatString = "n2";
            this.textEdit37.Properties.EditFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.textEdit37.Properties.Mask.EditMask = "n2";
            this.textEdit37.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.textEdit37.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.textEdit37.Properties.MaxLength = 20;
            this.spellChecker1.SetShowSpellCheckMenu(this.textEdit37, true);
            this.textEdit37.Size = new System.Drawing.Size(73, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.textEdit37, optionsSpelling83);
            this.textEdit37.TabIndex = 571;
            // 
            // textEdit38
            // 
            this.textEdit38.Location = new System.Drawing.Point(155, 8);
            this.textEdit38.Name = "textEdit38";
            this.textEdit38.Properties.DisplayFormat.FormatString = "n2";
            this.textEdit38.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.textEdit38.Properties.EditFormat.FormatString = "n2";
            this.textEdit38.Properties.EditFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.textEdit38.Properties.Mask.EditMask = "n2";
            this.textEdit38.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.textEdit38.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.textEdit38.Properties.MaxLength = 20;
            this.spellChecker1.SetShowSpellCheckMenu(this.textEdit38, true);
            this.textEdit38.Size = new System.Drawing.Size(73, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.textEdit38, optionsSpelling84);
            this.textEdit38.TabIndex = 3;
            // 
            // labelControl50
            // 
            this.labelControl50.Location = new System.Drawing.Point(5, 11);
            this.labelControl50.Name = "labelControl50";
            this.labelControl50.Size = new System.Drawing.Size(66, 13);
            this.labelControl50.TabIndex = 570;
            this.labelControl50.Text = "Overhead %:";
            // 
            // panelControl9
            // 
            this.panelControl9.Controls.Add(this.labelControl51);
            this.panelControl9.Controls.Add(this.textEdit39);
            this.panelControl9.Controls.Add(this.textEdit40);
            this.panelControl9.Controls.Add(this.labelControl53);
            this.panelControl9.Controls.Add(this.labelControl54);
            this.panelControl9.Controls.Add(this.textEdit41);
            this.panelControl9.Controls.Add(this.labelControl56);
            this.panelControl9.Controls.Add(this.textEdit42);
            this.panelControl9.Controls.Add(this.textEdit43);
            this.panelControl9.Controls.Add(this.labelControl62);
            this.panelControl9.Controls.Add(this.labelControl64);
            this.panelControl9.Controls.Add(this.textEdit44);
            this.panelControl9.Controls.Add(this.textEdit45);
            this.panelControl9.Controls.Add(this.labelControl67);
            this.panelControl9.Location = new System.Drawing.Point(17, 121);
            this.panelControl9.Name = "panelControl9";
            this.panelControl9.Size = new System.Drawing.Size(258, 192);
            this.panelControl9.TabIndex = 599;
            // 
            // labelControl51
            // 
            this.labelControl51.Location = new System.Drawing.Point(5, 165);
            this.labelControl51.Name = "labelControl51";
            this.labelControl51.Size = new System.Drawing.Size(125, 13);
            this.labelControl51.TabIndex = 582;
            this.labelControl51.Text = "Premium Time Labor Rate:";
            // 
            // textEdit39
            // 
            this.textEdit39.Location = new System.Drawing.Point(155, 164);
            this.textEdit39.Name = "textEdit39";
            this.textEdit39.Properties.DisplayFormat.FormatString = "n2";
            this.textEdit39.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.textEdit39.Properties.EditFormat.FormatString = "n2";
            this.textEdit39.Properties.EditFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.textEdit39.Properties.Mask.EditMask = "n2";
            this.textEdit39.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.textEdit39.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.textEdit39.Properties.MaxLength = 20;
            this.spellChecker1.SetShowSpellCheckMenu(this.textEdit39, true);
            this.textEdit39.Size = new System.Drawing.Size(73, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.textEdit39, optionsSpelling85);
            this.textEdit39.TabIndex = 581;
            // 
            // textEdit40
            // 
            this.textEdit40.Location = new System.Drawing.Point(155, 138);
            this.textEdit40.Name = "textEdit40";
            this.textEdit40.Properties.DisplayFormat.FormatString = "n2";
            this.textEdit40.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.textEdit40.Properties.EditFormat.FormatString = "n2";
            this.textEdit40.Properties.EditFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.textEdit40.Properties.Mask.EditMask = "n2";
            this.textEdit40.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.textEdit40.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.textEdit40.Properties.MaxLength = 20;
            this.spellChecker1.SetShowSpellCheckMenu(this.textEdit40, true);
            this.textEdit40.Size = new System.Drawing.Size(73, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.textEdit40, optionsSpelling86);
            this.textEdit40.TabIndex = 579;
            // 
            // labelControl53
            // 
            this.labelControl53.Location = new System.Drawing.Point(5, 141);
            this.labelControl53.Name = "labelControl53";
            this.labelControl53.Size = new System.Drawing.Size(138, 13);
            this.labelControl53.TabIndex = 580;
            this.labelControl53.Text = "Safety Meetings Labor Rate:";
            // 
            // labelControl54
            // 
            this.labelControl54.Location = new System.Drawing.Point(5, 113);
            this.labelControl54.Name = "labelControl54";
            this.labelControl54.Size = new System.Drawing.Size(139, 13);
            this.labelControl54.TabIndex = 578;
            this.labelControl54.Text = "Project Manager Labor Rate:";
            // 
            // textEdit41
            // 
            this.textEdit41.Location = new System.Drawing.Point(155, 112);
            this.textEdit41.Name = "textEdit41";
            this.textEdit41.Properties.DisplayFormat.FormatString = "n2";
            this.textEdit41.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.textEdit41.Properties.EditFormat.FormatString = "n2";
            this.textEdit41.Properties.EditFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.textEdit41.Properties.Mask.EditMask = "n2";
            this.textEdit41.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.textEdit41.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.textEdit41.Properties.MaxLength = 20;
            this.spellChecker1.SetShowSpellCheckMenu(this.textEdit41, true);
            this.textEdit41.Size = new System.Drawing.Size(73, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.textEdit41, optionsSpelling87);
            this.textEdit41.TabIndex = 577;
            // 
            // labelControl56
            // 
            this.labelControl56.Location = new System.Drawing.Point(5, 87);
            this.labelControl56.Name = "labelControl56";
            this.labelControl56.Size = new System.Drawing.Size(134, 13);
            this.labelControl56.TabIndex = 576;
            this.labelControl56.Text = "Superintendent Labor Rate:";
            // 
            // textEdit42
            // 
            this.textEdit42.Location = new System.Drawing.Point(155, 86);
            this.textEdit42.Name = "textEdit42";
            this.textEdit42.Properties.DisplayFormat.FormatString = "n2";
            this.textEdit42.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.textEdit42.Properties.EditFormat.FormatString = "n2";
            this.textEdit42.Properties.EditFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.textEdit42.Properties.Mask.EditMask = "n2";
            this.textEdit42.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.textEdit42.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.textEdit42.Properties.MaxLength = 20;
            this.spellChecker1.SetShowSpellCheckMenu(this.textEdit42, true);
            this.textEdit42.Size = new System.Drawing.Size(73, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.textEdit42, optionsSpelling88);
            this.textEdit42.TabIndex = 575;
            // 
            // textEdit43
            // 
            this.textEdit43.Location = new System.Drawing.Point(155, 60);
            this.textEdit43.Name = "textEdit43";
            this.textEdit43.Properties.DisplayFormat.FormatString = "n2";
            this.textEdit43.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.textEdit43.Properties.EditFormat.FormatString = "n2";
            this.textEdit43.Properties.EditFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.textEdit43.Properties.Mask.EditMask = "n2";
            this.textEdit43.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.textEdit43.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.textEdit43.Properties.MaxLength = 20;
            this.spellChecker1.SetShowSpellCheckMenu(this.textEdit43, true);
            this.textEdit43.Size = new System.Drawing.Size(73, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.textEdit43, optionsSpelling89);
            this.textEdit43.TabIndex = 573;
            // 
            // labelControl62
            // 
            this.labelControl62.Location = new System.Drawing.Point(5, 63);
            this.labelControl62.Name = "labelControl62";
            this.labelControl62.Size = new System.Drawing.Size(142, 13);
            this.labelControl62.TabIndex = 574;
            this.labelControl62.Text = "General Foreman Labor Rate:";
            // 
            // labelControl64
            // 
            this.labelControl64.Location = new System.Drawing.Point(5, 35);
            this.labelControl64.Name = "labelControl64";
            this.labelControl64.Size = new System.Drawing.Size(102, 13);
            this.labelControl64.TabIndex = 572;
            this.labelControl64.Text = "Foreman Labor Rate:";
            // 
            // textEdit44
            // 
            this.textEdit44.Location = new System.Drawing.Point(155, 34);
            this.textEdit44.Name = "textEdit44";
            this.textEdit44.Properties.DisplayFormat.FormatString = "n2";
            this.textEdit44.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.textEdit44.Properties.EditFormat.FormatString = "n2";
            this.textEdit44.Properties.EditFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.textEdit44.Properties.Mask.EditMask = "n2";
            this.textEdit44.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.textEdit44.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.textEdit44.Properties.MaxLength = 20;
            this.spellChecker1.SetShowSpellCheckMenu(this.textEdit44, true);
            this.textEdit44.Size = new System.Drawing.Size(73, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.textEdit44, optionsSpelling90);
            this.textEdit44.TabIndex = 571;
            // 
            // textEdit45
            // 
            this.textEdit45.Location = new System.Drawing.Point(155, 8);
            this.textEdit45.Name = "textEdit45";
            this.textEdit45.Properties.DisplayFormat.FormatString = "n2";
            this.textEdit45.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.textEdit45.Properties.EditFormat.FormatString = "n2";
            this.textEdit45.Properties.EditFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.textEdit45.Properties.Mask.EditMask = "n2";
            this.textEdit45.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.textEdit45.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.textEdit45.Properties.MaxLength = 20;
            this.spellChecker1.SetShowSpellCheckMenu(this.textEdit45, true);
            this.textEdit45.Size = new System.Drawing.Size(73, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.textEdit45, optionsSpelling91);
            this.textEdit45.TabIndex = 3;
            // 
            // labelControl67
            // 
            this.labelControl67.Location = new System.Drawing.Point(5, 11);
            this.labelControl67.Name = "labelControl67";
            this.labelControl67.Size = new System.Drawing.Size(108, 13);
            this.labelControl67.TabIndex = 570;
            this.labelControl67.Text = "Electrician Labor Rate:";
            // 
            // labelControl71
            // 
            this.labelControl71.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))));
            this.labelControl71.Location = new System.Drawing.Point(337, 16);
            this.labelControl71.Name = "labelControl71";
            this.labelControl71.Size = new System.Drawing.Size(53, 13);
            this.labelControl71.TabIndex = 598;
            this.labelControl71.Text = "Expenses";
            // 
            // panelControl10
            // 
            this.panelControl10.Controls.Add(this.labelControl73);
            this.panelControl10.Controls.Add(this.textEdit46);
            this.panelControl10.Controls.Add(this.textEdit47);
            this.panelControl10.Controls.Add(this.labelControl76);
            this.panelControl10.Controls.Add(this.labelControl80);
            this.panelControl10.Controls.Add(this.textEdit48);
            this.panelControl10.Controls.Add(this.textEdit49);
            this.panelControl10.Controls.Add(this.labelControl82);
            this.panelControl10.Location = new System.Drawing.Point(337, 35);
            this.panelControl10.Name = "panelControl10";
            this.panelControl10.Size = new System.Drawing.Size(258, 113);
            this.panelControl10.TabIndex = 597;
            // 
            // labelControl73
            // 
            this.labelControl73.Location = new System.Drawing.Point(5, 87);
            this.labelControl73.Name = "labelControl73";
            this.labelControl73.Size = new System.Drawing.Size(97, 13);
            this.labelControl73.TabIndex = 576;
            this.labelControl73.Text = "Cartige Handling %:";
            // 
            // textEdit46
            // 
            this.textEdit46.Location = new System.Drawing.Point(155, 86);
            this.textEdit46.Name = "textEdit46";
            this.textEdit46.Properties.DisplayFormat.FormatString = "n2";
            this.textEdit46.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.textEdit46.Properties.EditFormat.FormatString = "n2";
            this.textEdit46.Properties.EditFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.textEdit46.Properties.Mask.EditMask = "n2";
            this.textEdit46.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.textEdit46.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.textEdit46.Properties.MaxLength = 20;
            this.spellChecker1.SetShowSpellCheckMenu(this.textEdit46, true);
            this.textEdit46.Size = new System.Drawing.Size(73, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.textEdit46, optionsSpelling92);
            this.textEdit46.TabIndex = 575;
            // 
            // textEdit47
            // 
            this.textEdit47.Location = new System.Drawing.Point(155, 60);
            this.textEdit47.Name = "textEdit47";
            this.textEdit47.Properties.DisplayFormat.FormatString = "n2";
            this.textEdit47.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.textEdit47.Properties.EditFormat.FormatString = "n2";
            this.textEdit47.Properties.EditFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.textEdit47.Properties.Mask.EditMask = "n2";
            this.textEdit47.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.textEdit47.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.textEdit47.Properties.MaxLength = 20;
            this.spellChecker1.SetShowSpellCheckMenu(this.textEdit47, true);
            this.textEdit47.Size = new System.Drawing.Size(73, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.textEdit47, optionsSpelling93);
            this.textEdit47.TabIndex = 573;
            // 
            // labelControl76
            // 
            this.labelControl76.Location = new System.Drawing.Point(5, 63);
            this.labelControl76.Name = "labelControl76";
            this.labelControl76.Size = new System.Drawing.Size(70, 13);
            this.labelControl76.TabIndex = 574;
            this.labelControl76.Text = "Small Tools %:";
            // 
            // labelControl80
            // 
            this.labelControl80.Location = new System.Drawing.Point(5, 35);
            this.labelControl80.Name = "labelControl80";
            this.labelControl80.Size = new System.Drawing.Size(56, 13);
            this.labelControl80.TabIndex = 572;
            this.labelControl80.Text = "Storage %:";
            // 
            // textEdit48
            // 
            this.textEdit48.Location = new System.Drawing.Point(155, 34);
            this.textEdit48.Name = "textEdit48";
            this.textEdit48.Properties.DisplayFormat.FormatString = "n2";
            this.textEdit48.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.textEdit48.Properties.EditFormat.FormatString = "n2";
            this.textEdit48.Properties.EditFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.textEdit48.Properties.Mask.EditMask = "n2";
            this.textEdit48.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.textEdit48.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.textEdit48.Properties.MaxLength = 20;
            this.spellChecker1.SetShowSpellCheckMenu(this.textEdit48, true);
            this.textEdit48.Size = new System.Drawing.Size(73, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.textEdit48, optionsSpelling94);
            this.textEdit48.TabIndex = 571;
            // 
            // textEdit49
            // 
            this.textEdit49.Location = new System.Drawing.Point(155, 8);
            this.textEdit49.Name = "textEdit49";
            this.textEdit49.Properties.DisplayFormat.FormatString = "n2";
            this.textEdit49.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.textEdit49.Properties.EditFormat.FormatString = "n2";
            this.textEdit49.Properties.EditFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.textEdit49.Properties.Mask.EditMask = "n2";
            this.textEdit49.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.textEdit49.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.textEdit49.Properties.MaxLength = 20;
            this.spellChecker1.SetShowSpellCheckMenu(this.textEdit49, true);
            this.textEdit49.Size = new System.Drawing.Size(73, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.textEdit49, optionsSpelling95);
            this.textEdit49.TabIndex = 3;
            // 
            // labelControl82
            // 
            this.labelControl82.Location = new System.Drawing.Point(5, 11);
            this.labelControl82.Name = "labelControl82";
            this.labelControl82.Size = new System.Drawing.Size(119, 13);
            this.labelControl82.TabIndex = 570;
            this.labelControl82.Text = "As-Builts/Engineering %:";
            // 
            // panelControl11
            // 
            this.panelControl11.Controls.Add(this.labelControl85);
            this.panelControl11.Controls.Add(this.textEdit50);
            this.panelControl11.Controls.Add(this.textEdit51);
            this.panelControl11.Controls.Add(this.labelControl87);
            this.panelControl11.Location = new System.Drawing.Point(17, 35);
            this.panelControl11.Name = "panelControl11";
            this.panelControl11.Size = new System.Drawing.Size(258, 60);
            this.panelControl11.TabIndex = 596;
            // 
            // labelControl85
            // 
            this.labelControl85.Location = new System.Drawing.Point(5, 35);
            this.labelControl85.Name = "labelControl85";
            this.labelControl85.Size = new System.Drawing.Size(72, 13);
            this.labelControl85.TabIndex = 572;
            this.labelControl85.Text = "Sales Tax (%):";
            // 
            // textEdit50
            // 
            this.textEdit50.Location = new System.Drawing.Point(155, 34);
            this.textEdit50.Name = "textEdit50";
            this.textEdit50.Properties.DisplayFormat.FormatString = "n2";
            this.textEdit50.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.textEdit50.Properties.EditFormat.FormatString = "n2";
            this.textEdit50.Properties.EditFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.textEdit50.Properties.Mask.EditMask = "n2";
            this.textEdit50.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.textEdit50.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.textEdit50.Properties.MaxLength = 20;
            this.spellChecker1.SetShowSpellCheckMenu(this.textEdit50, true);
            this.textEdit50.Size = new System.Drawing.Size(73, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.textEdit50, optionsSpelling96);
            this.textEdit50.TabIndex = 571;
            // 
            // textEdit51
            // 
            this.textEdit51.Location = new System.Drawing.Point(155, 8);
            this.textEdit51.Name = "textEdit51";
            this.textEdit51.Properties.DisplayFormat.FormatString = "n2";
            this.textEdit51.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.textEdit51.Properties.EditFormat.FormatString = "n2";
            this.textEdit51.Properties.EditFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.textEdit51.Properties.Mask.EditMask = "n2";
            this.textEdit51.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.textEdit51.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.textEdit51.Properties.MaxLength = 20;
            this.spellChecker1.SetShowSpellCheckMenu(this.textEdit51, true);
            this.textEdit51.Size = new System.Drawing.Size(73, 20);
            this.spellChecker1.SetSpellCheckerOptions(this.textEdit51, optionsSpelling97);
            this.textEdit51.TabIndex = 3;
            // 
            // labelControl87
            // 
            this.labelControl87.Location = new System.Drawing.Point(5, 11);
            this.labelControl87.Name = "labelControl87";
            this.labelControl87.Size = new System.Drawing.Size(121, 13);
            this.labelControl87.TabIndex = 570;
            this.labelControl87.Text = "Sundries (% of Material):";
            // 
            // labelControl111
            // 
            this.labelControl111.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))));
            this.labelControl111.Location = new System.Drawing.Point(17, 16);
            this.labelControl111.Name = "labelControl111";
            this.labelControl111.Size = new System.Drawing.Size(47, 13);
            this.labelControl111.TabIndex = 595;
            this.labelControl111.Text = "Material";
            // 
            // spellChecker1
            // 
            this.spellChecker1.Culture = new System.Globalization.CultureInfo("en-US");
            this.spellChecker1.ParentContainer = null;
            // 
            // frmJobSystemDefaultValues
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(891, 549);
            this.Controls.Add(this.xtraTabControl1);
            this.Controls.Add(this.textEdit30);
            this.Controls.Add(this.labelControl66);
            this.Controls.Add(this.labelControl65);
            this.Controls.Add(this.labelControl63);
            this.Controls.Add(this.labelControl61);
            this.Controls.Add(this.labelControl49);
            this.Controls.Add(this.textEdit32);
            this.Controls.Add(this.textEdit31);
            this.Controls.Add(this.labelControl48);
            this.Controls.Add(this.labelControl60);
            this.Controls.Add(this.labelControl59);
            this.Controls.Add(this.labelControl68);
            this.Controls.Add(this.labelControl99);
            this.Controls.Add(this.labelControl98);
            this.Controls.Add(this.labelControl100);
            this.Controls.Add(this.labelControl97);
            this.Controls.Add(this.labelControl101);
            this.Controls.Add(this.labelControl102);
            this.Controls.Add(this.labelControl104);
            this.Controls.Add(this.labelControl96);
            this.Controls.Add(this.labelControl103);
            this.Controls.Add(this.textEdit78);
            this.Controls.Add(this.textEdit77);
            this.Controls.Add(this.textEdit76);
            this.Controls.Add(this.labelControl78);
            this.Controls.Add(this.labelControl77);
            this.Controls.Add(this.labelControl75);
            this.Controls.Add(this.labelControl79);
            this.Controls.Add(this.labelControl74);
            this.Controls.Add(this.labelControl70);
            this.Controls.Add(this.labelControl69);
            this.Controls.Add(this.labelControl72);
            this.Controls.Add(this.labelControl95);
            this.Controls.Add(this.labelControl94);
            this.Controls.Add(this.textEdit68);
            this.Controls.Add(this.labelControl93);
            this.Controls.Add(this.textEdit67);
            this.Controls.Add(this.textEdit69);
            this.Controls.Add(this.textEdit70);
            this.Controls.Add(this.textEdit75);
            this.Controls.Add(this.textEdit74);
            this.Controls.Add(this.textEdit73);
            this.Controls.Add(this.textEdit72);
            this.Controls.Add(this.textEdit71);
            this.Controls.Add(this.labelControl92);
            this.Controls.Add(this.labelControl91);
            this.Controls.Add(this.labelControl84);
            this.Controls.Add(this.labelControl83);
            this.Controls.Add(this.labelControl81);
            this.Controls.Add(this.labelControl86);
            this.Controls.Add(this.lookUpEdit3);
            this.Controls.Add(this.labelControl90);
            this.Controls.Add(this.labelControl89);
            this.Controls.Add(this.labelControl88);
            this.Controls.Add(this.textEdit66);
            this.Controls.Add(this.ribProjectOpportunity);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "frmJobSystemDefaultValues";
            this.Ribbon = this.ribProjectOpportunity;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "System Default Values";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.frmJobSystemDefaultValues_FormClosed);
            this.Load += new System.EventHandler(this.frmJobSystemDefaultValues_Load);
            ((System.ComponentModel.ISupportInitialize)(this.imgCollection)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.imageCollection1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dxErrorProvider)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.textEdit30.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.textEdit32.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.textEdit31.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.imageCollection2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ribProjectOpportunity)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.textEdit78.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.textEdit77.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.textEdit76.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.textEdit68.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.textEdit67.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.textEdit69.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.textEdit70.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.textEdit75.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.textEdit74.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.textEdit73.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.textEdit72.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.textEdit71.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lookUpEdit3.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.textEdit66.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radioGroup1.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.panelControl4)).EndInit();
            this.panelControl4.ResumeLayout(false);
            this.panelControl4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.textEdit4.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.textEdit5.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.textEdit6.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.textEdit7.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.memoEdit1.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.panelControl6)).EndInit();
            this.panelControl6.ResumeLayout(false);
            this.panelControl6.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dateEdit1.Properties.CalendarTimeProperties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dateEdit1.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lookUpEdit1.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lookUpEdit2.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lookUpEdit4.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lookUpEdit5.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.textEdit8.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.textEdit9.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dateEdit2.Properties.CalendarTimeProperties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dateEdit2.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.comboBoxEdit1.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lookUpEdit6.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dateEdit3.Properties.CalendarTimeProperties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dateEdit3.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dateEdit4.Properties.CalendarTimeProperties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dateEdit4.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.textEdit10.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.textEdit11.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.textEdit12.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.textEdit13.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.panelControl7)).EndInit();
            this.panelControl7.ResumeLayout(false);
            this.panelControl7.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dateEdit5.Properties.CalendarTimeProperties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dateEdit5.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dateEdit6.Properties.CalendarTimeProperties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dateEdit6.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.textEdit14.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.textEdit15.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.xtraTabControl1)).EndInit();
            this.xtraTabControl1.ResumeLayout(false);
            this.xtraTabPage1.ResumeLayout(false);
            this.xtraTabPage1.PerformLayout();
            this.xtraTabPage2.ResumeLayout(false);
            this.xtraTabPage2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.panelControl5)).EndInit();
            this.panelControl5.ResumeLayout(false);
            this.panelControl5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtBondPercent.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtWarrantyPercent.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtSubcontractAdministrationPercent.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtProfitPercent.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtOverheadPercent.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.panelControl3)).EndInit();
            this.panelControl3.ResumeLayout(false);
            this.panelControl3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtFringeBenefitsPercent.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtSafetyMeetingPercent.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtProjectEngineerPercentOfLabor.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtProjectManagerPercentOfLabor.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtSuperintendentPercentOfLabor.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtGeneralForemanPercentOfLabor.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtForemanPercentOfLabor.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.panelControl2)).EndInit();
            this.panelControl2.ResumeLayout(false);
            this.panelControl2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtCartigeHandlingPercent.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtSmallToolsPercent.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtStoragePercent.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtAsBuiltsEngineeringPercent.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.panelControl1)).EndInit();
            this.panelControl1.ResumeLayout(false);
            this.panelControl1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtSalesTaxPercent.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtSundriesPercentOfMaterial.Properties)).EndInit();
            this.xtraTabPage3.ResumeLayout(false);
            this.xtraTabPage3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.panelControl12)).EndInit();
            this.panelControl12.ResumeLayout(false);
            this.panelControl12.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtBIMRateDT.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtBIMRateOT.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtBIMRate.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtApprenticeLaborRateDT.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtProjectEngineerLaborRateDT.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtPremiumTimeLaborRateDT.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtSafetyMeetingsLaborRateDT.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtProjectManagerLaborRateDT.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtSuperintendentLaborRateDT.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtGeneralForemanLaborRateDT.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtForemanLaborRateDT.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtElectricianLaborRateDT.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtApprenticeLaborRateOT.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtProjectEngineerLaborRateOT.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtPremiumTimeLaborRateOT.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtSafetyMeetingsLaborRateOT.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtProjectManagerLaborRateOT.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtSuperintendentLaborRateOT.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtGeneralForemanLaborRateOT.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtForemanLaborRateOT.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtElectricianLaborRateOT.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtApprenticeLaborRate.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtProjectEngineerLaborRate.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtPremiumTimeLaborRate.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtSafetyMeetingsLaborRate.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtProjectManagerLaborRate.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtSuperintendentLaborRate.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtGeneralForemanLaborRate.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtForemanLaborRate.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtElectricianLaborRate.Properties)).EndInit();
            this.pagContactDefaultValues.ResumeLayout(false);
            this.pagContactDefaultValues.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.panelControl13)).EndInit();
            this.panelControl13.ResumeLayout(false);
            this.panelControl13.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.cboForeman.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cboDefaultFrom.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cboChangeOrderDefaultContact.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cboRFIDefaultContact.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtChangeOrderDefaultContactCompany.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtRFIDefaultContactCompany.Properties)).EndInit();
            this.pagMajorPONote.ResumeLayout(false);
            this.pagMajorPONote.PerformLayout();
            this.pagSmallPONote.ResumeLayout(false);
            this.pagSmallPONote.PerformLayout();
            this.pagSubmittalSpec.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.grdSubmittal)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridSubmittal)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repDescription)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repSection)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.panelControl8)).EndInit();
            this.panelControl8.ResumeLayout(false);
            this.panelControl8.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.textEdit34.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.textEdit35.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.textEdit36.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.textEdit37.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.textEdit38.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.panelControl9)).EndInit();
            this.panelControl9.ResumeLayout(false);
            this.panelControl9.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.textEdit39.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.textEdit40.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.textEdit41.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.textEdit42.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.textEdit43.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.textEdit44.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.textEdit45.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.panelControl10)).EndInit();
            this.panelControl10.ResumeLayout(false);
            this.panelControl10.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.textEdit46.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.textEdit47.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.textEdit48.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.textEdit49.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.panelControl11)).EndInit();
            this.panelControl11.ResumeLayout(false);
            this.panelControl11.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.textEdit50.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.textEdit51.Properties)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private DevExpress.Utils.ImageCollection imgCollection;
        private DevExpress.XtraBars.BarButtonItem btnToolInspectionsReport;
        private DevExpress.XtraBars.BarButtonItem btnToolRepairPartsReport;
        private DevExpress.XtraBars.BarButtonItem btnToolComponentsReport;
        private DevExpress.XtraBars.BarButtonItem btnToolAccessoriesReport;
        private DevExpress.XtraBars.BarButtonItem btnProjectInfoSheetReport;
        private DevExpress.XtraBars.BarButtonItem btnToolEventScheduledReport;
        private DevExpress.XtraBars.BarButtonItem btnAccessories;
        private DevExpress.XtraBars.BarButtonItem btnComponents;
        private DevExpress.XtraBars.BarButtonItem btnRepairParts;
        private DevExpress.XtraBars.BarButtonItem btnInspections;
        private DevExpress.XtraBars.BarButtonItem btnGeneral;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup ribbonAction;
        private DevExpress.XtraBars.BarButtonItem btnSave;
        private DevExpress.XtraBars.BarButtonItem btnUndo;
        private DevExpress.XtraBars.Ribbon.RibbonPage ribbonPage1;
        private DevExpress.XtraBars.BarSubItem barSubItemReports;
        private DevExpress.Utils.ImageCollection imageCollection1;
        private DevExpress.XtraBars.BarButtonGroup barButtonGroup5;
        private DevExpress.XtraBars.BarButtonItem btnTimeCard;
        private DevExpress.XtraBars.BarButtonItem btnCostToComplete;
        private DevExpress.XtraBars.BarButtonItem btnJobProgress;
        private DevExpress.XtraBars.BarButtonItem btnLaborProd;
        private DevExpress.XtraBars.BarButtonItem btnExcelQuantity;
        private DevExpress.XtraBars.BarButtonItem barButtonItem2;
        private DevExpress.XtraBars.BarButtonGroup barButtonGroup4;
        private DevExpress.XtraEditors.DXErrorProvider.DXErrorProvider dxErrorProvider;
        private DevExpress.XtraEditors.TextEdit textEdit30;
        private DevExpress.XtraEditors.LabelControl labelControl66;
        private DevExpress.XtraEditors.LabelControl labelControl65;
        private DevExpress.XtraEditors.LabelControl labelControl63;
        private DevExpress.XtraEditors.LabelControl labelControl61;
        private DevExpress.XtraEditors.LabelControl labelControl49;
        private DevExpress.XtraEditors.TextEdit textEdit32;
        private DevExpress.XtraEditors.TextEdit textEdit31;
        private DevExpress.XtraEditors.LabelControl labelControl48;
        private DevExpress.XtraEditors.LabelControl labelControl60;
        private DevExpress.XtraEditors.LabelControl labelControl59;
        private DevExpress.XtraBars.Ribbon.RibbonControl ribProjectOpportunity;
        private DevExpress.Utils.ImageCollection imageCollection2;
        private DevExpress.XtraBars.BarButtonItem iSaveAs;
        private DevExpress.XtraBars.BarButtonItem btnCostCodesWeekly;
        private DevExpress.XtraBars.BarButtonItem btnCostCodes;
        private DevExpress.XtraBars.BarButtonItem btnstrategic;
        private DevExpress.XtraBars.BarButtonItem btnTimeSheet;
        private DevExpress.XtraBars.BarButtonItem iSelectAll;
        private DevExpress.XtraBars.BarButtonItem btnGeneralOld;
        private DevExpress.XtraBars.BarButtonItem iFont;
        private DevExpress.XtraBars.BarButtonItem iBullets;
        private DevExpress.XtraBars.BarButtonItem iProtected;
        private DevExpress.XtraBars.BarButtonItem iWeb;
        private DevExpress.XtraBars.BarButtonItem iAbout;
        private DevExpress.XtraBars.BarButtonItem iBold;
        private DevExpress.XtraBars.BarButtonItem iUnderline;
        private DevExpress.XtraBars.BarButtonItem iAlignLeft;
        private DevExpress.XtraBars.BarButtonItem iCenter;
        private DevExpress.XtraBars.BarButtonItem iAlignRight;
        private DevExpress.XtraBars.BarButtonItem iFontColor;
        private DevExpress.XtraBars.BarButtonItem siPosition;
        private DevExpress.XtraBars.BarButtonItem siModified;
        private DevExpress.XtraBars.BarStaticItem siDocName;
        private DevExpress.XtraBars.BarButtonGroup bgFontStyle;
        private DevExpress.XtraBars.BarButtonGroup bgAlign;
        private DevExpress.XtraBars.BarButtonGroup bgFont;
        private DevExpress.XtraBars.BarButtonGroup bgBullets;
        private DevExpress.XtraBars.BarSubItem sbiPaste;
        private DevExpress.XtraBars.BarButtonItem iPasteSpecial;
        private DevExpress.XtraBars.BarButtonItem iNew;
        private DevExpress.XtraBars.BarLargeButtonItem iLargeUndo;
        private DevExpress.XtraBars.BarButtonItem iTemplate;
        private DevExpress.XtraBars.RibbonGalleryBarItem rgbiSkins;
        private DevExpress.XtraBars.BarEditItem beiFontSize;
        private DevExpress.XtraBars.RibbonGalleryBarItem rgbiFont;
        private DevExpress.XtraBars.BarButtonItem bbiFontColorPopup;
        private DevExpress.XtraBars.RibbonGalleryBarItem rgbiFontColor;
        private DevExpress.XtraBars.BarButtonItem btnPersonnel;
        private DevExpress.XtraBars.BarSubItem iGeneral;
        private DevExpress.XtraBars.BarButtonItem btnNote;
        private DevExpress.XtraBars.BarButtonItem barButtonItem5;
        private DevExpress.XtraBars.BarButtonItem barButtonItem6;
        private DevExpress.XtraBars.BarButtonGroup barButtonGroup1;
        private DevExpress.XtraBars.BarButtonGroup barButtonGroup2;
        private DevExpress.XtraBars.BarButtonGroup barButtonGroup3;
        private DevExpress.XtraBars.BarLinkContainerItem barLinkContainerItem1;
        private DevExpress.XtraBars.BarMdiChildrenListItem barMdiChildrenListItem1;
        private DevExpress.XtraBars.BarButtonItem barButtonItem1;
        private DevExpress.XtraBars.BarButtonItem btnLaborFeedback;
        private DevExpress.XtraBars.BarButtonItem btnLaborFeedbackReport;
        private DevExpress.XtraBars.BarButtonItem btnExcelHours;
        private DevExpress.XtraEditors.LabelControl labelControl68;
        private DevExpress.XtraEditors.LabelControl labelControl99;
        private DevExpress.XtraEditors.LabelControl labelControl98;
        private DevExpress.XtraEditors.LabelControl labelControl100;
        private DevExpress.XtraEditors.LabelControl labelControl97;
        private DevExpress.XtraEditors.LabelControl labelControl101;
        private DevExpress.XtraEditors.LabelControl labelControl102;
        private DevExpress.XtraEditors.LabelControl labelControl104;
        private DevExpress.XtraEditors.LabelControl labelControl96;
        private DevExpress.XtraEditors.LabelControl labelControl103;
        private DevExpress.XtraEditors.TextEdit textEdit78;
        private DevExpress.XtraEditors.TextEdit textEdit77;
        private DevExpress.XtraEditors.TextEdit textEdit76;
        private DevExpress.XtraEditors.LabelControl labelControl78;
        private DevExpress.XtraEditors.LabelControl labelControl77;
        private DevExpress.XtraEditors.LabelControl labelControl75;
        private DevExpress.XtraEditors.LabelControl labelControl79;
        private DevExpress.XtraEditors.LabelControl labelControl74;
        private DevExpress.XtraEditors.LabelControl labelControl70;
        private DevExpress.XtraEditors.LabelControl labelControl69;
        private DevExpress.XtraEditors.LabelControl labelControl72;
        private DevExpress.XtraEditors.LabelControl labelControl95;
        private DevExpress.XtraEditors.LabelControl labelControl94;
        private DevExpress.XtraEditors.TextEdit textEdit68;
        private DevExpress.XtraEditors.LabelControl labelControl93;
        private DevExpress.XtraEditors.TextEdit textEdit67;
        private DevExpress.XtraEditors.TextEdit textEdit69;
        private DevExpress.XtraEditors.TextEdit textEdit70;
        private DevExpress.XtraEditors.TextEdit textEdit75;
        private DevExpress.XtraEditors.TextEdit textEdit74;
        private DevExpress.XtraEditors.TextEdit textEdit73;
        private DevExpress.XtraEditors.TextEdit textEdit72;
        private DevExpress.XtraEditors.TextEdit textEdit71;
        private DevExpress.XtraEditors.LabelControl labelControl92;
        private DevExpress.XtraEditors.LabelControl labelControl91;
        private DevExpress.XtraEditors.LabelControl labelControl84;
        private DevExpress.XtraEditors.LabelControl labelControl83;
        private DevExpress.XtraEditors.LabelControl labelControl81;
        private DevExpress.XtraEditors.LabelControl labelControl86;
        private DevExpress.XtraEditors.LookUpEdit lookUpEdit3;
        private DevExpress.XtraEditors.LabelControl labelControl90;
        private DevExpress.XtraEditors.LabelControl labelControl89;
        private DevExpress.XtraEditors.LabelControl labelControl88;
        private DevExpress.XtraEditors.TextEdit textEdit66;
        private DevExpress.XtraEditors.LabelControl labelControl30;
        private DevExpress.XtraEditors.RadioGroup radioGroup1;
        private DevExpress.XtraEditors.LabelControl labelControl31;
        private DevExpress.XtraEditors.PanelControl panelControl4;
        private DevExpress.XtraEditors.TextEdit textEdit4;
        private DevExpress.XtraEditors.LabelControl labelControl32;
        private DevExpress.XtraEditors.TextEdit textEdit5;
        private DevExpress.XtraEditors.TextEdit textEdit6;
        private DevExpress.XtraEditors.LabelControl labelControl33;
        private DevExpress.XtraEditors.LabelControl labelControl34;
        private DevExpress.XtraEditors.LabelControl labelControl35;
        private DevExpress.XtraEditors.TextEdit textEdit7;
        private DevExpress.XtraEditors.MemoEdit memoEdit1;
        private DevExpress.XtraEditors.LabelControl labelControl36;
        private DevExpress.XtraEditors.PanelControl panelControl6;
        private DevExpress.XtraEditors.DateEdit dateEdit1;
        private DevExpress.XtraEditors.LookUpEdit lookUpEdit1;
        private DevExpress.XtraEditors.LabelControl labelControl38;
        private DevExpress.XtraEditors.LookUpEdit lookUpEdit2;
        private DevExpress.XtraEditors.LookUpEdit lookUpEdit4;
        private DevExpress.XtraEditors.LookUpEdit lookUpEdit5;
        private DevExpress.XtraEditors.TextEdit textEdit8;
        private DevExpress.XtraEditors.TextEdit textEdit9;
        private DevExpress.XtraEditors.DateEdit dateEdit2;
        private DevExpress.XtraEditors.ComboBoxEdit comboBoxEdit1;
        private DevExpress.XtraEditors.LabelControl labelControl39;
        private DevExpress.XtraEditors.LabelControl labelControl40;
        private DevExpress.XtraEditors.LabelControl labelControl41;
        private DevExpress.XtraEditors.LabelControl labelControl42;
        private DevExpress.XtraEditors.LabelControl labelControl43;
        private DevExpress.XtraEditors.LookUpEdit lookUpEdit6;
        private DevExpress.XtraEditors.DateEdit dateEdit3;
        private DevExpress.XtraEditors.LabelControl labelControl44;
        private DevExpress.XtraEditors.DateEdit dateEdit4;
        private DevExpress.XtraEditors.TextEdit textEdit10;
        private DevExpress.XtraEditors.TextEdit textEdit11;
        private DevExpress.XtraEditors.LabelControl labelControl45;
        private DevExpress.XtraEditors.TextEdit textEdit12;
        private DevExpress.XtraEditors.TextEdit textEdit13;
        private DevExpress.XtraEditors.LabelControl labelControl46;
        private DevExpress.XtraEditors.LabelControl labelControl47;
        private DevExpress.XtraEditors.LabelControl labelControl52;
        private DevExpress.XtraEditors.LabelControl labelControl55;
        private DevExpress.XtraEditors.LabelControl labelControl57;
        private DevExpress.XtraEditors.LabelControl labelControl58;
        private DevExpress.XtraEditors.LabelControl labelControl105;
        private DevExpress.XtraEditors.LabelControl labelControl106;
        private DevExpress.XtraEditors.PanelControl panelControl7;
        private DevExpress.XtraEditors.DateEdit dateEdit5;
        private DevExpress.XtraEditors.DateEdit dateEdit6;
        private DevExpress.XtraEditors.TextEdit textEdit14;
        private DevExpress.XtraEditors.TextEdit textEdit15;
        private DevExpress.XtraEditors.LabelControl labelControl107;
        private DevExpress.XtraEditors.LabelControl labelControl108;
        private DevExpress.XtraEditors.LabelControl labelControl109;
        private DevExpress.XtraEditors.LabelControl labelControl110;
        private DevExpress.XtraTab.XtraTabControl xtraTabControl1;
        private DevExpress.XtraTab.XtraTabPage xtraTabPage1;
        private DevExpress.XtraTab.XtraTabPage xtraTabPage2;
        private DevExpress.XtraTab.XtraTabPage xtraTabPage3;
        private DevExpress.XtraEditors.PanelControl panelControl1;
        private DevExpress.XtraEditors.LabelControl labelControl5;
        private DevExpress.XtraEditors.TextEdit txtSalesTaxPercent;
        private DevExpress.XtraEditors.TextEdit txtSundriesPercentOfMaterial;
        private DevExpress.XtraEditors.LabelControl labelControl4;
        private DevExpress.XtraEditors.LabelControl labelControl3;
        private DevExpress.XtraEditors.LabelControl labelControl23;
        private DevExpress.XtraEditors.LabelControl labelControl22;
        private DevExpress.XtraEditors.PanelControl panelControl5;
        private DevExpress.XtraEditors.LabelControl labelControl18;
        private DevExpress.XtraEditors.TextEdit txtWarrantyPercent;
        private DevExpress.XtraEditors.TextEdit txtSubcontractAdministrationPercent;
        private DevExpress.XtraEditors.LabelControl labelControl19;
        private DevExpress.XtraEditors.LabelControl labelControl20;
        private DevExpress.XtraEditors.TextEdit txtProfitPercent;
        private DevExpress.XtraEditors.TextEdit txtOverheadPercent;
        private DevExpress.XtraEditors.LabelControl labelControl21;
        private DevExpress.XtraEditors.PanelControl panelControl3;
        private DevExpress.XtraEditors.LabelControl labelControl15;
        private DevExpress.XtraEditors.TextEdit txtFringeBenefitsPercent;
        private DevExpress.XtraEditors.TextEdit txtSafetyMeetingPercent;
        private DevExpress.XtraEditors.LabelControl labelControl16;
        private DevExpress.XtraEditors.LabelControl labelControl17;
        private DevExpress.XtraEditors.TextEdit txtProjectEngineerPercentOfLabor;
        private DevExpress.XtraEditors.LabelControl labelControl11;
        private DevExpress.XtraEditors.TextEdit txtProjectManagerPercentOfLabor;
        private DevExpress.XtraEditors.TextEdit txtSuperintendentPercentOfLabor;
        private DevExpress.XtraEditors.LabelControl labelControl12;
        private DevExpress.XtraEditors.LabelControl labelControl13;
        private DevExpress.XtraEditors.TextEdit txtGeneralForemanPercentOfLabor;
        private DevExpress.XtraEditors.TextEdit txtForemanPercentOfLabor;
        private DevExpress.XtraEditors.LabelControl labelControl14;
        private DevExpress.XtraEditors.LabelControl labelControl10;
        private DevExpress.XtraEditors.PanelControl panelControl2;
        private DevExpress.XtraEditors.LabelControl labelControl8;
        private DevExpress.XtraEditors.TextEdit txtCartigeHandlingPercent;
        private DevExpress.XtraEditors.TextEdit txtSmallToolsPercent;
        private DevExpress.XtraEditors.LabelControl labelControl9;
        private DevExpress.XtraEditors.LabelControl labelControl6;
        private DevExpress.XtraEditors.TextEdit txtStoragePercent;
        private DevExpress.XtraEditors.TextEdit txtAsBuiltsEngineeringPercent;
        private DevExpress.XtraEditors.LabelControl labelControl7;
        private DevExpress.XtraEditors.LabelControl labelControl24;
        private DevExpress.XtraEditors.TextEdit txtBondPercent;
        private DevExpress.XtraEditors.LabelControl labelControl112;
        private DevExpress.XtraEditors.PanelControl panelControl12;
        private DevExpress.XtraEditors.LabelControl labelControl113;
        private DevExpress.XtraEditors.TextEdit txtPremiumTimeLaborRate;
        private DevExpress.XtraEditors.TextEdit txtSafetyMeetingsLaborRate;
        private DevExpress.XtraEditors.LabelControl labelControl114;
        private DevExpress.XtraEditors.LabelControl labelControl115;
        private DevExpress.XtraEditors.TextEdit txtProjectManagerLaborRate;
        private DevExpress.XtraEditors.LabelControl labelControl116;
        private DevExpress.XtraEditors.TextEdit txtSuperintendentLaborRate;
        private DevExpress.XtraEditors.TextEdit txtGeneralForemanLaborRate;
        private DevExpress.XtraEditors.LabelControl labelControl117;
        private DevExpress.XtraEditors.LabelControl labelControl118;
        private DevExpress.XtraEditors.TextEdit txtForemanLaborRate;
        private DevExpress.XtraEditors.TextEdit txtElectricianLaborRate;
        private DevExpress.XtraEditors.LabelControl labelControl119;
        private DevExpress.XtraEditors.LabelControl labelControl25;
        private DevExpress.XtraEditors.LabelControl labelControl26;
        private DevExpress.XtraEditors.PanelControl panelControl8;
        private DevExpress.XtraEditors.LabelControl labelControl27;
        private DevExpress.XtraEditors.TextEdit textEdit34;
        private DevExpress.XtraEditors.LabelControl labelControl28;
        private DevExpress.XtraEditors.TextEdit textEdit35;
        private DevExpress.XtraEditors.TextEdit textEdit36;
        private DevExpress.XtraEditors.LabelControl labelControl29;
        private DevExpress.XtraEditors.LabelControl labelControl37;
        private DevExpress.XtraEditors.TextEdit textEdit37;
        private DevExpress.XtraEditors.TextEdit textEdit38;
        private DevExpress.XtraEditors.LabelControl labelControl50;
        private DevExpress.XtraEditors.PanelControl panelControl9;
        private DevExpress.XtraEditors.LabelControl labelControl51;
        private DevExpress.XtraEditors.TextEdit textEdit39;
        private DevExpress.XtraEditors.TextEdit textEdit40;
        private DevExpress.XtraEditors.LabelControl labelControl53;
        private DevExpress.XtraEditors.LabelControl labelControl54;
        private DevExpress.XtraEditors.TextEdit textEdit41;
        private DevExpress.XtraEditors.LabelControl labelControl56;
        private DevExpress.XtraEditors.TextEdit textEdit42;
        private DevExpress.XtraEditors.TextEdit textEdit43;
        private DevExpress.XtraEditors.LabelControl labelControl62;
        private DevExpress.XtraEditors.LabelControl labelControl64;
        private DevExpress.XtraEditors.TextEdit textEdit44;
        private DevExpress.XtraEditors.TextEdit textEdit45;
        private DevExpress.XtraEditors.LabelControl labelControl67;
        private DevExpress.XtraEditors.LabelControl labelControl71;
        private DevExpress.XtraEditors.PanelControl panelControl10;
        private DevExpress.XtraEditors.LabelControl labelControl73;
        private DevExpress.XtraEditors.TextEdit textEdit46;
        private DevExpress.XtraEditors.TextEdit textEdit47;
        private DevExpress.XtraEditors.LabelControl labelControl76;
        private DevExpress.XtraEditors.LabelControl labelControl80;
        private DevExpress.XtraEditors.TextEdit textEdit48;
        private DevExpress.XtraEditors.TextEdit textEdit49;
        private DevExpress.XtraEditors.LabelControl labelControl82;
        private DevExpress.XtraEditors.PanelControl panelControl11;
        private DevExpress.XtraEditors.LabelControl labelControl85;
        private DevExpress.XtraEditors.TextEdit textEdit50;
        private DevExpress.XtraEditors.TextEdit textEdit51;
        private DevExpress.XtraEditors.LabelControl labelControl87;
        private DevExpress.XtraEditors.LabelControl labelControl111;
        private DevExpress.XtraEditors.LabelControl labelControl120;
        private DevExpress.XtraEditors.TextEdit txtProjectEngineerLaborRate;
        private DevExpress.XtraTab.XtraTabPage pagContactDefaultValues;
        private DevExpress.XtraEditors.LabelControl labelControl121;
        private DevExpress.XtraEditors.PanelControl panelControl13;
        private DevExpress.XtraEditors.LabelControl labelControl122;
        private DevExpress.XtraEditors.TextEdit txtChangeOrderDefaultContactCompany;
        private DevExpress.XtraEditors.LabelControl labelControl123;
        private DevExpress.XtraEditors.LabelControl labelControl124;
        private DevExpress.XtraEditors.TextEdit txtRFIDefaultContactCompany;
        private DevExpress.XtraEditors.LabelControl labelControl125;
        private DevExpress.XtraEditors.LookUpEdit cboChangeOrderDefaultContact;
        private DevExpress.XtraEditors.LookUpEdit cboRFIDefaultContact;
        private DevExpress.XtraEditors.LabelControl labelControl126;
        private DevExpress.XtraEditors.LookUpEdit cboDefaultFrom;
        private DevExpress.XtraTab.XtraTabPage pagMajorPONote;
        private DevExpress.XtraEditors.LookUpEdit cboForeman;
        private DevExpress.XtraEditors.LabelControl labelControl128;
        private DevExpress.XtraTab.XtraTabPage pagSubmittalSpec;
        private DevExpress.XtraGrid.GridControl grdSubmittal;
        private DevExpress.XtraGrid.Views.Grid.GridView gridSubmittal;
        private DevExpress.XtraEditors.Repository.RepositoryItemTextEdit repDescription;
        private DevExpress.XtraEditors.Repository.RepositoryItemTextEdit repSection;
        private DevExpress.XtraSpellChecker.SpellChecker spellChecker1;
        private DevExpress.XtraTab.XtraTabPage pagSmallPONote;
        private DevExpress.XtraEditors.TextEdit txtApprenticeLaborRate;
        private DevExpress.XtraEditors.LabelControl labelControl130;
        private ControlsLibrary.RichBoxEditor txtChangeOrderStipulationsParagraph2;
        private ControlsLibrary.RichBoxEditor txtChangeOrderStipulationsParagraph1;
        private ControlsLibrary.RichBoxEditor txtMajorPONote;
        private ControlsLibrary.RichBoxEditor txtSmallPONote;
        private DevExpress.XtraEditors.LabelControl labelControl133;
        private DevExpress.XtraEditors.LabelControl labelControl132;
        private DevExpress.XtraEditors.LabelControl labelControl131;
        private DevExpress.XtraEditors.TextEdit txtApprenticeLaborRateDT;
        private DevExpress.XtraEditors.TextEdit txtProjectEngineerLaborRateDT;
        private DevExpress.XtraEditors.TextEdit txtPremiumTimeLaborRateDT;
        private DevExpress.XtraEditors.TextEdit txtSafetyMeetingsLaborRateDT;
        private DevExpress.XtraEditors.TextEdit txtProjectManagerLaborRateDT;
        private DevExpress.XtraEditors.TextEdit txtSuperintendentLaborRateDT;
        private DevExpress.XtraEditors.TextEdit txtGeneralForemanLaborRateDT;
        private DevExpress.XtraEditors.TextEdit txtForemanLaborRateDT;
        private DevExpress.XtraEditors.TextEdit txtElectricianLaborRateDT;
        private DevExpress.XtraEditors.TextEdit txtApprenticeLaborRateOT;
        private DevExpress.XtraEditors.TextEdit txtProjectEngineerLaborRateOT;
        private DevExpress.XtraEditors.TextEdit txtPremiumTimeLaborRateOT;
        private DevExpress.XtraEditors.TextEdit txtSafetyMeetingsLaborRateOT;
        private DevExpress.XtraEditors.TextEdit txtProjectManagerLaborRateOT;
        private DevExpress.XtraEditors.TextEdit txtSuperintendentLaborRateOT;
        private DevExpress.XtraEditors.TextEdit txtGeneralForemanLaborRateOT;
        private DevExpress.XtraEditors.TextEdit txtForemanLaborRateOT;
        private DevExpress.XtraEditors.TextEdit txtElectricianLaborRateOT;
        private DevExpress.XtraEditors.TextEdit txtBIMRateDT;
        private DevExpress.XtraEditors.TextEdit txtBIMRateOT;
        private DevExpress.XtraEditors.TextEdit txtBIMRate;
        private DevExpress.XtraEditors.LabelControl labelControl134;
        private DevExpress.XtraEditors.HyperlinkLabelControl Paragraph1;
        private DevExpress.XtraEditors.HyperlinkLabelControl Paragraph2;
        private DevExpress.XtraEditors.HyperlinkLabelControl MajorPONote;
        private DevExpress.XtraEditors.HyperlinkLabelControl SmallPONote;
    }
}