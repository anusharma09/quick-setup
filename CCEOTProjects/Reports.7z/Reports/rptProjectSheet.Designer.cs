namespace CCEOTProjects.Reports
{
    partial class rptProjectSheet
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Detail = new DevExpress.XtraReports.UI.DetailBand();
            this.xrLabel206 = new DevExpress.XtraReports.UI.XRLabel();
            this.xrLabel205 = new DevExpress.XtraReports.UI.XRLabel();
            this.xrLabel190 = new DevExpress.XtraReports.UI.XRLabel();
            this.xrLabel189 = new DevExpress.XtraReports.UI.XRLabel();
            this.xrLabel204 = new DevExpress.XtraReports.UI.XRLabel();
            this.xrCheckBox20 = new DevExpress.XtraReports.UI.XRCheckBox();
            this.xrLabel203 = new DevExpress.XtraReports.UI.XRLabel();
            this.xrLabel202 = new DevExpress.XtraReports.UI.XRLabel();
            this.xrLabel201 = new DevExpress.XtraReports.UI.XRLabel();
            this.xrCheckBox18 = new DevExpress.XtraReports.UI.XRCheckBox();
            this.xrLabel200 = new DevExpress.XtraReports.UI.XRLabel();
            this.xrLabel199 = new DevExpress.XtraReports.UI.XRLabel();
            this.xrLabel198 = new DevExpress.XtraReports.UI.XRLabel();
            this.xrLabel197 = new DevExpress.XtraReports.UI.XRLabel();
            this.xrLabel68 = new DevExpress.XtraReports.UI.XRLabel();
            this.xrLabel52 = new DevExpress.XtraReports.UI.XRLabel();
            this.xrLabel196 = new DevExpress.XtraReports.UI.XRLabel();
            this.xrLabel195 = new DevExpress.XtraReports.UI.XRLabel();
            this.xrLabel194 = new DevExpress.XtraReports.UI.XRLabel();
            this.xrLabel193 = new DevExpress.XtraReports.UI.XRLabel();
            this.xrLabel192 = new DevExpress.XtraReports.UI.XRLabel();
            this.xrLabel191 = new DevExpress.XtraReports.UI.XRLabel();
            this.xrLabel188 = new DevExpress.XtraReports.UI.XRLabel();
            this.xrLabel187 = new DevExpress.XtraReports.UI.XRLabel();
            this.xrLabel186 = new DevExpress.XtraReports.UI.XRLabel();
            this.xrLabel185 = new DevExpress.XtraReports.UI.XRLabel();
            this.xrLabel184 = new DevExpress.XtraReports.UI.XRLabel();
            this.xrLabel183 = new DevExpress.XtraReports.UI.XRLabel();
            this.xrLabel182 = new DevExpress.XtraReports.UI.XRLabel();
            this.xrLabel181 = new DevExpress.XtraReports.UI.XRLabel();
            this.xrLabel180 = new DevExpress.XtraReports.UI.XRLabel();
            this.xrLabel179 = new DevExpress.XtraReports.UI.XRLabel();
            this.xrLabel178 = new DevExpress.XtraReports.UI.XRLabel();
            this.xrLabel177 = new DevExpress.XtraReports.UI.XRLabel();
            this.xrLabel176 = new DevExpress.XtraReports.UI.XRLabel();
            this.xrLabel175 = new DevExpress.XtraReports.UI.XRLabel();
            this.xrLabel174 = new DevExpress.XtraReports.UI.XRLabel();
            this.xrLabel173 = new DevExpress.XtraReports.UI.XRLabel();
            this.xrLabel172 = new DevExpress.XtraReports.UI.XRLabel();
            this.xrLabel171 = new DevExpress.XtraReports.UI.XRLabel();
            this.xrLabel170 = new DevExpress.XtraReports.UI.XRLabel();
            this.xrLabel169 = new DevExpress.XtraReports.UI.XRLabel();
            this.xrLabel168 = new DevExpress.XtraReports.UI.XRLabel();
            this.xrLabel167 = new DevExpress.XtraReports.UI.XRLabel();
            this.xrLabel166 = new DevExpress.XtraReports.UI.XRLabel();
            this.xrLabel165 = new DevExpress.XtraReports.UI.XRLabel();
            this.xrLabel164 = new DevExpress.XtraReports.UI.XRLabel();
            this.xrLabel163 = new DevExpress.XtraReports.UI.XRLabel();
            this.xrLabel162 = new DevExpress.XtraReports.UI.XRLabel();
            this.xrLabel161 = new DevExpress.XtraReports.UI.XRLabel();
            this.xrLabel160 = new DevExpress.XtraReports.UI.XRLabel();
            this.xrLabel159 = new DevExpress.XtraReports.UI.XRLabel();
            this.xrLabel158 = new DevExpress.XtraReports.UI.XRLabel();
            this.xrLabel157 = new DevExpress.XtraReports.UI.XRLabel();
            this.xrLabel156 = new DevExpress.XtraReports.UI.XRLabel();
            this.xrLabel155 = new DevExpress.XtraReports.UI.XRLabel();
            this.xrLabel154 = new DevExpress.XtraReports.UI.XRLabel();
            this.xrLabel153 = new DevExpress.XtraReports.UI.XRLabel();
            this.xrLabel152 = new DevExpress.XtraReports.UI.XRLabel();
            this.xrLabel151 = new DevExpress.XtraReports.UI.XRLabel();
            this.xrLabel150 = new DevExpress.XtraReports.UI.XRLabel();
            this.xrLabel149 = new DevExpress.XtraReports.UI.XRLabel();
            this.xrLabel148 = new DevExpress.XtraReports.UI.XRLabel();
            this.xrLabel147 = new DevExpress.XtraReports.UI.XRLabel();
            this.xrLabel145 = new DevExpress.XtraReports.UI.XRLabel();
            this.xrLabel144 = new DevExpress.XtraReports.UI.XRLabel();
            this.xrLabel141 = new DevExpress.XtraReports.UI.XRLabel();
            this.xrLabel140 = new DevExpress.XtraReports.UI.XRLabel();
            this.xrLabel139 = new DevExpress.XtraReports.UI.XRLabel();
            this.xrLabel138 = new DevExpress.XtraReports.UI.XRLabel();
            this.xrLabel137 = new DevExpress.XtraReports.UI.XRLabel();
            this.xrLabel136 = new DevExpress.XtraReports.UI.XRLabel();
            this.xrLabel135 = new DevExpress.XtraReports.UI.XRLabel();
            this.xrLabel134 = new DevExpress.XtraReports.UI.XRLabel();
            this.xrLabel133 = new DevExpress.XtraReports.UI.XRLabel();
            this.xrLabel132 = new DevExpress.XtraReports.UI.XRLabel();
            this.xrLabel131 = new DevExpress.XtraReports.UI.XRLabel();
            this.xrLabel130 = new DevExpress.XtraReports.UI.XRLabel();
            this.xrLabel129 = new DevExpress.XtraReports.UI.XRLabel();
            this.xrLabel128 = new DevExpress.XtraReports.UI.XRLabel();
            this.xrLabel127 = new DevExpress.XtraReports.UI.XRLabel();
            this.xrLabel126 = new DevExpress.XtraReports.UI.XRLabel();
            this.xrLabel124 = new DevExpress.XtraReports.UI.XRLabel();
            this.xrLabel123 = new DevExpress.XtraReports.UI.XRLabel();
            this.xrLabel122 = new DevExpress.XtraReports.UI.XRLabel();
            this.xrLabel121 = new DevExpress.XtraReports.UI.XRLabel();
            this.xrLabel120 = new DevExpress.XtraReports.UI.XRLabel();
            this.xrLabel119 = new DevExpress.XtraReports.UI.XRLabel();
            this.xrLabel118 = new DevExpress.XtraReports.UI.XRLabel();
            this.xrLabel117 = new DevExpress.XtraReports.UI.XRLabel();
            this.xrLabel116 = new DevExpress.XtraReports.UI.XRLabel();
            this.xrLabel115 = new DevExpress.XtraReports.UI.XRLabel();
            this.xrLabel114 = new DevExpress.XtraReports.UI.XRLabel();
            this.xrLabel113 = new DevExpress.XtraReports.UI.XRLabel();
            this.xrLabel112 = new DevExpress.XtraReports.UI.XRLabel();
            this.xrLabel111 = new DevExpress.XtraReports.UI.XRLabel();
            this.xrLabel110 = new DevExpress.XtraReports.UI.XRLabel();
            this.xrLabel109 = new DevExpress.XtraReports.UI.XRLabel();
            this.xrLabel108 = new DevExpress.XtraReports.UI.XRLabel();
            this.xrLabel107 = new DevExpress.XtraReports.UI.XRLabel();
            this.xrLabel106 = new DevExpress.XtraReports.UI.XRLabel();
            this.xrLabel105 = new DevExpress.XtraReports.UI.XRLabel();
            this.xrLabel104 = new DevExpress.XtraReports.UI.XRLabel();
            this.xrLabel103 = new DevExpress.XtraReports.UI.XRLabel();
            this.xrLabel102 = new DevExpress.XtraReports.UI.XRLabel();
            this.xrLabel101 = new DevExpress.XtraReports.UI.XRLabel();
            this.xrLabel100 = new DevExpress.XtraReports.UI.XRLabel();
            this.xrLabel99 = new DevExpress.XtraReports.UI.XRLabel();
            this.xrLabel98 = new DevExpress.XtraReports.UI.XRLabel();
            this.xrLabel97 = new DevExpress.XtraReports.UI.XRLabel();
            this.xrLabel96 = new DevExpress.XtraReports.UI.XRLabel();
            this.xrLabel95 = new DevExpress.XtraReports.UI.XRLabel();
            this.xrLabel94 = new DevExpress.XtraReports.UI.XRLabel();
            this.xrLabel93 = new DevExpress.XtraReports.UI.XRLabel();
            this.xrLabel92 = new DevExpress.XtraReports.UI.XRLabel();
            this.xrLabel91 = new DevExpress.XtraReports.UI.XRLabel();
            this.xrLabel90 = new DevExpress.XtraReports.UI.XRLabel();
            this.xrLabel89 = new DevExpress.XtraReports.UI.XRLabel();
            this.xrLabel88 = new DevExpress.XtraReports.UI.XRLabel();
            this.xrLabel87 = new DevExpress.XtraReports.UI.XRLabel();
            this.xrCheckBox25 = new DevExpress.XtraReports.UI.XRCheckBox();
            this.xrLabel86 = new DevExpress.XtraReports.UI.XRLabel();
            this.xrLabel85 = new DevExpress.XtraReports.UI.XRLabel();
            this.xrLabel84 = new DevExpress.XtraReports.UI.XRLabel();
            this.xrCheckBox24 = new DevExpress.XtraReports.UI.XRCheckBox();
            this.xrLabel83 = new DevExpress.XtraReports.UI.XRLabel();
            this.xrCheckBox22 = new DevExpress.XtraReports.UI.XRCheckBox();
            this.xrLabel82 = new DevExpress.XtraReports.UI.XRLabel();
            this.xrLabel81 = new DevExpress.XtraReports.UI.XRLabel();
            this.xrLabel80 = new DevExpress.XtraReports.UI.XRLabel();
            this.xrLabel79 = new DevExpress.XtraReports.UI.XRLabel();
            this.xrLabel78 = new DevExpress.XtraReports.UI.XRLabel();
            this.xrLabel77 = new DevExpress.XtraReports.UI.XRLabel();
            this.xrLabel76 = new DevExpress.XtraReports.UI.XRLabel();
            this.xrLabel75 = new DevExpress.XtraReports.UI.XRLabel();
            this.xrLabel74 = new DevExpress.XtraReports.UI.XRLabel();
            this.xrLabel73 = new DevExpress.XtraReports.UI.XRLabel();
            this.xrLabel72 = new DevExpress.XtraReports.UI.XRLabel();
            this.xrLabel71 = new DevExpress.XtraReports.UI.XRLabel();
            this.xrCheckBox21 = new DevExpress.XtraReports.UI.XRCheckBox();
            this.xrCheckBox19 = new DevExpress.XtraReports.UI.XRCheckBox();
            this.xrCheckBox17 = new DevExpress.XtraReports.UI.XRCheckBox();
            this.xrCheckBox16 = new DevExpress.XtraReports.UI.XRCheckBox();
            this.xrCheckBox15 = new DevExpress.XtraReports.UI.XRCheckBox();
            this.xrCheckBox14 = new DevExpress.XtraReports.UI.XRCheckBox();
            this.xrCheckBox13 = new DevExpress.XtraReports.UI.XRCheckBox();
            this.xrCheckBox12 = new DevExpress.XtraReports.UI.XRCheckBox();
            this.xrCheckBox11 = new DevExpress.XtraReports.UI.XRCheckBox();
            this.xrLabel70 = new DevExpress.XtraReports.UI.XRLabel();
            this.xrLabel69 = new DevExpress.XtraReports.UI.XRLabel();
            this.xrLabel53 = new DevExpress.XtraReports.UI.XRLabel();
            this.xrLabel51 = new DevExpress.XtraReports.UI.XRLabel();
            this.xrLabel50 = new DevExpress.XtraReports.UI.XRLabel();
            this.xrLabel46 = new DevExpress.XtraReports.UI.XRLabel();
            this.xrLabel44 = new DevExpress.XtraReports.UI.XRLabel();
            this.xrLabel43 = new DevExpress.XtraReports.UI.XRLabel();
            this.xrLabel42 = new DevExpress.XtraReports.UI.XRLabel();
            this.xrLabel41 = new DevExpress.XtraReports.UI.XRLabel();
            this.xrCheckBox8 = new DevExpress.XtraReports.UI.XRCheckBox();
            this.xrLabel40 = new DevExpress.XtraReports.UI.XRLabel();
            this.xrLabel39 = new DevExpress.XtraReports.UI.XRLabel();
            this.xrLabel38 = new DevExpress.XtraReports.UI.XRLabel();
            this.xrLabel37 = new DevExpress.XtraReports.UI.XRLabel();
            this.xrLabel36 = new DevExpress.XtraReports.UI.XRLabel();
            this.xrLabel35 = new DevExpress.XtraReports.UI.XRLabel();
            this.xrLabel34 = new DevExpress.XtraReports.UI.XRLabel();
            this.xrLabel47 = new DevExpress.XtraReports.UI.XRLabel();
            this.xrLabel67 = new DevExpress.XtraReports.UI.XRLabel();
            this.xrLabel66 = new DevExpress.XtraReports.UI.XRLabel();
            this.xrLabel65 = new DevExpress.XtraReports.UI.XRLabel();
            this.xrLabel64 = new DevExpress.XtraReports.UI.XRLabel();
            this.xrLabel63 = new DevExpress.XtraReports.UI.XRLabel();
            this.xrCheckBox10 = new DevExpress.XtraReports.UI.XRCheckBox();
            this.xrLabel62 = new DevExpress.XtraReports.UI.XRLabel();
            this.xrLabel61 = new DevExpress.XtraReports.UI.XRLabel();
            this.xrLabel49 = new DevExpress.XtraReports.UI.XRLabel();
            this.xrCheckBox9 = new DevExpress.XtraReports.UI.XRCheckBox();
            this.xrLabel45 = new DevExpress.XtraReports.UI.XRLabel();
            this.xrLabel29 = new DevExpress.XtraReports.UI.XRLabel();
            this.xrCheckBox7 = new DevExpress.XtraReports.UI.XRCheckBox();
            this.xrLabel22 = new DevExpress.XtraReports.UI.XRLabel();
            this.xrCheckBox6 = new DevExpress.XtraReports.UI.XRCheckBox();
            this.xrLabel21 = new DevExpress.XtraReports.UI.XRLabel();
            this.xrLabel60 = new DevExpress.XtraReports.UI.XRLabel();
            this.xrLabel59 = new DevExpress.XtraReports.UI.XRLabel();
            this.xrLabel58 = new DevExpress.XtraReports.UI.XRLabel();
            this.xrLabel33 = new DevExpress.XtraReports.UI.XRLabel();
            this.xrLabel32 = new DevExpress.XtraReports.UI.XRLabel();
            this.xrLabel28 = new DevExpress.XtraReports.UI.XRLabel();
            this.xrLabel27 = new DevExpress.XtraReports.UI.XRLabel();
            this.xrLabel26 = new DevExpress.XtraReports.UI.XRLabel();
            this.xrCheckBox4 = new DevExpress.XtraReports.UI.XRCheckBox();
            this.xrLabel24 = new DevExpress.XtraReports.UI.XRLabel();
            this.xrCheckBox3 = new DevExpress.XtraReports.UI.XRCheckBox();
            this.xrLabel20 = new DevExpress.XtraReports.UI.XRLabel();
            this.xrCheckBox2 = new DevExpress.XtraReports.UI.XRCheckBox();
            this.xrLabel19 = new DevExpress.XtraReports.UI.XRLabel();
            this.xrLabel1 = new DevExpress.XtraReports.UI.XRLabel();
            this.xrLabel13 = new DevExpress.XtraReports.UI.XRLabel();
            this.xrLabel14 = new DevExpress.XtraReports.UI.XRLabel();
            this.xrLabel15 = new DevExpress.XtraReports.UI.XRLabel();
            this.xrLine4 = new DevExpress.XtraReports.UI.XRLine();
            this.xrLabel142 = new DevExpress.XtraReports.UI.XRLabel();
            this.xrLabel143 = new DevExpress.XtraReports.UI.XRLabel();
            this.xrLabel146 = new DevExpress.XtraReports.UI.XRLabel();
            this.xrLine2 = new DevExpress.XtraReports.UI.XRLine();
            this.xrLabel2 = new DevExpress.XtraReports.UI.XRLabel();
            this.xrLabel4 = new DevExpress.XtraReports.UI.XRLabel();
            this.xrLabel3 = new DevExpress.XtraReports.UI.XRLabel();
            this.xrLabel5 = new DevExpress.XtraReports.UI.XRLabel();
            this.xrLabel6 = new DevExpress.XtraReports.UI.XRLabel();
            this.xrLabel8 = new DevExpress.XtraReports.UI.XRLabel();
            this.xrLabel9 = new DevExpress.XtraReports.UI.XRLabel();
            this.xrLabel10 = new DevExpress.XtraReports.UI.XRLabel();
            this.xrLabel11 = new DevExpress.XtraReports.UI.XRLabel();
            this.xrLabel16 = new DevExpress.XtraReports.UI.XRLabel();
            this.xrLabel17 = new DevExpress.XtraReports.UI.XRLabel();
            this.xrLabel18 = new DevExpress.XtraReports.UI.XRLabel();
            this.xrLabel23 = new DevExpress.XtraReports.UI.XRLabel();
            this.xrLabel25 = new DevExpress.XtraReports.UI.XRLabel();
            this.xrLabel30 = new DevExpress.XtraReports.UI.XRLabel();
            this.xrLabel31 = new DevExpress.XtraReports.UI.XRLabel();
            this.xrLabel48 = new DevExpress.XtraReports.UI.XRLabel();
            this.xrLabel54 = new DevExpress.XtraReports.UI.XRLabel();
            this.xrLabel55 = new DevExpress.XtraReports.UI.XRLabel();
            this.xrLabel56 = new DevExpress.XtraReports.UI.XRLabel();
            this.xrLabel57 = new DevExpress.XtraReports.UI.XRLabel();
            this.xrCheckBox1 = new DevExpress.XtraReports.UI.XRCheckBox();
            this.PageHeader = new DevExpress.XtraReports.UI.PageHeaderBand();
            this.xrLabel125 = new DevExpress.XtraReports.UI.XRLabel();
            this.xrPageInfo1 = new DevExpress.XtraReports.UI.XRPageInfo();
            this.xrLabel221 = new DevExpress.XtraReports.UI.XRLabel();
            this.txtPhone = new DevExpress.XtraReports.UI.XRLabel();
            this.txtFax = new DevExpress.XtraReports.UI.XRLabel();
            this.xrLine1 = new DevExpress.XtraReports.UI.XRLine();
            this.logo = new DevExpress.XtraReports.UI.XRPictureBox();
            this.txtCompany = new DevExpress.XtraReports.UI.XRLabel();
            this.xrLabel12 = new DevExpress.XtraReports.UI.XRLabel();
            this.txtAddress = new DevExpress.XtraReports.UI.XRLabel();
            this.PageFooter = new DevExpress.XtraReports.UI.PageFooterBand();
            this.GroupHeader1 = new DevExpress.XtraReports.UI.GroupHeaderBand();
            ((System.ComponentModel.ISupportInitialize)(this)).BeginInit();
            // 
            // Detail
            // 
            this.Detail.Controls.AddRange(new DevExpress.XtraReports.UI.XRControl[] {
            this.xrLabel206,
            this.xrLabel205,
            this.xrLabel190,
            this.xrLabel189,
            this.xrLabel204,
            this.xrCheckBox20,
            this.xrLabel203,
            this.xrLabel202,
            this.xrLabel201,
            this.xrCheckBox18,
            this.xrLabel200,
            this.xrLabel199,
            this.xrLabel198,
            this.xrLabel197,
            this.xrLabel68,
            this.xrLabel52,
            this.xrLabel196,
            this.xrLabel195,
            this.xrLabel194,
            this.xrLabel193,
            this.xrLabel192,
            this.xrLabel191,
            this.xrLabel188,
            this.xrLabel187,
            this.xrLabel186,
            this.xrLabel185,
            this.xrLabel184,
            this.xrLabel183,
            this.xrLabel182,
            this.xrLabel181,
            this.xrLabel180,
            this.xrLabel179,
            this.xrLabel178,
            this.xrLabel177,
            this.xrLabel176,
            this.xrLabel175,
            this.xrLabel174,
            this.xrLabel173,
            this.xrLabel172,
            this.xrLabel171,
            this.xrLabel170,
            this.xrLabel169,
            this.xrLabel168,
            this.xrLabel167,
            this.xrLabel166,
            this.xrLabel165,
            this.xrLabel164,
            this.xrLabel163,
            this.xrLabel162,
            this.xrLabel161,
            this.xrLabel160,
            this.xrLabel159,
            this.xrLabel158,
            this.xrLabel157,
            this.xrLabel156,
            this.xrLabel155,
            this.xrLabel154,
            this.xrLabel153,
            this.xrLabel152,
            this.xrLabel151,
            this.xrLabel150,
            this.xrLabel149,
            this.xrLabel148,
            this.xrLabel147,
            this.xrLabel145,
            this.xrLabel144,
            this.xrLabel141,
            this.xrLabel140,
            this.xrLabel139,
            this.xrLabel138,
            this.xrLabel137,
            this.xrLabel136,
            this.xrLabel135,
            this.xrLabel134,
            this.xrLabel133,
            this.xrLabel132,
            this.xrLabel131,
            this.xrLabel130,
            this.xrLabel129,
            this.xrLabel128,
            this.xrLabel127,
            this.xrLabel126,
            this.xrLabel124,
            this.xrLabel123,
            this.xrLabel122,
            this.xrLabel121,
            this.xrLabel120,
            this.xrLabel119,
            this.xrLabel118,
            this.xrLabel117,
            this.xrLabel116,
            this.xrLabel115,
            this.xrLabel114,
            this.xrLabel113,
            this.xrLabel112,
            this.xrLabel111,
            this.xrLabel110,
            this.xrLabel109,
            this.xrLabel108,
            this.xrLabel107,
            this.xrLabel106,
            this.xrLabel105,
            this.xrLabel104,
            this.xrLabel103,
            this.xrLabel102,
            this.xrLabel101,
            this.xrLabel100,
            this.xrLabel99,
            this.xrLabel98,
            this.xrLabel97,
            this.xrLabel96,
            this.xrLabel95,
            this.xrLabel94,
            this.xrLabel93,
            this.xrLabel92,
            this.xrLabel91,
            this.xrLabel90,
            this.xrLabel89,
            this.xrLabel88,
            this.xrLabel87,
            this.xrCheckBox25,
            this.xrLabel86,
            this.xrLabel85,
            this.xrLabel84,
            this.xrCheckBox24,
            this.xrLabel83,
            this.xrCheckBox22,
            this.xrLabel82,
            this.xrLabel81,
            this.xrLabel80,
            this.xrLabel79,
            this.xrLabel78,
            this.xrLabel77,
            this.xrLabel76,
            this.xrLabel75,
            this.xrLabel74,
            this.xrLabel73,
            this.xrLabel72,
            this.xrLabel71,
            this.xrCheckBox21,
            this.xrCheckBox19,
            this.xrCheckBox17,
            this.xrCheckBox16,
            this.xrCheckBox15,
            this.xrCheckBox14,
            this.xrCheckBox13,
            this.xrCheckBox12,
            this.xrCheckBox11,
            this.xrLabel70,
            this.xrLabel69,
            this.xrLabel53,
            this.xrLabel51,
            this.xrLabel50,
            this.xrLabel46,
            this.xrLabel44,
            this.xrLabel43,
            this.xrLabel42,
            this.xrLabel41,
            this.xrCheckBox8,
            this.xrLabel40,
            this.xrLabel39,
            this.xrLabel38,
            this.xrLabel37,
            this.xrLabel36,
            this.xrLabel35,
            this.xrLabel34,
            this.xrLabel47,
            this.xrLabel67,
            this.xrLabel66,
            this.xrLabel65,
            this.xrLabel64,
            this.xrLabel63,
            this.xrCheckBox10,
            this.xrLabel62,
            this.xrLabel61,
            this.xrLabel49,
            this.xrCheckBox9,
            this.xrLabel45,
            this.xrLabel29,
            this.xrCheckBox7,
            this.xrLabel22,
            this.xrCheckBox6,
            this.xrLabel21,
            this.xrLabel60,
            this.xrLabel59,
            this.xrLabel58,
            this.xrLabel33,
            this.xrLabel32,
            this.xrLabel28,
            this.xrLabel27,
            this.xrLabel26,
            this.xrCheckBox4,
            this.xrLabel24,
            this.xrCheckBox3,
            this.xrLabel20,
            this.xrCheckBox2,
            this.xrLabel19,
            this.xrLabel1,
            this.xrLabel13,
            this.xrLabel14,
            this.xrLabel15,
            this.xrLine4,
            this.xrLabel142,
            this.xrLabel143,
            this.xrLabel146,
            this.xrLine2,
            this.xrLabel2,
            this.xrLabel4,
            this.xrLabel3,
            this.xrLabel5,
            this.xrLabel6,
            this.xrLabel8,
            this.xrLabel9,
            this.xrLabel10,
            this.xrLabel11,
            this.xrLabel16,
            this.xrLabel17,
            this.xrLabel18,
            this.xrLabel23,
            this.xrLabel25,
            this.xrLabel30,
            this.xrLabel31,
            this.xrLabel48,
            this.xrLabel54,
            this.xrLabel55,
            this.xrLabel56,
            this.xrLabel57,
            this.xrCheckBox1});
            this.Detail.Font = new System.Drawing.Font("Times New Roman", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Detail.Height = 901;
            this.Detail.KeepTogether = true;
            this.Detail.Name = "Detail";
            this.Detail.ParentStyleUsing.UseFont = false;
            // 
            // xrLabel206
            // 
            this.xrLabel206.DataBindings.AddRange(new DevExpress.XtraReports.UI.XRBinding[] {
            new DevExpress.XtraReports.UI.XRBinding("Text", null, "tblAccount.Units", "{0:n0}")});
            this.xrLabel206.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xrLabel206.Location = new System.Drawing.Point(585, 175);
            this.xrLabel206.Name = "xrLabel206";
            this.xrLabel206.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xrLabel206.ParentStyleUsing.UseFont = false;
            this.xrLabel206.Size = new System.Drawing.Size(81, 17);
            this.xrLabel206.Text = "xrLabel206";
            this.xrLabel206.WordWrap = false;
            // 
            // xrLabel205
            // 
            this.xrLabel205.DataBindings.AddRange(new DevExpress.XtraReports.UI.XRBinding[] {
            new DevExpress.XtraReports.UI.XRBinding("Text", null, "tblAccount.UnitType", "")});
            this.xrLabel205.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xrLabel205.Location = new System.Drawing.Point(500, 175);
            this.xrLabel205.Name = "xrLabel205";
            this.xrLabel205.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xrLabel205.ParentStyleUsing.UseFont = false;
            this.xrLabel205.Size = new System.Drawing.Size(50, 17);
            this.xrLabel205.Text = "xrLabel205";
            this.xrLabel205.WordWrap = false;
            // 
            // xrLabel190
            // 
            this.xrLabel190.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xrLabel190.Location = new System.Drawing.Point(550, 175);
            this.xrLabel190.Name = "xrLabel190";
            this.xrLabel190.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xrLabel190.ParentStyleUsing.UseFont = false;
            this.xrLabel190.Size = new System.Drawing.Size(35, 17);
            this.xrLabel190.Text = "Units:";
            this.xrLabel190.WordWrap = false;
            // 
            // xrLabel189
            // 
            this.xrLabel189.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xrLabel189.Location = new System.Drawing.Point(442, 175);
            this.xrLabel189.Name = "xrLabel189";
            this.xrLabel189.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xrLabel189.ParentStyleUsing.UseFont = false;
            this.xrLabel189.Size = new System.Drawing.Size(58, 17);
            this.xrLabel189.Text = "Unit Type:";
            this.xrLabel189.WordWrap = false;
            // 
            // xrLabel204
            // 
            this.xrLabel204.DataBindings.AddRange(new DevExpress.XtraReports.UI.XRBinding[] {
            new DevExpress.XtraReports.UI.XRBinding("Text", null, "tblAccount.StatusDate", "{0:MM/dd/yyyy}")});
            this.xrLabel204.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xrLabel204.Location = new System.Drawing.Point(418, 42);
            this.xrLabel204.Name = "xrLabel204";
            this.xrLabel204.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xrLabel204.ParentStyleUsing.UseFont = false;
            this.xrLabel204.Size = new System.Drawing.Size(75, 17);
            this.xrLabel204.Text = "xrLabel204";
            this.xrLabel204.WordWrap = false;
            // 
            // xrCheckBox20
            // 
            this.xrCheckBox20.DataBindings.AddRange(new DevExpress.XtraReports.UI.XRBinding[] {
            new DevExpress.XtraReports.UI.XRBinding("CheckState", null, "tblAccount.AssignedToAccepted", "")});
            this.xrCheckBox20.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xrCheckBox20.Location = new System.Drawing.Point(392, 108);
            this.xrCheckBox20.Name = "xrCheckBox20";
            this.xrCheckBox20.ParentStyleUsing.UseFont = false;
            this.xrCheckBox20.Size = new System.Drawing.Size(25, 17);
            this.xrCheckBox20.WordWrap = false;
            // 
            // xrLabel203
            // 
            this.xrLabel203.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xrLabel203.Location = new System.Drawing.Point(250, 107);
            this.xrLabel203.Name = "xrLabel203";
            this.xrLabel203.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xrLabel203.ParentStyleUsing.UseFont = false;
            this.xrLabel203.Size = new System.Drawing.Size(133, 17);
            this.xrLabel203.Text = "Assigned To Accepted:";
            this.xrLabel203.WordWrap = false;
            // 
            // xrLabel202
            // 
            this.xrLabel202.DataBindings.AddRange(new DevExpress.XtraReports.UI.XRBinding[] {
            new DevExpress.XtraReports.UI.XRBinding("Text", null, "tblAccount.PApprovedBy", "")});
            this.xrLabel202.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xrLabel202.Location = new System.Drawing.Point(658, 433);
            this.xrLabel202.Name = "xrLabel202";
            this.xrLabel202.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xrLabel202.ParentStyleUsing.UseFont = false;
            this.xrLabel202.Size = new System.Drawing.Size(133, 17);
            this.xrLabel202.Text = "xrLabel202";
            this.xrLabel202.WordWrap = false;
            // 
            // xrLabel201
            // 
            this.xrLabel201.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xrLabel201.Location = new System.Drawing.Point(543, 433);
            this.xrLabel201.Name = "xrLabel201";
            this.xrLabel201.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xrLabel201.ParentStyleUsing.UseFont = false;
            this.xrLabel201.Size = new System.Drawing.Size(108, 17);
            this.xrLabel201.Text = "CEO Approved By:";
            this.xrLabel201.WordWrap = false;
            // 
            // xrCheckBox18
            // 
            this.xrCheckBox18.DataBindings.AddRange(new DevExpress.XtraReports.UI.XRBinding[] {
            new DevExpress.XtraReports.UI.XRBinding("CheckState", null, "tblAccount.PApproved", "")});
            this.xrCheckBox18.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xrCheckBox18.Location = new System.Drawing.Point(517, 433);
            this.xrCheckBox18.Name = "xrCheckBox18";
            this.xrCheckBox18.ParentStyleUsing.UseFont = false;
            this.xrCheckBox18.Size = new System.Drawing.Size(25, 17);
            this.xrCheckBox18.WordWrap = false;
            // 
            // xrLabel200
            // 
            this.xrLabel200.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xrLabel200.Location = new System.Drawing.Point(433, 433);
            this.xrLabel200.Name = "xrLabel200";
            this.xrLabel200.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xrLabel200.ParentStyleUsing.UseFont = false;
            this.xrLabel200.Size = new System.Drawing.Size(83, 17);
            this.xrLabel200.Text = "CEO Approved:";
            this.xrLabel200.WordWrap = false;
            // 
            // xrLabel199
            // 
            this.xrLabel199.DataBindings.AddRange(new DevExpress.XtraReports.UI.XRBinding[] {
            new DevExpress.XtraReports.UI.XRBinding("Text", null, "tblAccount.PrequalRequired", "")});
            this.xrLabel199.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xrLabel199.Location = new System.Drawing.Point(174, 175);
            this.xrLabel199.Name = "xrLabel199";
            this.xrLabel199.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xrLabel199.ParentStyleUsing.UseFont = false;
            this.xrLabel199.Size = new System.Drawing.Size(92, 17);
            this.xrLabel199.Text = "xrLabel199";
            this.xrLabel199.WordWrap = false;
            // 
            // xrLabel198
            // 
            this.xrLabel198.DataBindings.AddRange(new DevExpress.XtraReports.UI.XRBinding[] {
            new DevExpress.XtraReports.UI.XRBinding("Text", null, "tblAccount.ReferenceNumber", "")});
            this.xrLabel198.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xrLabel198.Location = new System.Drawing.Point(600, 408);
            this.xrLabel198.Name = "xrLabel198";
            this.xrLabel198.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xrLabel198.ParentStyleUsing.UseFont = false;
            this.xrLabel198.Size = new System.Drawing.Size(192, 17);
            this.xrLabel198.Text = "xrLabel198";
            this.xrLabel198.WordWrap = false;
            // 
            // xrLabel197
            // 
            this.xrLabel197.DataBindings.AddRange(new DevExpress.XtraReports.UI.XRBinding[] {
            new DevExpress.XtraReports.UI.XRBinding("Text", null, "tblAccount.Source", "")});
            this.xrLabel197.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xrLabel197.Location = new System.Drawing.Point(192, 408);
            this.xrLabel197.Name = "xrLabel197";
            this.xrLabel197.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xrLabel197.ParentStyleUsing.UseFont = false;
            this.xrLabel197.Size = new System.Drawing.Size(275, 17);
            this.xrLabel197.Text = "xrLabel197";
            this.xrLabel197.WordWrap = false;
            // 
            // xrLabel68
            // 
            this.xrLabel68.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xrLabel68.Location = new System.Drawing.Point(483, 408);
            this.xrLabel68.Name = "xrLabel68";
            this.xrLabel68.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xrLabel68.ParentStyleUsing.UseFont = false;
            this.xrLabel68.Size = new System.Drawing.Size(108, 17);
            this.xrLabel68.Text = "Reference Number:";
            this.xrLabel68.WordWrap = false;
            // 
            // xrLabel52
            // 
            this.xrLabel52.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xrLabel52.Location = new System.Drawing.Point(75, 408);
            this.xrLabel52.Name = "xrLabel52";
            this.xrLabel52.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xrLabel52.ParentStyleUsing.UseFont = false;
            this.xrLabel52.Size = new System.Drawing.Size(108, 17);
            this.xrLabel52.Text = "Source:";
            this.xrLabel52.WordWrap = false;
            // 
            // xrLabel196
            // 
            this.xrLabel196.DataBindings.AddRange(new DevExpress.XtraReports.UI.XRBinding[] {
            new DevExpress.XtraReports.UI.XRBinding("Text", null, "tblAccount.BidWalk", "")});
            this.xrLabel196.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xrLabel196.Location = new System.Drawing.Point(464, 142);
            this.xrLabel196.Name = "xrLabel196";
            this.xrLabel196.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xrLabel196.ParentStyleUsing.UseFont = false;
            this.xrLabel196.Size = new System.Drawing.Size(133, 17);
            this.xrLabel196.Text = "xrLabel196";
            this.xrLabel196.WordWrap = false;
            // 
            // xrLabel195
            // 
            this.xrLabel195.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xrLabel195.Location = new System.Drawing.Point(375, 142);
            this.xrLabel195.Name = "xrLabel195";
            this.xrLabel195.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xrLabel195.ParentStyleUsing.UseFont = false;
            this.xrLabel195.Size = new System.Drawing.Size(83, 17);
            this.xrLabel195.Text = "Bid Walk:";
            this.xrLabel195.WordWrap = false;
            // 
            // xrLabel194
            // 
            this.xrLabel194.DataBindings.AddRange(new DevExpress.XtraReports.UI.XRBinding[] {
            new DevExpress.XtraReports.UI.XRBinding("Text", null, "tblAccount.NextActionDateAuto", "{0:MM/dd/yyyy}")});
            this.xrLabel194.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xrLabel194.Location = new System.Drawing.Point(722, 175);
            this.xrLabel194.Name = "xrLabel194";
            this.xrLabel194.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xrLabel194.ParentStyleUsing.UseFont = false;
            this.xrLabel194.Size = new System.Drawing.Size(75, 17);
            this.xrLabel194.Text = "xrLabel194";
            this.xrLabel194.WordWrap = false;
            // 
            // xrLabel193
            // 
            this.xrLabel193.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xrLabel193.Location = new System.Drawing.Point(667, 175);
            this.xrLabel193.Name = "xrLabel193";
            this.xrLabel193.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xrLabel193.ParentStyleUsing.UseFont = false;
            this.xrLabel193.Size = new System.Drawing.Size(54, 17);
            this.xrLabel193.Text = "Next Act.:";
            this.xrLabel193.WordWrap = false;
            // 
            // xrLabel192
            // 
            this.xrLabel192.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xrLabel192.Location = new System.Drawing.Point(275, 175);
            this.xrLabel192.Name = "xrLabel192";
            this.xrLabel192.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xrLabel192.ParentStyleUsing.UseFont = false;
            this.xrLabel192.Size = new System.Drawing.Size(100, 17);
            this.xrLabel192.Text = "Prequal Due Date:";
            this.xrLabel192.WordWrap = false;
            // 
            // xrLabel191
            // 
            this.xrLabel191.DataBindings.AddRange(new DevExpress.XtraReports.UI.XRBinding[] {
            new DevExpress.XtraReports.UI.XRBinding("Text", null, "tblAccount.PrequalDate", "{0:MM/dd/yyyy}")});
            this.xrLabel191.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xrLabel191.Location = new System.Drawing.Point(375, 175);
            this.xrLabel191.Name = "xrLabel191";
            this.xrLabel191.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xrLabel191.ParentStyleUsing.UseFont = false;
            this.xrLabel191.Size = new System.Drawing.Size(67, 17);
            this.xrLabel191.Text = "xrLabel191";
            this.xrLabel191.WordWrap = false;
            // 
            // xrLabel188
            // 
            this.xrLabel188.DataBindings.AddRange(new DevExpress.XtraReports.UI.XRBinding[] {
            new DevExpress.XtraReports.UI.XRBinding("Text", null, "tblAccount.Note", "")});
            this.xrLabel188.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xrLabel188.Location = new System.Drawing.Point(75, 875);
            this.xrLabel188.Name = "xrLabel188";
            this.xrLabel188.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xrLabel188.ParentStyleUsing.UseFont = false;
            this.xrLabel188.Size = new System.Drawing.Size(683, 25);
            this.xrLabel188.Text = "xrLabel188";
            this.xrLabel188.Visible = false;
            // 
            // xrLabel187
            // 
            this.xrLabel187.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xrLabel187.Location = new System.Drawing.Point(75, 858);
            this.xrLabel187.Name = "xrLabel187";
            this.xrLabel187.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xrLabel187.ParentStyleUsing.UseFont = false;
            this.xrLabel187.Size = new System.Drawing.Size(267, 17);
            this.xrLabel187.Text = "Note:";
            this.xrLabel187.Visible = false;
            this.xrLabel187.WordWrap = false;
            // 
            // xrLabel186
            // 
            this.xrLabel186.DataBindings.AddRange(new DevExpress.XtraReports.UI.XRBinding[] {
            new DevExpress.XtraReports.UI.XRBinding("Text", null, "tblAccount.EngineerContactFax", "")});
            this.xrLabel186.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xrLabel186.Location = new System.Drawing.Point(658, 833);
            this.xrLabel186.Name = "xrLabel186";
            this.xrLabel186.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xrLabel186.ParentStyleUsing.UseFont = false;
            this.xrLabel186.Size = new System.Drawing.Size(100, 17);
            this.xrLabel186.Text = "xrLabel186";
            this.xrLabel186.WordWrap = false;
            // 
            // xrLabel185
            // 
            this.xrLabel185.DataBindings.AddRange(new DevExpress.XtraReports.UI.XRBinding[] {
            new DevExpress.XtraReports.UI.XRBinding("Text", null, "tblAccount.EngineerContactPhone", "")});
            this.xrLabel185.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xrLabel185.Location = new System.Drawing.Point(492, 833);
            this.xrLabel185.Name = "xrLabel185";
            this.xrLabel185.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xrLabel185.ParentStyleUsing.UseFont = false;
            this.xrLabel185.Size = new System.Drawing.Size(100, 17);
            this.xrLabel185.Text = "xrLabel185";
            this.xrLabel185.WordWrap = false;
            // 
            // xrLabel184
            // 
            this.xrLabel184.DataBindings.AddRange(new DevExpress.XtraReports.UI.XRBinding[] {
            new DevExpress.XtraReports.UI.XRBinding("Text", null, "tblAccount.EngineerContactEmail", "")});
            this.xrLabel184.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xrLabel184.Location = new System.Drawing.Point(492, 817);
            this.xrLabel184.Name = "xrLabel184";
            this.xrLabel184.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xrLabel184.ParentStyleUsing.UseFont = false;
            this.xrLabel184.Size = new System.Drawing.Size(267, 17);
            this.xrLabel184.Text = "xrLabel184";
            this.xrLabel184.WordWrap = false;
            // 
            // xrLabel183
            // 
            this.xrLabel183.DataBindings.AddRange(new DevExpress.XtraReports.UI.XRBinding[] {
            new DevExpress.XtraReports.UI.XRBinding("Text", null, "tblAccount.EngineerContactName", "")});
            this.xrLabel183.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xrLabel183.Location = new System.Drawing.Point(492, 800);
            this.xrLabel183.Name = "xrLabel183";
            this.xrLabel183.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xrLabel183.ParentStyleUsing.UseFont = false;
            this.xrLabel183.Size = new System.Drawing.Size(267, 17);
            this.xrLabel183.Text = "xrLabel183";
            this.xrLabel183.WordWrap = false;
            // 
            // xrLabel182
            // 
            this.xrLabel182.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xrLabel182.Location = new System.Drawing.Point(608, 833);
            this.xrLabel182.Name = "xrLabel182";
            this.xrLabel182.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xrLabel182.ParentStyleUsing.UseFont = false;
            this.xrLabel182.Size = new System.Drawing.Size(50, 17);
            this.xrLabel182.Text = "Fax:";
            this.xrLabel182.WordWrap = false;
            // 
            // xrLabel181
            // 
            this.xrLabel181.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xrLabel181.Location = new System.Drawing.Point(433, 833);
            this.xrLabel181.Name = "xrLabel181";
            this.xrLabel181.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xrLabel181.ParentStyleUsing.UseFont = false;
            this.xrLabel181.Size = new System.Drawing.Size(58, 17);
            this.xrLabel181.Text = "Phone:";
            this.xrLabel181.WordWrap = false;
            // 
            // xrLabel180
            // 
            this.xrLabel180.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xrLabel180.Location = new System.Drawing.Point(433, 817);
            this.xrLabel180.Name = "xrLabel180";
            this.xrLabel180.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xrLabel180.ParentStyleUsing.UseFont = false;
            this.xrLabel180.Size = new System.Drawing.Size(58, 17);
            this.xrLabel180.Text = "Email:";
            this.xrLabel180.WordWrap = false;
            // 
            // xrLabel179
            // 
            this.xrLabel179.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xrLabel179.Location = new System.Drawing.Point(433, 800);
            this.xrLabel179.Name = "xrLabel179";
            this.xrLabel179.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xrLabel179.ParentStyleUsing.UseFont = false;
            this.xrLabel179.Size = new System.Drawing.Size(58, 17);
            this.xrLabel179.Text = "Contact:";
            this.xrLabel179.WordWrap = false;
            // 
            // xrLabel178
            // 
            this.xrLabel178.DataBindings.AddRange(new DevExpress.XtraReports.UI.XRBinding[] {
            new DevExpress.XtraReports.UI.XRBinding("Text", null, "tblAccount.EngineerZip", "")});
            this.xrLabel178.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xrLabel178.Location = new System.Drawing.Point(342, 833);
            this.xrLabel178.Name = "xrLabel178";
            this.xrLabel178.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xrLabel178.ParentStyleUsing.UseFont = false;
            this.xrLabel178.Size = new System.Drawing.Size(48, 17);
            this.xrLabel178.Text = "xrLabel178";
            this.xrLabel178.WordWrap = false;
            // 
            // xrLabel177
            // 
            this.xrLabel177.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xrLabel177.Location = new System.Drawing.Point(317, 833);
            this.xrLabel177.Name = "xrLabel177";
            this.xrLabel177.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xrLabel177.ParentStyleUsing.UseFont = false;
            this.xrLabel177.Size = new System.Drawing.Size(25, 17);
            this.xrLabel177.Text = "Zip:";
            this.xrLabel177.WordWrap = false;
            // 
            // xrLabel176
            // 
            this.xrLabel176.DataBindings.AddRange(new DevExpress.XtraReports.UI.XRBinding[] {
            new DevExpress.XtraReports.UI.XRBinding("Text", null, "tblAccount.EngineerState", "")});
            this.xrLabel176.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xrLabel176.Location = new System.Drawing.Point(275, 833);
            this.xrLabel176.Name = "xrLabel176";
            this.xrLabel176.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xrLabel176.ParentStyleUsing.UseFont = false;
            this.xrLabel176.Size = new System.Drawing.Size(33, 17);
            this.xrLabel176.Text = "xrLabel176";
            this.xrLabel176.WordWrap = false;
            // 
            // xrLabel175
            // 
            this.xrLabel175.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xrLabel175.Location = new System.Drawing.Point(233, 833);
            this.xrLabel175.Name = "xrLabel175";
            this.xrLabel175.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xrLabel175.ParentStyleUsing.UseFont = false;
            this.xrLabel175.Size = new System.Drawing.Size(42, 17);
            this.xrLabel175.Text = "State:";
            this.xrLabel175.WordWrap = false;
            // 
            // xrLabel174
            // 
            this.xrLabel174.DataBindings.AddRange(new DevExpress.XtraReports.UI.XRBinding[] {
            new DevExpress.XtraReports.UI.XRBinding("Text", null, "tblAccount.EngineerCity", "")});
            this.xrLabel174.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xrLabel174.Location = new System.Drawing.Point(133, 833);
            this.xrLabel174.Name = "xrLabel174";
            this.xrLabel174.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xrLabel174.ParentStyleUsing.UseFont = false;
            this.xrLabel174.Size = new System.Drawing.Size(100, 17);
            this.xrLabel174.Text = "xrLabel174";
            this.xrLabel174.WordWrap = false;
            // 
            // xrLabel173
            // 
            this.xrLabel173.DataBindings.AddRange(new DevExpress.XtraReports.UI.XRBinding[] {
            new DevExpress.XtraReports.UI.XRBinding("Text", null, "tblAccount.EngineerAddress", "")});
            this.xrLabel173.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xrLabel173.Location = new System.Drawing.Point(133, 817);
            this.xrLabel173.Name = "xrLabel173";
            this.xrLabel173.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xrLabel173.ParentStyleUsing.UseFont = false;
            this.xrLabel173.Size = new System.Drawing.Size(158, 17);
            this.xrLabel173.Text = "xrLabel173";
            this.xrLabel173.WordWrap = false;
            // 
            // xrLabel172
            // 
            this.xrLabel172.DataBindings.AddRange(new DevExpress.XtraReports.UI.XRBinding[] {
            new DevExpress.XtraReports.UI.XRBinding("Text", null, "tblAccount.EngineerName", "")});
            this.xrLabel172.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xrLabel172.Location = new System.Drawing.Point(133, 800);
            this.xrLabel172.Name = "xrLabel172";
            this.xrLabel172.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xrLabel172.ParentStyleUsing.UseFont = false;
            this.xrLabel172.Size = new System.Drawing.Size(158, 17);
            this.xrLabel172.Text = "xrLabel172";
            this.xrLabel172.WordWrap = false;
            // 
            // xrLabel171
            // 
            this.xrLabel171.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xrLabel171.Location = new System.Drawing.Point(75, 833);
            this.xrLabel171.Name = "xrLabel171";
            this.xrLabel171.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xrLabel171.ParentStyleUsing.UseFont = false;
            this.xrLabel171.Size = new System.Drawing.Size(58, 17);
            this.xrLabel171.Text = "City:";
            this.xrLabel171.WordWrap = false;
            // 
            // xrLabel170
            // 
            this.xrLabel170.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xrLabel170.Location = new System.Drawing.Point(75, 817);
            this.xrLabel170.Name = "xrLabel170";
            this.xrLabel170.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xrLabel170.ParentStyleUsing.UseFont = false;
            this.xrLabel170.Size = new System.Drawing.Size(58, 17);
            this.xrLabel170.Text = "Address:";
            this.xrLabel170.WordWrap = false;
            // 
            // xrLabel169
            // 
            this.xrLabel169.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xrLabel169.Location = new System.Drawing.Point(75, 800);
            this.xrLabel169.Name = "xrLabel169";
            this.xrLabel169.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xrLabel169.ParentStyleUsing.UseFont = false;
            this.xrLabel169.Size = new System.Drawing.Size(58, 17);
            this.xrLabel169.Text = "Name:";
            this.xrLabel169.WordWrap = false;
            // 
            // xrLabel168
            // 
            this.xrLabel168.Font = new System.Drawing.Font("Tahoma", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xrLabel168.Location = new System.Drawing.Point(75, 783);
            this.xrLabel168.Name = "xrLabel168";
            this.xrLabel168.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xrLabel168.ParentStyleUsing.UseFont = false;
            this.xrLabel168.Size = new System.Drawing.Size(117, 17);
            this.xrLabel168.Text = "Engineer";
            this.xrLabel168.WordWrap = false;
            // 
            // xrLabel167
            // 
            this.xrLabel167.DataBindings.AddRange(new DevExpress.XtraReports.UI.XRBinding[] {
            new DevExpress.XtraReports.UI.XRBinding("Text", null, "tblAccount.ArchitectContactFax", "")});
            this.xrLabel167.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xrLabel167.Location = new System.Drawing.Point(658, 761);
            this.xrLabel167.Name = "xrLabel167";
            this.xrLabel167.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xrLabel167.ParentStyleUsing.UseFont = false;
            this.xrLabel167.Size = new System.Drawing.Size(100, 17);
            this.xrLabel167.Text = "xrLabel167";
            this.xrLabel167.WordWrap = false;
            // 
            // xrLabel166
            // 
            this.xrLabel166.DataBindings.AddRange(new DevExpress.XtraReports.UI.XRBinding[] {
            new DevExpress.XtraReports.UI.XRBinding("Text", null, "tblAccount.ArchitectContactPhone", "")});
            this.xrLabel166.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xrLabel166.Location = new System.Drawing.Point(492, 761);
            this.xrLabel166.Name = "xrLabel166";
            this.xrLabel166.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xrLabel166.ParentStyleUsing.UseFont = false;
            this.xrLabel166.Size = new System.Drawing.Size(100, 17);
            this.xrLabel166.Text = "xrLabel166";
            this.xrLabel166.WordWrap = false;
            // 
            // xrLabel165
            // 
            this.xrLabel165.DataBindings.AddRange(new DevExpress.XtraReports.UI.XRBinding[] {
            new DevExpress.XtraReports.UI.XRBinding("Text", null, "tblAccount.ArchitectContactEmail", "")});
            this.xrLabel165.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xrLabel165.Location = new System.Drawing.Point(492, 745);
            this.xrLabel165.Name = "xrLabel165";
            this.xrLabel165.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xrLabel165.ParentStyleUsing.UseFont = false;
            this.xrLabel165.Size = new System.Drawing.Size(267, 17);
            this.xrLabel165.Text = "xrLabel165";
            this.xrLabel165.WordWrap = false;
            // 
            // xrLabel164
            // 
            this.xrLabel164.DataBindings.AddRange(new DevExpress.XtraReports.UI.XRBinding[] {
            new DevExpress.XtraReports.UI.XRBinding("Text", null, "tblAccount.ArchitectContactName", "")});
            this.xrLabel164.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xrLabel164.Location = new System.Drawing.Point(492, 728);
            this.xrLabel164.Name = "xrLabel164";
            this.xrLabel164.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xrLabel164.ParentStyleUsing.UseFont = false;
            this.xrLabel164.Size = new System.Drawing.Size(267, 17);
            this.xrLabel164.Text = "xrLabel164";
            this.xrLabel164.WordWrap = false;
            // 
            // xrLabel163
            // 
            this.xrLabel163.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xrLabel163.Location = new System.Drawing.Point(608, 761);
            this.xrLabel163.Name = "xrLabel163";
            this.xrLabel163.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xrLabel163.ParentStyleUsing.UseFont = false;
            this.xrLabel163.Size = new System.Drawing.Size(50, 17);
            this.xrLabel163.Text = "Fax:";
            this.xrLabel163.WordWrap = false;
            // 
            // xrLabel162
            // 
            this.xrLabel162.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xrLabel162.Location = new System.Drawing.Point(433, 761);
            this.xrLabel162.Name = "xrLabel162";
            this.xrLabel162.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xrLabel162.ParentStyleUsing.UseFont = false;
            this.xrLabel162.Size = new System.Drawing.Size(58, 17);
            this.xrLabel162.Text = "Phone:";
            this.xrLabel162.WordWrap = false;
            // 
            // xrLabel161
            // 
            this.xrLabel161.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xrLabel161.Location = new System.Drawing.Point(433, 745);
            this.xrLabel161.Name = "xrLabel161";
            this.xrLabel161.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xrLabel161.ParentStyleUsing.UseFont = false;
            this.xrLabel161.Size = new System.Drawing.Size(58, 17);
            this.xrLabel161.Text = "Email:";
            this.xrLabel161.WordWrap = false;
            // 
            // xrLabel160
            // 
            this.xrLabel160.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xrLabel160.Location = new System.Drawing.Point(433, 728);
            this.xrLabel160.Name = "xrLabel160";
            this.xrLabel160.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xrLabel160.ParentStyleUsing.UseFont = false;
            this.xrLabel160.Size = new System.Drawing.Size(58, 17);
            this.xrLabel160.Text = "Contact:";
            this.xrLabel160.WordWrap = false;
            // 
            // xrLabel159
            // 
            this.xrLabel159.DataBindings.AddRange(new DevExpress.XtraReports.UI.XRBinding[] {
            new DevExpress.XtraReports.UI.XRBinding("Text", null, "tblAccount.ArchitectZip", "")});
            this.xrLabel159.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xrLabel159.Location = new System.Drawing.Point(342, 761);
            this.xrLabel159.Name = "xrLabel159";
            this.xrLabel159.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xrLabel159.ParentStyleUsing.UseFont = false;
            this.xrLabel159.Size = new System.Drawing.Size(48, 17);
            this.xrLabel159.Text = "xrLabel159";
            this.xrLabel159.WordWrap = false;
            // 
            // xrLabel158
            // 
            this.xrLabel158.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xrLabel158.Location = new System.Drawing.Point(317, 761);
            this.xrLabel158.Name = "xrLabel158";
            this.xrLabel158.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xrLabel158.ParentStyleUsing.UseFont = false;
            this.xrLabel158.Size = new System.Drawing.Size(25, 17);
            this.xrLabel158.Text = "Zip:";
            this.xrLabel158.WordWrap = false;
            // 
            // xrLabel157
            // 
            this.xrLabel157.DataBindings.AddRange(new DevExpress.XtraReports.UI.XRBinding[] {
            new DevExpress.XtraReports.UI.XRBinding("Text", null, "tblAccount.ArchitectState", "")});
            this.xrLabel157.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xrLabel157.Location = new System.Drawing.Point(275, 761);
            this.xrLabel157.Name = "xrLabel157";
            this.xrLabel157.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xrLabel157.ParentStyleUsing.UseFont = false;
            this.xrLabel157.Size = new System.Drawing.Size(33, 17);
            this.xrLabel157.Text = "xrLabel157";
            this.xrLabel157.WordWrap = false;
            // 
            // xrLabel156
            // 
            this.xrLabel156.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xrLabel156.Location = new System.Drawing.Point(233, 761);
            this.xrLabel156.Name = "xrLabel156";
            this.xrLabel156.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xrLabel156.ParentStyleUsing.UseFont = false;
            this.xrLabel156.Size = new System.Drawing.Size(42, 17);
            this.xrLabel156.Text = "State:";
            this.xrLabel156.WordWrap = false;
            // 
            // xrLabel155
            // 
            this.xrLabel155.DataBindings.AddRange(new DevExpress.XtraReports.UI.XRBinding[] {
            new DevExpress.XtraReports.UI.XRBinding("Text", null, "tblAccount.ArchitectCity", "")});
            this.xrLabel155.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xrLabel155.Location = new System.Drawing.Point(133, 761);
            this.xrLabel155.Name = "xrLabel155";
            this.xrLabel155.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xrLabel155.ParentStyleUsing.UseFont = false;
            this.xrLabel155.Size = new System.Drawing.Size(100, 17);
            this.xrLabel155.Text = "xrLabel155";
            this.xrLabel155.WordWrap = false;
            // 
            // xrLabel154
            // 
            this.xrLabel154.DataBindings.AddRange(new DevExpress.XtraReports.UI.XRBinding[] {
            new DevExpress.XtraReports.UI.XRBinding("Text", null, "tblAccount.ArchitectAddress", "")});
            this.xrLabel154.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xrLabel154.Location = new System.Drawing.Point(133, 745);
            this.xrLabel154.Name = "xrLabel154";
            this.xrLabel154.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xrLabel154.ParentStyleUsing.UseFont = false;
            this.xrLabel154.Size = new System.Drawing.Size(158, 17);
            this.xrLabel154.Text = "xrLabel154";
            this.xrLabel154.WordWrap = false;
            // 
            // xrLabel153
            // 
            this.xrLabel153.DataBindings.AddRange(new DevExpress.XtraReports.UI.XRBinding[] {
            new DevExpress.XtraReports.UI.XRBinding("Text", null, "tblAccount.ArchitectName", "")});
            this.xrLabel153.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xrLabel153.Location = new System.Drawing.Point(133, 728);
            this.xrLabel153.Name = "xrLabel153";
            this.xrLabel153.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xrLabel153.ParentStyleUsing.UseFont = false;
            this.xrLabel153.Size = new System.Drawing.Size(158, 17);
            this.xrLabel153.Text = "xrLabel153";
            this.xrLabel153.WordWrap = false;
            // 
            // xrLabel152
            // 
            this.xrLabel152.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xrLabel152.Location = new System.Drawing.Point(75, 761);
            this.xrLabel152.Name = "xrLabel152";
            this.xrLabel152.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xrLabel152.ParentStyleUsing.UseFont = false;
            this.xrLabel152.Size = new System.Drawing.Size(58, 17);
            this.xrLabel152.Text = "City:";
            this.xrLabel152.WordWrap = false;
            // 
            // xrLabel151
            // 
            this.xrLabel151.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xrLabel151.Location = new System.Drawing.Point(75, 745);
            this.xrLabel151.Name = "xrLabel151";
            this.xrLabel151.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xrLabel151.ParentStyleUsing.UseFont = false;
            this.xrLabel151.Size = new System.Drawing.Size(58, 17);
            this.xrLabel151.Text = "Address:";
            this.xrLabel151.WordWrap = false;
            // 
            // xrLabel150
            // 
            this.xrLabel150.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xrLabel150.Location = new System.Drawing.Point(75, 728);
            this.xrLabel150.Name = "xrLabel150";
            this.xrLabel150.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xrLabel150.ParentStyleUsing.UseFont = false;
            this.xrLabel150.Size = new System.Drawing.Size(58, 17);
            this.xrLabel150.Text = "Name:";
            this.xrLabel150.WordWrap = false;
            // 
            // xrLabel149
            // 
            this.xrLabel149.Font = new System.Drawing.Font("Tahoma", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xrLabel149.Location = new System.Drawing.Point(75, 711);
            this.xrLabel149.Name = "xrLabel149";
            this.xrLabel149.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xrLabel149.ParentStyleUsing.UseFont = false;
            this.xrLabel149.Size = new System.Drawing.Size(117, 17);
            this.xrLabel149.Text = "Architect";
            this.xrLabel149.WordWrap = false;
            // 
            // xrLabel148
            // 
            this.xrLabel148.DataBindings.AddRange(new DevExpress.XtraReports.UI.XRBinding[] {
            new DevExpress.XtraReports.UI.XRBinding("Text", null, "tblAccount.DeveloperContactFax", "")});
            this.xrLabel148.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xrLabel148.Location = new System.Drawing.Point(658, 692);
            this.xrLabel148.Name = "xrLabel148";
            this.xrLabel148.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xrLabel148.ParentStyleUsing.UseFont = false;
            this.xrLabel148.Size = new System.Drawing.Size(100, 17);
            this.xrLabel148.Text = "xrLabel148";
            this.xrLabel148.WordWrap = false;
            // 
            // xrLabel147
            // 
            this.xrLabel147.DataBindings.AddRange(new DevExpress.XtraReports.UI.XRBinding[] {
            new DevExpress.XtraReports.UI.XRBinding("Text", null, "tblAccount.DeveloperContactPhone", "")});
            this.xrLabel147.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xrLabel147.Location = new System.Drawing.Point(492, 692);
            this.xrLabel147.Name = "xrLabel147";
            this.xrLabel147.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xrLabel147.ParentStyleUsing.UseFont = false;
            this.xrLabel147.Size = new System.Drawing.Size(100, 17);
            this.xrLabel147.Text = "xrLabel147";
            this.xrLabel147.WordWrap = false;
            // 
            // xrLabel145
            // 
            this.xrLabel145.DataBindings.AddRange(new DevExpress.XtraReports.UI.XRBinding[] {
            new DevExpress.XtraReports.UI.XRBinding("Text", null, "tblAccount.DeveloperContactEmail", "")});
            this.xrLabel145.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xrLabel145.Location = new System.Drawing.Point(492, 675);
            this.xrLabel145.Name = "xrLabel145";
            this.xrLabel145.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xrLabel145.ParentStyleUsing.UseFont = false;
            this.xrLabel145.Size = new System.Drawing.Size(267, 17);
            this.xrLabel145.Text = "xrLabel145";
            this.xrLabel145.WordWrap = false;
            // 
            // xrLabel144
            // 
            this.xrLabel144.DataBindings.AddRange(new DevExpress.XtraReports.UI.XRBinding[] {
            new DevExpress.XtraReports.UI.XRBinding("Text", null, "tblAccount.DeveloperContactName", "")});
            this.xrLabel144.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xrLabel144.Location = new System.Drawing.Point(492, 658);
            this.xrLabel144.Name = "xrLabel144";
            this.xrLabel144.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xrLabel144.ParentStyleUsing.UseFont = false;
            this.xrLabel144.Size = new System.Drawing.Size(267, 17);
            this.xrLabel144.Text = "xrLabel144";
            this.xrLabel144.WordWrap = false;
            // 
            // xrLabel141
            // 
            this.xrLabel141.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xrLabel141.Location = new System.Drawing.Point(608, 692);
            this.xrLabel141.Name = "xrLabel141";
            this.xrLabel141.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xrLabel141.ParentStyleUsing.UseFont = false;
            this.xrLabel141.Size = new System.Drawing.Size(50, 17);
            this.xrLabel141.Text = "Fax:";
            this.xrLabel141.WordWrap = false;
            // 
            // xrLabel140
            // 
            this.xrLabel140.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xrLabel140.Location = new System.Drawing.Point(433, 692);
            this.xrLabel140.Name = "xrLabel140";
            this.xrLabel140.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xrLabel140.ParentStyleUsing.UseFont = false;
            this.xrLabel140.Size = new System.Drawing.Size(58, 17);
            this.xrLabel140.Text = "Phone:";
            this.xrLabel140.WordWrap = false;
            // 
            // xrLabel139
            // 
            this.xrLabel139.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xrLabel139.Location = new System.Drawing.Point(433, 675);
            this.xrLabel139.Name = "xrLabel139";
            this.xrLabel139.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xrLabel139.ParentStyleUsing.UseFont = false;
            this.xrLabel139.Size = new System.Drawing.Size(58, 17);
            this.xrLabel139.Text = "Email:";
            this.xrLabel139.WordWrap = false;
            // 
            // xrLabel138
            // 
            this.xrLabel138.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xrLabel138.Location = new System.Drawing.Point(433, 658);
            this.xrLabel138.Name = "xrLabel138";
            this.xrLabel138.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xrLabel138.ParentStyleUsing.UseFont = false;
            this.xrLabel138.Size = new System.Drawing.Size(58, 17);
            this.xrLabel138.Text = "Contact:";
            this.xrLabel138.WordWrap = false;
            // 
            // xrLabel137
            // 
            this.xrLabel137.DataBindings.AddRange(new DevExpress.XtraReports.UI.XRBinding[] {
            new DevExpress.XtraReports.UI.XRBinding("Text", null, "tblAccount.DeveloperZip", "")});
            this.xrLabel137.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xrLabel137.Location = new System.Drawing.Point(342, 692);
            this.xrLabel137.Name = "xrLabel137";
            this.xrLabel137.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xrLabel137.ParentStyleUsing.UseFont = false;
            this.xrLabel137.Size = new System.Drawing.Size(48, 17);
            this.xrLabel137.Text = "xrLabel137";
            this.xrLabel137.WordWrap = false;
            // 
            // xrLabel136
            // 
            this.xrLabel136.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xrLabel136.Location = new System.Drawing.Point(317, 692);
            this.xrLabel136.Name = "xrLabel136";
            this.xrLabel136.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xrLabel136.ParentStyleUsing.UseFont = false;
            this.xrLabel136.Size = new System.Drawing.Size(25, 17);
            this.xrLabel136.Text = "Zip:";
            this.xrLabel136.WordWrap = false;
            // 
            // xrLabel135
            // 
            this.xrLabel135.DataBindings.AddRange(new DevExpress.XtraReports.UI.XRBinding[] {
            new DevExpress.XtraReports.UI.XRBinding("Text", null, "tblAccount.DeveloperState", "")});
            this.xrLabel135.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xrLabel135.Location = new System.Drawing.Point(275, 692);
            this.xrLabel135.Name = "xrLabel135";
            this.xrLabel135.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xrLabel135.ParentStyleUsing.UseFont = false;
            this.xrLabel135.Size = new System.Drawing.Size(33, 17);
            this.xrLabel135.Text = "xrLabel135";
            this.xrLabel135.WordWrap = false;
            // 
            // xrLabel134
            // 
            this.xrLabel134.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xrLabel134.Location = new System.Drawing.Point(233, 692);
            this.xrLabel134.Name = "xrLabel134";
            this.xrLabel134.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xrLabel134.ParentStyleUsing.UseFont = false;
            this.xrLabel134.Size = new System.Drawing.Size(42, 17);
            this.xrLabel134.Text = "State:";
            this.xrLabel134.WordWrap = false;
            // 
            // xrLabel133
            // 
            this.xrLabel133.DataBindings.AddRange(new DevExpress.XtraReports.UI.XRBinding[] {
            new DevExpress.XtraReports.UI.XRBinding("Text", null, "tblAccount.DeveloperCity", "")});
            this.xrLabel133.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xrLabel133.Location = new System.Drawing.Point(133, 692);
            this.xrLabel133.Name = "xrLabel133";
            this.xrLabel133.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xrLabel133.ParentStyleUsing.UseFont = false;
            this.xrLabel133.Size = new System.Drawing.Size(100, 17);
            this.xrLabel133.Text = "xrLabel133";
            this.xrLabel133.WordWrap = false;
            // 
            // xrLabel132
            // 
            this.xrLabel132.DataBindings.AddRange(new DevExpress.XtraReports.UI.XRBinding[] {
            new DevExpress.XtraReports.UI.XRBinding("Text", null, "tblAccount.DeveloperAddress", "")});
            this.xrLabel132.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xrLabel132.Location = new System.Drawing.Point(133, 675);
            this.xrLabel132.Name = "xrLabel132";
            this.xrLabel132.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xrLabel132.ParentStyleUsing.UseFont = false;
            this.xrLabel132.Size = new System.Drawing.Size(158, 17);
            this.xrLabel132.Text = "xrLabel132";
            this.xrLabel132.WordWrap = false;
            // 
            // xrLabel131
            // 
            this.xrLabel131.DataBindings.AddRange(new DevExpress.XtraReports.UI.XRBinding[] {
            new DevExpress.XtraReports.UI.XRBinding("Text", null, "tblAccount.DeveloperName", "")});
            this.xrLabel131.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xrLabel131.Location = new System.Drawing.Point(133, 658);
            this.xrLabel131.Name = "xrLabel131";
            this.xrLabel131.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xrLabel131.ParentStyleUsing.UseFont = false;
            this.xrLabel131.Size = new System.Drawing.Size(158, 17);
            this.xrLabel131.Text = "xrLabel131";
            this.xrLabel131.WordWrap = false;
            // 
            // xrLabel130
            // 
            this.xrLabel130.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xrLabel130.Location = new System.Drawing.Point(75, 692);
            this.xrLabel130.Name = "xrLabel130";
            this.xrLabel130.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xrLabel130.ParentStyleUsing.UseFont = false;
            this.xrLabel130.Size = new System.Drawing.Size(58, 17);
            this.xrLabel130.Text = "City:";
            this.xrLabel130.WordWrap = false;
            // 
            // xrLabel129
            // 
            this.xrLabel129.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xrLabel129.Location = new System.Drawing.Point(75, 675);
            this.xrLabel129.Name = "xrLabel129";
            this.xrLabel129.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xrLabel129.ParentStyleUsing.UseFont = false;
            this.xrLabel129.Size = new System.Drawing.Size(58, 17);
            this.xrLabel129.Text = "Address:";
            this.xrLabel129.WordWrap = false;
            // 
            // xrLabel128
            // 
            this.xrLabel128.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xrLabel128.Location = new System.Drawing.Point(75, 658);
            this.xrLabel128.Name = "xrLabel128";
            this.xrLabel128.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xrLabel128.ParentStyleUsing.UseFont = false;
            this.xrLabel128.Size = new System.Drawing.Size(58, 17);
            this.xrLabel128.Text = "Name:";
            this.xrLabel128.WordWrap = false;
            // 
            // xrLabel127
            // 
            this.xrLabel127.Font = new System.Drawing.Font("Tahoma", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xrLabel127.Location = new System.Drawing.Point(75, 642);
            this.xrLabel127.Name = "xrLabel127";
            this.xrLabel127.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xrLabel127.ParentStyleUsing.UseFont = false;
            this.xrLabel127.Size = new System.Drawing.Size(117, 17);
            this.xrLabel127.Text = "Developer";
            this.xrLabel127.WordWrap = false;
            // 
            // xrLabel126
            // 
            this.xrLabel126.DataBindings.AddRange(new DevExpress.XtraReports.UI.XRBinding[] {
            new DevExpress.XtraReports.UI.XRBinding("Text", null, "tblAccount.GeneralContractorContactFax", "")});
            this.xrLabel126.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xrLabel126.Location = new System.Drawing.Point(658, 617);
            this.xrLabel126.Name = "xrLabel126";
            this.xrLabel126.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xrLabel126.ParentStyleUsing.UseFont = false;
            this.xrLabel126.Size = new System.Drawing.Size(100, 17);
            this.xrLabel126.Text = "xrLabel126";
            this.xrLabel126.WordWrap = false;
            // 
            // xrLabel124
            // 
            this.xrLabel124.DataBindings.AddRange(new DevExpress.XtraReports.UI.XRBinding[] {
            new DevExpress.XtraReports.UI.XRBinding("Text", null, "tblAccount.GeneralContractorContactPhone", "")});
            this.xrLabel124.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xrLabel124.Location = new System.Drawing.Point(492, 617);
            this.xrLabel124.Name = "xrLabel124";
            this.xrLabel124.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xrLabel124.ParentStyleUsing.UseFont = false;
            this.xrLabel124.Size = new System.Drawing.Size(100, 17);
            this.xrLabel124.Text = "xrLabel124";
            this.xrLabel124.WordWrap = false;
            // 
            // xrLabel123
            // 
            this.xrLabel123.DataBindings.AddRange(new DevExpress.XtraReports.UI.XRBinding[] {
            new DevExpress.XtraReports.UI.XRBinding("Text", null, "tblAccount.GeneralContractorContactEmail", "")});
            this.xrLabel123.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xrLabel123.Location = new System.Drawing.Point(492, 600);
            this.xrLabel123.Name = "xrLabel123";
            this.xrLabel123.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xrLabel123.ParentStyleUsing.UseFont = false;
            this.xrLabel123.Size = new System.Drawing.Size(267, 17);
            this.xrLabel123.Text = "xrLabel123";
            this.xrLabel123.WordWrap = false;
            // 
            // xrLabel122
            // 
            this.xrLabel122.DataBindings.AddRange(new DevExpress.XtraReports.UI.XRBinding[] {
            new DevExpress.XtraReports.UI.XRBinding("Text", null, "tblAccount.GeneralContractorContactName", "")});
            this.xrLabel122.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xrLabel122.Location = new System.Drawing.Point(492, 583);
            this.xrLabel122.Name = "xrLabel122";
            this.xrLabel122.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xrLabel122.ParentStyleUsing.UseFont = false;
            this.xrLabel122.Size = new System.Drawing.Size(267, 17);
            this.xrLabel122.Text = "xrLabel122";
            this.xrLabel122.WordWrap = false;
            // 
            // xrLabel121
            // 
            this.xrLabel121.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xrLabel121.Location = new System.Drawing.Point(608, 617);
            this.xrLabel121.Name = "xrLabel121";
            this.xrLabel121.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xrLabel121.ParentStyleUsing.UseFont = false;
            this.xrLabel121.Size = new System.Drawing.Size(50, 17);
            this.xrLabel121.Text = "Fax:";
            this.xrLabel121.WordWrap = false;
            // 
            // xrLabel120
            // 
            this.xrLabel120.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xrLabel120.Location = new System.Drawing.Point(433, 617);
            this.xrLabel120.Name = "xrLabel120";
            this.xrLabel120.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xrLabel120.ParentStyleUsing.UseFont = false;
            this.xrLabel120.Size = new System.Drawing.Size(58, 17);
            this.xrLabel120.Text = "Phone:";
            this.xrLabel120.WordWrap = false;
            // 
            // xrLabel119
            // 
            this.xrLabel119.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xrLabel119.Location = new System.Drawing.Point(433, 600);
            this.xrLabel119.Name = "xrLabel119";
            this.xrLabel119.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xrLabel119.ParentStyleUsing.UseFont = false;
            this.xrLabel119.Size = new System.Drawing.Size(58, 17);
            this.xrLabel119.Text = "Email:";
            this.xrLabel119.WordWrap = false;
            // 
            // xrLabel118
            // 
            this.xrLabel118.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xrLabel118.Location = new System.Drawing.Point(433, 583);
            this.xrLabel118.Name = "xrLabel118";
            this.xrLabel118.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xrLabel118.ParentStyleUsing.UseFont = false;
            this.xrLabel118.Size = new System.Drawing.Size(58, 17);
            this.xrLabel118.Text = "Contact:";
            this.xrLabel118.WordWrap = false;
            // 
            // xrLabel117
            // 
            this.xrLabel117.DataBindings.AddRange(new DevExpress.XtraReports.UI.XRBinding[] {
            new DevExpress.XtraReports.UI.XRBinding("Text", null, "tblAccount.GeneralContractorZip", "")});
            this.xrLabel117.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xrLabel117.Location = new System.Drawing.Point(342, 617);
            this.xrLabel117.Name = "xrLabel117";
            this.xrLabel117.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xrLabel117.ParentStyleUsing.UseFont = false;
            this.xrLabel117.Size = new System.Drawing.Size(48, 17);
            this.xrLabel117.Text = "xrLabel117";
            this.xrLabel117.WordWrap = false;
            // 
            // xrLabel116
            // 
            this.xrLabel116.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xrLabel116.Location = new System.Drawing.Point(317, 617);
            this.xrLabel116.Name = "xrLabel116";
            this.xrLabel116.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xrLabel116.ParentStyleUsing.UseFont = false;
            this.xrLabel116.Size = new System.Drawing.Size(25, 17);
            this.xrLabel116.Text = "Zip:";
            this.xrLabel116.WordWrap = false;
            // 
            // xrLabel115
            // 
            this.xrLabel115.DataBindings.AddRange(new DevExpress.XtraReports.UI.XRBinding[] {
            new DevExpress.XtraReports.UI.XRBinding("Text", null, "tblAccount.GeneralContractorState", "")});
            this.xrLabel115.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xrLabel115.Location = new System.Drawing.Point(275, 617);
            this.xrLabel115.Name = "xrLabel115";
            this.xrLabel115.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xrLabel115.ParentStyleUsing.UseFont = false;
            this.xrLabel115.Size = new System.Drawing.Size(33, 17);
            this.xrLabel115.Text = "xrLabel115";
            this.xrLabel115.WordWrap = false;
            // 
            // xrLabel114
            // 
            this.xrLabel114.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xrLabel114.Location = new System.Drawing.Point(233, 617);
            this.xrLabel114.Name = "xrLabel114";
            this.xrLabel114.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xrLabel114.ParentStyleUsing.UseFont = false;
            this.xrLabel114.Size = new System.Drawing.Size(42, 17);
            this.xrLabel114.Text = "State:";
            this.xrLabel114.WordWrap = false;
            // 
            // xrLabel113
            // 
            this.xrLabel113.DataBindings.AddRange(new DevExpress.XtraReports.UI.XRBinding[] {
            new DevExpress.XtraReports.UI.XRBinding("Text", null, "tblAccount.GeneralContractorCity", "")});
            this.xrLabel113.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xrLabel113.Location = new System.Drawing.Point(133, 617);
            this.xrLabel113.Name = "xrLabel113";
            this.xrLabel113.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xrLabel113.ParentStyleUsing.UseFont = false;
            this.xrLabel113.Size = new System.Drawing.Size(100, 17);
            this.xrLabel113.Text = "xrLabel113";
            this.xrLabel113.WordWrap = false;
            // 
            // xrLabel112
            // 
            this.xrLabel112.DataBindings.AddRange(new DevExpress.XtraReports.UI.XRBinding[] {
            new DevExpress.XtraReports.UI.XRBinding("Text", null, "tblAccount.GeneralContractorAddress", "")});
            this.xrLabel112.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xrLabel112.Location = new System.Drawing.Point(133, 600);
            this.xrLabel112.Name = "xrLabel112";
            this.xrLabel112.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xrLabel112.ParentStyleUsing.UseFont = false;
            this.xrLabel112.Size = new System.Drawing.Size(158, 17);
            this.xrLabel112.Text = "xrLabel112";
            this.xrLabel112.WordWrap = false;
            // 
            // xrLabel111
            // 
            this.xrLabel111.DataBindings.AddRange(new DevExpress.XtraReports.UI.XRBinding[] {
            new DevExpress.XtraReports.UI.XRBinding("Text", null, "tblAccount.GeneralContractorName", "")});
            this.xrLabel111.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xrLabel111.Location = new System.Drawing.Point(133, 583);
            this.xrLabel111.Name = "xrLabel111";
            this.xrLabel111.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xrLabel111.ParentStyleUsing.UseFont = false;
            this.xrLabel111.Size = new System.Drawing.Size(158, 17);
            this.xrLabel111.Text = "xrLabel111";
            this.xrLabel111.WordWrap = false;
            // 
            // xrLabel110
            // 
            this.xrLabel110.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xrLabel110.Location = new System.Drawing.Point(75, 617);
            this.xrLabel110.Name = "xrLabel110";
            this.xrLabel110.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xrLabel110.ParentStyleUsing.UseFont = false;
            this.xrLabel110.Size = new System.Drawing.Size(58, 17);
            this.xrLabel110.Text = "City:";
            this.xrLabel110.WordWrap = false;
            // 
            // xrLabel109
            // 
            this.xrLabel109.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xrLabel109.Location = new System.Drawing.Point(75, 600);
            this.xrLabel109.Name = "xrLabel109";
            this.xrLabel109.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xrLabel109.ParentStyleUsing.UseFont = false;
            this.xrLabel109.Size = new System.Drawing.Size(58, 17);
            this.xrLabel109.Text = "Address:";
            this.xrLabel109.WordWrap = false;
            // 
            // xrLabel108
            // 
            this.xrLabel108.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xrLabel108.Location = new System.Drawing.Point(75, 583);
            this.xrLabel108.Name = "xrLabel108";
            this.xrLabel108.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xrLabel108.ParentStyleUsing.UseFont = false;
            this.xrLabel108.Size = new System.Drawing.Size(58, 17);
            this.xrLabel108.Text = "Name:";
            this.xrLabel108.WordWrap = false;
            // 
            // xrLabel107
            // 
            this.xrLabel107.Font = new System.Drawing.Font("Tahoma", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xrLabel107.Location = new System.Drawing.Point(75, 567);
            this.xrLabel107.Name = "xrLabel107";
            this.xrLabel107.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xrLabel107.ParentStyleUsing.UseFont = false;
            this.xrLabel107.Size = new System.Drawing.Size(117, 17);
            this.xrLabel107.Text = "General Contractor";
            this.xrLabel107.WordWrap = false;
            // 
            // xrLabel106
            // 
            this.xrLabel106.DataBindings.AddRange(new DevExpress.XtraReports.UI.XRBinding[] {
            new DevExpress.XtraReports.UI.XRBinding("Text", null, "tblAccount.OwnerContactFax", "")});
            this.xrLabel106.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xrLabel106.Location = new System.Drawing.Point(659, 542);
            this.xrLabel106.Name = "xrLabel106";
            this.xrLabel106.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xrLabel106.ParentStyleUsing.UseFont = false;
            this.xrLabel106.Size = new System.Drawing.Size(100, 17);
            this.xrLabel106.Text = "xrLabel106";
            this.xrLabel106.WordWrap = false;
            // 
            // xrLabel105
            // 
            this.xrLabel105.DataBindings.AddRange(new DevExpress.XtraReports.UI.XRBinding[] {
            new DevExpress.XtraReports.UI.XRBinding("Text", null, "tblAccount.OwnerContactPhone", "")});
            this.xrLabel105.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xrLabel105.Location = new System.Drawing.Point(492, 542);
            this.xrLabel105.Name = "xrLabel105";
            this.xrLabel105.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xrLabel105.ParentStyleUsing.UseFont = false;
            this.xrLabel105.Size = new System.Drawing.Size(100, 17);
            this.xrLabel105.Text = "xrLabel105";
            this.xrLabel105.WordWrap = false;
            // 
            // xrLabel104
            // 
            this.xrLabel104.DataBindings.AddRange(new DevExpress.XtraReports.UI.XRBinding[] {
            new DevExpress.XtraReports.UI.XRBinding("Text", null, "tblAccount.OwnerContactEmail", "")});
            this.xrLabel104.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xrLabel104.Location = new System.Drawing.Point(492, 525);
            this.xrLabel104.Name = "xrLabel104";
            this.xrLabel104.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xrLabel104.ParentStyleUsing.UseFont = false;
            this.xrLabel104.Size = new System.Drawing.Size(267, 17);
            this.xrLabel104.Text = "xrLabel104";
            this.xrLabel104.WordWrap = false;
            // 
            // xrLabel103
            // 
            this.xrLabel103.DataBindings.AddRange(new DevExpress.XtraReports.UI.XRBinding[] {
            new DevExpress.XtraReports.UI.XRBinding("Text", null, "tblAccount.OwnerContactName", "")});
            this.xrLabel103.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xrLabel103.Location = new System.Drawing.Point(492, 507);
            this.xrLabel103.Name = "xrLabel103";
            this.xrLabel103.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xrLabel103.ParentStyleUsing.UseFont = false;
            this.xrLabel103.Size = new System.Drawing.Size(267, 17);
            this.xrLabel103.Text = "xrLabel103";
            this.xrLabel103.WordWrap = false;
            // 
            // xrLabel102
            // 
            this.xrLabel102.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xrLabel102.Location = new System.Drawing.Point(608, 542);
            this.xrLabel102.Name = "xrLabel102";
            this.xrLabel102.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xrLabel102.ParentStyleUsing.UseFont = false;
            this.xrLabel102.Size = new System.Drawing.Size(50, 17);
            this.xrLabel102.Text = "Fax:";
            this.xrLabel102.WordWrap = false;
            // 
            // xrLabel101
            // 
            this.xrLabel101.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xrLabel101.Location = new System.Drawing.Point(433, 542);
            this.xrLabel101.Name = "xrLabel101";
            this.xrLabel101.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xrLabel101.ParentStyleUsing.UseFont = false;
            this.xrLabel101.Size = new System.Drawing.Size(58, 17);
            this.xrLabel101.Text = "Phone:";
            this.xrLabel101.WordWrap = false;
            // 
            // xrLabel100
            // 
            this.xrLabel100.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xrLabel100.Location = new System.Drawing.Point(433, 525);
            this.xrLabel100.Name = "xrLabel100";
            this.xrLabel100.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xrLabel100.ParentStyleUsing.UseFont = false;
            this.xrLabel100.Size = new System.Drawing.Size(58, 17);
            this.xrLabel100.Text = "Email:";
            this.xrLabel100.WordWrap = false;
            // 
            // xrLabel99
            // 
            this.xrLabel99.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xrLabel99.Location = new System.Drawing.Point(433, 507);
            this.xrLabel99.Name = "xrLabel99";
            this.xrLabel99.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xrLabel99.ParentStyleUsing.UseFont = false;
            this.xrLabel99.Size = new System.Drawing.Size(58, 17);
            this.xrLabel99.Text = "Contact:";
            this.xrLabel99.WordWrap = false;
            // 
            // xrLabel98
            // 
            this.xrLabel98.DataBindings.AddRange(new DevExpress.XtraReports.UI.XRBinding[] {
            new DevExpress.XtraReports.UI.XRBinding("Text", null, "tblAccount.OwnerZip", "")});
            this.xrLabel98.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xrLabel98.Location = new System.Drawing.Point(344, 542);
            this.xrLabel98.Name = "xrLabel98";
            this.xrLabel98.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xrLabel98.ParentStyleUsing.UseFont = false;
            this.xrLabel98.Size = new System.Drawing.Size(48, 17);
            this.xrLabel98.Text = "xrLabel98";
            this.xrLabel98.WordWrap = false;
            // 
            // xrLabel97
            // 
            this.xrLabel97.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xrLabel97.Location = new System.Drawing.Point(317, 542);
            this.xrLabel97.Name = "xrLabel97";
            this.xrLabel97.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xrLabel97.ParentStyleUsing.UseFont = false;
            this.xrLabel97.Size = new System.Drawing.Size(25, 17);
            this.xrLabel97.Text = "Zip:";
            this.xrLabel97.WordWrap = false;
            // 
            // xrLabel96
            // 
            this.xrLabel96.DataBindings.AddRange(new DevExpress.XtraReports.UI.XRBinding[] {
            new DevExpress.XtraReports.UI.XRBinding("Text", null, "tblAccount.OwnerState", "")});
            this.xrLabel96.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xrLabel96.Location = new System.Drawing.Point(275, 542);
            this.xrLabel96.Name = "xrLabel96";
            this.xrLabel96.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xrLabel96.ParentStyleUsing.UseFont = false;
            this.xrLabel96.Size = new System.Drawing.Size(33, 17);
            this.xrLabel96.Text = "xrLabel96";
            this.xrLabel96.WordWrap = false;
            // 
            // xrLabel95
            // 
            this.xrLabel95.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xrLabel95.Location = new System.Drawing.Point(233, 542);
            this.xrLabel95.Name = "xrLabel95";
            this.xrLabel95.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xrLabel95.ParentStyleUsing.UseFont = false;
            this.xrLabel95.Size = new System.Drawing.Size(42, 17);
            this.xrLabel95.Text = "State:";
            this.xrLabel95.WordWrap = false;
            // 
            // xrLabel94
            // 
            this.xrLabel94.DataBindings.AddRange(new DevExpress.XtraReports.UI.XRBinding[] {
            new DevExpress.XtraReports.UI.XRBinding("Text", null, "tblAccount.OwnerCity", "")});
            this.xrLabel94.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xrLabel94.Location = new System.Drawing.Point(133, 542);
            this.xrLabel94.Name = "xrLabel94";
            this.xrLabel94.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xrLabel94.ParentStyleUsing.UseFont = false;
            this.xrLabel94.Size = new System.Drawing.Size(100, 17);
            this.xrLabel94.Text = "xrLabel94";
            this.xrLabel94.WordWrap = false;
            // 
            // xrLabel93
            // 
            this.xrLabel93.DataBindings.AddRange(new DevExpress.XtraReports.UI.XRBinding[] {
            new DevExpress.XtraReports.UI.XRBinding("Text", null, "tblAccount.OwnerAddress", "")});
            this.xrLabel93.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xrLabel93.Location = new System.Drawing.Point(133, 525);
            this.xrLabel93.Name = "xrLabel93";
            this.xrLabel93.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xrLabel93.ParentStyleUsing.UseFont = false;
            this.xrLabel93.Size = new System.Drawing.Size(158, 17);
            this.xrLabel93.Text = "xrLabel93";
            this.xrLabel93.WordWrap = false;
            // 
            // xrLabel92
            // 
            this.xrLabel92.DataBindings.AddRange(new DevExpress.XtraReports.UI.XRBinding[] {
            new DevExpress.XtraReports.UI.XRBinding("Text", null, "tblAccount.OwnerName", "")});
            this.xrLabel92.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xrLabel92.Location = new System.Drawing.Point(133, 507);
            this.xrLabel92.Name = "xrLabel92";
            this.xrLabel92.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xrLabel92.ParentStyleUsing.UseFont = false;
            this.xrLabel92.Size = new System.Drawing.Size(158, 17);
            this.xrLabel92.Text = "xrLabel92";
            this.xrLabel92.WordWrap = false;
            // 
            // xrLabel91
            // 
            this.xrLabel91.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xrLabel91.Location = new System.Drawing.Point(75, 542);
            this.xrLabel91.Name = "xrLabel91";
            this.xrLabel91.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xrLabel91.ParentStyleUsing.UseFont = false;
            this.xrLabel91.Size = new System.Drawing.Size(58, 17);
            this.xrLabel91.Text = "City:";
            this.xrLabel91.WordWrap = false;
            // 
            // xrLabel90
            // 
            this.xrLabel90.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xrLabel90.Location = new System.Drawing.Point(75, 525);
            this.xrLabel90.Name = "xrLabel90";
            this.xrLabel90.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xrLabel90.ParentStyleUsing.UseFont = false;
            this.xrLabel90.Size = new System.Drawing.Size(58, 17);
            this.xrLabel90.Text = "Address:";
            this.xrLabel90.WordWrap = false;
            // 
            // xrLabel89
            // 
            this.xrLabel89.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xrLabel89.Location = new System.Drawing.Point(75, 507);
            this.xrLabel89.Name = "xrLabel89";
            this.xrLabel89.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xrLabel89.ParentStyleUsing.UseFont = false;
            this.xrLabel89.Size = new System.Drawing.Size(58, 17);
            this.xrLabel89.Text = "Name:";
            this.xrLabel89.WordWrap = false;
            // 
            // xrLabel88
            // 
            this.xrLabel88.Font = new System.Drawing.Font("Tahoma", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xrLabel88.Location = new System.Drawing.Point(75, 492);
            this.xrLabel88.Name = "xrLabel88";
            this.xrLabel88.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xrLabel88.ParentStyleUsing.UseFont = false;
            this.xrLabel88.Size = new System.Drawing.Size(117, 17);
            this.xrLabel88.Text = "Owner";
            this.xrLabel88.WordWrap = false;
            // 
            // xrLabel87
            // 
            this.xrLabel87.DataBindings.AddRange(new DevExpress.XtraReports.UI.XRBinding[] {
            new DevExpress.XtraReports.UI.XRBinding("Text", null, "tblAccount.ApprovedBy", "")});
            this.xrLabel87.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xrLabel87.Location = new System.Drawing.Point(292, 433);
            this.xrLabel87.Name = "xrLabel87";
            this.xrLabel87.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xrLabel87.ParentStyleUsing.UseFont = false;
            this.xrLabel87.Size = new System.Drawing.Size(133, 17);
            this.xrLabel87.Text = "xrLabel87";
            this.xrLabel87.WordWrap = false;
            // 
            // xrCheckBox25
            // 
            this.xrCheckBox25.DataBindings.AddRange(new DevExpress.XtraReports.UI.XRBinding[] {
            new DevExpress.XtraReports.UI.XRBinding("CheckState", null, "tblAccount.Approved", "")});
            this.xrCheckBox25.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xrCheckBox25.Location = new System.Drawing.Point(158, 433);
            this.xrCheckBox25.Name = "xrCheckBox25";
            this.xrCheckBox25.ParentStyleUsing.UseFont = false;
            this.xrCheckBox25.Size = new System.Drawing.Size(25, 17);
            this.xrCheckBox25.WordWrap = false;
            // 
            // xrLabel86
            // 
            this.xrLabel86.DataBindings.AddRange(new DevExpress.XtraReports.UI.XRBinding[] {
            new DevExpress.XtraReports.UI.XRBinding("Text", null, "tblAccount.SubmittedDate", "{0:MM/dd/yyyy}")});
            this.xrLabel86.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xrLabel86.Location = new System.Drawing.Point(683, 0);
            this.xrLabel86.Name = "xrLabel86";
            this.xrLabel86.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xrLabel86.ParentStyleUsing.UseFont = false;
            this.xrLabel86.Size = new System.Drawing.Size(83, 17);
            this.xrLabel86.Text = "xrLabel86";
            this.xrLabel86.WordWrap = false;
            // 
            // xrLabel85
            // 
            this.xrLabel85.DataBindings.AddRange(new DevExpress.XtraReports.UI.XRBinding[] {
            new DevExpress.XtraReports.UI.XRBinding("Text", null, "tblAccount.SubmittedByName", "")});
            this.xrLabel85.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xrLabel85.Location = new System.Drawing.Point(492, 0);
            this.xrLabel85.Name = "xrLabel85";
            this.xrLabel85.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xrLabel85.ParentStyleUsing.UseFont = false;
            this.xrLabel85.Size = new System.Drawing.Size(133, 17);
            this.xrLabel85.Text = "xrLabel85";
            this.xrLabel85.WordWrap = false;
            // 
            // xrLabel84
            // 
            this.xrLabel84.DataBindings.AddRange(new DevExpress.XtraReports.UI.XRBinding[] {
            new DevExpress.XtraReports.UI.XRBinding("Text", null, "tblAccount.OpportunityValue", "")});
            this.xrLabel84.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xrLabel84.Location = new System.Drawing.Point(633, 377);
            this.xrLabel84.Name = "xrLabel84";
            this.xrLabel84.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xrLabel84.ParentStyleUsing.UseFont = false;
            this.xrLabel84.Size = new System.Drawing.Size(83, 17);
            this.xrLabel84.Text = "xrLabel84";
            this.xrLabel84.WordWrap = false;
            // 
            // xrCheckBox24
            // 
            this.xrCheckBox24.DataBindings.AddRange(new DevExpress.XtraReports.UI.XRBinding[] {
            new DevExpress.XtraReports.UI.XRBinding("CheckState", null, "tblAccount.DrawingAvailable", "")});
            this.xrCheckBox24.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xrCheckBox24.Location = new System.Drawing.Point(417, 377);
            this.xrCheckBox24.Name = "xrCheckBox24";
            this.xrCheckBox24.ParentStyleUsing.UseFont = false;
            this.xrCheckBox24.Size = new System.Drawing.Size(25, 17);
            this.xrCheckBox24.WordWrap = false;
            // 
            // xrLabel83
            // 
            this.xrLabel83.DataBindings.AddRange(new DevExpress.XtraReports.UI.XRBinding[] {
            new DevExpress.XtraReports.UI.XRBinding("Text", null, "tblAccount.MinorityType", "")});
            this.xrLabel83.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xrLabel83.Location = new System.Drawing.Point(575, 360);
            this.xrLabel83.Name = "xrLabel83";
            this.xrLabel83.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xrLabel83.ParentStyleUsing.UseFont = false;
            this.xrLabel83.Size = new System.Drawing.Size(108, 17);
            this.xrLabel83.Text = "xrLabel83";
            this.xrLabel83.WordWrap = false;
            // 
            // xrCheckBox22
            // 
            this.xrCheckBox22.DataBindings.AddRange(new DevExpress.XtraReports.UI.XRBinding[] {
            new DevExpress.XtraReports.UI.XRBinding("CheckState", null, "tblAccount.MinorityRequirements", "")});
            this.xrCheckBox22.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xrCheckBox22.Location = new System.Drawing.Point(417, 360);
            this.xrCheckBox22.Name = "xrCheckBox22";
            this.xrCheckBox22.ParentStyleUsing.UseFont = false;
            this.xrCheckBox22.Size = new System.Drawing.Size(25, 17);
            this.xrCheckBox22.WordWrap = false;
            // 
            // xrLabel82
            // 
            this.xrLabel82.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xrLabel82.Location = new System.Drawing.Point(192, 433);
            this.xrLabel82.Name = "xrLabel82";
            this.xrLabel82.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xrLabel82.ParentStyleUsing.UseFont = false;
            this.xrLabel82.Size = new System.Drawing.Size(100, 17);
            this.xrLabel82.Text = "DM Approved By:";
            this.xrLabel82.WordWrap = false;
            // 
            // xrLabel81
            // 
            this.xrLabel81.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xrLabel81.Location = new System.Drawing.Point(75, 433);
            this.xrLabel81.Name = "xrLabel81";
            this.xrLabel81.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xrLabel81.ParentStyleUsing.UseFont = false;
            this.xrLabel81.Size = new System.Drawing.Size(83, 17);
            this.xrLabel81.Text = "DM. Approved:";
            this.xrLabel81.WordWrap = false;
            // 
            // xrLabel80
            // 
            this.xrLabel80.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xrLabel80.Location = new System.Drawing.Point(633, 0);
            this.xrLabel80.Name = "xrLabel80";
            this.xrLabel80.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xrLabel80.ParentStyleUsing.UseFont = false;
            this.xrLabel80.Size = new System.Drawing.Size(42, 17);
            this.xrLabel80.Text = "Date:";
            this.xrLabel80.WordWrap = false;
            // 
            // xrLabel79
            // 
            this.xrLabel79.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xrLabel79.Location = new System.Drawing.Point(408, 0);
            this.xrLabel79.Name = "xrLabel79";
            this.xrLabel79.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xrLabel79.ParentStyleUsing.UseFont = false;
            this.xrLabel79.Size = new System.Drawing.Size(75, 17);
            this.xrLabel79.Text = "Submitted by:";
            this.xrLabel79.WordWrap = false;
            // 
            // xrLabel78
            // 
            this.xrLabel78.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xrLabel78.Location = new System.Drawing.Point(483, 377);
            this.xrLabel78.Name = "xrLabel78";
            this.xrLabel78.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xrLabel78.ParentStyleUsing.UseFont = false;
            this.xrLabel78.Size = new System.Drawing.Size(142, 17);
            this.xrLabel78.Text = "Opportunity Value (1-10):";
            this.xrLabel78.WordWrap = false;
            // 
            // xrLabel77
            // 
            this.xrLabel77.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xrLabel77.Location = new System.Drawing.Point(292, 377);
            this.xrLabel77.Name = "xrLabel77";
            this.xrLabel77.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xrLabel77.ParentStyleUsing.UseFont = false;
            this.xrLabel77.Size = new System.Drawing.Size(108, 17);
            this.xrLabel77.Text = "Drawings Available?";
            this.xrLabel77.WordWrap = false;
            // 
            // xrLabel76
            // 
            this.xrLabel76.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xrLabel76.Location = new System.Drawing.Point(75, 175);
            this.xrLabel76.Name = "xrLabel76";
            this.xrLabel76.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xrLabel76.ParentStyleUsing.UseFont = false;
            this.xrLabel76.Size = new System.Drawing.Size(100, 17);
            this.xrLabel76.Text = "Prequal required?";
            this.xrLabel76.WordWrap = false;
            // 
            // xrLabel75
            // 
            this.xrLabel75.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xrLabel75.Location = new System.Drawing.Point(483, 360);
            this.xrLabel75.Name = "xrLabel75";
            this.xrLabel75.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xrLabel75.ParentStyleUsing.UseFont = false;
            this.xrLabel75.Size = new System.Drawing.Size(83, 17);
            this.xrLabel75.Text = "Minority Type:";
            this.xrLabel75.WordWrap = false;
            // 
            // xrLabel74
            // 
            this.xrLabel74.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xrLabel74.Location = new System.Drawing.Point(292, 360);
            this.xrLabel74.Name = "xrLabel74";
            this.xrLabel74.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xrLabel74.ParentStyleUsing.UseFont = false;
            this.xrLabel74.Size = new System.Drawing.Size(125, 17);
            this.xrLabel74.Text = "Minority requirements?";
            this.xrLabel74.WordWrap = false;
            // 
            // xrLabel73
            // 
            this.xrLabel73.DataBindings.AddRange(new DevExpress.XtraReports.UI.XRBinding[] {
            new DevExpress.XtraReports.UI.XRBinding("Text", null, "tblAccount.FinanceInPlace", "")});
            this.xrLabel73.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xrLabel73.Location = new System.Drawing.Point(192, 360);
            this.xrLabel73.Name = "xrLabel73";
            this.xrLabel73.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xrLabel73.ParentStyleUsing.UseFont = false;
            this.xrLabel73.Size = new System.Drawing.Size(75, 17);
            this.xrLabel73.Text = "xrLabel73";
            this.xrLabel73.WordWrap = false;
            // 
            // xrLabel72
            // 
            this.xrLabel72.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xrLabel72.Location = new System.Drawing.Point(75, 360);
            this.xrLabel72.Name = "xrLabel72";
            this.xrLabel72.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xrLabel72.ParentStyleUsing.UseFont = false;
            this.xrLabel72.Size = new System.Drawing.Size(108, 17);
            this.xrLabel72.Text = "Financing in Place?";
            this.xrLabel72.WordWrap = false;
            // 
            // xrLabel71
            // 
            this.xrLabel71.DataBindings.AddRange(new DevExpress.XtraReports.UI.XRBinding[] {
            new DevExpress.XtraReports.UI.XRBinding("Text", null, "tblAccount.Other", "")});
            this.xrLabel71.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xrLabel71.Location = new System.Drawing.Point(642, 335);
            this.xrLabel71.Name = "xrLabel71";
            this.xrLabel71.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xrLabel71.ParentStyleUsing.UseFont = false;
            this.xrLabel71.Size = new System.Drawing.Size(158, 17);
            this.xrLabel71.Text = "xrLabel71";
            this.xrLabel71.WordWrap = false;
            // 
            // xrCheckBox21
            // 
            this.xrCheckBox21.DataBindings.AddRange(new DevExpress.XtraReports.UI.XRBinding[] {
            new DevExpress.XtraReports.UI.XRBinding("CheckState", null, "tblAccount.Negotiated", "")});
            this.xrCheckBox21.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xrCheckBox21.Location = new System.Drawing.Point(520, 335);
            this.xrCheckBox21.Name = "xrCheckBox21";
            this.xrCheckBox21.ParentStyleUsing.UseFont = false;
            this.xrCheckBox21.Size = new System.Drawing.Size(25, 17);
            this.xrCheckBox21.WordWrap = false;
            // 
            // xrCheckBox19
            // 
            this.xrCheckBox19.DataBindings.AddRange(new DevExpress.XtraReports.UI.XRBinding[] {
            new DevExpress.XtraReports.UI.XRBinding("CheckState", null, "tblAccount.Bid", "")});
            this.xrCheckBox19.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xrCheckBox19.Location = new System.Drawing.Point(317, 335);
            this.xrCheckBox19.Name = "xrCheckBox19";
            this.xrCheckBox19.ParentStyleUsing.UseFont = false;
            this.xrCheckBox19.Size = new System.Drawing.Size(25, 17);
            this.xrCheckBox19.WordWrap = false;
            // 
            // xrCheckBox17
            // 
            this.xrCheckBox17.DataBindings.AddRange(new DevExpress.XtraReports.UI.XRBinding[] {
            new DevExpress.XtraReports.UI.XRBinding("CheckState", null, "tblAccount.BudgetOnly", "")});
            this.xrCheckBox17.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xrCheckBox17.Location = new System.Drawing.Point(158, 335);
            this.xrCheckBox17.Name = "xrCheckBox17";
            this.xrCheckBox17.ParentStyleUsing.UseFont = false;
            this.xrCheckBox17.Size = new System.Drawing.Size(25, 17);
            this.xrCheckBox17.WordWrap = false;
            // 
            // xrCheckBox16
            // 
            this.xrCheckBox16.DataBindings.AddRange(new DevExpress.XtraReports.UI.XRBinding[] {
            new DevExpress.XtraReports.UI.XRBinding("CheckState", null, "tblAccount.PrevailingWage", "")});
            this.xrCheckBox16.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xrCheckBox16.Location = new System.Drawing.Point(642, 319);
            this.xrCheckBox16.Name = "xrCheckBox16";
            this.xrCheckBox16.ParentStyleUsing.UseFont = false;
            this.xrCheckBox16.Size = new System.Drawing.Size(25, 17);
            this.xrCheckBox16.WordWrap = false;
            // 
            // xrCheckBox15
            // 
            this.xrCheckBox15.DataBindings.AddRange(new DevExpress.XtraReports.UI.XRBinding[] {
            new DevExpress.XtraReports.UI.XRBinding("CheckState", null, "tblAccount.PLA", "")});
            this.xrCheckBox15.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xrCheckBox15.Location = new System.Drawing.Point(520, 319);
            this.xrCheckBox15.Name = "xrCheckBox15";
            this.xrCheckBox15.ParentStyleUsing.UseFont = false;
            this.xrCheckBox15.Size = new System.Drawing.Size(25, 17);
            this.xrCheckBox15.WordWrap = false;
            // 
            // xrCheckBox14
            // 
            this.xrCheckBox14.DataBindings.AddRange(new DevExpress.XtraReports.UI.XRBinding[] {
            new DevExpress.XtraReports.UI.XRBinding("CheckState", null, "tblAccount.DesignAssist", "")});
            this.xrCheckBox14.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xrCheckBox14.Location = new System.Drawing.Point(425, 319);
            this.xrCheckBox14.Name = "xrCheckBox14";
            this.xrCheckBox14.ParentStyleUsing.UseFont = false;
            this.xrCheckBox14.Size = new System.Drawing.Size(25, 17);
            this.xrCheckBox14.WordWrap = false;
            // 
            // xrCheckBox13
            // 
            this.xrCheckBox13.DataBindings.AddRange(new DevExpress.XtraReports.UI.XRBinding[] {
            new DevExpress.XtraReports.UI.XRBinding("CheckState", null, "tblAccount.DesignBuild", "")});
            this.xrCheckBox13.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xrCheckBox13.Location = new System.Drawing.Point(317, 319);
            this.xrCheckBox13.Name = "xrCheckBox13";
            this.xrCheckBox13.ParentStyleUsing.UseFont = false;
            this.xrCheckBox13.Size = new System.Drawing.Size(25, 17);
            this.xrCheckBox13.WordWrap = false;
            // 
            // xrCheckBox12
            // 
            this.xrCheckBox12.DataBindings.AddRange(new DevExpress.XtraReports.UI.XRBinding[] {
            new DevExpress.XtraReports.UI.XRBinding("CheckState", null, "tblAccount.LEED", "")});
            this.xrCheckBox12.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xrCheckBox12.Location = new System.Drawing.Point(217, 319);
            this.xrCheckBox12.Name = "xrCheckBox12";
            this.xrCheckBox12.ParentStyleUsing.UseFont = false;
            this.xrCheckBox12.Size = new System.Drawing.Size(25, 17);
            this.xrCheckBox12.WordWrap = false;
            // 
            // xrCheckBox11
            // 
            this.xrCheckBox11.DataBindings.AddRange(new DevExpress.XtraReports.UI.XRBinding[] {
            new DevExpress.XtraReports.UI.XRBinding("CheckState", null, "tblAccount.Engineered", "")});
            this.xrCheckBox11.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xrCheckBox11.Location = new System.Drawing.Point(150, 319);
            this.xrCheckBox11.Name = "xrCheckBox11";
            this.xrCheckBox11.ParentStyleUsing.UseFont = false;
            this.xrCheckBox11.Size = new System.Drawing.Size(25, 17);
            this.xrCheckBox11.WordWrap = false;
            // 
            // xrLabel70
            // 
            this.xrLabel70.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xrLabel70.Location = new System.Drawing.Point(573, 335);
            this.xrLabel70.Name = "xrLabel70";
            this.xrLabel70.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xrLabel70.ParentStyleUsing.UseFont = false;
            this.xrLabel70.Size = new System.Drawing.Size(67, 17);
            this.xrLabel70.Text = "Other:";
            this.xrLabel70.WordWrap = false;
            // 
            // xrLabel69
            // 
            this.xrLabel69.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xrLabel69.Location = new System.Drawing.Point(450, 335);
            this.xrLabel69.Name = "xrLabel69";
            this.xrLabel69.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xrLabel69.ParentStyleUsing.UseFont = false;
            this.xrLabel69.Size = new System.Drawing.Size(67, 17);
            this.xrLabel69.Text = "Negotiated:";
            this.xrLabel69.WordWrap = false;
            // 
            // xrLabel53
            // 
            this.xrLabel53.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xrLabel53.Location = new System.Drawing.Point(283, 335);
            this.xrLabel53.Name = "xrLabel53";
            this.xrLabel53.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xrLabel53.ParentStyleUsing.UseFont = false;
            this.xrLabel53.Size = new System.Drawing.Size(25, 17);
            this.xrLabel53.Text = "Bid:";
            this.xrLabel53.WordWrap = false;
            // 
            // xrLabel51
            // 
            this.xrLabel51.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xrLabel51.Location = new System.Drawing.Point(75, 335);
            this.xrLabel51.Name = "xrLabel51";
            this.xrLabel51.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xrLabel51.ParentStyleUsing.UseFont = false;
            this.xrLabel51.Size = new System.Drawing.Size(83, 17);
            this.xrLabel51.Text = "*Budget* Only:";
            this.xrLabel51.WordWrap = false;
            // 
            // xrLabel50
            // 
            this.xrLabel50.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xrLabel50.Location = new System.Drawing.Point(548, 319);
            this.xrLabel50.Name = "xrLabel50";
            this.xrLabel50.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xrLabel50.ParentStyleUsing.UseFont = false;
            this.xrLabel50.Size = new System.Drawing.Size(92, 17);
            this.xrLabel50.Text = "Prevailing Wage:";
            this.xrLabel50.WordWrap = false;
            // 
            // xrLabel46
            // 
            this.xrLabel46.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xrLabel46.Location = new System.Drawing.Point(483, 319);
            this.xrLabel46.Name = "xrLabel46";
            this.xrLabel46.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xrLabel46.ParentStyleUsing.UseFont = false;
            this.xrLabel46.Size = new System.Drawing.Size(33, 17);
            this.xrLabel46.Text = "PLA:";
            this.xrLabel46.WordWrap = false;
            // 
            // xrLabel44
            // 
            this.xrLabel44.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xrLabel44.Location = new System.Drawing.Point(350, 319);
            this.xrLabel44.Name = "xrLabel44";
            this.xrLabel44.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xrLabel44.ParentStyleUsing.UseFont = false;
            this.xrLabel44.Size = new System.Drawing.Size(75, 17);
            this.xrLabel44.Text = "Design/Assist:";
            this.xrLabel44.WordWrap = false;
            // 
            // xrLabel43
            // 
            this.xrLabel43.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xrLabel43.Location = new System.Drawing.Point(250, 319);
            this.xrLabel43.Name = "xrLabel43";
            this.xrLabel43.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xrLabel43.ParentStyleUsing.UseFont = false;
            this.xrLabel43.Size = new System.Drawing.Size(67, 17);
            this.xrLabel43.Text = "Design/Build:";
            this.xrLabel43.WordWrap = false;
            // 
            // xrLabel42
            // 
            this.xrLabel42.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xrLabel42.Location = new System.Drawing.Point(175, 319);
            this.xrLabel42.Name = "xrLabel42";
            this.xrLabel42.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xrLabel42.ParentStyleUsing.UseFont = false;
            this.xrLabel42.Size = new System.Drawing.Size(42, 17);
            this.xrLabel42.Text = "LEED:";
            this.xrLabel42.WordWrap = false;
            // 
            // xrLabel41
            // 
            this.xrLabel41.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xrLabel41.Location = new System.Drawing.Point(75, 319);
            this.xrLabel41.Name = "xrLabel41";
            this.xrLabel41.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xrLabel41.ParentStyleUsing.UseFont = false;
            this.xrLabel41.Size = new System.Drawing.Size(67, 17);
            this.xrLabel41.Text = "Engineered:";
            this.xrLabel41.WordWrap = false;
            // 
            // xrCheckBox8
            // 
            this.xrCheckBox8.DataBindings.AddRange(new DevExpress.XtraReports.UI.XRBinding[] {
            new DevExpress.XtraReports.UI.XRBinding("CheckState", null, "tblAccount.ForwardForApproval", "")});
            this.xrCheckBox8.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xrCheckBox8.Location = new System.Drawing.Point(708, 294);
            this.xrCheckBox8.Name = "xrCheckBox8";
            this.xrCheckBox8.ParentStyleUsing.UseFont = false;
            this.xrCheckBox8.Size = new System.Drawing.Size(25, 17);
            this.xrCheckBox8.WordWrap = false;
            // 
            // xrLabel40
            // 
            this.xrLabel40.DataBindings.AddRange(new DevExpress.XtraReports.UI.XRBinding[] {
            new DevExpress.XtraReports.UI.XRBinding("Text", null, "tblAccount.ElectricalDollar", "{0:c2}")});
            this.xrLabel40.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xrLabel40.Location = new System.Drawing.Point(708, 277);
            this.xrLabel40.Name = "xrLabel40";
            this.xrLabel40.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xrLabel40.ParentStyleUsing.UseFont = false;
            this.xrLabel40.Size = new System.Drawing.Size(92, 17);
            this.xrLabel40.Text = "xrLabel40";
            this.xrLabel40.WordWrap = false;
            // 
            // xrLabel39
            // 
            this.xrLabel39.DataBindings.AddRange(new DevExpress.XtraReports.UI.XRBinding[] {
            new DevExpress.XtraReports.UI.XRBinding("Text", null, "tblAccount.ProjectTotalDollar", "{0:c2}")});
            this.xrLabel39.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xrLabel39.Location = new System.Drawing.Point(708, 260);
            this.xrLabel39.Name = "xrLabel39";
            this.xrLabel39.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xrLabel39.ParentStyleUsing.UseFont = false;
            this.xrLabel39.Size = new System.Drawing.Size(92, 17);
            this.xrLabel39.Text = "xrLabel39";
            this.xrLabel39.WordWrap = false;
            // 
            // xrLabel38
            // 
            this.xrLabel38.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xrLabel38.Location = new System.Drawing.Point(583, 294);
            this.xrLabel38.Name = "xrLabel38";
            this.xrLabel38.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xrLabel38.ParentStyleUsing.UseFont = false;
            this.xrLabel38.Size = new System.Drawing.Size(125, 17);
            this.xrLabel38.Text = "Forward for Approval:";
            this.xrLabel38.WordWrap = false;
            // 
            // xrLabel37
            // 
            this.xrLabel37.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xrLabel37.Location = new System.Drawing.Point(583, 277);
            this.xrLabel37.Name = "xrLabel37";
            this.xrLabel37.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xrLabel37.ParentStyleUsing.UseFont = false;
            this.xrLabel37.Size = new System.Drawing.Size(83, 17);
            this.xrLabel37.Text = "Electrical $:";
            this.xrLabel37.WordWrap = false;
            // 
            // xrLabel36
            // 
            this.xrLabel36.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xrLabel36.Location = new System.Drawing.Point(583, 260);
            this.xrLabel36.Name = "xrLabel36";
            this.xrLabel36.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xrLabel36.ParentStyleUsing.UseFont = false;
            this.xrLabel36.Size = new System.Drawing.Size(83, 17);
            this.xrLabel36.Text = "Project Total $:";
            this.xrLabel36.WordWrap = false;
            // 
            // xrLabel35
            // 
            this.xrLabel35.DataBindings.AddRange(new DevExpress.XtraReports.UI.XRBinding[] {
            new DevExpress.XtraReports.UI.XRBinding("Text", null, "tblAccount.BidToOtherDescription", "")});
            this.xrLabel35.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xrLabel35.Location = new System.Drawing.Point(75, 261);
            this.xrLabel35.Name = "xrLabel35";
            this.xrLabel35.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xrLabel35.ParentStyleUsing.UseFont = false;
            this.xrLabel35.Size = new System.Drawing.Size(500, 49);
            this.xrLabel35.Text = "xrLabel26";
            // 
            // xrLabel34
            // 
            this.xrLabel34.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xrLabel34.Location = new System.Drawing.Point(75, 244);
            this.xrLabel34.Name = "xrLabel34";
            this.xrLabel34.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xrLabel34.ParentStyleUsing.UseFont = false;
            this.xrLabel34.Size = new System.Drawing.Size(83, 17);
            this.xrLabel34.Text = "Description:";
            this.xrLabel34.WordWrap = false;
            // 
            // xrLabel47
            // 
            this.xrLabel47.DataBindings.AddRange(new DevExpress.XtraReports.UI.XRBinding[] {
            new DevExpress.XtraReports.UI.XRBinding("Text", null, "tblAccount.NextActionDate", "{0:MM/dd/yyyy}")});
            this.xrLabel47.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xrLabel47.Location = new System.Drawing.Point(435, 158);
            this.xrLabel47.Name = "xrLabel47";
            this.xrLabel47.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xrLabel47.ParentStyleUsing.UseFont = false;
            this.xrLabel47.Size = new System.Drawing.Size(83, 17);
            this.xrLabel47.Text = "xrLabel47";
            this.xrLabel47.WordWrap = false;
            // 
            // xrLabel67
            // 
            this.xrLabel67.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xrLabel67.Location = new System.Drawing.Point(336, 158);
            this.xrLabel67.Name = "xrLabel67";
            this.xrLabel67.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xrLabel67.ParentStyleUsing.UseFont = false;
            this.xrLabel67.Size = new System.Drawing.Size(98, 17);
            this.xrLabel67.Text = "Other Action Date:";
            this.xrLabel67.WordWrap = false;
            // 
            // xrLabel66
            // 
            this.xrLabel66.DataBindings.AddRange(new DevExpress.XtraReports.UI.XRBinding[] {
            new DevExpress.XtraReports.UI.XRBinding("Text", null, "tblAccount.CCERepForBidWalk", "")});
            this.xrLabel66.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xrLabel66.Location = new System.Drawing.Point(192, 158);
            this.xrLabel66.Name = "xrLabel66";
            this.xrLabel66.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xrLabel66.ParentStyleUsing.UseFont = false;
            this.xrLabel66.Size = new System.Drawing.Size(142, 17);
            this.xrLabel66.Text = "xrLabel66";
            this.xrLabel66.WordWrap = false;
            // 
            // xrLabel65
            // 
            this.xrLabel65.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xrLabel65.Location = new System.Drawing.Point(75, 158);
            this.xrLabel65.Name = "xrLabel65";
            this.xrLabel65.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xrLabel65.ParentStyleUsing.UseFont = false;
            this.xrLabel65.Size = new System.Drawing.Size(117, 17);
            this.xrLabel65.Text = "CCE Rep for Walk:";
            this.xrLabel65.WordWrap = false;
            // 
            // xrLabel64
            // 
            this.xrLabel64.DataBindings.AddRange(new DevExpress.XtraReports.UI.XRBinding[] {
            new DevExpress.XtraReports.UI.XRBinding("Text", null, "tblAccount.NextActionNeeded", "")});
            this.xrLabel64.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xrLabel64.Location = new System.Drawing.Point(635, 158);
            this.xrLabel64.Name = "xrLabel64";
            this.xrLabel64.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xrLabel64.ParentStyleUsing.UseFont = false;
            this.xrLabel64.Size = new System.Drawing.Size(162, 17);
            this.xrLabel64.Text = "xrLabel64";
            this.xrLabel64.WordWrap = false;
            // 
            // xrLabel63
            // 
            this.xrLabel63.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xrLabel63.Location = new System.Drawing.Point(521, 158);
            this.xrLabel63.Name = "xrLabel63";
            this.xrLabel63.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xrLabel63.ParentStyleUsing.UseFont = false;
            this.xrLabel63.Size = new System.Drawing.Size(112, 17);
            this.xrLabel63.Text = "Other Action Needed:";
            this.xrLabel63.WordWrap = false;
            // 
            // xrCheckBox10
            // 
            this.xrCheckBox10.DataBindings.AddRange(new DevExpress.XtraReports.UI.XRBinding[] {
            new DevExpress.XtraReports.UI.XRBinding("CheckState", null, "tblAccount.PPBRequired", "")});
            this.xrCheckBox10.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xrCheckBox10.Location = new System.Drawing.Point(781, 125);
            this.xrCheckBox10.Name = "xrCheckBox10";
            this.xrCheckBox10.ParentStyleUsing.UseFont = false;
            this.xrCheckBox10.Size = new System.Drawing.Size(19, 17);
            this.xrCheckBox10.WordWrap = false;
            // 
            // xrLabel62
            // 
            this.xrLabel62.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xrLabel62.Location = new System.Drawing.Point(714, 125);
            this.xrLabel62.Name = "xrLabel62";
            this.xrLabel62.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xrLabel62.ParentStyleUsing.UseFont = false;
            this.xrLabel62.Size = new System.Drawing.Size(70, 17);
            this.xrLabel62.Text = "P&PB Req\'d?";
            this.xrLabel62.WordWrap = false;
            // 
            // xrLabel61
            // 
            this.xrLabel61.DataBindings.AddRange(new DevExpress.XtraReports.UI.XRBinding[] {
            new DevExpress.XtraReports.UI.XRBinding("Text", null, "tblAccount.BidWalkTime", "")});
            this.xrLabel61.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xrLabel61.Location = new System.Drawing.Point(293, 142);
            this.xrLabel61.Name = "xrLabel61";
            this.xrLabel61.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xrLabel61.ParentStyleUsing.UseFont = false;
            this.xrLabel61.Size = new System.Drawing.Size(75, 17);
            this.xrLabel61.Text = "xrLabel61";
            this.xrLabel61.WordWrap = false;
            // 
            // xrLabel49
            // 
            this.xrLabel49.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xrLabel49.Location = new System.Drawing.Point(210, 142);
            this.xrLabel49.Name = "xrLabel49";
            this.xrLabel49.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xrLabel49.ParentStyleUsing.UseFont = false;
            this.xrLabel49.Size = new System.Drawing.Size(83, 17);
            this.xrLabel49.Text = "Bid Walk Time:";
            this.xrLabel49.WordWrap = false;
            // 
            // xrCheckBox9
            // 
            this.xrCheckBox9.DataBindings.AddRange(new DevExpress.XtraReports.UI.XRBinding[] {
            new DevExpress.XtraReports.UI.XRBinding("CheckState", null, "tblAccount.BidBondRequired", "")});
            this.xrCheckBox9.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xrCheckBox9.Location = new System.Drawing.Point(688, 125);
            this.xrCheckBox9.Name = "xrCheckBox9";
            this.xrCheckBox9.ParentStyleUsing.UseFont = false;
            this.xrCheckBox9.Size = new System.Drawing.Size(25, 17);
            this.xrCheckBox9.WordWrap = false;
            // 
            // xrLabel45
            // 
            this.xrLabel45.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xrLabel45.Location = new System.Drawing.Point(603, 125);
            this.xrLabel45.Name = "xrLabel45";
            this.xrLabel45.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xrLabel45.ParentStyleUsing.UseFont = false;
            this.xrLabel45.Size = new System.Drawing.Size(89, 17);
            this.xrLabel45.Text = "Bid Bond Req\'d?";
            this.xrLabel45.WordWrap = false;
            // 
            // xrLabel29
            // 
            this.xrLabel29.CanShrink = true;
            this.xrLabel29.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xrLabel29.Location = new System.Drawing.Point(0, 492);
            this.xrLabel29.Multiline = true;
            this.xrLabel29.Name = "xrLabel29";
            this.xrLabel29.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xrLabel29.ParentStyleUsing.UseFont = false;
            this.xrLabel29.Size = new System.Drawing.Size(42, 33);
            this.xrLabel29.Text = "Detail";
            // 
            // xrCheckBox7
            // 
            this.xrCheckBox7.DataBindings.AddRange(new DevExpress.XtraReports.UI.XRBinding[] {
            new DevExpress.XtraReports.UI.XRBinding("CheckState", null, "tblAccount.BiddingAsSub", "")});
            this.xrCheckBox7.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xrCheckBox7.Location = new System.Drawing.Point(577, 125);
            this.xrCheckBox7.Name = "xrCheckBox7";
            this.xrCheckBox7.ParentStyleUsing.UseFont = false;
            this.xrCheckBox7.Size = new System.Drawing.Size(25, 17);
            this.xrCheckBox7.WordWrap = false;
            // 
            // xrLabel22
            // 
            this.xrLabel22.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xrLabel22.Location = new System.Drawing.Point(492, 125);
            this.xrLabel22.Name = "xrLabel22";
            this.xrLabel22.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xrLabel22.ParentStyleUsing.UseFont = false;
            this.xrLabel22.Size = new System.Drawing.Size(83, 17);
            this.xrLabel22.Text = "Bidding as Sub:";
            this.xrLabel22.WordWrap = false;
            // 
            // xrCheckBox6
            // 
            this.xrCheckBox6.DataBindings.AddRange(new DevExpress.XtraReports.UI.XRBinding[] {
            new DevExpress.XtraReports.UI.XRBinding("CheckState", null, "tblAccount.BiddingAsPrime", "")});
            this.xrCheckBox6.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xrCheckBox6.Location = new System.Drawing.Point(464, 125);
            this.xrCheckBox6.Name = "xrCheckBox6";
            this.xrCheckBox6.ParentStyleUsing.UseFont = false;
            this.xrCheckBox6.Size = new System.Drawing.Size(25, 17);
            this.xrCheckBox6.WordWrap = false;
            // 
            // xrLabel21
            // 
            this.xrLabel21.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xrLabel21.Location = new System.Drawing.Point(374, 125);
            this.xrLabel21.Name = "xrLabel21";
            this.xrLabel21.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xrLabel21.ParentStyleUsing.UseFont = false;
            this.xrLabel21.Size = new System.Drawing.Size(92, 17);
            this.xrLabel21.Text = "Bidding as Prime:";
            this.xrLabel21.WordWrap = false;
            // 
            // xrLabel60
            // 
            this.xrLabel60.DataBindings.AddRange(new DevExpress.XtraReports.UI.XRBinding[] {
            new DevExpress.XtraReports.UI.XRBinding("Text", null, "tblAccount.BidWalkDate", "{0:MM/dd/yyyy}")});
            this.xrLabel60.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xrLabel60.Location = new System.Drawing.Point(293, 125);
            this.xrLabel60.Name = "xrLabel60";
            this.xrLabel60.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xrLabel60.ParentStyleUsing.UseFont = false;
            this.xrLabel60.Size = new System.Drawing.Size(75, 17);
            this.xrLabel60.Text = "xrLabel60";
            this.xrLabel60.WordWrap = false;
            // 
            // xrLabel59
            // 
            this.xrLabel59.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xrLabel59.Location = new System.Drawing.Point(210, 125);
            this.xrLabel59.Name = "xrLabel59";
            this.xrLabel59.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xrLabel59.ParentStyleUsing.UseFont = false;
            this.xrLabel59.Size = new System.Drawing.Size(83, 17);
            this.xrLabel59.Text = "Bid Walk Date:";
            this.xrLabel59.WordWrap = false;
            // 
            // xrLabel58
            // 
            this.xrLabel58.DataBindings.AddRange(new DevExpress.XtraReports.UI.XRBinding[] {
            new DevExpress.XtraReports.UI.XRBinding("Text", null, "tblAccount.OTProjectZip", "")});
            this.xrLabel58.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xrLabel58.Location = new System.Drawing.Point(417, 77);
            this.xrLabel58.Name = "xrLabel58";
            this.xrLabel58.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xrLabel58.ParentStyleUsing.UseFont = false;
            this.xrLabel58.Size = new System.Drawing.Size(58, 17);
            this.xrLabel58.Text = "xrLabel58";
            this.xrLabel58.WordWrap = false;
            // 
            // xrLabel33
            // 
            this.xrLabel33.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xrLabel33.Location = new System.Drawing.Point(385, 77);
            this.xrLabel33.Name = "xrLabel33";
            this.xrLabel33.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xrLabel33.ParentStyleUsing.UseFont = false;
            this.xrLabel33.Size = new System.Drawing.Size(25, 17);
            this.xrLabel33.Text = "Zip:";
            this.xrLabel33.WordWrap = false;
            // 
            // xrLabel32
            // 
            this.xrLabel32.DataBindings.AddRange(new DevExpress.XtraReports.UI.XRBinding[] {
            new DevExpress.XtraReports.UI.XRBinding("Text", null, "tblAccount.OTProjectState", "")});
            this.xrLabel32.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xrLabel32.Location = new System.Drawing.Point(350, 77);
            this.xrLabel32.Name = "xrLabel32";
            this.xrLabel32.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xrLabel32.ParentStyleUsing.UseFont = false;
            this.xrLabel32.Size = new System.Drawing.Size(33, 17);
            this.xrLabel32.Text = "xrLabel32";
            this.xrLabel32.WordWrap = false;
            // 
            // xrLabel28
            // 
            this.xrLabel28.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xrLabel28.Location = new System.Drawing.Point(312, 77);
            this.xrLabel28.Name = "xrLabel28";
            this.xrLabel28.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xrLabel28.ParentStyleUsing.UseFont = false;
            this.xrLabel28.Size = new System.Drawing.Size(33, 17);
            this.xrLabel28.Text = "State:";
            this.xrLabel28.WordWrap = false;
            // 
            // xrLabel27
            // 
            this.xrLabel27.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xrLabel27.Location = new System.Drawing.Point(350, 42);
            this.xrLabel27.Name = "xrLabel27";
            this.xrLabel27.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xrLabel27.ParentStyleUsing.UseFont = false;
            this.xrLabel27.Size = new System.Drawing.Size(67, 17);
            this.xrLabel27.Text = "Status Date:";
            this.xrLabel27.WordWrap = false;
            // 
            // xrLabel26
            // 
            this.xrLabel26.DataBindings.AddRange(new DevExpress.XtraReports.UI.XRBinding[] {
            new DevExpress.XtraReports.UI.XRBinding("Text", null, "tblAccount.BidToOtherDescription", "")});
            this.xrLabel26.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xrLabel26.Location = new System.Drawing.Point(533, 225);
            this.xrLabel26.Name = "xrLabel26";
            this.xrLabel26.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xrLabel26.ParentStyleUsing.UseFont = false;
            this.xrLabel26.Size = new System.Drawing.Size(192, 17);
            this.xrLabel26.Text = "xrLabel26";
            this.xrLabel26.WordWrap = false;
            // 
            // xrCheckBox4
            // 
            this.xrCheckBox4.DataBindings.AddRange(new DevExpress.XtraReports.UI.XRBinding[] {
            new DevExpress.XtraReports.UI.XRBinding("CheckState", null, "tblAccount.BidToOther", "")});
            this.xrCheckBox4.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xrCheckBox4.Location = new System.Drawing.Point(508, 225);
            this.xrCheckBox4.Name = "xrCheckBox4";
            this.xrCheckBox4.ParentStyleUsing.UseFont = false;
            this.xrCheckBox4.Size = new System.Drawing.Size(25, 17);
            this.xrCheckBox4.WordWrap = false;
            // 
            // xrLabel24
            // 
            this.xrLabel24.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xrLabel24.Location = new System.Drawing.Point(458, 225);
            this.xrLabel24.Name = "xrLabel24";
            this.xrLabel24.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xrLabel24.ParentStyleUsing.UseFont = false;
            this.xrLabel24.Size = new System.Drawing.Size(42, 17);
            this.xrLabel24.Text = "Other:";
            this.xrLabel24.WordWrap = false;
            // 
            // xrCheckBox3
            // 
            this.xrCheckBox3.DataBindings.AddRange(new DevExpress.XtraReports.UI.XRBinding[] {
            new DevExpress.XtraReports.UI.XRBinding("CheckState", null, "tblAccount.BidToDeveloper", "")});
            this.xrCheckBox3.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xrCheckBox3.Location = new System.Drawing.Point(425, 225);
            this.xrCheckBox3.Name = "xrCheckBox3";
            this.xrCheckBox3.ParentStyleUsing.UseFont = false;
            this.xrCheckBox3.Size = new System.Drawing.Size(25, 17);
            this.xrCheckBox3.WordWrap = false;
            // 
            // xrLabel20
            // 
            this.xrLabel20.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xrLabel20.Location = new System.Drawing.Point(351, 225);
            this.xrLabel20.Name = "xrLabel20";
            this.xrLabel20.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xrLabel20.ParentStyleUsing.UseFont = false;
            this.xrLabel20.Size = new System.Drawing.Size(67, 17);
            this.xrLabel20.Text = "Developer:";
            this.xrLabel20.WordWrap = false;
            // 
            // xrCheckBox2
            // 
            this.xrCheckBox2.DataBindings.AddRange(new DevExpress.XtraReports.UI.XRBinding[] {
            new DevExpress.XtraReports.UI.XRBinding("CheckState", null, "tblAccount.BidToContractor", "")});
            this.xrCheckBox2.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xrCheckBox2.Location = new System.Drawing.Point(317, 225);
            this.xrCheckBox2.Name = "xrCheckBox2";
            this.xrCheckBox2.ParentStyleUsing.UseFont = false;
            this.xrCheckBox2.Size = new System.Drawing.Size(25, 17);
            this.xrCheckBox2.WordWrap = false;
            // 
            // xrLabel19
            // 
            this.xrLabel19.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xrLabel19.Location = new System.Drawing.Point(200, 225);
            this.xrLabel19.Name = "xrLabel19";
            this.xrLabel19.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xrLabel19.ParentStyleUsing.UseFont = false;
            this.xrLabel19.Size = new System.Drawing.Size(117, 17);
            this.xrLabel19.Text = "General Contractors:";
            this.xrLabel19.WordWrap = false;
            // 
            // xrLabel1
            // 
            this.xrLabel1.CanShrink = true;
            this.xrLabel1.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xrLabel1.Location = new System.Drawing.Point(0, 0);
            this.xrLabel1.Multiline = true;
            this.xrLabel1.Name = "xrLabel1";
            this.xrLabel1.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xrLabel1.ParentStyleUsing.UseFont = false;
            this.xrLabel1.Size = new System.Drawing.Size(42, 33);
            this.xrLabel1.Text = "Info.";
            // 
            // xrLabel13
            // 
            this.xrLabel13.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xrLabel13.Location = new System.Drawing.Point(75, 42);
            this.xrLabel13.Name = "xrLabel13";
            this.xrLabel13.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xrLabel13.ParentStyleUsing.UseFont = false;
            this.xrLabel13.Size = new System.Drawing.Size(117, 17);
            this.xrLabel13.Text = "Name:";
            this.xrLabel13.WordWrap = false;
            // 
            // xrLabel14
            // 
            this.xrLabel14.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xrLabel14.Location = new System.Drawing.Point(496, 42);
            this.xrLabel14.Name = "xrLabel14";
            this.xrLabel14.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xrLabel14.ParentStyleUsing.UseFont = false;
            this.xrLabel14.Size = new System.Drawing.Size(117, 17);
            this.xrLabel14.Text = "Project Status:";
            this.xrLabel14.WordWrap = false;
            // 
            // xrLabel15
            // 
            this.xrLabel15.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xrLabel15.Location = new System.Drawing.Point(75, 59);
            this.xrLabel15.Name = "xrLabel15";
            this.xrLabel15.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xrLabel15.ParentStyleUsing.UseFont = false;
            this.xrLabel15.Size = new System.Drawing.Size(117, 17);
            this.xrLabel15.Text = "Address:";
            this.xrLabel15.WordWrap = false;
            // 
            // xrLine4
            // 
            this.xrLine4.Location = new System.Drawing.Point(0, 475);
            this.xrLine4.Name = "xrLine4";
            this.xrLine4.Size = new System.Drawing.Size(800, 8);
            // 
            // xrLabel142
            // 
            this.xrLabel142.DataBindings.AddRange(new DevExpress.XtraReports.UI.XRBinding[] {
            new DevExpress.XtraReports.UI.XRBinding("Text", null, "tblAccount.OTProjectName", "")});
            this.xrLabel142.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xrLabel142.Location = new System.Drawing.Point(192, 42);
            this.xrLabel142.Name = "xrLabel142";
            this.xrLabel142.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xrLabel142.ParentStyleUsing.UseFont = false;
            this.xrLabel142.Size = new System.Drawing.Size(158, 15);
            this.xrLabel142.Text = "xrLabel142";
            this.xrLabel142.WordWrap = false;
            // 
            // xrLabel143
            // 
            this.xrLabel143.DataBindings.AddRange(new DevExpress.XtraReports.UI.XRBinding[] {
            new DevExpress.XtraReports.UI.XRBinding("Text", null, "tblAccount.OTStatusDescription", "")});
            this.xrLabel143.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xrLabel143.Location = new System.Drawing.Point(615, 42);
            this.xrLabel143.Name = "xrLabel143";
            this.xrLabel143.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xrLabel143.ParentStyleUsing.UseFont = false;
            this.xrLabel143.Size = new System.Drawing.Size(124, 17);
            this.xrLabel143.Text = "xrLabel143";
            this.xrLabel143.WordWrap = false;
            // 
            // xrLabel146
            // 
            this.xrLabel146.DataBindings.AddRange(new DevExpress.XtraReports.UI.XRBinding[] {
            new DevExpress.XtraReports.UI.XRBinding("Text", null, "tblAccount.OTProjectAddress", "")});
            this.xrLabel146.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xrLabel146.Location = new System.Drawing.Point(192, 59);
            this.xrLabel146.Name = "xrLabel146";
            this.xrLabel146.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xrLabel146.ParentStyleUsing.UseFont = false;
            this.xrLabel146.Size = new System.Drawing.Size(175, 17);
            this.xrLabel146.Text = "xrLabel146";
            this.xrLabel146.WordWrap = false;
            // 
            // xrLine2
            // 
            this.xrLine2.LineDirection = DevExpress.XtraReports.UI.LineDirection.Vertical;
            this.xrLine2.Location = new System.Drawing.Point(67, 0);
            this.xrLine2.Name = "xrLine2";
            this.xrLine2.Size = new System.Drawing.Size(2, 900);
            // 
            // xrLabel2
            // 
            this.xrLabel2.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xrLabel2.Location = new System.Drawing.Point(497, 59);
            this.xrLabel2.Name = "xrLabel2";
            this.xrLabel2.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xrLabel2.ParentStyleUsing.UseFont = false;
            this.xrLabel2.Size = new System.Drawing.Size(117, 17);
            this.xrLabel2.Text = "Work Type:";
            this.xrLabel2.WordWrap = false;
            // 
            // xrLabel4
            // 
            this.xrLabel4.DataBindings.AddRange(new DevExpress.XtraReports.UI.XRBinding[] {
            new DevExpress.XtraReports.UI.XRBinding("Text", null, "tblAccount.WorkType", "")});
            this.xrLabel4.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xrLabel4.Location = new System.Drawing.Point(615, 59);
            this.xrLabel4.Name = "xrLabel4";
            this.xrLabel4.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xrLabel4.ParentStyleUsing.UseFont = false;
            this.xrLabel4.Size = new System.Drawing.Size(124, 17);
            this.xrLabel4.Text = "xrLabel4";
            this.xrLabel4.WordWrap = false;
            // 
            // xrLabel3
            // 
            this.xrLabel3.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xrLabel3.Location = new System.Drawing.Point(75, 77);
            this.xrLabel3.Name = "xrLabel3";
            this.xrLabel3.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xrLabel3.ParentStyleUsing.UseFont = false;
            this.xrLabel3.Size = new System.Drawing.Size(117, 17);
            this.xrLabel3.Text = "City:";
            this.xrLabel3.WordWrap = false;
            // 
            // xrLabel5
            // 
            this.xrLabel5.DataBindings.AddRange(new DevExpress.XtraReports.UI.XRBinding[] {
            new DevExpress.XtraReports.UI.XRBinding("Text", null, "tblAccount.OTProjectCity", "")});
            this.xrLabel5.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xrLabel5.Location = new System.Drawing.Point(192, 77);
            this.xrLabel5.Name = "xrLabel5";
            this.xrLabel5.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xrLabel5.ParentStyleUsing.UseFont = false;
            this.xrLabel5.Size = new System.Drawing.Size(117, 17);
            this.xrLabel5.Text = "xrLabel5";
            this.xrLabel5.WordWrap = false;
            // 
            // xrLabel6
            // 
            this.xrLabel6.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xrLabel6.Location = new System.Drawing.Point(497, 77);
            this.xrLabel6.Name = "xrLabel6";
            this.xrLabel6.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xrLabel6.ParentStyleUsing.UseFont = false;
            this.xrLabel6.Size = new System.Drawing.Size(117, 17);
            this.xrLabel6.Text = "Office Bidding:";
            this.xrLabel6.WordWrap = false;
            // 
            // xrLabel8
            // 
            this.xrLabel8.DataBindings.AddRange(new DevExpress.XtraReports.UI.XRBinding[] {
            new DevExpress.XtraReports.UI.XRBinding("Text", null, "tblAccount.OfficeName", "")});
            this.xrLabel8.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xrLabel8.Location = new System.Drawing.Point(615, 77);
            this.xrLabel8.Name = "xrLabel8";
            this.xrLabel8.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xrLabel8.ParentStyleUsing.UseFont = false;
            this.xrLabel8.Size = new System.Drawing.Size(124, 17);
            this.xrLabel8.Text = "xrLabel8";
            this.xrLabel8.WordWrap = false;
            // 
            // xrLabel9
            // 
            this.xrLabel9.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xrLabel9.Location = new System.Drawing.Point(75, 94);
            this.xrLabel9.Name = "xrLabel9";
            this.xrLabel9.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xrLabel9.ParentStyleUsing.UseFont = false;
            this.xrLabel9.Size = new System.Drawing.Size(117, 17);
            this.xrLabel9.Text = "Web Site";
            this.xrLabel9.WordWrap = false;
            // 
            // xrLabel10
            // 
            this.xrLabel10.DataBindings.AddRange(new DevExpress.XtraReports.UI.XRBinding[] {
            new DevExpress.XtraReports.UI.XRBinding("Text", null, "tblAccount.Website", "")});
            this.xrLabel10.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xrLabel10.Location = new System.Drawing.Point(192, 94);
            this.xrLabel10.Name = "xrLabel10";
            this.xrLabel10.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xrLabel10.ParentStyleUsing.UseFont = false;
            this.xrLabel10.Size = new System.Drawing.Size(283, 17);
            this.xrLabel10.Text = "xrLabel10";
            this.xrLabel10.WordWrap = false;
            // 
            // xrLabel11
            // 
            this.xrLabel11.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xrLabel11.Location = new System.Drawing.Point(497, 94);
            this.xrLabel11.Name = "xrLabel11";
            this.xrLabel11.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xrLabel11.ParentStyleUsing.UseFont = false;
            this.xrLabel11.Size = new System.Drawing.Size(117, 17);
            this.xrLabel11.Text = "Department Bidding:";
            this.xrLabel11.WordWrap = false;
            // 
            // xrLabel16
            // 
            this.xrLabel16.DataBindings.AddRange(new DevExpress.XtraReports.UI.XRBinding[] {
            new DevExpress.XtraReports.UI.XRBinding("Text", null, "tblAccount.DepartmentName", "")});
            this.xrLabel16.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xrLabel16.Location = new System.Drawing.Point(615, 94);
            this.xrLabel16.Name = "xrLabel16";
            this.xrLabel16.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xrLabel16.ParentStyleUsing.UseFont = false;
            this.xrLabel16.Size = new System.Drawing.Size(124, 17);
            this.xrLabel16.Text = "xrLabel16";
            this.xrLabel16.WordWrap = false;
            // 
            // xrLabel17
            // 
            this.xrLabel17.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xrLabel17.Location = new System.Drawing.Point(75, 125);
            this.xrLabel17.Name = "xrLabel17";
            this.xrLabel17.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xrLabel17.ParentStyleUsing.UseFont = false;
            this.xrLabel17.Size = new System.Drawing.Size(58, 17);
            this.xrLabel17.Text = "Bid Date:";
            this.xrLabel17.WordWrap = false;
            // 
            // xrLabel18
            // 
            this.xrLabel18.DataBindings.AddRange(new DevExpress.XtraReports.UI.XRBinding[] {
            new DevExpress.XtraReports.UI.XRBinding("Text", null, "tblAccount.BidDate", "{0:MM/dd/yyyy}")});
            this.xrLabel18.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xrLabel18.Location = new System.Drawing.Point(133, 125);
            this.xrLabel18.Name = "xrLabel18";
            this.xrLabel18.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xrLabel18.ParentStyleUsing.UseFont = false;
            this.xrLabel18.Size = new System.Drawing.Size(75, 17);
            this.xrLabel18.Text = "xrLabel18";
            this.xrLabel18.WordWrap = false;
            // 
            // xrLabel23
            // 
            this.xrLabel23.Font = new System.Drawing.Font("Tahoma", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xrLabel23.Location = new System.Drawing.Point(75, 207);
            this.xrLabel23.Name = "xrLabel23";
            this.xrLabel23.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xrLabel23.ParentStyleUsing.UseFont = false;
            this.xrLabel23.Size = new System.Drawing.Size(117, 17);
            this.xrLabel23.Text = "Bid To";
            this.xrLabel23.WordWrap = false;
            // 
            // xrLabel25
            // 
            this.xrLabel25.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xrLabel25.Location = new System.Drawing.Point(75, 225);
            this.xrLabel25.Name = "xrLabel25";
            this.xrLabel25.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xrLabel25.ParentStyleUsing.UseFont = false;
            this.xrLabel25.Size = new System.Drawing.Size(83, 17);
            this.xrLabel25.Text = "Owner/Direct: ";
            this.xrLabel25.WordWrap = false;
            // 
            // xrLabel30
            // 
            this.xrLabel30.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xrLabel30.Location = new System.Drawing.Point(75, 142);
            this.xrLabel30.Name = "xrLabel30";
            this.xrLabel30.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xrLabel30.ParentStyleUsing.UseFont = false;
            this.xrLabel30.Size = new System.Drawing.Size(58, 17);
            this.xrLabel30.Text = "Bid Time:";
            this.xrLabel30.WordWrap = false;
            // 
            // xrLabel31
            // 
            this.xrLabel31.DataBindings.AddRange(new DevExpress.XtraReports.UI.XRBinding[] {
            new DevExpress.XtraReports.UI.XRBinding("Text", null, "tblAccount.BidTime", "")});
            this.xrLabel31.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xrLabel31.Location = new System.Drawing.Point(133, 142);
            this.xrLabel31.Name = "xrLabel31";
            this.xrLabel31.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xrLabel31.ParentStyleUsing.UseFont = false;
            this.xrLabel31.Size = new System.Drawing.Size(75, 17);
            this.xrLabel31.Text = "xrLabel31";
            this.xrLabel31.WordWrap = false;
            // 
            // xrLabel48
            // 
            this.xrLabel48.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xrLabel48.Location = new System.Drawing.Point(75, 0);
            this.xrLabel48.Name = "xrLabel48";
            this.xrLabel48.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xrLabel48.ParentStyleUsing.UseFont = false;
            this.xrLabel48.Size = new System.Drawing.Size(83, 17);
            this.xrLabel48.Text = "Opportunity #:";
            this.xrLabel48.WordWrap = false;
            // 
            // xrLabel54
            // 
            this.xrLabel54.DataBindings.AddRange(new DevExpress.XtraReports.UI.XRBinding[] {
            new DevExpress.XtraReports.UI.XRBinding("Text", null, "tblAccount.OTProjectNumber", "")});
            this.xrLabel54.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xrLabel54.Location = new System.Drawing.Point(158, 0);
            this.xrLabel54.Name = "xrLabel54";
            this.xrLabel54.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xrLabel54.ParentStyleUsing.UseFont = false;
            this.xrLabel54.Size = new System.Drawing.Size(83, 15);
            this.xrLabel54.Text = "xrLabel54";
            this.xrLabel54.WordWrap = false;
            // 
            // xrLabel55
            // 
            this.xrLabel55.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xrLabel55.Location = new System.Drawing.Point(250, 0);
            this.xrLabel55.Name = "xrLabel55";
            this.xrLabel55.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xrLabel55.ParentStyleUsing.UseFont = false;
            this.xrLabel55.Size = new System.Drawing.Size(67, 17);
            this.xrLabel55.Text = "Estimate #:";
            this.xrLabel55.WordWrap = false;
            // 
            // xrLabel56
            // 
            this.xrLabel56.DataBindings.AddRange(new DevExpress.XtraReports.UI.XRBinding[] {
            new DevExpress.XtraReports.UI.XRBinding("Text", null, "tblAccount.EstimateNumber", "")});
            this.xrLabel56.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xrLabel56.Location = new System.Drawing.Point(317, 0);
            this.xrLabel56.Name = "xrLabel56";
            this.xrLabel56.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xrLabel56.ParentStyleUsing.UseFont = false;
            this.xrLabel56.Size = new System.Drawing.Size(83, 17);
            this.xrLabel56.Text = "xrLabel56";
            this.xrLabel56.WordWrap = false;
            // 
            // xrLabel57
            // 
            this.xrLabel57.Font = new System.Drawing.Font("Tahoma", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xrLabel57.Location = new System.Drawing.Point(75, 25);
            this.xrLabel57.Name = "xrLabel57";
            this.xrLabel57.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xrLabel57.ParentStyleUsing.UseFont = false;
            this.xrLabel57.Size = new System.Drawing.Size(117, 17);
            this.xrLabel57.Text = "Project";
            this.xrLabel57.WordWrap = false;
            // 
            // xrCheckBox1
            // 
            this.xrCheckBox1.DataBindings.AddRange(new DevExpress.XtraReports.UI.XRBinding[] {
            new DevExpress.XtraReports.UI.XRBinding("CheckState", null, "tblAccount.BidToOwner", "")});
            this.xrCheckBox1.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xrCheckBox1.Location = new System.Drawing.Point(167, 225);
            this.xrCheckBox1.Name = "xrCheckBox1";
            this.xrCheckBox1.ParentStyleUsing.UseFont = false;
            this.xrCheckBox1.Size = new System.Drawing.Size(25, 17);
            this.xrCheckBox1.WordWrap = false;
            // 
            // PageHeader
            // 
            this.PageHeader.Controls.AddRange(new DevExpress.XtraReports.UI.XRControl[] {
            this.xrLabel125,
            this.xrPageInfo1,
            this.xrLabel221,
            this.txtPhone,
            this.txtFax,
            this.xrLine1,
            this.logo,
            this.txtCompany,
            this.xrLabel12,
            this.txtAddress});
            this.PageHeader.Name = "PageHeader";
            // 
            // xrLabel125
            // 
            this.xrLabel125.Font = new System.Drawing.Font("Times New Roman", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xrLabel125.ForeColor = System.Drawing.Color.Maroon;
            this.xrLabel125.Location = new System.Drawing.Point(567, 75);
            this.xrLabel125.Multiline = true;
            this.xrLabel125.Name = "xrLabel125";
            this.xrLabel125.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xrLabel125.ParentStyleUsing.UseFont = false;
            this.xrLabel125.ParentStyleUsing.UseForeColor = false;
            this.xrLabel125.Size = new System.Drawing.Size(67, 17);
            this.xrLabel125.Text = "Print Date:";
            this.xrLabel125.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleLeft;
            // 
            // xrPageInfo1
            // 
            this.xrPageInfo1.Font = new System.Drawing.Font("Microsoft Sans Serif", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xrPageInfo1.ForeColor = System.Drawing.Color.Maroon;
            this.xrPageInfo1.Location = new System.Drawing.Point(633, 75);
            this.xrPageInfo1.Name = "xrPageInfo1";
            this.xrPageInfo1.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xrPageInfo1.PageInfo = DevExpress.XtraPrinting.PageInfo.DateTime;
            this.xrPageInfo1.ParentStyleUsing.UseFont = false;
            this.xrPageInfo1.ParentStyleUsing.UseForeColor = false;
            this.xrPageInfo1.Size = new System.Drawing.Size(158, 17);
            this.xrPageInfo1.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleLeft;
            // 
            // xrLabel221
            // 
            this.xrLabel221.Font = new System.Drawing.Font("Times New Roman", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xrLabel221.ForeColor = System.Drawing.Color.Maroon;
            this.xrLabel221.Location = new System.Drawing.Point(617, 8);
            this.xrLabel221.Multiline = true;
            this.xrLabel221.Name = "xrLabel221";
            this.xrLabel221.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xrLabel221.ParentStyleUsing.UseFont = false;
            this.xrLabel221.ParentStyleUsing.UseForeColor = false;
            this.xrLabel221.Size = new System.Drawing.Size(175, 17);
            this.xrLabel221.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleCenter;
            // 
            // txtPhone
            // 
            this.txtPhone.Font = new System.Drawing.Font("Times New Roman", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPhone.ForeColor = System.Drawing.Color.Maroon;
            this.txtPhone.Location = new System.Drawing.Point(617, 25);
            this.txtPhone.Multiline = true;
            this.txtPhone.Name = "txtPhone";
            this.txtPhone.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.txtPhone.ParentStyleUsing.UseFont = false;
            this.txtPhone.ParentStyleUsing.UseForeColor = false;
            this.txtPhone.Size = new System.Drawing.Size(175, 17);
            this.txtPhone.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleCenter;
            // 
            // txtFax
            // 
            this.txtFax.Font = new System.Drawing.Font("Times New Roman", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtFax.ForeColor = System.Drawing.Color.Maroon;
            this.txtFax.Location = new System.Drawing.Point(617, 42);
            this.txtFax.Multiline = true;
            this.txtFax.Name = "txtFax";
            this.txtFax.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.txtFax.ParentStyleUsing.UseFont = false;
            this.txtFax.ParentStyleUsing.UseForeColor = false;
            this.txtFax.Size = new System.Drawing.Size(175, 17);
            this.txtFax.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleCenter;
            // 
            // xrLine1
            // 
            this.xrLine1.Location = new System.Drawing.Point(0, 92);
            this.xrLine1.Name = "xrLine1";
            this.xrLine1.Size = new System.Drawing.Size(800, 8);
            // 
            // logo
            // 
            this.logo.Location = new System.Drawing.Point(0, 0);
            this.logo.Name = "logo";
            this.logo.Size = new System.Drawing.Size(150, 42);
            this.logo.Sizing = DevExpress.XtraPrinting.ImageSizeMode.StretchImage;
            // 
            // txtCompany
            // 
            this.txtCompany.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCompany.ForeColor = System.Drawing.Color.Maroon;
            this.txtCompany.Location = new System.Drawing.Point(0, 8);
            this.txtCompany.Name = "txtCompany";
            this.txtCompany.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.txtCompany.ParentStyleUsing.UseFont = false;
            this.txtCompany.ParentStyleUsing.UseForeColor = false;
            this.txtCompany.Size = new System.Drawing.Size(800, 25);
            this.txtCompany.Text = "CONTRA COSTA ELECTRIC, INC.";
            this.txtCompany.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleCenter;
            // 
            // xrLabel12
            // 
            this.xrLabel12.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xrLabel12.ForeColor = System.Drawing.Color.Maroon;
            this.xrLabel12.Location = new System.Drawing.Point(0, 67);
            this.xrLabel12.Multiline = true;
            this.xrLabel12.Name = "xrLabel12";
            this.xrLabel12.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xrLabel12.ParentStyleUsing.UseFont = false;
            this.xrLabel12.ParentStyleUsing.UseForeColor = false;
            this.xrLabel12.Size = new System.Drawing.Size(800, 25);
            this.xrLabel12.Text = "Project Sheet";
            this.xrLabel12.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleCenter;
            // 
            // txtAddress
            // 
            this.txtAddress.Font = new System.Drawing.Font("Times New Roman", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtAddress.ForeColor = System.Drawing.Color.Maroon;
            this.txtAddress.Location = new System.Drawing.Point(17, 42);
            this.txtAddress.Multiline = true;
            this.txtAddress.Name = "txtAddress";
            this.txtAddress.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.txtAddress.ParentStyleUsing.UseFont = false;
            this.txtAddress.ParentStyleUsing.UseForeColor = false;
            this.txtAddress.Size = new System.Drawing.Size(783, 17);
            this.txtAddress.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleCenter;
            // 
            // PageFooter
            // 
            this.PageFooter.Height = 5;
            this.PageFooter.Name = "PageFooter";
            // 
            // GroupHeader1
            // 
            this.GroupHeader1.GroupFields.AddRange(new DevExpress.XtraReports.UI.GroupField[] {
            new DevExpress.XtraReports.UI.GroupField("JobNumber", DevExpress.XtraReports.UI.XRColumnSortOrder.Ascending)});
            this.GroupHeader1.Height = 0;
            this.GroupHeader1.Name = "GroupHeader1";
            // 
            // rptProjectSheet
            // 
            this.Bands.AddRange(new DevExpress.XtraReports.UI.Band[] {
            this.Detail,
            this.PageHeader,
            this.PageFooter,
            this.GroupHeader1});
            this.Font = new System.Drawing.Font("Times New Roman", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margins = new System.Drawing.Printing.Margins(25, 25, 25, 25);
            ((System.ComponentModel.ISupportInitialize)(this)).EndInit();

        }

        #endregion

        private DevExpress.XtraReports.UI.DetailBand Detail;
        private DevExpress.XtraReports.UI.PageHeaderBand PageHeader;
        private DevExpress.XtraReports.UI.PageFooterBand PageFooter;
        private DevExpress.XtraReports.UI.XRPictureBox logo;
        private DevExpress.XtraReports.UI.XRLabel txtCompany;
        private DevExpress.XtraReports.UI.XRLabel xrLabel12;
        private DevExpress.XtraReports.UI.XRLine xrLine1;
        private DevExpress.XtraReports.UI.XRLabel xrLabel1;
        private DevExpress.XtraReports.UI.XRLabel xrLabel15;
        private DevExpress.XtraReports.UI.XRLabel xrLabel14;
        private DevExpress.XtraReports.UI.XRLabel xrLabel13;
        private DevExpress.XtraReports.UI.XRLine xrLine4;
        private DevExpress.XtraReports.UI.XRLabel xrLabel143;
        private DevExpress.XtraReports.UI.XRLabel xrLabel142;
        private DevExpress.XtraReports.UI.XRLabel xrLabel146;
        private DevExpress.XtraReports.UI.XRLine xrLine2;
        private DevExpress.XtraReports.UI.XRLabel xrLabel221;
        public DevExpress.XtraReports.UI.XRLabel txtPhone;
        public DevExpress.XtraReports.UI.XRLabel txtFax;
        public DevExpress.XtraReports.UI.XRLabel txtAddress;
        private DevExpress.XtraReports.UI.GroupHeaderBand GroupHeader1;
        private DevExpress.XtraReports.UI.XRLabel xrLabel4;
        private DevExpress.XtraReports.UI.XRLabel xrLabel2;
        private DevExpress.XtraReports.UI.XRLabel xrLabel18;
        private DevExpress.XtraReports.UI.XRLabel xrLabel17;
        private DevExpress.XtraReports.UI.XRLabel xrLabel16;
        private DevExpress.XtraReports.UI.XRLabel xrLabel11;
        private DevExpress.XtraReports.UI.XRLabel xrLabel10;
        private DevExpress.XtraReports.UI.XRLabel xrLabel9;
        private DevExpress.XtraReports.UI.XRLabel xrLabel8;
        private DevExpress.XtraReports.UI.XRLabel xrLabel6;
        private DevExpress.XtraReports.UI.XRLabel xrLabel5;
        private DevExpress.XtraReports.UI.XRLabel xrLabel3;
        private DevExpress.XtraReports.UI.XRLabel xrLabel25;
        private DevExpress.XtraReports.UI.XRLabel xrLabel23;
        private DevExpress.XtraReports.UI.XRLabel xrLabel31;
        private DevExpress.XtraReports.UI.XRLabel xrLabel30;
        private DevExpress.XtraReports.UI.XRLabel xrLabel125;
        private DevExpress.XtraReports.UI.XRPageInfo xrPageInfo1;
        private DevExpress.XtraReports.UI.XRLabel xrLabel56;
        private DevExpress.XtraReports.UI.XRLabel xrLabel55;
        private DevExpress.XtraReports.UI.XRLabel xrLabel54;
        private DevExpress.XtraReports.UI.XRLabel xrLabel48;
        private DevExpress.XtraReports.UI.XRLabel xrLabel57;
        private DevExpress.XtraReports.UI.XRCheckBox xrCheckBox3;
        private DevExpress.XtraReports.UI.XRLabel xrLabel20;
        private DevExpress.XtraReports.UI.XRCheckBox xrCheckBox2;
        private DevExpress.XtraReports.UI.XRLabel xrLabel19;
        private DevExpress.XtraReports.UI.XRCheckBox xrCheckBox1;
        private DevExpress.XtraReports.UI.XRLabel xrLabel26;
        private DevExpress.XtraReports.UI.XRCheckBox xrCheckBox4;
        private DevExpress.XtraReports.UI.XRLabel xrLabel24;
        private DevExpress.XtraReports.UI.XRLabel xrLabel32;
        private DevExpress.XtraReports.UI.XRLabel xrLabel28;
        private DevExpress.XtraReports.UI.XRLabel xrLabel27;
        private DevExpress.XtraReports.UI.XRLabel xrLabel59;
        private DevExpress.XtraReports.UI.XRLabel xrLabel58;
        private DevExpress.XtraReports.UI.XRLabel xrLabel33;
        private DevExpress.XtraReports.UI.XRCheckBox xrCheckBox7;
        private DevExpress.XtraReports.UI.XRLabel xrLabel22;
        private DevExpress.XtraReports.UI.XRCheckBox xrCheckBox6;
        private DevExpress.XtraReports.UI.XRLabel xrLabel21;
        private DevExpress.XtraReports.UI.XRLabel xrLabel60;
        private DevExpress.XtraReports.UI.XRLabel xrLabel45;
        private DevExpress.XtraReports.UI.XRLabel xrLabel29;
        private DevExpress.XtraReports.UI.XRLabel xrLabel49;
        private DevExpress.XtraReports.UI.XRCheckBox xrCheckBox9;
        private DevExpress.XtraReports.UI.XRLabel xrLabel64;
        private DevExpress.XtraReports.UI.XRLabel xrLabel63;
        private DevExpress.XtraReports.UI.XRCheckBox xrCheckBox10;
        private DevExpress.XtraReports.UI.XRLabel xrLabel62;
        private DevExpress.XtraReports.UI.XRLabel xrLabel61;
        private DevExpress.XtraReports.UI.XRLabel xrLabel47;
        private DevExpress.XtraReports.UI.XRLabel xrLabel67;
        private DevExpress.XtraReports.UI.XRLabel xrLabel66;
        private DevExpress.XtraReports.UI.XRLabel xrLabel65;
        private DevExpress.XtraReports.UI.XRLabel xrLabel38;
        private DevExpress.XtraReports.UI.XRLabel xrLabel37;
        private DevExpress.XtraReports.UI.XRLabel xrLabel36;
        private DevExpress.XtraReports.UI.XRLabel xrLabel35;
        private DevExpress.XtraReports.UI.XRLabel xrLabel34;
        private DevExpress.XtraReports.UI.XRLabel xrLabel44;
        private DevExpress.XtraReports.UI.XRLabel xrLabel43;
        private DevExpress.XtraReports.UI.XRLabel xrLabel42;
        private DevExpress.XtraReports.UI.XRLabel xrLabel41;
        private DevExpress.XtraReports.UI.XRCheckBox xrCheckBox8;
        private DevExpress.XtraReports.UI.XRLabel xrLabel40;
        private DevExpress.XtraReports.UI.XRLabel xrLabel39;
        private DevExpress.XtraReports.UI.XRLabel xrLabel70;
        private DevExpress.XtraReports.UI.XRLabel xrLabel69;
        private DevExpress.XtraReports.UI.XRLabel xrLabel53;
        private DevExpress.XtraReports.UI.XRLabel xrLabel51;
        private DevExpress.XtraReports.UI.XRLabel xrLabel50;
        private DevExpress.XtraReports.UI.XRLabel xrLabel46;
        private DevExpress.XtraReports.UI.XRLabel xrLabel73;
        private DevExpress.XtraReports.UI.XRLabel xrLabel72;
        private DevExpress.XtraReports.UI.XRLabel xrLabel71;
        private DevExpress.XtraReports.UI.XRCheckBox xrCheckBox21;
        private DevExpress.XtraReports.UI.XRCheckBox xrCheckBox19;
        private DevExpress.XtraReports.UI.XRCheckBox xrCheckBox17;
        private DevExpress.XtraReports.UI.XRCheckBox xrCheckBox16;
        private DevExpress.XtraReports.UI.XRCheckBox xrCheckBox15;
        private DevExpress.XtraReports.UI.XRCheckBox xrCheckBox14;
        private DevExpress.XtraReports.UI.XRCheckBox xrCheckBox13;
        private DevExpress.XtraReports.UI.XRCheckBox xrCheckBox12;
        private DevExpress.XtraReports.UI.XRCheckBox xrCheckBox11;
        private DevExpress.XtraReports.UI.XRLabel xrLabel82;
        private DevExpress.XtraReports.UI.XRLabel xrLabel81;
        private DevExpress.XtraReports.UI.XRLabel xrLabel80;
        private DevExpress.XtraReports.UI.XRLabel xrLabel79;
        private DevExpress.XtraReports.UI.XRLabel xrLabel78;
        private DevExpress.XtraReports.UI.XRLabel xrLabel77;
        private DevExpress.XtraReports.UI.XRLabel xrLabel76;
        private DevExpress.XtraReports.UI.XRLabel xrLabel75;
        private DevExpress.XtraReports.UI.XRLabel xrLabel74;
        private DevExpress.XtraReports.UI.XRCheckBox xrCheckBox25;
        private DevExpress.XtraReports.UI.XRLabel xrLabel86;
        private DevExpress.XtraReports.UI.XRLabel xrLabel85;
        private DevExpress.XtraReports.UI.XRLabel xrLabel84;
        private DevExpress.XtraReports.UI.XRCheckBox xrCheckBox24;
        private DevExpress.XtraReports.UI.XRLabel xrLabel83;
        private DevExpress.XtraReports.UI.XRCheckBox xrCheckBox22;
        private DevExpress.XtraReports.UI.XRLabel xrLabel93;
        private DevExpress.XtraReports.UI.XRLabel xrLabel92;
        private DevExpress.XtraReports.UI.XRLabel xrLabel91;
        private DevExpress.XtraReports.UI.XRLabel xrLabel90;
        private DevExpress.XtraReports.UI.XRLabel xrLabel89;
        private DevExpress.XtraReports.UI.XRLabel xrLabel88;
        private DevExpress.XtraReports.UI.XRLabel xrLabel87;
        private DevExpress.XtraReports.UI.XRLabel xrLabel105;
        private DevExpress.XtraReports.UI.XRLabel xrLabel104;
        private DevExpress.XtraReports.UI.XRLabel xrLabel103;
        private DevExpress.XtraReports.UI.XRLabel xrLabel102;
        private DevExpress.XtraReports.UI.XRLabel xrLabel101;
        private DevExpress.XtraReports.UI.XRLabel xrLabel100;
        private DevExpress.XtraReports.UI.XRLabel xrLabel99;
        private DevExpress.XtraReports.UI.XRLabel xrLabel98;
        private DevExpress.XtraReports.UI.XRLabel xrLabel97;
        private DevExpress.XtraReports.UI.XRLabel xrLabel96;
        private DevExpress.XtraReports.UI.XRLabel xrLabel95;
        private DevExpress.XtraReports.UI.XRLabel xrLabel94;
        private DevExpress.XtraReports.UI.XRLabel xrLabel106;
        private DevExpress.XtraReports.UI.XRLabel xrLabel126;
        private DevExpress.XtraReports.UI.XRLabel xrLabel124;
        private DevExpress.XtraReports.UI.XRLabel xrLabel123;
        private DevExpress.XtraReports.UI.XRLabel xrLabel122;
        private DevExpress.XtraReports.UI.XRLabel xrLabel121;
        private DevExpress.XtraReports.UI.XRLabel xrLabel120;
        private DevExpress.XtraReports.UI.XRLabel xrLabel119;
        private DevExpress.XtraReports.UI.XRLabel xrLabel118;
        private DevExpress.XtraReports.UI.XRLabel xrLabel117;
        private DevExpress.XtraReports.UI.XRLabel xrLabel116;
        private DevExpress.XtraReports.UI.XRLabel xrLabel115;
        private DevExpress.XtraReports.UI.XRLabel xrLabel114;
        private DevExpress.XtraReports.UI.XRLabel xrLabel113;
        private DevExpress.XtraReports.UI.XRLabel xrLabel112;
        private DevExpress.XtraReports.UI.XRLabel xrLabel111;
        private DevExpress.XtraReports.UI.XRLabel xrLabel110;
        private DevExpress.XtraReports.UI.XRLabel xrLabel109;
        private DevExpress.XtraReports.UI.XRLabel xrLabel108;
        private DevExpress.XtraReports.UI.XRLabel xrLabel107;
        private DevExpress.XtraReports.UI.XRLabel xrLabel186;
        private DevExpress.XtraReports.UI.XRLabel xrLabel185;
        private DevExpress.XtraReports.UI.XRLabel xrLabel184;
        private DevExpress.XtraReports.UI.XRLabel xrLabel183;
        private DevExpress.XtraReports.UI.XRLabel xrLabel182;
        private DevExpress.XtraReports.UI.XRLabel xrLabel181;
        private DevExpress.XtraReports.UI.XRLabel xrLabel180;
        private DevExpress.XtraReports.UI.XRLabel xrLabel179;
        private DevExpress.XtraReports.UI.XRLabel xrLabel178;
        private DevExpress.XtraReports.UI.XRLabel xrLabel177;
        private DevExpress.XtraReports.UI.XRLabel xrLabel176;
        private DevExpress.XtraReports.UI.XRLabel xrLabel175;
        private DevExpress.XtraReports.UI.XRLabel xrLabel174;
        private DevExpress.XtraReports.UI.XRLabel xrLabel173;
        private DevExpress.XtraReports.UI.XRLabel xrLabel172;
        private DevExpress.XtraReports.UI.XRLabel xrLabel171;
        private DevExpress.XtraReports.UI.XRLabel xrLabel170;
        private DevExpress.XtraReports.UI.XRLabel xrLabel169;
        private DevExpress.XtraReports.UI.XRLabel xrLabel168;
        private DevExpress.XtraReports.UI.XRLabel xrLabel167;
        private DevExpress.XtraReports.UI.XRLabel xrLabel166;
        private DevExpress.XtraReports.UI.XRLabel xrLabel165;
        private DevExpress.XtraReports.UI.XRLabel xrLabel164;
        private DevExpress.XtraReports.UI.XRLabel xrLabel163;
        private DevExpress.XtraReports.UI.XRLabel xrLabel162;
        private DevExpress.XtraReports.UI.XRLabel xrLabel161;
        private DevExpress.XtraReports.UI.XRLabel xrLabel160;
        private DevExpress.XtraReports.UI.XRLabel xrLabel159;
        private DevExpress.XtraReports.UI.XRLabel xrLabel158;
        private DevExpress.XtraReports.UI.XRLabel xrLabel157;
        private DevExpress.XtraReports.UI.XRLabel xrLabel156;
        private DevExpress.XtraReports.UI.XRLabel xrLabel155;
        private DevExpress.XtraReports.UI.XRLabel xrLabel154;
        private DevExpress.XtraReports.UI.XRLabel xrLabel153;
        private DevExpress.XtraReports.UI.XRLabel xrLabel152;
        private DevExpress.XtraReports.UI.XRLabel xrLabel151;
        private DevExpress.XtraReports.UI.XRLabel xrLabel150;
        private DevExpress.XtraReports.UI.XRLabel xrLabel149;
        private DevExpress.XtraReports.UI.XRLabel xrLabel148;
        private DevExpress.XtraReports.UI.XRLabel xrLabel147;
        private DevExpress.XtraReports.UI.XRLabel xrLabel145;
        private DevExpress.XtraReports.UI.XRLabel xrLabel144;
        private DevExpress.XtraReports.UI.XRLabel xrLabel141;
        private DevExpress.XtraReports.UI.XRLabel xrLabel140;
        private DevExpress.XtraReports.UI.XRLabel xrLabel139;
        private DevExpress.XtraReports.UI.XRLabel xrLabel138;
        private DevExpress.XtraReports.UI.XRLabel xrLabel137;
        private DevExpress.XtraReports.UI.XRLabel xrLabel136;
        private DevExpress.XtraReports.UI.XRLabel xrLabel135;
        private DevExpress.XtraReports.UI.XRLabel xrLabel134;
        private DevExpress.XtraReports.UI.XRLabel xrLabel133;
        private DevExpress.XtraReports.UI.XRLabel xrLabel132;
        private DevExpress.XtraReports.UI.XRLabel xrLabel131;
        private DevExpress.XtraReports.UI.XRLabel xrLabel130;
        private DevExpress.XtraReports.UI.XRLabel xrLabel129;
        private DevExpress.XtraReports.UI.XRLabel xrLabel128;
        private DevExpress.XtraReports.UI.XRLabel xrLabel127;
        private DevExpress.XtraReports.UI.XRLabel xrLabel188;
        private DevExpress.XtraReports.UI.XRLabel xrLabel187;
        private DevExpress.XtraReports.UI.XRLabel xrLabel194;
        private DevExpress.XtraReports.UI.XRLabel xrLabel193;
        private DevExpress.XtraReports.UI.XRLabel xrLabel192;
        private DevExpress.XtraReports.UI.XRLabel xrLabel191;
        private DevExpress.XtraReports.UI.XRLabel xrLabel196;
        private DevExpress.XtraReports.UI.XRLabel xrLabel195;
        private DevExpress.XtraReports.UI.XRLabel xrLabel198;
        private DevExpress.XtraReports.UI.XRLabel xrLabel197;
        private DevExpress.XtraReports.UI.XRLabel xrLabel68;
        private DevExpress.XtraReports.UI.XRLabel xrLabel52;
        private DevExpress.XtraReports.UI.XRLabel xrLabel199;
        private DevExpress.XtraReports.UI.XRLabel xrLabel202;
        private DevExpress.XtraReports.UI.XRLabel xrLabel201;
        private DevExpress.XtraReports.UI.XRCheckBox xrCheckBox18;
        private DevExpress.XtraReports.UI.XRLabel xrLabel200;
        private DevExpress.XtraReports.UI.XRCheckBox xrCheckBox20;
        private DevExpress.XtraReports.UI.XRLabel xrLabel203;
        private DevExpress.XtraReports.UI.XRLabel xrLabel204;
        private DevExpress.XtraReports.UI.XRLabel xrLabel190;
        private DevExpress.XtraReports.UI.XRLabel xrLabel189;
        private DevExpress.XtraReports.UI.XRLabel xrLabel206;
        private DevExpress.XtraReports.UI.XRLabel xrLabel205;
    }
}
